Has filtered some open source or sdk package, include:
1. android.support
https://developer.android.com/topic/libraries/support-library/

2. androidx
https://developer.android.com/topic/libraries/architecture/index

3. com.google.common
https://github.com/google/guava

4. com.google.android.gms
https://developers.google.com/android/guides/setup

5. com.google.android.material
https://material.io/develop/android/docs/getting-started/

6. com.google.firebase
https://firebase.google.com/support/guides/firebase-android

7. com.google.protobuf
https://github.com/protocolbuffers/protobuf

8. kotlin
https://kotlinlang.org/

9. okhttp3
https://github.com/square/okhttp

10. javax
https://docs.oracle.com/javase/7/docs/api/

11. okio
https://github.com/square/okio

12. org.intellij.lang
https://github.com/JetBrains

13. org.jetbrains.annotations
https://github.com/JetBrains/java-annotations

14. org.json
https://github.com/stleary/JSON-java

