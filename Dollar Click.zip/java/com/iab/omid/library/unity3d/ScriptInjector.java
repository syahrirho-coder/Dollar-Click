package com.iab.omid.library.unity3d;

public final class ScriptInjector {
    private ScriptInjector() {
    }

    public static String injectScriptContentIntoHtml(String str, String str2) {
        return c.b(str, str2);
    }
}
