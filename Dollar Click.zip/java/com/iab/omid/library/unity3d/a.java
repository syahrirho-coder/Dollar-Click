package com.iab.omid.library.unity3d;

public final class a {
    public static final Boolean a = Boolean.FALSE;
}
