package com.iab.omid.library.unity3d.adsession;

public enum OutputDeviceStatus {
    NOT_DETECTED,
    UNKNOWN
}
