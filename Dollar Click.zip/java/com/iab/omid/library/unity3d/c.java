package com.iab.omid.library.unity3d;

import com.iab.omid.library.unity3d.utils.g;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

class c {
    private static final Pattern a = Pattern.compile("<(head)( [^>]*)?>", 2);
    private static final Pattern b = Pattern.compile("<(head)( [^>]*)?/>", 2);
    private static final Pattern c = Pattern.compile("<(body)( [^>]*?)?>", 2);
    private static final Pattern d = Pattern.compile("<(body)( [^>]*?)?/>", 2);
    private static final Pattern e = Pattern.compile("<(html)( [^>]*?)?>", 2);
    private static final Pattern f = Pattern.compile("<(html)( [^>]*?)?/>", 2);
    private static final Pattern g = Pattern.compile("<!DOCTYPE [^>]*>", 2);

    static String a(String str, String str2) {
        g.a(str, "HTML is null or empty");
        int[][] a = a(str);
        StringBuilder stringBuilder = new StringBuilder((str.length() + str2.length()) + 16);
        return b(str, stringBuilder, b, str2, a) ? stringBuilder.toString() : a(str, stringBuilder, a, str2, a) ? stringBuilder.toString() : b(str, stringBuilder, d, str2, a) ? stringBuilder.toString() : a(str, stringBuilder, c, str2, a) ? stringBuilder.toString() : b(str, stringBuilder, f, str2, a) ? stringBuilder.toString() : a(str, stringBuilder, e, str2, a) ? stringBuilder.toString() : a(str, stringBuilder, g, str2, a) ? stringBuilder.toString() : str2 + str;
    }

    private static boolean a(int i, int[][] iArr) {
        if (iArr != null) {
            for (int[] iArr2 : iArr) {
                if (i >= iArr2[0] && i <= iArr2[1]) {
                    return true;
                }
            }
        }
        return false;
    }

    private static boolean a(String str, StringBuilder stringBuilder, Pattern pattern, String str2, int[][] iArr) {
        Matcher matcher = pattern.matcher(str);
        int i = 0;
        while (matcher.find(i)) {
            i = matcher.start();
            int end = matcher.end();
            if (a(i, iArr)) {
                i = end;
            } else {
                stringBuilder.append(str.substring(0, matcher.end()));
                stringBuilder.append(str2);
                stringBuilder.append(str.substring(matcher.end()));
                return true;
            }
        }
        return false;
    }

    private static int[][] a(String str) {
        ArrayList arrayList = new ArrayList();
        int length = str.length();
        int i = 0;
        while (i < length) {
            i = str.indexOf("<!--", i);
            if (i >= 0) {
                int indexOf = str.indexOf("-->", i);
                if (indexOf >= 0) {
                    arrayList.add(new int[]{i, indexOf});
                    i = indexOf + 3;
                } else {
                    arrayList.add(new int[]{i, length});
                }
            }
            i = length;
        }
        return (int[][]) arrayList.toArray((int[][]) Array.newInstance(Integer.TYPE, new int[]{2, 0}));
    }

    static String b(String str, String str2) {
        return a(str2, "<script type=\"text/javascript\">" + str + "</script>");
    }

    private static boolean b(String str, StringBuilder stringBuilder, Pattern pattern, String str2, int[][] iArr) {
        Matcher matcher = pattern.matcher(str);
        int i = 0;
        while (matcher.find(i)) {
            i = matcher.start();
            int end = matcher.end();
            if (a(i, iArr)) {
                i = end;
            } else {
                stringBuilder.append(str.substring(0, matcher.end() - 2));
                String str3 = ">";
                stringBuilder.append(str3);
                stringBuilder.append(str2);
                stringBuilder.append("</");
                stringBuilder.append(matcher.group(1));
                stringBuilder.append(str3);
                stringBuilder.append(str.substring(matcher.end()));
                return true;
            }
        }
        return false;
    }
}
