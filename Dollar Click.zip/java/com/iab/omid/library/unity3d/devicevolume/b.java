package com.iab.omid.library.unity3d.devicevolume;

public class b {
    public a a() {
        return new a();
    }
}
