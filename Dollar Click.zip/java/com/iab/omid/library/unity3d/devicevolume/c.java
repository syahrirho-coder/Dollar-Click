package com.iab.omid.library.unity3d.devicevolume;

public interface c {
    void a(float f);
}
