package com.iab.omid.library.unity3d.internal;

import android.content.Context;
import com.iab.omid.library.unity3d.utils.f;
import java.util.Date;

public class a implements com.iab.omid.library.unity3d.internal.d.a {
    private static a f = new a(new d());
    protected f a = new f();
    private Date b;
    private boolean c;
    private d d;
    private boolean e;

    private a(d dVar) {
        this.d = dVar;
    }

    public static a a() {
        return f;
    }

    private void c() {
        if (this.c && this.b != null) {
            for (com.iab.omid.library.unity3d.adsession.a adSessionStatePublisher : c.c().a()) {
                adSessionStatePublisher.getAdSessionStatePublisher().a(b());
            }
        }
    }

    public void a(Context context) {
        if (!this.c) {
            this.d.a(context);
            this.d.a((com.iab.omid.library.unity3d.internal.d.a) this);
            this.d.e();
            this.e = this.d.c();
            this.c = true;
        }
    }

    public void a(boolean z) {
        if (!this.e && z) {
            d();
        }
        this.e = z;
    }

    public Date b() {
        Date date = this.b;
        return date != null ? (Date) date.clone() : null;
    }

    public void d() {
        Date a = this.a.a();
        Date date = this.b;
        if (date == null || a.after(date)) {
            this.b = a;
            c();
        }
    }
}
