package com.iab.omid.library.unity3d.internal;

import android.content.Context;
import android.os.Handler;
import com.iab.omid.library.unity3d.devicevolume.b;
import com.iab.omid.library.unity3d.devicevolume.c;
import com.iab.omid.library.unity3d.devicevolume.d;
import com.iab.omid.library.unity3d.devicevolume.e;
import com.iab.omid.library.unity3d.internal.d.a;
import com.iab.omid.library.unity3d.walking.TreeWalker;

public class h implements a, c {
    private static h f;
    private float a = 0.0f;
    private final e b;
    private final b c;
    private d d;
    private c e;

    public h(e eVar, b bVar) {
        this.b = eVar;
        this.c = bVar;
    }

    private c a() {
        if (this.e == null) {
            this.e = c.c();
        }
        return this.e;
    }

    public static h c() {
        if (f == null) {
            f = new h(new e(), new b());
        }
        return f;
    }

    public void a(float f) {
        this.a = f;
        for (com.iab.omid.library.unity3d.adsession.a adSessionStatePublisher : a().a()) {
            adSessionStatePublisher.getAdSessionStatePublisher().a(f);
        }
    }

    public void a(Context context) {
        this.d = this.b.a(new Handler(), context, this.c.a(), this);
    }

    public void a(boolean z) {
        if (z) {
            TreeWalker.getInstance().h();
        } else {
            TreeWalker.getInstance().g();
        }
    }

    public float b() {
        return this.a;
    }

    public void d() {
        b.g().a((a) this);
        b.g().e();
        TreeWalker.getInstance().h();
        this.d.c();
    }

    public void e() {
        TreeWalker.getInstance().j();
        b.g().f();
        this.d.d();
    }
}
