package com.iab.omid.library.unity3d.processor;

public class b {
    private final d a;
    private final c b;

    public b() {
        a dVar = new d();
        this.a = dVar;
        this.b = new c(dVar);
    }

    public a a() {
        return this.b;
    }

    public a b() {
        return this.a;
    }
}
