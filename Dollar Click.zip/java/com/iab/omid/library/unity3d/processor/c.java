package com.iab.omid.library.unity3d.processor;

import android.view.View;
import com.iab.omid.library.unity3d.adsession.a;
import com.iab.omid.library.unity3d.utils.e;
import com.iab.omid.library.unity3d.utils.h;
import java.util.ArrayList;
import java.util.Collection;
import java.util.IdentityHashMap;
import java.util.Iterator;
import org.json.JSONObject;

public class c implements a {
    private final a a;

    public c(a aVar) {
        this.a = aVar;
    }

    ArrayList<View> a() {
        ArrayList<View> arrayList = new ArrayList();
        com.iab.omid.library.unity3d.internal.c c = com.iab.omid.library.unity3d.internal.c.c();
        if (c != null) {
            Collection<a> a = c.a();
            IdentityHashMap identityHashMap = new IdentityHashMap((a.size() * 2) + 3);
            for (a c2 : a) {
                View c3 = c2.c();
                if (c3 != null && h.e(c3)) {
                    c3 = c3.getRootView();
                    if (!(c3 == null || identityHashMap.containsKey(c3))) {
                        identityHashMap.put(c3, c3);
                        float c4 = h.c(c3);
                        int size = arrayList.size();
                        while (size > 0 && h.c((View) arrayList.get(size - 1)) > c4) {
                            size--;
                        }
                        arrayList.add(size, c3);
                    }
                }
            }
        }
        return arrayList;
    }

    public JSONObject a(View view) {
        JSONObject a = com.iab.omid.library.unity3d.utils.c.a(0, 0, 0, 0);
        com.iab.omid.library.unity3d.utils.c.a(a, e.a());
        return a;
    }

    public void a(View view, JSONObject jSONObject, a.a aVar, boolean z, boolean z2) {
        Iterator it = a().iterator();
        while (it.hasNext()) {
            aVar.a((View) it.next(), this.a, jSONObject, z2);
        }
    }
}
