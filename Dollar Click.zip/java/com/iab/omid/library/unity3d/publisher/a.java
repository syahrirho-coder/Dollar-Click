package com.iab.omid.library.unity3d.publisher;

import android.webkit.WebView;

public class a extends AdSessionStatePublisher {
    public a(String str, WebView webView) {
        super(str);
        if (!(webView == null || webView.getSettings().getJavaScriptEnabled())) {
            webView.getSettings().setJavaScriptEnabled(true);
        }
        a(webView);
    }
}
