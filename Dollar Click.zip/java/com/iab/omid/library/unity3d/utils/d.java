package com.iab.omid.library.unity3d.utils;

import android.text.TextUtils;
import android.util.Log;
import com.iab.omid.library.unity3d.a;

public final class d {
    public static void a(String str) {
        if (a.a.booleanValue() && !TextUtils.isEmpty(str)) {
            Log.i("OMIDLIB", str);
        }
    }

    public static void a(String str, Exception exception) {
        if ((a.a.booleanValue() && !TextUtils.isEmpty(str)) || exception != null) {
            Log.e("OMIDLIB", str, exception);
        }
    }
}
