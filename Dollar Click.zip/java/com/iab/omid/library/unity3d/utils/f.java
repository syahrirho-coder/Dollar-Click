package com.iab.omid.library.unity3d.utils;

import java.util.Date;

public class f {
    public static long b() {
        return System.nanoTime();
    }

    public Date a() {
        return new Date();
    }
}
