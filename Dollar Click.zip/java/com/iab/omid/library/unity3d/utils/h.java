package com.iab.omid.library.unity3d.utils;

import android.view.View;
import android.view.ViewParent;

public final class h {
    public static String a(View view) {
        if (!view.isAttachedToWindow()) {
            return "notAttached";
        }
        int visibility = view.getVisibility();
        return visibility == 8 ? "viewGone" : visibility == 4 ? "viewInvisible" : visibility != 0 ? "viewNotVisible" : view.getAlpha() == 0.0f ? "viewAlphaZero" : null;
    }

    public static View b(View view) {
        ViewParent parent = view.getParent();
        return parent instanceof View ? (View) parent : null;
    }

    public static float c(View view) {
        return view.getZ();
    }

    public static boolean d(View view) {
        return a(view) == null;
    }

    public static boolean e(View view) {
        if (!view.isAttachedToWindow() || !view.isShown()) {
            return false;
        }
        while (view != null) {
            if (view.getAlpha() == 0.0f) {
                return false;
            }
            view = b(view);
        }
        return true;
    }
}
