package com.iab.omid.library.unity3d.walking.async;

import com.iab.omid.library.unity3d.walking.async.b.b;

public class d extends b {
    public d(b bVar) {
        super(bVar);
    }

    /* renamed from: a */
    protected String doInBackground(Object... objArr) {
        this.b.a(null);
        return null;
    }
}
