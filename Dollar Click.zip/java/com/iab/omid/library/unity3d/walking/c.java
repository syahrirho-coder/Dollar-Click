package com.iab.omid.library.unity3d.walking;

public enum c {
    PARENT_VIEW,
    OBSTRUCTION_VIEW,
    UNDERLYING_VIEW
}
