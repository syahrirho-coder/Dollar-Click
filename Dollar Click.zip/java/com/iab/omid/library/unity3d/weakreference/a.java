package com.iab.omid.library.unity3d.weakreference;

import android.view.View;
import java.lang.ref.WeakReference;

public class a extends WeakReference<View> {
    public a(View view) {
        super(view);
    }
}
