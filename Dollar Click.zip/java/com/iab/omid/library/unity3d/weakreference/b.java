package com.iab.omid.library.unity3d.weakreference;

import android.webkit.WebView;
import java.lang.ref.WeakReference;

public class b extends WeakReference<WebView> {
    public b(WebView webView) {
        super(webView);
    }
}
