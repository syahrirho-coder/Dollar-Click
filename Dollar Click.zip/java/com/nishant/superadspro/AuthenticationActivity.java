package com.nishant.superadspro;

import android.app.Dialog;
import android.content.Intent;
import android.content.SharedPreferences.Editor;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import java.util.Objects;

public class AuthenticationActivity extends AppCompatActivity {
    Button btn_BuyKey;
    Button btn_CheckKey;
    Button btn_SkipKey;
    FirebaseDatabase database;
    Dialog progressDialog;
    EditText username_edittext;

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_authentication);
        this.btn_CheckKey = (Button) findViewById(R.id.btn_CheckKey);
        this.btn_BuyKey = (Button) findViewById(R.id.btn_BuyKey);
        this.btn_SkipKey = (Button) findViewById(R.id.btn_SkipKey);
        this.username_edittext = (EditText) findViewById(R.id.username_edittext);
        this.progressDialog = new Dialog(this);
        this.database = FirebaseDatabase.getInstance();
        this.btn_SkipKey.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                Toast.makeText(AuthenticationActivity.this, "Enter Authentication Key 'nishant' & Try App with Developer Ads", 0).show();
            }
        });
        this.btn_CheckKey.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                if (AuthenticationActivity.this.username_edittext.getText().toString().trim().isEmpty()) {
                    Toast.makeText(AuthenticationActivity.this, "Enter Authentication Key", 0).show();
                    return;
                }
                AuthenticationActivity.this.progressDialog();
                AuthenticationActivity.this.database.getReference().child(AuthenticationActivity.this.username_edittext.getText().toString().trim()).child("unity").addListenerForSingleValueEvent(new ValueEventListener() {
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        String str = (String) dataSnapshot.getValue(String.class);
                        if (str == null || str.isEmpty()) {
                            AuthenticationActivity.this.progressDialog.dismiss();
                            Toast.makeText(AuthenticationActivity.this, "Invalid Key", 0).show();
                            return;
                        }
                        AuthenticationActivity.this.progressDialog.dismiss();
                        Editor edit = AuthenticationActivity.this.getSharedPreferences("Dollar", 0).edit();
                        String str2 = "Unity";
                        edit.putString(str2, str);
                        edit.putString("Key", AuthenticationActivity.this.username_edittext.getText().toString().trim());
                        edit.apply();
                        Intent intent = new Intent(AuthenticationActivity.this, DashboardActivity.class);
                        intent.putExtra(str2, str);
                        AuthenticationActivity.this.startActivity(intent);
                        Toast.makeText(AuthenticationActivity.this, "Authentication Successful", 0).show();
                    }

                    public void onCancelled(DatabaseError databaseError) {
                        AuthenticationActivity.this.progressDialog.dismiss();
                        Toast.makeText(AuthenticationActivity.this, "Invalid Key", 0).show();
                    }
                });
            }
        });
        this.btn_BuyKey.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                AuthenticationActivity.this.openLink("https://telegram.me/@nishantsharmaop");
            }
        });
    }

    public void openLink(String str) {
        startActivity(new Intent("android.intent.action.VIEW", Uri.parse(str)));
    }

    public void progressDialog() {
        Dialog dialog = new Dialog(this);
        this.progressDialog = dialog;
        dialog.setContentView(R.layout.progress_dialog);
        this.progressDialog.getWindow().setBackgroundDrawable(getDrawable(R.drawable.app2_background));
        ((Window) Objects.requireNonNull(this.progressDialog.getWindow())).setLayout(-2, -2);
        this.progressDialog.setCancelable(false);
        this.progressDialog.show();
    }
}
