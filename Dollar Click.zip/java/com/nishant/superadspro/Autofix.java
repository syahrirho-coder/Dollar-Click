package com.nishant.superadspro;

import android.app.Notification.Builder;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build.VERSION;
import android.os.Handler;
import android.util.Log;
import android.widget.Toast;
import androidx.constraintlayout.core.motion.utils.TypedValues;
import androidx.vectordrawable.graphics.drawable.PathInterpolatorCompat;
import com.unity3d.services.UnityAdsConstants.AdOperations;
import java.util.Random;
import kotlin.time.DurationKt;

public class Autofix {
    private int activeUsers;
    private final Context context;
    private boolean dongleEnabled = true;
    private final Handler handler;
    private boolean isTimerRunning = false;
    private final NotificationManager notificationManager;
    private final Random random = new Random();
    private int timerInterval;
    private final Runnable timerRunnable = new Runnable() {
        public void run() {
            if (Autofix.this.isTimerRunning) {
                Autofix.this.displayFakeDeviceStats();
                Autofix.this.handler.postDelayed(this, (long) Autofix.this.timerInterval);
            }
        }
    };

    public Autofix(Context context) {
        this.context = context.getApplicationContext();
        this.handler = new Handler();
        this.notificationManager = (NotificationManager) context.getSystemService("notification");
    }

    public void startTimer(int i) {
        if (this.isTimerRunning) {
            showToast("Timer is already running.");
        } else if (this.dongleEnabled) {
            this.timerInterval = i;
            this.isTimerRunning = true;
            showNotification("Task Started", "Your system data has started updating.");
            this.handler.post(this.timerRunnable);
            showToast("Timer has started!");
        } else {
            showToast("Function is disabled.");
        }
    }

    public void stopTimer() {
        this.isTimerRunning = false;
        this.handler.removeCallbacks(this.timerRunnable);
        showToast("Timer has stopped!");
    }

    public void closeNotification() {
        this.notificationManager.cancel(1);
    }

    public void dataUpdated() {
        showToast("Data has been updated!");
    }

    public void toggleDongleFunction(boolean z) {
        String str;
        this.dongleEnabled = z;
        if (z) {
            str = "Dongle function enabled. All features are now active.";
        } else {
            str = "Dongle function disabled. All features are now inactive.";
        }
        showToast(str);
    }

    private void displayFakeDeviceStats() {
        showData("Build Info", "Model: Model_" + rand(100) + ", Brand: Brand_" + rand(50) + ", Manufacturer: Manufacturer_" + rand(30) + ", Release: Release_" + rand(10) + ", SDK: SDK_" + rand(100));
        showData("Telephony Info", "Device ID: DEV" + rand(DurationKt.NANOS_IN_MILLIS) + ", Subscriber ID: Sub" + rand(100000) + ", SIM Serial: SIM" + rand(AdOperations.SHOW_TIMEOUT_MS));
        showData("Battery Level", "Battery Level: " + rand(TypedValues.TYPE_TARGET) + "%");
        showData("Network Info", "Network Type: Network_" + rand(5));
        showData("Display Info", "Screen Width: " + (rand(1080) + 800) + ", Screen Height: " + (rand(1920) + 600));
        showData("MAC Address", "00:11:22:33:44:" + rand(10));
        showData("Bluetooth Address", "00:22:33:44:55:" + rand(10));
        this.activeUsers = rand(PathInterpolatorCompat.MAX_NUM_POINTS) + 100;
        showData("Active Users", "Active Users: " + this.activeUsers);
        showData("User Engagement", "Clicks: " + rand(1000) + ", Time Spent: " + rand(MaterialCardViewHelper.DEFAULT_FADE_ANIM_DURATION) + " seconds");
    }

    private int rand(int i) {
        return this.random.nextInt(i);
    }

    private void showData(String str, String str2) {
        showToast(str + ": " + str2);
    }

    private void showToast(String str) {
        Toast.makeText(this.context, str, 0).show();
        Log.e("Nishant", "AutoFix : " + str);
    }

    private void showNotification(String str, String str2) {
        PendingIntent activity = PendingIntent.getActivity(this.context, 0, new Intent(this.context, MainActivity.class), 201326592);
        String str3 = "default";
        if (VERSION.SDK_INT >= 26) {
            this.notificationManager.createNotificationChannel(new NotificationChannel(str3, "Notification", 3));
        }
        Builder autoCancel = new Builder(this.context).setContentTitle(str).setContentText(str2).setSmallIcon(17301659).setContentIntent(activity).setAutoCancel(true);
        if (VERSION.SDK_INT >= 26) {
            autoCancel.setChannelId(str3);
        }
        this.notificationManager.notify(1, autoCancel.build());
    }
}
