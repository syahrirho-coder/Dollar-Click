package com.nishant.superadspro;

import android.content.Intent;
import android.icu.text.SimpleDateFormat;
import android.icu.util.TimeZone;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.ViewCompat;
import androidx.vectordrawable.graphics.drawable.PathInterpolatorCompat;
import com.google.firebase.database.FirebaseDatabase;
import com.nishant.superadspro.IPGeolocation.Callback;
import com.nishant.superadspro.IPUtils.IPCallback;
import com.unity3d.ads.IUnityAdsInitializationListener;
import com.unity3d.ads.IUnityAdsLoadListener;
import com.unity3d.ads.IUnityAdsShowListener;
import com.unity3d.ads.UnityAds;
import com.unity3d.ads.UnityAds.UnityAdsInitializationError;
import com.unity3d.ads.UnityAds.UnityAdsLoadError;
import com.unity3d.ads.UnityAds.UnityAdsShowCompletionState;
import com.unity3d.ads.UnityAds.UnityAdsShowError;
import com.unity3d.ads.UnityAdsShowOptions;
import java.text.DecimalFormat;
import java.util.Date;
import java.util.Locale;
import java.util.Random;

public class DashboardActivity extends AppCompatActivity implements IUnityAdsInitializationListener {
    static final /* synthetic */ boolean $assertionsDisabled = false;
    private static String INTERSTITIAL_AD = "Interstitial_Android";
    private static String REWARDED_ID = "Rewarded_Android";
    private static boolean testMode = false;
    private TextView CountryTxt;
    public String IP = "";
    private String TimeZone;
    private String UNITY_ID = "5077399";
    DotLoadingAnimator animator1;
    DotLoadingAnimator animator2;
    private Button btn_joinTL;
    private Button btn_rewarded;
    private Button btn_subscribeYT;
    private ImageView countryTxt;
    DecimalFormat decimalFormat = new DecimalFormat("0.0000");
    private int dotstate = 0;
    int ecpm = 0;
    private int interstitialAdWatched = 0;
    private Button interstitialBtn;
    private IUnityAdsLoadListener interstitialLoadListener = new IUnityAdsLoadListener() {
        public void onUnityAdsAdLoaded(String str) {
            DashboardActivity.this.animator1.stop();
            DashboardActivity.this.ShowToast("Ad is loaded");
            new Handler().postDelayed(new Runnable() {
                public void run() {
                    DashboardActivity.this.txt_ecpm.setText(DashboardActivity.this.ecpm + "$ - " + (DashboardActivity.this.ecpm + 4) + "$");
                    DashboardActivity.this.ShowToast("High eCPM is Updated...");
                }
            }, (long) new Random(3000).nextInt(4000));
            DashboardActivity dashboardActivity = DashboardActivity.this;
            dashboardActivity.ecpm = dashboardActivity.r.nextInt(50) + 5;
            dashboardActivity = DashboardActivity.this;
            dashboardActivity.perAdPrice = ((double) dashboardActivity.ecpm) / 1000.0d;
            DashboardActivity.this.UpdateLogs("Interstitial Ad is Loaded");
            DashboardActivity.this.isInterstitialLoaded(true);
        }

        public void onUnityAdsFailedToLoad(String str, UnityAdsLoadError unityAdsLoadError, String str2) {
            str = "Unity Ads failed to load ad for " + str + " with error: [" + unityAdsLoadError + "] " + str2;
            Log.e("UnityAdsExample", str);
            DashboardActivity.this.isInterstitialLoaded(false);
            DashboardActivity.this.interstitialBtn.setText("Loading Failed Restart App");
            DashboardActivity.this.UpdateLogs(str);
        }
    };
    private IUnityAdsShowListener interstitialShowListener = new IUnityAdsShowListener() {
        public void onUnityAdsShowFailure(String str, UnityAdsShowError unityAdsShowError, String str2) {
            str = "Unity Ads failed to show ad for " + str + " with error: [" + unityAdsShowError + "] " + str2;
            Log.e("UnityAdsExample", str);
            UnityAds.show(DashboardActivity.this, DashboardActivity.INTERSTITIAL_AD, new UnityAdsShowOptions(), DashboardActivity.this.interstitialShowListener);
            DashboardActivity.this.UpdateLogs(str);
        }

        public void onUnityAdsShowStart(String str) {
            str = "onUnityAdsShowStart: " + str;
            Log.v("UnityAdsExample", str);
            DashboardActivity.this.UpdateLogs(str);
        }

        public void onUnityAdsShowClick(String str) {
            str = "onUnityAdsShowClick: " + str;
            Log.v("UnityAdsExample", str);
            DashboardActivity.this.UpdateLogs(str);
        }

        public void onUnityAdsShowComplete(String str, UnityAdsShowCompletionState unityAdsShowCompletionState) {
            str = "onUnityAdsShowComplete: " + str;
            Log.v("UnityAdsExample", str);
            DashboardActivity.this.UpdateLogs(str);
            DashboardActivity.this.txt_adCondition.setText("Loading Ad");
            DashboardActivity.this.animator1.start();
            DashboardActivity dashboardActivity = DashboardActivity.this;
            dashboardActivity.interstitialAdWatched = dashboardActivity.interstitialAdWatched + 1;
            DashboardActivity.this.UpdateAdWatchedText();
            DashboardActivity.this.isInterstitialLoaded(false);
            UnityAds.load(DashboardActivity.INTERSTITIAL_AD, DashboardActivity.this.interstitialLoadListener);
        }
    };
    private TextView ipConnection;
    private TextView isVpnConnectedTxt;
    private LinearLayout ll_vpnInfo;
    double perAdPrice = 0.0d;
    Random r = new Random(3000);
    private int rewardedAdWatched = 0;
    private IUnityAdsLoadListener rewardedLoadListener = new IUnityAdsLoadListener() {
        public void onUnityAdsAdLoaded(String str) {
            DashboardActivity.this.ShowToast("Ad is loaded");
            DashboardActivity.this.animator1.stop();
            DashboardActivity dashboardActivity = DashboardActivity.this;
            dashboardActivity.ecpm = dashboardActivity.r.nextInt(50) + 5;
            dashboardActivity = DashboardActivity.this;
            dashboardActivity.perAdPrice = ((double) dashboardActivity.ecpm) / 1000.0d;
            DashboardActivity.this.UpdateLogs("Rewarded Ad is Loaded");
            DashboardActivity.this.isRewardedLoaded(true);
        }

        public void onUnityAdsFailedToLoad(String str, UnityAdsLoadError unityAdsLoadError, String str2) {
            str = "Unity Ads failed to load ad for " + str + " with error: [" + unityAdsLoadError + "] " + str2;
            Log.e("UnityAdsExample", str);
            DashboardActivity.this.isRewardedLoaded(false);
            DashboardActivity.this.btn_rewarded.setText("Loading Failed Restart App");
            DashboardActivity.this.UpdateLogs(str);
        }
    };
    private IUnityAdsShowListener rewardedShowListener = new IUnityAdsShowListener() {
        public void onUnityAdsShowFailure(String str, UnityAdsShowError unityAdsShowError, String str2) {
            str = "Unity Ads failed to show ad for " + str + " with error: [" + unityAdsShowError + "] " + str2;
            Log.e("UnityAdsExample", str);
            UnityAds.show(DashboardActivity.this, DashboardActivity.REWARDED_ID, new UnityAdsShowOptions(), DashboardActivity.this.rewardedShowListener);
            DashboardActivity.this.UpdateLogs(str);
        }

        public void onUnityAdsShowStart(String str) {
            str = "onUnityAdsShowStart: " + str;
            Log.v("UnityAdsExample", str);
            DashboardActivity.this.UpdateLogs(str);
        }

        public void onUnityAdsShowClick(String str) {
            str = "onUnityAdsShowClick: " + str;
            Log.v("UnityAdsExample", str);
            DashboardActivity.this.UpdateLogs(str);
        }

        public void onUnityAdsShowComplete(String str, UnityAdsShowCompletionState unityAdsShowCompletionState) {
            str = "onUnityAdsShowComplete: " + str;
            Log.v("UnityAdsExample", str);
            DashboardActivity.this.UpdateLogs(str);
            DashboardActivity.this.isRewardedLoaded(false);
            DashboardActivity.this.animator1.start();
            DashboardActivity dashboardActivity = DashboardActivity.this;
            dashboardActivity.rewardedAdWatched = dashboardActivity.rewardedAdWatched + 1;
            DashboardActivity.this.UpdateAdWatchedText();
            UnityAds.load(DashboardActivity.REWARDED_ID, DashboardActivity.this.rewardedLoadListener);
        }
    };
    private TextView txt_adCondition;
    private TextView txt_adWatched;
    TextView txt_ecpm;
    private TextView txt_loadingVpnInfo;
    private TextView txt_logs;
    private TextView txt_lowECPM;
    private TextView txt_unityid;

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_dashboard);
        this.interstitialBtn = (Button) findViewById(R.id.btn_interstitial);
        this.txt_adCondition = (TextView) findViewById(R.id.txt_adCondition);
        this.txt_unityid = (TextView) findViewById(R.id.txt_unityID);
        this.txt_adWatched = (TextView) findViewById(R.id.txt_adWatched);
        this.countryTxt = (ImageView) findViewById(R.id.countryImg);
        this.CountryTxt = (TextView) findViewById(R.id.CountryTxt);
        this.ipConnection = (TextView) findViewById(R.id.ipConnection);
        this.txt_logs = (TextView) findViewById(R.id.txt_logs);
        this.btn_subscribeYT = (Button) findViewById(R.id.btn_subscribeYT);
        this.btn_joinTL = (Button) findViewById(R.id.btn_joinTL);
        this.btn_rewarded = (Button) findViewById(R.id.btn_rewarded);
        this.ll_vpnInfo = (LinearLayout) findViewById(R.id.ll_vpnInfo);
        this.isVpnConnectedTxt = (TextView) findViewById(R.id.isVpnConnectedTxt);
        this.txt_loadingVpnInfo = (TextView) findViewById(R.id.txt_loadingVpnInfo);
        this.txt_lowECPM = (TextView) findViewById(R.id.txt_lowECPM);
        this.txt_ecpm = (TextView) findViewById(R.id.txt_ecpm);
        int nextInt = this.r.nextInt(50) + 5;
        this.ecpm = nextInt;
        this.perAdPrice = ((double) nextInt) / 1000.0d;
        String stringExtra = getIntent().getStringExtra("Unity");
        if (!stringExtra.isEmpty()) {
            this.UNITY_ID = stringExtra;
        }
        this.animator1 = new DotLoadingAnimator(this.txt_adCondition);
        this.animator2 = new DotLoadingAnimator(this.txt_loadingVpnInfo);
        this.interstitialBtn.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                DashboardActivity.this.ShowToast("Showing Interstitial Ad");
                UnityAds.show(DashboardActivity.this, DashboardActivity.INTERSTITIAL_AD, new UnityAdsShowOptions(), DashboardActivity.this.interstitialShowListener);
            }
        });
        this.btn_rewarded.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                DashboardActivity.this.ShowToast("Showing Rewarded Ad");
                UnityAds.show(DashboardActivity.this, DashboardActivity.REWARDED_ID, new UnityAdsShowOptions(), DashboardActivity.this.rewardedShowListener);
            }
        });
        ShowToast("Initialization started");
        this.animator1.start();
        this.animator2.start();
        isInterstitialLoaded(false);
        isRewardedLoaded(false);
        UnityAds.initialize(this, this.UNITY_ID, testMode, this);
        CheckVpnConnection();
        this.btn_joinTL.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                DashboardActivity.this.openLink("https://telegram.me/UnitySelfClickingApp");
            }
        });
        this.btn_subscribeYT.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                DashboardActivity.this.openLink("https://youtube.com/@loudnishant");
            }
        });
        this.txt_unityid.setText(this.UNITY_ID);
        UpdateAdWatchedText();
        UpdateFirebase();
        CheckVpnConnection();
    }

    private void isInterstitialLoaded(boolean z) {
        if (z) {
            this.interstitialBtn.setBackgroundDrawable(getDrawable(R.drawable.button_main));
            this.interstitialBtn.setText("Interstitial Ad ( " + this.decimalFormat.format(this.perAdPrice) + " )");
            this.interstitialBtn.setTextColor(ViewCompat.MEASURED_STATE_MASK);
            return;
        }
        this.interstitialBtn.setBackgroundDrawable(getDrawable(R.drawable.app2_background));
        this.interstitialBtn.setText("Interstitial Ad..");
        this.interstitialBtn.setTextColor(-1);
    }

    private void isRewardedLoaded(boolean z) {
        if (z) {
            this.btn_rewarded.setBackgroundDrawable(getDrawable(R.drawable.button_main));
            this.btn_rewarded.setText("Rewarded Ad ( " + this.decimalFormat.format(this.perAdPrice * 8.0d) + " )");
            this.btn_rewarded.setTextColor(ViewCompat.MEASURED_STATE_MASK);
            return;
        }
        this.btn_rewarded.setBackgroundDrawable(getDrawable(R.drawable.app2_background));
        this.btn_rewarded.setText("Rewarded Ad..");
        this.btn_rewarded.setTextColor(-1);
    }

    private void UpdateFirebase() {
        String string = getSharedPreferences("Dollar", 0).getString("Key", "");
        FirebaseDatabase instance = FirebaseDatabase.getInstance();
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("HH:mm:ss dd|MM|yy", Locale.getDefault());
        if (!string.isEmpty()) {
            instance.getReference().child(string).child("liveTime").setValue(simpleDateFormat.format(new Date()));
        }
    }

    private void CheckVpnConnection() {
        if (VPNCheck.isVpnConnected(this)) {
            this.isVpnConnectedTxt.setText("Connected");
            this.isVpnConnectedTxt.setTextColor(ViewCompat.MEASURED_STATE_MASK);
            this.isVpnConnectedTxt.setBackground(getDrawable(R.drawable.green_background));
        } else {
            this.isVpnConnectedTxt.setText("Disconnected");
            this.isVpnConnectedTxt.setTextColor(-1);
            this.isVpnConnectedTxt.setBackground(getDrawable(R.drawable.red_background));
        }
        this.txt_loadingVpnInfo.setText("loading vpn info");
        this.txt_loadingVpnInfo.setVisibility(0);
        this.ll_vpnInfo.setVisibility(8);
        CheckVpn();
    }

    private void UpdateAdWatchedText() {
        DecimalFormat decimalFormat = new DecimalFormat("00");
        this.txt_adWatched.setText("I : " + decimalFormat.format((long) this.interstitialAdWatched) + " R : " + decimalFormat.format((long) this.rewardedAdWatched));
    }

    public void onInitializationComplete() {
        ShowToast("Initialization Completed Successfully");
        this.animator1.stop();
        int nextInt = new Random(3000).nextInt(PathInterpolatorCompat.MAX_NUM_POINTS);
        ShowToast("Activating Anti - Ban...");
        new Handler().postDelayed(new Runnable() {
            public void run() {
                DashboardActivity.this.ShowToast("Anti - Ban Activated Successfully");
            }
        }, (long) nextInt);
        UnityAds.load(REWARDED_ID, this.rewardedLoadListener);
        UnityAds.load(INTERSTITIAL_AD, this.interstitialLoadListener);
        ShowToast("Loading Ad");
        this.animator1.start();
    }

    private void ShowToast(String str) {
        this.txt_adCondition.setText(str);
        UpdateLogs(str);
    }

    public void openLink(String str) {
        startActivity(new Intent("android.intent.action.VIEW", Uri.parse(str)));
    }

    private void UpdateLogs(String str) {
        String currentTime = getCurrentTime();
        this.txt_logs.setText(currentTime + " -> " + str + "\n" + this.txt_logs.getText().toString());
    }

    public static String getCurrentTime() {
        return new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date());
    }

    public void onInitializationFailed(UnityAdsInitializationError unityAdsInitializationError, String str) {
        ShowToast("Initialization Failed");
    }

    public void CheckVpn() {
        IPUtils.getPublicIP(new IPCallback() {
            public void onResult(String str) {
                DashboardActivity.this.ipConnection.setText(str);
                DashboardActivity.this.IP = str;
                DashboardActivity.this.UpdateLogs("Public IP:  " + str);
            }

            public void onError(Exception exception) {
                exception.printStackTrace();
            }
        });
        this.CountryTxt.setText(" ");
        IPGeolocation.getCountryCode(new Callback() {
            public void onResult(String str, String str2) {
                DashboardActivity.this.txt_loadingVpnInfo.setVisibility(8);
                DashboardActivity.this.CountryTxt.setText(str);
                DashboardActivity.this.country(str);
                DashboardActivity.this.TimeZone = str2;
                DashboardActivity.this.startTimeUpdater();
                DashboardActivity.this.animator2.stop();
                DashboardActivity.this.txt_loadingVpnInfo.setText("Vpn Info loaded.");
                DashboardActivity.this.ll_vpnInfo.setVisibility(0);
                if (!DashboardActivity.this.IP.isEmpty()) {
                    DashboardActivity.this.ipConnection.setText(DashboardActivity.this.IP);
                }
            }

            public void onError(Exception exception) {
                Log.e("CountryCode", "Error fetching country code", exception);
            }
        });
    }

    private void startTimeUpdater() {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("HH:mm:ss", Locale.getDefault());
        simpleDateFormat.setTimeZone(TimeZone.getTimeZone(this.TimeZone));
        String format = simpleDateFormat.format(new Date());
        Log.e("Nishant", "TimeZone : " + this.TimeZone + " Time : " + format);
    }

    public void country(String str) {
        String str2 = "IN";
        String str3 = "Low eCPM Country Detected";
        if (str.equals(str2) || str.equals("BD") || str.equals("PK")) {
            ShowToast(str3);
            this.txt_lowECPM.setVisibility(0);
        } else {
            ShowToast("HIGH eCPM Country");
            this.txt_lowECPM.setVisibility(8);
        }
        this.CountryTxt.setText(" : " + str);
        this.isVpnConnectedTxt.setVisibility(0);
        getApplicationContext();
        if (str.equals("US")) {
            this.countryTxt.setImageDrawable(getDrawable(R.drawable.us));
        } else if (str.equals("DK")) {
            this.countryTxt.setImageDrawable(getDrawable(R.drawable.dk));
        } else if (str.equals("NL")) {
            this.countryTxt.setImageDrawable(getDrawable(R.drawable.nl));
        } else if (str.equals("AU")) {
            this.countryTxt.setImageDrawable(getDrawable(R.drawable.au));
        } else if (str.equals("CH")) {
            this.countryTxt.setImageDrawable(getDrawable(R.drawable.ch));
        } else if (str.equals("CA")) {
            this.countryTxt.setImageDrawable(getDrawable(R.drawable.ca));
        } else if (str.equals("UK")) {
            this.countryTxt.setImageDrawable(getDrawable(R.drawable.uk));
        } else if (str.equals("JP")) {
            this.countryTxt.setImageDrawable(getDrawable(R.drawable.jp));
        } else if (str.equals("SE")) {
            this.countryTxt.setImageDrawable(getDrawable(R.drawable.se));
        } else if (str.equals("NO")) {
            this.countryTxt.setImageDrawable(getDrawable(R.drawable.no));
        } else if (str.equals("FR")) {
            this.countryTxt.setImageDrawable(getDrawable(R.drawable.fr));
        } else if (str.equals("DE")) {
            this.countryTxt.setImageDrawable(getDrawable(R.drawable.de));
        } else if (str.equals(str2)) {
            this.countryTxt.setImageDrawable(getDrawable(R.drawable.in));
        } else {
            ShowToast(str3);
            this.txt_ecpm.setText("...");
        }
    }
}
