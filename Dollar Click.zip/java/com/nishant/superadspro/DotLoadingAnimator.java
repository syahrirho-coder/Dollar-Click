package com.nishant.superadspro;

import android.os.Handler;
import android.widget.TextView;
import com.unity3d.services.UnityAdsConstants.RequestPolicy;

public class DotLoadingAnimator {
    private final int delay = RequestPolicy.RETRY_WAIT_BASE;
    private int dotCount = 0;
    private final Handler handler = new Handler();
    private boolean isAnimating = false;
    private final int maxDots = 3;
    TextView textView;

    DotLoadingAnimator(TextView textView) {
        this.textView = textView;
    }

    public void start() {
        this.isAnimating = true;
        final String replaceAll = this.textView.getText().toString().replaceAll("\\.*$", "");
        this.handler.post(new Runnable() {
            public void run() {
                if (DotLoadingAnimator.this.isAnimating) {
                    StringBuilder stringBuilder = new StringBuilder(replaceAll);
                    for (int i = 0; i < DotLoadingAnimator.this.dotCount; i++) {
                        stringBuilder.append(".");
                    }
                    DotLoadingAnimator.this.textView.setText(stringBuilder.toString());
                    DotLoadingAnimator dotLoadingAnimator = DotLoadingAnimator.this;
                    dotLoadingAnimator.dotCount = (dotLoadingAnimator.dotCount + 1) % 4;
                    DotLoadingAnimator.this.handler.postDelayed(this, 500);
                }
            }
        });
    }

    public void stop() {
        this.isAnimating = false;
        this.handler.removeCallbacksAndMessages(null);
    }
}
