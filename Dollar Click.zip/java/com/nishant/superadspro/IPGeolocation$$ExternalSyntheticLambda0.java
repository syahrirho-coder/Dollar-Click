package com.nishant.superadspro;

import com.nishant.superadspro.IPGeolocation.Callback;

/* compiled from: D8$$SyntheticClass */
public final /* synthetic */ class IPGeolocation$$ExternalSyntheticLambda0 implements Runnable {
    public final /* synthetic */ Callback f$0;
    public final /* synthetic */ String f$1;
    public final /* synthetic */ String f$2;

    public /* synthetic */ IPGeolocation$$ExternalSyntheticLambda0(Callback callback, String str, String str2) {
        this.f$0 = callback;
        this.f$1 = str;
        this.f$2 = str2;
    }

    public final void run() {
        this.f$0.onResult(this.f$1, this.f$2);
    }
}
