package com.nishant.superadspro;

import com.nishant.superadspro.IPGeolocation.Callback;

/* compiled from: D8$$SyntheticClass */
public final /* synthetic */ class IPGeolocation$$ExternalSyntheticLambda1 implements Runnable {
    public final /* synthetic */ Callback f$0;
    public final /* synthetic */ Exception f$1;

    public /* synthetic */ IPGeolocation$$ExternalSyntheticLambda1(Callback callback, Exception exception) {
        this.f$0 = callback;
        this.f$1 = exception;
    }

    public final void run() {
        this.f$0.onError(this.f$1);
    }
}
