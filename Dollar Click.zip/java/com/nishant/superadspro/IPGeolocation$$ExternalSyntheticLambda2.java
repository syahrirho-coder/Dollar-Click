package com.nishant.superadspro;

import com.nishant.superadspro.IPGeolocation.Callback;

/* compiled from: D8$$SyntheticClass */
public final /* synthetic */ class IPGeolocation$$ExternalSyntheticLambda2 implements Runnable {
    public final /* synthetic */ Callback f$0;

    public /* synthetic */ IPGeolocation$$ExternalSyntheticLambda2(Callback callback) {
        this.f$0 = callback;
    }

    public final void run() {
        IPGeolocation.lambda$getCountryCode$2(this.f$0);
    }
}
