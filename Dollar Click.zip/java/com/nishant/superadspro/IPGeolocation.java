package com.nishant.superadspro;

import android.os.Handler;
import android.os.Looper;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import org.json.JSONObject;

public class IPGeolocation {

    public interface Callback {
        void onError(Exception exception);

        void onResult(String str, String str2);
    }

    public static void getCountryCode(Callback callback) {
        new Thread(new IPGeolocation$$ExternalSyntheticLambda2(callback)).start();
    }

    static /* synthetic */ void lambda$getCountryCode$2(Callback callback) {
        try {
            HttpURLConnection httpURLConnection = (HttpURLConnection) new URL("https://ipinfo.io/json").openConnection();
            httpURLConnection.setRequestMethod("GET");
            httpURLConnection.setConnectTimeout(5000);
            httpURLConnection.setReadTimeout(5000);
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(httpURLConnection.getInputStream()));
            StringBuilder stringBuilder = new StringBuilder();
            while (true) {
                String readLine = bufferedReader.readLine();
                if (readLine != null) {
                    stringBuilder.append(readLine);
                } else {
                    bufferedReader.close();
                    JSONObject jSONObject = new JSONObject(stringBuilder.toString());
                    new Handler(Looper.getMainLooper()).post(new IPGeolocation$$ExternalSyntheticLambda0(callback, jSONObject.getString("country"), jSONObject.getString("timezone")));
                    return;
                }
            }
        } catch (Exception e) {
            new Handler(Looper.getMainLooper()).post(new IPGeolocation$$ExternalSyntheticLambda1(callback, e));
        }
    }
}
