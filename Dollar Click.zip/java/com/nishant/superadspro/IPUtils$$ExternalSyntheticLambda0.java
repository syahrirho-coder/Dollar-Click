package com.nishant.superadspro;

import com.nishant.superadspro.IPUtils.IPCallback;

/* compiled from: D8$$SyntheticClass */
public final /* synthetic */ class IPUtils$$ExternalSyntheticLambda0 implements Runnable {
    public final /* synthetic */ IPCallback f$0;

    public /* synthetic */ IPUtils$$ExternalSyntheticLambda0(IPCallback iPCallback) {
        this.f$0 = iPCallback;
    }

    public final void run() {
        IPUtils.lambda$getPublicIP$0(this.f$0);
    }
}
