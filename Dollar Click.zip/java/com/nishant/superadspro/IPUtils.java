package com.nishant.superadspro;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class IPUtils {

    public interface IPCallback {
        void onError(Exception exception);

        void onResult(String str);
    }

    public static void getPublicIP(IPCallback iPCallback) {
        new Thread(new IPUtils$$ExternalSyntheticLambda0(iPCallback)).start();
    }

    static /* synthetic */ void lambda$getPublicIP$0(IPCallback iPCallback) {
        try {
            HttpURLConnection httpURLConnection = (HttpURLConnection) new URL("https://api.ipify.org").openConnection();
            httpURLConnection.setRequestMethod("GET");
            httpURLConnection.setConnectTimeout(5000);
            httpURLConnection.setReadTimeout(5000);
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(httpURLConnection.getInputStream()));
            String readLine = bufferedReader.readLine();
            bufferedReader.close();
            iPCallback.onResult(readLine);
        } catch (Exception e) {
            iPCallback.onError(e);
        }
    }
}
