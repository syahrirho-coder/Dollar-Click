package com.nishant.superadspro;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    TextView appName;
    ImageView imageView;

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_main);
        this.imageView = (ImageView) findViewById(R.id.imageView);
        this.appName = (TextView) findViewById(R.id.appName);
        this.imageView.animate().alpha(1.0f).setDuration(900).scaleX(1.0f).scaleY(1.0f);
        new Handler().postDelayed(new Runnable() {
            public void run() {
                MainActivity.this.appName.animate().alpha(1.0f).setDuration(500).scaleX(1.0f);
            }
        }, 1000);
        final String string = getSharedPreferences("Dollar", 0).getString("Unity", "");
        if (string.isEmpty()) {
            new Handler().postDelayed(new Runnable() {
                public void run() {
                    MainActivity.this.startActivity(new Intent(MainActivity.this, AuthenticationActivity.class));
                }
            }, 2500);
        } else {
            new Handler().postDelayed(new Runnable() {
                public void run() {
                    Intent intent = new Intent(MainActivity.this, DashboardActivity.class);
                    intent.putExtra("Unity", string);
                    MainActivity.this.startActivity(intent);
                }
            }, 2500);
        }
    }
}
