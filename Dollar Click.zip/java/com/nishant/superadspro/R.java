package com.nishant.superadspro;

public final class R {

    public static final class color {
        public static int background = 2131034141;
        public static int background2 = 2131034142;
        public static int black = 2131034147;
        public static int green = 2131034219;
        public static int ic_launcher_background = 2131034222;
        public static int primary = 2131034879;
        public static int red = 2131034888;
        public static int white = 2131034903;
        public static int white_light = 2131034904;
        /* added by DevToolsApp */
        public static final int abc_background_cache_hint_selector_material_dark = 2131034112;
        /* added by DevToolsApp */
        public static final int abc_background_cache_hint_selector_material_light = 2131034113;
        /* added by DevToolsApp */
        public static final int abc_btn_colored_borderless_text_material = 2131034114;
        /* added by DevToolsApp */
        public static final int abc_btn_colored_text_material = 2131034115;
        /* added by DevToolsApp */
        public static final int abc_color_highlight_material = 2131034116;
        /* added by DevToolsApp */
        public static final int abc_decor_view_status_guard = 2131034117;
        /* added by DevToolsApp */
        public static final int abc_decor_view_status_guard_light = 2131034118;
        /* added by DevToolsApp */
        public static final int abc_hint_foreground_material_dark = 2131034119;
        /* added by DevToolsApp */
        public static final int abc_hint_foreground_material_light = 2131034120;
        /* added by DevToolsApp */
        public static final int abc_primary_text_disable_only_material_dark = 2131034121;
        /* added by DevToolsApp */
        public static final int abc_primary_text_disable_only_material_light = 2131034122;
        /* added by DevToolsApp */
        public static final int abc_primary_text_material_dark = 2131034123;
        /* added by DevToolsApp */
        public static final int abc_primary_text_material_light = 2131034124;
        /* added by DevToolsApp */
        public static final int abc_search_url_text = 2131034125;
        /* added by DevToolsApp */
        public static final int abc_search_url_text_normal = 2131034126;
        /* added by DevToolsApp */
        public static final int abc_search_url_text_pressed = 2131034127;
        /* added by DevToolsApp */
        public static final int abc_search_url_text_selected = 2131034128;
        /* added by DevToolsApp */
        public static final int abc_secondary_text_material_dark = 2131034129;
        /* added by DevToolsApp */
        public static final int abc_secondary_text_material_light = 2131034130;
        /* added by DevToolsApp */
        public static final int abc_tint_btn_checkable = 2131034131;
        /* added by DevToolsApp */
        public static final int abc_tint_default = 2131034132;
        /* added by DevToolsApp */
        public static final int abc_tint_edittext = 2131034133;
        /* added by DevToolsApp */
        public static final int abc_tint_seek_thumb = 2131034134;
        /* added by DevToolsApp */
        public static final int abc_tint_spinner = 2131034135;
        /* added by DevToolsApp */
        public static final int abc_tint_switch_track = 2131034136;
        /* added by DevToolsApp */
        public static final int accent_material_dark = 2131034137;
        /* added by DevToolsApp */
        public static final int accent_material_light = 2131034138;
        /* added by DevToolsApp */
        public static final int androidx_core_ripple_material_light = 2131034139;
        /* added by DevToolsApp */
        public static final int androidx_core_secondary_text_default_material_light = 2131034140;
        /* added by DevToolsApp */
        public static final int background_floating_material_dark = 2131034143;
        /* added by DevToolsApp */
        public static final int background_floating_material_light = 2131034144;
        /* added by DevToolsApp */
        public static final int background_material_dark = 2131034145;
        /* added by DevToolsApp */
        public static final int background_material_light = 2131034146;
        /* added by DevToolsApp */
        public static final int bright_foreground_disabled_material_dark = 2131034148;
        /* added by DevToolsApp */
        public static final int bright_foreground_disabled_material_light = 2131034149;
        /* added by DevToolsApp */
        public static final int bright_foreground_inverse_material_dark = 2131034150;
        /* added by DevToolsApp */
        public static final int bright_foreground_inverse_material_light = 2131034151;
        /* added by DevToolsApp */
        public static final int bright_foreground_material_dark = 2131034152;
        /* added by DevToolsApp */
        public static final int bright_foreground_material_light = 2131034153;
        /* added by DevToolsApp */
        public static final int button_material_dark = 2131034154;
        /* added by DevToolsApp */
        public static final int button_material_light = 2131034155;
        /* added by DevToolsApp */
        public static final int call_notification_answer_color = 2131034156;
        /* added by DevToolsApp */
        public static final int call_notification_decline_color = 2131034157;
        /* added by DevToolsApp */
        public static final int cardview_dark_background = 2131034158;
        /* added by DevToolsApp */
        public static final int cardview_light_background = 2131034159;
        /* added by DevToolsApp */
        public static final int cardview_shadow_end_color = 2131034160;
        /* added by DevToolsApp */
        public static final int cardview_shadow_start_color = 2131034161;
        /* added by DevToolsApp */
        public static final int common_google_signin_btn_text_dark = 2131034162;
        /* added by DevToolsApp */
        public static final int common_google_signin_btn_text_dark_default = 2131034163;
        /* added by DevToolsApp */
        public static final int common_google_signin_btn_text_dark_disabled = 2131034164;
        /* added by DevToolsApp */
        public static final int common_google_signin_btn_text_dark_focused = 2131034165;
        /* added by DevToolsApp */
        public static final int common_google_signin_btn_text_dark_pressed = 2131034166;
        /* added by DevToolsApp */
        public static final int common_google_signin_btn_text_light = 2131034167;
        /* added by DevToolsApp */
        public static final int common_google_signin_btn_text_light_default = 2131034168;
        /* added by DevToolsApp */
        public static final int common_google_signin_btn_text_light_disabled = 2131034169;
        /* added by DevToolsApp */
        public static final int common_google_signin_btn_text_light_focused = 2131034170;
        /* added by DevToolsApp */
        public static final int common_google_signin_btn_text_light_pressed = 2131034171;
        /* added by DevToolsApp */
        public static final int common_google_signin_btn_tint = 2131034172;
        /* added by DevToolsApp */
        public static final int design_bottom_navigation_shadow_color = 2131034173;
        /* added by DevToolsApp */
        public static final int design_box_stroke_color = 2131034174;
        /* added by DevToolsApp */
        public static final int design_dark_default_color_background = 2131034175;
        /* added by DevToolsApp */
        public static final int design_dark_default_color_error = 2131034176;
        /* added by DevToolsApp */
        public static final int design_dark_default_color_on_background = 2131034177;
        /* added by DevToolsApp */
        public static final int design_dark_default_color_on_error = 2131034178;
        /* added by DevToolsApp */
        public static final int design_dark_default_color_on_primary = 2131034179;
        /* added by DevToolsApp */
        public static final int design_dark_default_color_on_secondary = 2131034180;
        /* added by DevToolsApp */
        public static final int design_dark_default_color_on_surface = 2131034181;
        /* added by DevToolsApp */
        public static final int design_dark_default_color_primary = 2131034182;
        /* added by DevToolsApp */
        public static final int design_dark_default_color_primary_dark = 2131034183;
        /* added by DevToolsApp */
        public static final int design_dark_default_color_primary_variant = 2131034184;
        /* added by DevToolsApp */
        public static final int design_dark_default_color_secondary = 2131034185;
        /* added by DevToolsApp */
        public static final int design_dark_default_color_secondary_variant = 2131034186;
        /* added by DevToolsApp */
        public static final int design_dark_default_color_surface = 2131034187;
        /* added by DevToolsApp */
        public static final int design_default_color_background = 2131034188;
        /* added by DevToolsApp */
        public static final int design_default_color_error = 2131034189;
        /* added by DevToolsApp */
        public static final int design_default_color_on_background = 2131034190;
        /* added by DevToolsApp */
        public static final int design_default_color_on_error = 2131034191;
        /* added by DevToolsApp */
        public static final int design_default_color_on_primary = 2131034192;
        /* added by DevToolsApp */
        public static final int design_default_color_on_secondary = 2131034193;
        /* added by DevToolsApp */
        public static final int design_default_color_on_surface = 2131034194;
        /* added by DevToolsApp */
        public static final int design_default_color_primary = 2131034195;
        /* added by DevToolsApp */
        public static final int design_default_color_primary_dark = 2131034196;
        /* added by DevToolsApp */
        public static final int design_default_color_primary_variant = 2131034197;
        /* added by DevToolsApp */
        public static final int design_default_color_secondary = 2131034198;
        /* added by DevToolsApp */
        public static final int design_default_color_secondary_variant = 2131034199;
        /* added by DevToolsApp */
        public static final int design_default_color_surface = 2131034200;
        /* added by DevToolsApp */
        public static final int design_error = 2131034201;
        /* added by DevToolsApp */
        public static final int design_fab_shadow_end_color = 2131034202;
        /* added by DevToolsApp */
        public static final int design_fab_shadow_mid_color = 2131034203;
        /* added by DevToolsApp */
        public static final int design_fab_shadow_start_color = 2131034204;
        /* added by DevToolsApp */
        public static final int design_fab_stroke_end_inner_color = 2131034205;
        /* added by DevToolsApp */
        public static final int design_fab_stroke_end_outer_color = 2131034206;
        /* added by DevToolsApp */
        public static final int design_fab_stroke_top_inner_color = 2131034207;
        /* added by DevToolsApp */
        public static final int design_fab_stroke_top_outer_color = 2131034208;
        /* added by DevToolsApp */
        public static final int design_icon_tint = 2131034209;
        /* added by DevToolsApp */
        public static final int design_snackbar_background_color = 2131034210;
        /* added by DevToolsApp */
        public static final int dim_foreground_disabled_material_dark = 2131034211;
        /* added by DevToolsApp */
        public static final int dim_foreground_disabled_material_light = 2131034212;
        /* added by DevToolsApp */
        public static final int dim_foreground_material_dark = 2131034213;
        /* added by DevToolsApp */
        public static final int dim_foreground_material_light = 2131034214;
        /* added by DevToolsApp */
        public static final int error_color_material_dark = 2131034215;
        /* added by DevToolsApp */
        public static final int error_color_material_light = 2131034216;
        /* added by DevToolsApp */
        public static final int foreground_material_dark = 2131034217;
        /* added by DevToolsApp */
        public static final int foreground_material_light = 2131034218;
        /* added by DevToolsApp */
        public static final int highlighted_text_material_dark = 2131034220;
        /* added by DevToolsApp */
        public static final int highlighted_text_material_light = 2131034221;
        /* added by DevToolsApp */
        public static final int m3_appbar_overlay_color = 2131034223;
        /* added by DevToolsApp */
        public static final int m3_assist_chip_icon_tint_color = 2131034224;
        /* added by DevToolsApp */
        public static final int m3_assist_chip_stroke_color = 2131034225;
        /* added by DevToolsApp */
        public static final int m3_bottom_sheet_drag_handle_color = 2131034226;
        /* added by DevToolsApp */
        public static final int m3_button_background_color_selector = 2131034227;
        /* added by DevToolsApp */
        public static final int m3_button_foreground_color_selector = 2131034228;
        /* added by DevToolsApp */
        public static final int m3_button_outline_color_selector = 2131034229;
        /* added by DevToolsApp */
        public static final int m3_button_ripple_color = 2131034230;
        /* added by DevToolsApp */
        public static final int m3_button_ripple_color_selector = 2131034231;
        /* added by DevToolsApp */
        public static final int m3_calendar_item_disabled_text = 2131034232;
        /* added by DevToolsApp */
        public static final int m3_calendar_item_stroke_color = 2131034233;
        /* added by DevToolsApp */
        public static final int m3_card_foreground_color = 2131034234;
        /* added by DevToolsApp */
        public static final int m3_card_ripple_color = 2131034235;
        /* added by DevToolsApp */
        public static final int m3_card_stroke_color = 2131034236;
        /* added by DevToolsApp */
        public static final int m3_checkbox_button_icon_tint = 2131034237;
        /* added by DevToolsApp */
        public static final int m3_checkbox_button_tint = 2131034238;
        /* added by DevToolsApp */
        public static final int m3_chip_assist_text_color = 2131034239;
        /* added by DevToolsApp */
        public static final int m3_chip_background_color = 2131034240;
        /* added by DevToolsApp */
        public static final int m3_chip_ripple_color = 2131034241;
        /* added by DevToolsApp */
        public static final int m3_chip_stroke_color = 2131034242;
        /* added by DevToolsApp */
        public static final int m3_chip_text_color = 2131034243;
        /* added by DevToolsApp */
        public static final int m3_dark_default_color_primary_text = 2131034244;
        /* added by DevToolsApp */
        public static final int m3_dark_default_color_secondary_text = 2131034245;
        /* added by DevToolsApp */
        public static final int m3_dark_highlighted_text = 2131034246;
        /* added by DevToolsApp */
        public static final int m3_dark_hint_foreground = 2131034247;
        /* added by DevToolsApp */
        public static final int m3_dark_primary_text_disable_only = 2131034248;
        /* added by DevToolsApp */
        public static final int m3_default_color_primary_text = 2131034249;
        /* added by DevToolsApp */
        public static final int m3_default_color_secondary_text = 2131034250;
        /* added by DevToolsApp */
        public static final int m3_dynamic_dark_default_color_primary_text = 2131034251;
        /* added by DevToolsApp */
        public static final int m3_dynamic_dark_default_color_secondary_text = 2131034252;
        /* added by DevToolsApp */
        public static final int m3_dynamic_dark_highlighted_text = 2131034253;
        /* added by DevToolsApp */
        public static final int m3_dynamic_dark_hint_foreground = 2131034254;
        /* added by DevToolsApp */
        public static final int m3_dynamic_dark_primary_text_disable_only = 2131034255;
        /* added by DevToolsApp */
        public static final int m3_dynamic_default_color_primary_text = 2131034256;
        /* added by DevToolsApp */
        public static final int m3_dynamic_default_color_secondary_text = 2131034257;
        /* added by DevToolsApp */
        public static final int m3_dynamic_highlighted_text = 2131034258;
        /* added by DevToolsApp */
        public static final int m3_dynamic_hint_foreground = 2131034259;
        /* added by DevToolsApp */
        public static final int m3_dynamic_primary_text_disable_only = 2131034260;
        /* added by DevToolsApp */
        public static final int m3_efab_ripple_color_selector = 2131034261;
        /* added by DevToolsApp */
        public static final int m3_elevated_chip_background_color = 2131034262;
        /* added by DevToolsApp */
        public static final int m3_fab_efab_background_color_selector = 2131034263;
        /* added by DevToolsApp */
        public static final int m3_fab_efab_foreground_color_selector = 2131034264;
        /* added by DevToolsApp */
        public static final int m3_fab_ripple_color_selector = 2131034265;
        /* added by DevToolsApp */
        public static final int m3_filled_icon_button_container_color_selector = 2131034266;
        /* added by DevToolsApp */
        public static final int m3_highlighted_text = 2131034267;
        /* added by DevToolsApp */
        public static final int m3_hint_foreground = 2131034268;
        /* added by DevToolsApp */
        public static final int m3_icon_button_icon_color_selector = 2131034269;
        /* added by DevToolsApp */
        public static final int m3_navigation_bar_item_with_indicator_icon_tint = 2131034270;
        /* added by DevToolsApp */
        public static final int m3_navigation_bar_item_with_indicator_label_tint = 2131034271;
        /* added by DevToolsApp */
        public static final int m3_navigation_bar_ripple_color_selector = 2131034272;
        /* added by DevToolsApp */
        public static final int m3_navigation_item_background_color = 2131034273;
        /* added by DevToolsApp */
        public static final int m3_navigation_item_icon_tint = 2131034274;
        /* added by DevToolsApp */
        public static final int m3_navigation_item_ripple_color = 2131034275;
        /* added by DevToolsApp */
        public static final int m3_navigation_item_text_color = 2131034276;
        /* added by DevToolsApp */
        public static final int m3_navigation_rail_item_with_indicator_icon_tint = 2131034277;
        /* added by DevToolsApp */
        public static final int m3_navigation_rail_item_with_indicator_label_tint = 2131034278;
        /* added by DevToolsApp */
        public static final int m3_navigation_rail_ripple_color_selector = 2131034279;
        /* added by DevToolsApp */
        public static final int m3_popupmenu_overlay_color = 2131034280;
        /* added by DevToolsApp */
        public static final int m3_primary_text_disable_only = 2131034281;
        /* added by DevToolsApp */
        public static final int m3_radiobutton_button_tint = 2131034282;
        /* added by DevToolsApp */
        public static final int m3_radiobutton_ripple_tint = 2131034283;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_black = 2131034284;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_dynamic_neutral0 = 2131034285;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_dynamic_neutral10 = 2131034286;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_dynamic_neutral100 = 2131034287;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_dynamic_neutral12 = 2131034288;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_dynamic_neutral17 = 2131034289;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_dynamic_neutral20 = 2131034290;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_dynamic_neutral22 = 2131034291;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_dynamic_neutral24 = 2131034292;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_dynamic_neutral30 = 2131034293;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_dynamic_neutral4 = 2131034294;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_dynamic_neutral40 = 2131034295;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_dynamic_neutral50 = 2131034296;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_dynamic_neutral6 = 2131034297;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_dynamic_neutral60 = 2131034298;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_dynamic_neutral70 = 2131034299;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_dynamic_neutral80 = 2131034300;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_dynamic_neutral87 = 2131034301;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_dynamic_neutral90 = 2131034302;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_dynamic_neutral92 = 2131034303;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_dynamic_neutral94 = 2131034304;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_dynamic_neutral95 = 2131034305;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_dynamic_neutral96 = 2131034306;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_dynamic_neutral98 = 2131034307;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_dynamic_neutral99 = 2131034308;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_dynamic_neutral_variant0 = 2131034309;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_dynamic_neutral_variant10 = 2131034310;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_dynamic_neutral_variant100 = 2131034311;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_dynamic_neutral_variant12 = 2131034312;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_dynamic_neutral_variant17 = 2131034313;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_dynamic_neutral_variant20 = 2131034314;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_dynamic_neutral_variant22 = 2131034315;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_dynamic_neutral_variant24 = 2131034316;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_dynamic_neutral_variant30 = 2131034317;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_dynamic_neutral_variant4 = 2131034318;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_dynamic_neutral_variant40 = 2131034319;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_dynamic_neutral_variant50 = 2131034320;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_dynamic_neutral_variant6 = 2131034321;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_dynamic_neutral_variant60 = 2131034322;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_dynamic_neutral_variant70 = 2131034323;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_dynamic_neutral_variant80 = 2131034324;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_dynamic_neutral_variant87 = 2131034325;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_dynamic_neutral_variant90 = 2131034326;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_dynamic_neutral_variant92 = 2131034327;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_dynamic_neutral_variant94 = 2131034328;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_dynamic_neutral_variant95 = 2131034329;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_dynamic_neutral_variant96 = 2131034330;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_dynamic_neutral_variant98 = 2131034331;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_dynamic_neutral_variant99 = 2131034332;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_dynamic_primary0 = 2131034333;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_dynamic_primary10 = 2131034334;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_dynamic_primary100 = 2131034335;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_dynamic_primary20 = 2131034336;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_dynamic_primary30 = 2131034337;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_dynamic_primary40 = 2131034338;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_dynamic_primary50 = 2131034339;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_dynamic_primary60 = 2131034340;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_dynamic_primary70 = 2131034341;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_dynamic_primary80 = 2131034342;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_dynamic_primary90 = 2131034343;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_dynamic_primary95 = 2131034344;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_dynamic_primary99 = 2131034345;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_dynamic_secondary0 = 2131034346;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_dynamic_secondary10 = 2131034347;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_dynamic_secondary100 = 2131034348;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_dynamic_secondary20 = 2131034349;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_dynamic_secondary30 = 2131034350;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_dynamic_secondary40 = 2131034351;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_dynamic_secondary50 = 2131034352;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_dynamic_secondary60 = 2131034353;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_dynamic_secondary70 = 2131034354;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_dynamic_secondary80 = 2131034355;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_dynamic_secondary90 = 2131034356;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_dynamic_secondary95 = 2131034357;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_dynamic_secondary99 = 2131034358;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_dynamic_tertiary0 = 2131034359;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_dynamic_tertiary10 = 2131034360;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_dynamic_tertiary100 = 2131034361;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_dynamic_tertiary20 = 2131034362;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_dynamic_tertiary30 = 2131034363;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_dynamic_tertiary40 = 2131034364;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_dynamic_tertiary50 = 2131034365;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_dynamic_tertiary60 = 2131034366;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_dynamic_tertiary70 = 2131034367;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_dynamic_tertiary80 = 2131034368;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_dynamic_tertiary90 = 2131034369;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_dynamic_tertiary95 = 2131034370;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_dynamic_tertiary99 = 2131034371;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_error0 = 2131034372;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_error10 = 2131034373;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_error100 = 2131034374;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_error20 = 2131034375;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_error30 = 2131034376;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_error40 = 2131034377;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_error50 = 2131034378;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_error60 = 2131034379;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_error70 = 2131034380;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_error80 = 2131034381;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_error90 = 2131034382;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_error95 = 2131034383;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_error99 = 2131034384;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_neutral0 = 2131034385;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_neutral10 = 2131034386;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_neutral100 = 2131034387;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_neutral12 = 2131034388;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_neutral17 = 2131034389;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_neutral20 = 2131034390;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_neutral22 = 2131034391;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_neutral24 = 2131034392;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_neutral30 = 2131034393;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_neutral4 = 2131034394;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_neutral40 = 2131034395;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_neutral50 = 2131034396;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_neutral6 = 2131034397;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_neutral60 = 2131034398;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_neutral70 = 2131034399;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_neutral80 = 2131034400;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_neutral87 = 2131034401;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_neutral90 = 2131034402;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_neutral92 = 2131034403;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_neutral94 = 2131034404;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_neutral95 = 2131034405;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_neutral96 = 2131034406;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_neutral98 = 2131034407;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_neutral99 = 2131034408;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_neutral_variant0 = 2131034409;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_neutral_variant10 = 2131034410;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_neutral_variant100 = 2131034411;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_neutral_variant20 = 2131034412;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_neutral_variant30 = 2131034413;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_neutral_variant40 = 2131034414;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_neutral_variant50 = 2131034415;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_neutral_variant60 = 2131034416;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_neutral_variant70 = 2131034417;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_neutral_variant80 = 2131034418;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_neutral_variant90 = 2131034419;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_neutral_variant95 = 2131034420;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_neutral_variant99 = 2131034421;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_primary0 = 2131034422;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_primary10 = 2131034423;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_primary100 = 2131034424;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_primary20 = 2131034425;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_primary30 = 2131034426;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_primary40 = 2131034427;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_primary50 = 2131034428;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_primary60 = 2131034429;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_primary70 = 2131034430;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_primary80 = 2131034431;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_primary90 = 2131034432;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_primary95 = 2131034433;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_primary99 = 2131034434;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_secondary0 = 2131034435;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_secondary10 = 2131034436;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_secondary100 = 2131034437;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_secondary20 = 2131034438;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_secondary30 = 2131034439;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_secondary40 = 2131034440;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_secondary50 = 2131034441;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_secondary60 = 2131034442;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_secondary70 = 2131034443;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_secondary80 = 2131034444;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_secondary90 = 2131034445;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_secondary95 = 2131034446;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_secondary99 = 2131034447;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_tertiary0 = 2131034448;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_tertiary10 = 2131034449;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_tertiary100 = 2131034450;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_tertiary20 = 2131034451;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_tertiary30 = 2131034452;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_tertiary40 = 2131034453;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_tertiary50 = 2131034454;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_tertiary60 = 2131034455;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_tertiary70 = 2131034456;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_tertiary80 = 2131034457;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_tertiary90 = 2131034458;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_tertiary95 = 2131034459;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_tertiary99 = 2131034460;
        /* added by DevToolsApp */
        public static final int m3_ref_palette_white = 2131034461;
        /* added by DevToolsApp */
        public static final int m3_selection_control_ripple_color_selector = 2131034462;
        /* added by DevToolsApp */
        public static final int m3_simple_item_ripple_color = 2131034463;
        /* added by DevToolsApp */
        public static final int m3_slider_active_track_color = 2131034464;
        /* added by DevToolsApp */
        public static final int m3_slider_active_track_color_legacy = 2131034465;
        /* added by DevToolsApp */
        public static final int m3_slider_halo_color_legacy = 2131034466;
        /* added by DevToolsApp */
        public static final int m3_slider_inactive_track_color = 2131034467;
        /* added by DevToolsApp */
        public static final int m3_slider_inactive_track_color_legacy = 2131034468;
        /* added by DevToolsApp */
        public static final int m3_slider_thumb_color = 2131034469;
        /* added by DevToolsApp */
        public static final int m3_slider_thumb_color_legacy = 2131034470;
        /* added by DevToolsApp */
        public static final int m3_switch_thumb_tint = 2131034471;
        /* added by DevToolsApp */
        public static final int m3_switch_track_tint = 2131034472;
        /* added by DevToolsApp */
        public static final int m3_sys_color_dark_background = 2131034473;
        /* added by DevToolsApp */
        public static final int m3_sys_color_dark_error = 2131034474;
        /* added by DevToolsApp */
        public static final int m3_sys_color_dark_error_container = 2131034475;
        /* added by DevToolsApp */
        public static final int m3_sys_color_dark_inverse_on_surface = 2131034476;
        /* added by DevToolsApp */
        public static final int m3_sys_color_dark_inverse_primary = 2131034477;
        /* added by DevToolsApp */
        public static final int m3_sys_color_dark_inverse_surface = 2131034478;
        /* added by DevToolsApp */
        public static final int m3_sys_color_dark_on_background = 2131034479;
        /* added by DevToolsApp */
        public static final int m3_sys_color_dark_on_error = 2131034480;
        /* added by DevToolsApp */
        public static final int m3_sys_color_dark_on_error_container = 2131034481;
        /* added by DevToolsApp */
        public static final int m3_sys_color_dark_on_primary = 2131034482;
        /* added by DevToolsApp */
        public static final int m3_sys_color_dark_on_primary_container = 2131034483;
        /* added by DevToolsApp */
        public static final int m3_sys_color_dark_on_secondary = 2131034484;
        /* added by DevToolsApp */
        public static final int m3_sys_color_dark_on_secondary_container = 2131034485;
        /* added by DevToolsApp */
        public static final int m3_sys_color_dark_on_surface = 2131034486;
        /* added by DevToolsApp */
        public static final int m3_sys_color_dark_on_surface_variant = 2131034487;
        /* added by DevToolsApp */
        public static final int m3_sys_color_dark_on_tertiary = 2131034488;
        /* added by DevToolsApp */
        public static final int m3_sys_color_dark_on_tertiary_container = 2131034489;
        /* added by DevToolsApp */
        public static final int m3_sys_color_dark_outline = 2131034490;
        /* added by DevToolsApp */
        public static final int m3_sys_color_dark_outline_variant = 2131034491;
        /* added by DevToolsApp */
        public static final int m3_sys_color_dark_primary = 2131034492;
        /* added by DevToolsApp */
        public static final int m3_sys_color_dark_primary_container = 2131034493;
        /* added by DevToolsApp */
        public static final int m3_sys_color_dark_secondary = 2131034494;
        /* added by DevToolsApp */
        public static final int m3_sys_color_dark_secondary_container = 2131034495;
        /* added by DevToolsApp */
        public static final int m3_sys_color_dark_surface = 2131034496;
        /* added by DevToolsApp */
        public static final int m3_sys_color_dark_surface_bright = 2131034497;
        /* added by DevToolsApp */
        public static final int m3_sys_color_dark_surface_container = 2131034498;
        /* added by DevToolsApp */
        public static final int m3_sys_color_dark_surface_container_high = 2131034499;
        /* added by DevToolsApp */
        public static final int m3_sys_color_dark_surface_container_highest = 2131034500;
        /* added by DevToolsApp */
        public static final int m3_sys_color_dark_surface_container_low = 2131034501;
        /* added by DevToolsApp */
        public static final int m3_sys_color_dark_surface_container_lowest = 2131034502;
        /* added by DevToolsApp */
        public static final int m3_sys_color_dark_surface_dim = 2131034503;
        /* added by DevToolsApp */
        public static final int m3_sys_color_dark_surface_variant = 2131034504;
        /* added by DevToolsApp */
        public static final int m3_sys_color_dark_tertiary = 2131034505;
        /* added by DevToolsApp */
        public static final int m3_sys_color_dark_tertiary_container = 2131034506;
        /* added by DevToolsApp */
        public static final int m3_sys_color_dynamic_dark_background = 2131034507;
        /* added by DevToolsApp */
        public static final int m3_sys_color_dynamic_dark_error = 2131034508;
        /* added by DevToolsApp */
        public static final int m3_sys_color_dynamic_dark_error_container = 2131034509;
        /* added by DevToolsApp */
        public static final int m3_sys_color_dynamic_dark_inverse_on_surface = 2131034510;
        /* added by DevToolsApp */
        public static final int m3_sys_color_dynamic_dark_inverse_primary = 2131034511;
        /* added by DevToolsApp */
        public static final int m3_sys_color_dynamic_dark_inverse_surface = 2131034512;
        /* added by DevToolsApp */
        public static final int m3_sys_color_dynamic_dark_on_background = 2131034513;
        /* added by DevToolsApp */
        public static final int m3_sys_color_dynamic_dark_on_error = 2131034514;
        /* added by DevToolsApp */
        public static final int m3_sys_color_dynamic_dark_on_error_container = 2131034515;
        /* added by DevToolsApp */
        public static final int m3_sys_color_dynamic_dark_on_primary = 2131034516;
        /* added by DevToolsApp */
        public static final int m3_sys_color_dynamic_dark_on_primary_container = 2131034517;
        /* added by DevToolsApp */
        public static final int m3_sys_color_dynamic_dark_on_secondary = 2131034518;
        /* added by DevToolsApp */
        public static final int m3_sys_color_dynamic_dark_on_secondary_container = 2131034519;
        /* added by DevToolsApp */
        public static final int m3_sys_color_dynamic_dark_on_surface = 2131034520;
        /* added by DevToolsApp */
        public static final int m3_sys_color_dynamic_dark_on_surface_variant = 2131034521;
        /* added by DevToolsApp */
        public static final int m3_sys_color_dynamic_dark_on_tertiary = 2131034522;
        /* added by DevToolsApp */
        public static final int m3_sys_color_dynamic_dark_on_tertiary_container = 2131034523;
        /* added by DevToolsApp */
        public static final int m3_sys_color_dynamic_dark_outline = 2131034524;
        /* added by DevToolsApp */
        public static final int m3_sys_color_dynamic_dark_outline_variant = 2131034525;
        /* added by DevToolsApp */
        public static final int m3_sys_color_dynamic_dark_primary = 2131034526;
        /* added by DevToolsApp */
        public static final int m3_sys_color_dynamic_dark_primary_container = 2131034527;
        /* added by DevToolsApp */
        public static final int m3_sys_color_dynamic_dark_secondary = 2131034528;
        /* added by DevToolsApp */
        public static final int m3_sys_color_dynamic_dark_secondary_container = 2131034529;
        /* added by DevToolsApp */
        public static final int m3_sys_color_dynamic_dark_surface = 2131034530;
        /* added by DevToolsApp */
        public static final int m3_sys_color_dynamic_dark_surface_bright = 2131034531;
        /* added by DevToolsApp */
        public static final int m3_sys_color_dynamic_dark_surface_container = 2131034532;
        /* added by DevToolsApp */
        public static final int m3_sys_color_dynamic_dark_surface_container_high = 2131034533;
        /* added by DevToolsApp */
        public static final int m3_sys_color_dynamic_dark_surface_container_highest = 2131034534;
        /* added by DevToolsApp */
        public static final int m3_sys_color_dynamic_dark_surface_container_low = 2131034535;
        /* added by DevToolsApp */
        public static final int m3_sys_color_dynamic_dark_surface_container_lowest = 2131034536;
        /* added by DevToolsApp */
        public static final int m3_sys_color_dynamic_dark_surface_dim = 2131034537;
        /* added by DevToolsApp */
        public static final int m3_sys_color_dynamic_dark_surface_variant = 2131034538;
        /* added by DevToolsApp */
        public static final int m3_sys_color_dynamic_dark_tertiary = 2131034539;
        /* added by DevToolsApp */
        public static final int m3_sys_color_dynamic_dark_tertiary_container = 2131034540;
        /* added by DevToolsApp */
        public static final int m3_sys_color_dynamic_light_background = 2131034541;
        /* added by DevToolsApp */
        public static final int m3_sys_color_dynamic_light_error = 2131034542;
        /* added by DevToolsApp */
        public static final int m3_sys_color_dynamic_light_error_container = 2131034543;
        /* added by DevToolsApp */
        public static final int m3_sys_color_dynamic_light_inverse_on_surface = 2131034544;
        /* added by DevToolsApp */
        public static final int m3_sys_color_dynamic_light_inverse_primary = 2131034545;
        /* added by DevToolsApp */
        public static final int m3_sys_color_dynamic_light_inverse_surface = 2131034546;
        /* added by DevToolsApp */
        public static final int m3_sys_color_dynamic_light_on_background = 2131034547;
        /* added by DevToolsApp */
        public static final int m3_sys_color_dynamic_light_on_error = 2131034548;
        /* added by DevToolsApp */
        public static final int m3_sys_color_dynamic_light_on_error_container = 2131034549;
        /* added by DevToolsApp */
        public static final int m3_sys_color_dynamic_light_on_primary = 2131034550;
        /* added by DevToolsApp */
        public static final int m3_sys_color_dynamic_light_on_primary_container = 2131034551;
        /* added by DevToolsApp */
        public static final int m3_sys_color_dynamic_light_on_secondary = 2131034552;
        /* added by DevToolsApp */
        public static final int m3_sys_color_dynamic_light_on_secondary_container = 2131034553;
        /* added by DevToolsApp */
        public static final int m3_sys_color_dynamic_light_on_surface = 2131034554;
        /* added by DevToolsApp */
        public static final int m3_sys_color_dynamic_light_on_surface_variant = 2131034555;
        /* added by DevToolsApp */
        public static final int m3_sys_color_dynamic_light_on_tertiary = 2131034556;
        /* added by DevToolsApp */
        public static final int m3_sys_color_dynamic_light_on_tertiary_container = 2131034557;
        /* added by DevToolsApp */
        public static final int m3_sys_color_dynamic_light_outline = 2131034558;
        /* added by DevToolsApp */
        public static final int m3_sys_color_dynamic_light_outline_variant = 2131034559;
        /* added by DevToolsApp */
        public static final int m3_sys_color_dynamic_light_primary = 2131034560;
        /* added by DevToolsApp */
        public static final int m3_sys_color_dynamic_light_primary_container = 2131034561;
        /* added by DevToolsApp */
        public static final int m3_sys_color_dynamic_light_secondary = 2131034562;
        /* added by DevToolsApp */
        public static final int m3_sys_color_dynamic_light_secondary_container = 2131034563;
        /* added by DevToolsApp */
        public static final int m3_sys_color_dynamic_light_surface = 2131034564;
        /* added by DevToolsApp */
        public static final int m3_sys_color_dynamic_light_surface_bright = 2131034565;
        /* added by DevToolsApp */
        public static final int m3_sys_color_dynamic_light_surface_container = 2131034566;
        /* added by DevToolsApp */
        public static final int m3_sys_color_dynamic_light_surface_container_high = 2131034567;
        /* added by DevToolsApp */
        public static final int m3_sys_color_dynamic_light_surface_container_highest = 2131034568;
        /* added by DevToolsApp */
        public static final int m3_sys_color_dynamic_light_surface_container_low = 2131034569;
        /* added by DevToolsApp */
        public static final int m3_sys_color_dynamic_light_surface_container_lowest = 2131034570;
        /* added by DevToolsApp */
        public static final int m3_sys_color_dynamic_light_surface_dim = 2131034571;
        /* added by DevToolsApp */
        public static final int m3_sys_color_dynamic_light_surface_variant = 2131034572;
        /* added by DevToolsApp */
        public static final int m3_sys_color_dynamic_light_tertiary = 2131034573;
        /* added by DevToolsApp */
        public static final int m3_sys_color_dynamic_light_tertiary_container = 2131034574;
        /* added by DevToolsApp */
        public static final int m3_sys_color_dynamic_on_primary_fixed = 2131034575;
        /* added by DevToolsApp */
        public static final int m3_sys_color_dynamic_on_primary_fixed_variant = 2131034576;
        /* added by DevToolsApp */
        public static final int m3_sys_color_dynamic_on_secondary_fixed = 2131034577;
        /* added by DevToolsApp */
        public static final int m3_sys_color_dynamic_on_secondary_fixed_variant = 2131034578;
        /* added by DevToolsApp */
        public static final int m3_sys_color_dynamic_on_tertiary_fixed = 2131034579;
        /* added by DevToolsApp */
        public static final int m3_sys_color_dynamic_on_tertiary_fixed_variant = 2131034580;
        /* added by DevToolsApp */
        public static final int m3_sys_color_dynamic_primary_fixed = 2131034581;
        /* added by DevToolsApp */
        public static final int m3_sys_color_dynamic_primary_fixed_dim = 2131034582;
        /* added by DevToolsApp */
        public static final int m3_sys_color_dynamic_secondary_fixed = 2131034583;
        /* added by DevToolsApp */
        public static final int m3_sys_color_dynamic_secondary_fixed_dim = 2131034584;
        /* added by DevToolsApp */
        public static final int m3_sys_color_dynamic_tertiary_fixed = 2131034585;
        /* added by DevToolsApp */
        public static final int m3_sys_color_dynamic_tertiary_fixed_dim = 2131034586;
        /* added by DevToolsApp */
        public static final int m3_sys_color_light_background = 2131034587;
        /* added by DevToolsApp */
        public static final int m3_sys_color_light_error = 2131034588;
        /* added by DevToolsApp */
        public static final int m3_sys_color_light_error_container = 2131034589;
        /* added by DevToolsApp */
        public static final int m3_sys_color_light_inverse_on_surface = 2131034590;
        /* added by DevToolsApp */
        public static final int m3_sys_color_light_inverse_primary = 2131034591;
        /* added by DevToolsApp */
        public static final int m3_sys_color_light_inverse_surface = 2131034592;
        /* added by DevToolsApp */
        public static final int m3_sys_color_light_on_background = 2131034593;
        /* added by DevToolsApp */
        public static final int m3_sys_color_light_on_error = 2131034594;
        /* added by DevToolsApp */
        public static final int m3_sys_color_light_on_error_container = 2131034595;
        /* added by DevToolsApp */
        public static final int m3_sys_color_light_on_primary = 2131034596;
        /* added by DevToolsApp */
        public static final int m3_sys_color_light_on_primary_container = 2131034597;
        /* added by DevToolsApp */
        public static final int m3_sys_color_light_on_secondary = 2131034598;
        /* added by DevToolsApp */
        public static final int m3_sys_color_light_on_secondary_container = 2131034599;
        /* added by DevToolsApp */
        public static final int m3_sys_color_light_on_surface = 2131034600;
        /* added by DevToolsApp */
        public static final int m3_sys_color_light_on_surface_variant = 2131034601;
        /* added by DevToolsApp */
        public static final int m3_sys_color_light_on_tertiary = 2131034602;
        /* added by DevToolsApp */
        public static final int m3_sys_color_light_on_tertiary_container = 2131034603;
        /* added by DevToolsApp */
        public static final int m3_sys_color_light_outline = 2131034604;
        /* added by DevToolsApp */
        public static final int m3_sys_color_light_outline_variant = 2131034605;
        /* added by DevToolsApp */
        public static final int m3_sys_color_light_primary = 2131034606;
        /* added by DevToolsApp */
        public static final int m3_sys_color_light_primary_container = 2131034607;
        /* added by DevToolsApp */
        public static final int m3_sys_color_light_secondary = 2131034608;
        /* added by DevToolsApp */
        public static final int m3_sys_color_light_secondary_container = 2131034609;
        /* added by DevToolsApp */
        public static final int m3_sys_color_light_surface = 2131034610;
        /* added by DevToolsApp */
        public static final int m3_sys_color_light_surface_bright = 2131034611;
        /* added by DevToolsApp */
        public static final int m3_sys_color_light_surface_container = 2131034612;
        /* added by DevToolsApp */
        public static final int m3_sys_color_light_surface_container_high = 2131034613;
        /* added by DevToolsApp */
        public static final int m3_sys_color_light_surface_container_highest = 2131034614;
        /* added by DevToolsApp */
        public static final int m3_sys_color_light_surface_container_low = 2131034615;
        /* added by DevToolsApp */
        public static final int m3_sys_color_light_surface_container_lowest = 2131034616;
        /* added by DevToolsApp */
        public static final int m3_sys_color_light_surface_dim = 2131034617;
        /* added by DevToolsApp */
        public static final int m3_sys_color_light_surface_variant = 2131034618;
        /* added by DevToolsApp */
        public static final int m3_sys_color_light_tertiary = 2131034619;
        /* added by DevToolsApp */
        public static final int m3_sys_color_light_tertiary_container = 2131034620;
        /* added by DevToolsApp */
        public static final int m3_sys_color_on_primary_fixed = 2131034621;
        /* added by DevToolsApp */
        public static final int m3_sys_color_on_primary_fixed_variant = 2131034622;
        /* added by DevToolsApp */
        public static final int m3_sys_color_on_secondary_fixed = 2131034623;
        /* added by DevToolsApp */
        public static final int m3_sys_color_on_secondary_fixed_variant = 2131034624;
        /* added by DevToolsApp */
        public static final int m3_sys_color_on_tertiary_fixed = 2131034625;
        /* added by DevToolsApp */
        public static final int m3_sys_color_on_tertiary_fixed_variant = 2131034626;
        /* added by DevToolsApp */
        public static final int m3_sys_color_primary_fixed = 2131034627;
        /* added by DevToolsApp */
        public static final int m3_sys_color_primary_fixed_dim = 2131034628;
        /* added by DevToolsApp */
        public static final int m3_sys_color_secondary_fixed = 2131034629;
        /* added by DevToolsApp */
        public static final int m3_sys_color_secondary_fixed_dim = 2131034630;
        /* added by DevToolsApp */
        public static final int m3_sys_color_tertiary_fixed = 2131034631;
        /* added by DevToolsApp */
        public static final int m3_sys_color_tertiary_fixed_dim = 2131034632;
        /* added by DevToolsApp */
        public static final int m3_tabs_icon_color = 2131034633;
        /* added by DevToolsApp */
        public static final int m3_tabs_icon_color_secondary = 2131034634;
        /* added by DevToolsApp */
        public static final int m3_tabs_ripple_color = 2131034635;
        /* added by DevToolsApp */
        public static final int m3_tabs_ripple_color_secondary = 2131034636;
        /* added by DevToolsApp */
        public static final int m3_tabs_text_color = 2131034637;
        /* added by DevToolsApp */
        public static final int m3_tabs_text_color_secondary = 2131034638;
        /* added by DevToolsApp */
        public static final int m3_text_button_background_color_selector = 2131034639;
        /* added by DevToolsApp */
        public static final int m3_text_button_foreground_color_selector = 2131034640;
        /* added by DevToolsApp */
        public static final int m3_text_button_ripple_color_selector = 2131034641;
        /* added by DevToolsApp */
        public static final int m3_textfield_filled_background_color = 2131034642;
        /* added by DevToolsApp */
        public static final int m3_textfield_indicator_text_color = 2131034643;
        /* added by DevToolsApp */
        public static final int m3_textfield_input_text_color = 2131034644;
        /* added by DevToolsApp */
        public static final int m3_textfield_label_color = 2131034645;
        /* added by DevToolsApp */
        public static final int m3_textfield_stroke_color = 2131034646;
        /* added by DevToolsApp */
        public static final int m3_timepicker_button_background_color = 2131034647;
        /* added by DevToolsApp */
        public static final int m3_timepicker_button_ripple_color = 2131034648;
        /* added by DevToolsApp */
        public static final int m3_timepicker_button_text_color = 2131034649;
        /* added by DevToolsApp */
        public static final int m3_timepicker_clock_text_color = 2131034650;
        /* added by DevToolsApp */
        public static final int m3_timepicker_display_background_color = 2131034651;
        /* added by DevToolsApp */
        public static final int m3_timepicker_display_ripple_color = 2131034652;
        /* added by DevToolsApp */
        public static final int m3_timepicker_display_text_color = 2131034653;
        /* added by DevToolsApp */
        public static final int m3_timepicker_secondary_text_button_ripple_color = 2131034654;
        /* added by DevToolsApp */
        public static final int m3_timepicker_secondary_text_button_text_color = 2131034655;
        /* added by DevToolsApp */
        public static final int m3_timepicker_time_input_stroke_color = 2131034656;
        /* added by DevToolsApp */
        public static final int m3_tonal_button_ripple_color_selector = 2131034657;
        /* added by DevToolsApp */
        public static final int material_blue_grey_800 = 2131034658;
        /* added by DevToolsApp */
        public static final int material_blue_grey_900 = 2131034659;
        /* added by DevToolsApp */
        public static final int material_blue_grey_950 = 2131034660;
        /* added by DevToolsApp */
        public static final int material_cursor_color = 2131034661;
        /* added by DevToolsApp */
        public static final int material_deep_teal_200 = 2131034662;
        /* added by DevToolsApp */
        public static final int material_deep_teal_500 = 2131034663;
        /* added by DevToolsApp */
        public static final int material_divider_color = 2131034664;
        /* added by DevToolsApp */
        public static final int material_dynamic_color_dark_error = 2131034665;
        /* added by DevToolsApp */
        public static final int material_dynamic_color_dark_error_container = 2131034666;
        /* added by DevToolsApp */
        public static final int material_dynamic_color_dark_on_error = 2131034667;
        /* added by DevToolsApp */
        public static final int material_dynamic_color_dark_on_error_container = 2131034668;
        /* added by DevToolsApp */
        public static final int material_dynamic_color_light_error = 2131034669;
        /* added by DevToolsApp */
        public static final int material_dynamic_color_light_error_container = 2131034670;
        /* added by DevToolsApp */
        public static final int material_dynamic_color_light_on_error = 2131034671;
        /* added by DevToolsApp */
        public static final int material_dynamic_color_light_on_error_container = 2131034672;
        /* added by DevToolsApp */
        public static final int material_dynamic_neutral0 = 2131034673;
        /* added by DevToolsApp */
        public static final int material_dynamic_neutral10 = 2131034674;
        /* added by DevToolsApp */
        public static final int material_dynamic_neutral100 = 2131034675;
        /* added by DevToolsApp */
        public static final int material_dynamic_neutral20 = 2131034676;
        /* added by DevToolsApp */
        public static final int material_dynamic_neutral30 = 2131034677;
        /* added by DevToolsApp */
        public static final int material_dynamic_neutral40 = 2131034678;
        /* added by DevToolsApp */
        public static final int material_dynamic_neutral50 = 2131034679;
        /* added by DevToolsApp */
        public static final int material_dynamic_neutral60 = 2131034680;
        /* added by DevToolsApp */
        public static final int material_dynamic_neutral70 = 2131034681;
        /* added by DevToolsApp */
        public static final int material_dynamic_neutral80 = 2131034682;
        /* added by DevToolsApp */
        public static final int material_dynamic_neutral90 = 2131034683;
        /* added by DevToolsApp */
        public static final int material_dynamic_neutral95 = 2131034684;
        /* added by DevToolsApp */
        public static final int material_dynamic_neutral99 = 2131034685;
        /* added by DevToolsApp */
        public static final int material_dynamic_neutral_variant0 = 2131034686;
        /* added by DevToolsApp */
        public static final int material_dynamic_neutral_variant10 = 2131034687;
        /* added by DevToolsApp */
        public static final int material_dynamic_neutral_variant100 = 2131034688;
        /* added by DevToolsApp */
        public static final int material_dynamic_neutral_variant20 = 2131034689;
        /* added by DevToolsApp */
        public static final int material_dynamic_neutral_variant30 = 2131034690;
        /* added by DevToolsApp */
        public static final int material_dynamic_neutral_variant40 = 2131034691;
        /* added by DevToolsApp */
        public static final int material_dynamic_neutral_variant50 = 2131034692;
        /* added by DevToolsApp */
        public static final int material_dynamic_neutral_variant60 = 2131034693;
        /* added by DevToolsApp */
        public static final int material_dynamic_neutral_variant70 = 2131034694;
        /* added by DevToolsApp */
        public static final int material_dynamic_neutral_variant80 = 2131034695;
        /* added by DevToolsApp */
        public static final int material_dynamic_neutral_variant90 = 2131034696;
        /* added by DevToolsApp */
        public static final int material_dynamic_neutral_variant95 = 2131034697;
        /* added by DevToolsApp */
        public static final int material_dynamic_neutral_variant99 = 2131034698;
        /* added by DevToolsApp */
        public static final int material_dynamic_primary0 = 2131034699;
        /* added by DevToolsApp */
        public static final int material_dynamic_primary10 = 2131034700;
        /* added by DevToolsApp */
        public static final int material_dynamic_primary100 = 2131034701;
        /* added by DevToolsApp */
        public static final int material_dynamic_primary20 = 2131034702;
        /* added by DevToolsApp */
        public static final int material_dynamic_primary30 = 2131034703;
        /* added by DevToolsApp */
        public static final int material_dynamic_primary40 = 2131034704;
        /* added by DevToolsApp */
        public static final int material_dynamic_primary50 = 2131034705;
        /* added by DevToolsApp */
        public static final int material_dynamic_primary60 = 2131034706;
        /* added by DevToolsApp */
        public static final int material_dynamic_primary70 = 2131034707;
        /* added by DevToolsApp */
        public static final int material_dynamic_primary80 = 2131034708;
        /* added by DevToolsApp */
        public static final int material_dynamic_primary90 = 2131034709;
        /* added by DevToolsApp */
        public static final int material_dynamic_primary95 = 2131034710;
        /* added by DevToolsApp */
        public static final int material_dynamic_primary99 = 2131034711;
        /* added by DevToolsApp */
        public static final int material_dynamic_secondary0 = 2131034712;
        /* added by DevToolsApp */
        public static final int material_dynamic_secondary10 = 2131034713;
        /* added by DevToolsApp */
        public static final int material_dynamic_secondary100 = 2131034714;
        /* added by DevToolsApp */
        public static final int material_dynamic_secondary20 = 2131034715;
        /* added by DevToolsApp */
        public static final int material_dynamic_secondary30 = 2131034716;
        /* added by DevToolsApp */
        public static final int material_dynamic_secondary40 = 2131034717;
        /* added by DevToolsApp */
        public static final int material_dynamic_secondary50 = 2131034718;
        /* added by DevToolsApp */
        public static final int material_dynamic_secondary60 = 2131034719;
        /* added by DevToolsApp */
        public static final int material_dynamic_secondary70 = 2131034720;
        /* added by DevToolsApp */
        public static final int material_dynamic_secondary80 = 2131034721;
        /* added by DevToolsApp */
        public static final int material_dynamic_secondary90 = 2131034722;
        /* added by DevToolsApp */
        public static final int material_dynamic_secondary95 = 2131034723;
        /* added by DevToolsApp */
        public static final int material_dynamic_secondary99 = 2131034724;
        /* added by DevToolsApp */
        public static final int material_dynamic_tertiary0 = 2131034725;
        /* added by DevToolsApp */
        public static final int material_dynamic_tertiary10 = 2131034726;
        /* added by DevToolsApp */
        public static final int material_dynamic_tertiary100 = 2131034727;
        /* added by DevToolsApp */
        public static final int material_dynamic_tertiary20 = 2131034728;
        /* added by DevToolsApp */
        public static final int material_dynamic_tertiary30 = 2131034729;
        /* added by DevToolsApp */
        public static final int material_dynamic_tertiary40 = 2131034730;
        /* added by DevToolsApp */
        public static final int material_dynamic_tertiary50 = 2131034731;
        /* added by DevToolsApp */
        public static final int material_dynamic_tertiary60 = 2131034732;
        /* added by DevToolsApp */
        public static final int material_dynamic_tertiary70 = 2131034733;
        /* added by DevToolsApp */
        public static final int material_dynamic_tertiary80 = 2131034734;
        /* added by DevToolsApp */
        public static final int material_dynamic_tertiary90 = 2131034735;
        /* added by DevToolsApp */
        public static final int material_dynamic_tertiary95 = 2131034736;
        /* added by DevToolsApp */
        public static final int material_dynamic_tertiary99 = 2131034737;
        /* added by DevToolsApp */
        public static final int material_grey_100 = 2131034738;
        /* added by DevToolsApp */
        public static final int material_grey_300 = 2131034739;
        /* added by DevToolsApp */
        public static final int material_grey_50 = 2131034740;
        /* added by DevToolsApp */
        public static final int material_grey_600 = 2131034741;
        /* added by DevToolsApp */
        public static final int material_grey_800 = 2131034742;
        /* added by DevToolsApp */
        public static final int material_grey_850 = 2131034743;
        /* added by DevToolsApp */
        public static final int material_grey_900 = 2131034744;
        /* added by DevToolsApp */
        public static final int material_harmonized_color_error = 2131034745;
        /* added by DevToolsApp */
        public static final int material_harmonized_color_error_container = 2131034746;
        /* added by DevToolsApp */
        public static final int material_harmonized_color_on_error = 2131034747;
        /* added by DevToolsApp */
        public static final int material_harmonized_color_on_error_container = 2131034748;
        /* added by DevToolsApp */
        public static final int material_on_background_disabled = 2131034749;
        /* added by DevToolsApp */
        public static final int material_on_background_emphasis_high_type = 2131034750;
        /* added by DevToolsApp */
        public static final int material_on_background_emphasis_medium = 2131034751;
        /* added by DevToolsApp */
        public static final int material_on_primary_disabled = 2131034752;
        /* added by DevToolsApp */
        public static final int material_on_primary_emphasis_high_type = 2131034753;
        /* added by DevToolsApp */
        public static final int material_on_primary_emphasis_medium = 2131034754;
        /* added by DevToolsApp */
        public static final int material_on_surface_disabled = 2131034755;
        /* added by DevToolsApp */
        public static final int material_on_surface_emphasis_high_type = 2131034756;
        /* added by DevToolsApp */
        public static final int material_on_surface_emphasis_medium = 2131034757;
        /* added by DevToolsApp */
        public static final int material_on_surface_stroke = 2131034758;
        /* added by DevToolsApp */
        public static final int material_personalized__highlighted_text = 2131034759;
        /* added by DevToolsApp */
        public static final int material_personalized__highlighted_text_inverse = 2131034760;
        /* added by DevToolsApp */
        public static final int material_personalized_color_background = 2131034761;
        /* added by DevToolsApp */
        public static final int material_personalized_color_control_activated = 2131034762;
        /* added by DevToolsApp */
        public static final int material_personalized_color_control_highlight = 2131034763;
        /* added by DevToolsApp */
        public static final int material_personalized_color_control_normal = 2131034764;
        /* added by DevToolsApp */
        public static final int material_personalized_color_error = 2131034765;
        /* added by DevToolsApp */
        public static final int material_personalized_color_error_container = 2131034766;
        /* added by DevToolsApp */
        public static final int material_personalized_color_on_background = 2131034767;
        /* added by DevToolsApp */
        public static final int material_personalized_color_on_error = 2131034768;
        /* added by DevToolsApp */
        public static final int material_personalized_color_on_error_container = 2131034769;
        /* added by DevToolsApp */
        public static final int material_personalized_color_on_primary = 2131034770;
        /* added by DevToolsApp */
        public static final int material_personalized_color_on_primary_container = 2131034771;
        /* added by DevToolsApp */
        public static final int material_personalized_color_on_secondary = 2131034772;
        /* added by DevToolsApp */
        public static final int material_personalized_color_on_secondary_container = 2131034773;
        /* added by DevToolsApp */
        public static final int material_personalized_color_on_surface = 2131034774;
        /* added by DevToolsApp */
        public static final int material_personalized_color_on_surface_inverse = 2131034775;
        /* added by DevToolsApp */
        public static final int material_personalized_color_on_surface_variant = 2131034776;
        /* added by DevToolsApp */
        public static final int material_personalized_color_on_tertiary = 2131034777;
        /* added by DevToolsApp */
        public static final int material_personalized_color_on_tertiary_container = 2131034778;
        /* added by DevToolsApp */
        public static final int material_personalized_color_outline = 2131034779;
        /* added by DevToolsApp */
        public static final int material_personalized_color_outline_variant = 2131034780;
        /* added by DevToolsApp */
        public static final int material_personalized_color_primary = 2131034781;
        /* added by DevToolsApp */
        public static final int material_personalized_color_primary_container = 2131034782;
        /* added by DevToolsApp */
        public static final int material_personalized_color_primary_inverse = 2131034783;
        /* added by DevToolsApp */
        public static final int material_personalized_color_primary_text = 2131034784;
        /* added by DevToolsApp */
        public static final int material_personalized_color_primary_text_inverse = 2131034785;
        /* added by DevToolsApp */
        public static final int material_personalized_color_secondary = 2131034786;
        /* added by DevToolsApp */
        public static final int material_personalized_color_secondary_container = 2131034787;
        /* added by DevToolsApp */
        public static final int material_personalized_color_secondary_text = 2131034788;
        /* added by DevToolsApp */
        public static final int material_personalized_color_secondary_text_inverse = 2131034789;
        /* added by DevToolsApp */
        public static final int material_personalized_color_surface = 2131034790;
        /* added by DevToolsApp */
        public static final int material_personalized_color_surface_bright = 2131034791;
        /* added by DevToolsApp */
        public static final int material_personalized_color_surface_container = 2131034792;
        /* added by DevToolsApp */
        public static final int material_personalized_color_surface_container_high = 2131034793;
        /* added by DevToolsApp */
        public static final int material_personalized_color_surface_container_highest = 2131034794;
        /* added by DevToolsApp */
        public static final int material_personalized_color_surface_container_low = 2131034795;
        /* added by DevToolsApp */
        public static final int material_personalized_color_surface_container_lowest = 2131034796;
        /* added by DevToolsApp */
        public static final int material_personalized_color_surface_dim = 2131034797;
        /* added by DevToolsApp */
        public static final int material_personalized_color_surface_inverse = 2131034798;
        /* added by DevToolsApp */
        public static final int material_personalized_color_surface_variant = 2131034799;
        /* added by DevToolsApp */
        public static final int material_personalized_color_tertiary = 2131034800;
        /* added by DevToolsApp */
        public static final int material_personalized_color_tertiary_container = 2131034801;
        /* added by DevToolsApp */
        public static final int material_personalized_color_text_hint_foreground_inverse = 2131034802;
        /* added by DevToolsApp */
        public static final int material_personalized_color_text_primary_inverse = 2131034803;
        /* added by DevToolsApp */
        public static final int material_personalized_color_text_primary_inverse_disable_only = 2131034804;
        /* added by DevToolsApp */
        public static final int material_personalized_color_text_secondary_and_tertiary_inverse = 2131034805;
        /* added by DevToolsApp */
        public static final int material_personalized_color_text_secondary_and_tertiary_inverse_disabled = 2131034806;
        /* added by DevToolsApp */
        public static final int material_personalized_hint_foreground = 2131034807;
        /* added by DevToolsApp */
        public static final int material_personalized_hint_foreground_inverse = 2131034808;
        /* added by DevToolsApp */
        public static final int material_personalized_primary_inverse_text_disable_only = 2131034809;
        /* added by DevToolsApp */
        public static final int material_personalized_primary_text_disable_only = 2131034810;
        /* added by DevToolsApp */
        public static final int material_slider_active_tick_marks_color = 2131034811;
        /* added by DevToolsApp */
        public static final int material_slider_active_track_color = 2131034812;
        /* added by DevToolsApp */
        public static final int material_slider_halo_color = 2131034813;
        /* added by DevToolsApp */
        public static final int material_slider_inactive_tick_marks_color = 2131034814;
        /* added by DevToolsApp */
        public static final int material_slider_inactive_track_color = 2131034815;
        /* added by DevToolsApp */
        public static final int material_slider_thumb_color = 2131034816;
        /* added by DevToolsApp */
        public static final int material_timepicker_button_background = 2131034817;
        /* added by DevToolsApp */
        public static final int material_timepicker_button_stroke = 2131034818;
        /* added by DevToolsApp */
        public static final int material_timepicker_clock_text_color = 2131034819;
        /* added by DevToolsApp */
        public static final int material_timepicker_clockface = 2131034820;
        /* added by DevToolsApp */
        public static final int material_timepicker_modebutton_tint = 2131034821;
        /* added by DevToolsApp */
        public static final int mtrl_btn_bg_color_selector = 2131034822;
        /* added by DevToolsApp */
        public static final int mtrl_btn_ripple_color = 2131034823;
        /* added by DevToolsApp */
        public static final int mtrl_btn_stroke_color_selector = 2131034824;
        /* added by DevToolsApp */
        public static final int mtrl_btn_text_btn_bg_color_selector = 2131034825;
        /* added by DevToolsApp */
        public static final int mtrl_btn_text_btn_ripple_color = 2131034826;
        /* added by DevToolsApp */
        public static final int mtrl_btn_text_color_disabled = 2131034827;
        /* added by DevToolsApp */
        public static final int mtrl_btn_text_color_selector = 2131034828;
        /* added by DevToolsApp */
        public static final int mtrl_btn_transparent_bg_color = 2131034829;
        /* added by DevToolsApp */
        public static final int mtrl_calendar_item_stroke_color = 2131034830;
        /* added by DevToolsApp */
        public static final int mtrl_calendar_selected_range = 2131034831;
        /* added by DevToolsApp */
        public static final int mtrl_card_view_foreground = 2131034832;
        /* added by DevToolsApp */
        public static final int mtrl_card_view_ripple = 2131034833;
        /* added by DevToolsApp */
        public static final int mtrl_chip_background_color = 2131034834;
        /* added by DevToolsApp */
        public static final int mtrl_chip_close_icon_tint = 2131034835;
        /* added by DevToolsApp */
        public static final int mtrl_chip_surface_color = 2131034836;
        /* added by DevToolsApp */
        public static final int mtrl_chip_text_color = 2131034837;
        /* added by DevToolsApp */
        public static final int mtrl_choice_chip_background_color = 2131034838;
        /* added by DevToolsApp */
        public static final int mtrl_choice_chip_ripple_color = 2131034839;
        /* added by DevToolsApp */
        public static final int mtrl_choice_chip_text_color = 2131034840;
        /* added by DevToolsApp */
        public static final int mtrl_error = 2131034841;
        /* added by DevToolsApp */
        public static final int mtrl_fab_bg_color_selector = 2131034842;
        /* added by DevToolsApp */
        public static final int mtrl_fab_icon_text_color_selector = 2131034843;
        /* added by DevToolsApp */
        public static final int mtrl_fab_ripple_color = 2131034844;
        /* added by DevToolsApp */
        public static final int mtrl_filled_background_color = 2131034845;
        /* added by DevToolsApp */
        public static final int mtrl_filled_icon_tint = 2131034846;
        /* added by DevToolsApp */
        public static final int mtrl_filled_stroke_color = 2131034847;
        /* added by DevToolsApp */
        public static final int mtrl_indicator_text_color = 2131034848;
        /* added by DevToolsApp */
        public static final int mtrl_navigation_bar_colored_item_tint = 2131034849;
        /* added by DevToolsApp */
        public static final int mtrl_navigation_bar_colored_ripple_color = 2131034850;
        /* added by DevToolsApp */
        public static final int mtrl_navigation_bar_item_tint = 2131034851;
        /* added by DevToolsApp */
        public static final int mtrl_navigation_bar_ripple_color = 2131034852;
        /* added by DevToolsApp */
        public static final int mtrl_navigation_item_background_color = 2131034853;
        /* added by DevToolsApp */
        public static final int mtrl_navigation_item_icon_tint = 2131034854;
        /* added by DevToolsApp */
        public static final int mtrl_navigation_item_text_color = 2131034855;
        /* added by DevToolsApp */
        public static final int mtrl_on_primary_text_btn_text_color_selector = 2131034856;
        /* added by DevToolsApp */
        public static final int mtrl_on_surface_ripple_color = 2131034857;
        /* added by DevToolsApp */
        public static final int mtrl_outlined_icon_tint = 2131034858;
        /* added by DevToolsApp */
        public static final int mtrl_outlined_stroke_color = 2131034859;
        /* added by DevToolsApp */
        public static final int mtrl_popupmenu_overlay_color = 2131034860;
        /* added by DevToolsApp */
        public static final int mtrl_scrim_color = 2131034861;
        /* added by DevToolsApp */
        public static final int mtrl_switch_thumb_icon_tint = 2131034862;
        /* added by DevToolsApp */
        public static final int mtrl_switch_thumb_tint = 2131034863;
        /* added by DevToolsApp */
        public static final int mtrl_switch_track_decoration_tint = 2131034864;
        /* added by DevToolsApp */
        public static final int mtrl_switch_track_tint = 2131034865;
        /* added by DevToolsApp */
        public static final int mtrl_tabs_colored_ripple_color = 2131034866;
        /* added by DevToolsApp */
        public static final int mtrl_tabs_icon_color_selector = 2131034867;
        /* added by DevToolsApp */
        public static final int mtrl_tabs_icon_color_selector_colored = 2131034868;
        /* added by DevToolsApp */
        public static final int mtrl_tabs_legacy_text_color_selector = 2131034869;
        /* added by DevToolsApp */
        public static final int mtrl_tabs_ripple_color = 2131034870;
        /* added by DevToolsApp */
        public static final int mtrl_text_btn_text_color_selector = 2131034871;
        /* added by DevToolsApp */
        public static final int mtrl_textinput_default_box_stroke_color = 2131034872;
        /* added by DevToolsApp */
        public static final int mtrl_textinput_disabled_color = 2131034873;
        /* added by DevToolsApp */
        public static final int mtrl_textinput_filled_box_default_background_color = 2131034874;
        /* added by DevToolsApp */
        public static final int mtrl_textinput_focused_box_stroke_color = 2131034875;
        /* added by DevToolsApp */
        public static final int mtrl_textinput_hovered_box_stroke_color = 2131034876;
        /* added by DevToolsApp */
        public static final int notification_action_color_filter = 2131034877;
        /* added by DevToolsApp */
        public static final int notification_icon_bg_color = 2131034878;
        /* added by DevToolsApp */
        public static final int primary_dark_material_dark = 2131034880;
        /* added by DevToolsApp */
        public static final int primary_dark_material_light = 2131034881;
        /* added by DevToolsApp */
        public static final int primary_material_dark = 2131034882;
        /* added by DevToolsApp */
        public static final int primary_material_light = 2131034883;
        /* added by DevToolsApp */
        public static final int primary_text_default_material_dark = 2131034884;
        /* added by DevToolsApp */
        public static final int primary_text_default_material_light = 2131034885;
        /* added by DevToolsApp */
        public static final int primary_text_disabled_material_dark = 2131034886;
        /* added by DevToolsApp */
        public static final int primary_text_disabled_material_light = 2131034887;
        /* added by DevToolsApp */
        public static final int ripple_material_dark = 2131034889;
        /* added by DevToolsApp */
        public static final int ripple_material_light = 2131034890;
        /* added by DevToolsApp */
        public static final int secondary_text_default_material_dark = 2131034891;
        /* added by DevToolsApp */
        public static final int secondary_text_default_material_light = 2131034892;
        /* added by DevToolsApp */
        public static final int secondary_text_disabled_material_dark = 2131034893;
        /* added by DevToolsApp */
        public static final int secondary_text_disabled_material_light = 2131034894;
        /* added by DevToolsApp */
        public static final int switch_thumb_disabled_material_dark = 2131034895;
        /* added by DevToolsApp */
        public static final int switch_thumb_disabled_material_light = 2131034896;
        /* added by DevToolsApp */
        public static final int switch_thumb_material_dark = 2131034897;
        /* added by DevToolsApp */
        public static final int switch_thumb_material_light = 2131034898;
        /* added by DevToolsApp */
        public static final int switch_thumb_normal_material_dark = 2131034899;
        /* added by DevToolsApp */
        public static final int switch_thumb_normal_material_light = 2131034900;
        /* added by DevToolsApp */
        public static final int tooltip_background_dark = 2131034901;
        /* added by DevToolsApp */
        public static final int tooltip_background_light = 2131034902;

        private color() {
        }
    }

    public static final class drawable {
        public static int app2_background = 2131165304;
        public static int app_background = 2131165305;
        public static int au = 2131165306;
        public static int baseline_done_24 = 2131165309;
        public static int baseline_keyboard_arrow_right_24 = 2131165310;
        public static int button_main = 2131165319;
        public static int button_main_pressed = 2131165320;
        public static int button_main_un_pressed = 2131165321;
        public static int ca = 2131165322;
        public static int ch = 2131165323;
        public static int de = 2131165343;
        public static int design_background = 2131165344;
        public static int dk = 2131165350;
        public static int dollarclick_logo = 2131165351;
        public static int dollarclick_logo_blur = 2131165352;
        public static int fr = 2131165353;
        public static int green_background = 2131165356;
        public static int ic_launcher_background = 2131165367;
        public static int ic_launcher_foreground = 2131165368;
        public static int in = 2131165377;
        public static int jp = 2131165379;
        public static int nl = 2131165439;
        public static int no = 2131165440;
        public static int red_background = 2131165454;
        public static int se = 2131165455;
        public static int telegram = 2131165456;
        public static int uk = 2131165460;
        public static int unity = 2131165461;
        public static int us = 2131165462;
        public static int white_background = 2131165463;
        public static int white_corner = 2131165464;
        public static int yt = 2131165465;
        /* added by DevToolsApp */
        public static final int $avd_hide_password__0 = 2131165184;
        /* added by DevToolsApp */
        public static final int $avd_hide_password__1 = 2131165185;
        /* added by DevToolsApp */
        public static final int $avd_hide_password__2 = 2131165186;
        /* added by DevToolsApp */
        public static final int $avd_show_password__0 = 2131165187;
        /* added by DevToolsApp */
        public static final int $avd_show_password__1 = 2131165188;
        /* added by DevToolsApp */
        public static final int $avd_show_password__2 = 2131165189;
        /* added by DevToolsApp */
        public static final int $ic_launcher_foreground__0 = 2131165190;
        /* added by DevToolsApp */
        public static final int $m3_avd_hide_password__0 = 2131165191;
        /* added by DevToolsApp */
        public static final int $m3_avd_hide_password__1 = 2131165192;
        /* added by DevToolsApp */
        public static final int $m3_avd_hide_password__2 = 2131165193;
        /* added by DevToolsApp */
        public static final int $m3_avd_show_password__0 = 2131165194;
        /* added by DevToolsApp */
        public static final int $m3_avd_show_password__1 = 2131165195;
        /* added by DevToolsApp */
        public static final int $m3_avd_show_password__2 = 2131165196;
        /* added by DevToolsApp */
        public static final int $mtrl_checkbox_button_checked_unchecked__0 = 2131165197;
        /* added by DevToolsApp */
        public static final int $mtrl_checkbox_button_checked_unchecked__1 = 2131165198;
        /* added by DevToolsApp */
        public static final int $mtrl_checkbox_button_checked_unchecked__2 = 2131165199;
        /* added by DevToolsApp */
        public static final int $mtrl_checkbox_button_icon_checked_indeterminate__0 = 2131165200;
        /* added by DevToolsApp */
        public static final int $mtrl_checkbox_button_icon_checked_unchecked__0 = 2131165201;
        /* added by DevToolsApp */
        public static final int $mtrl_checkbox_button_icon_checked_unchecked__1 = 2131165202;
        /* added by DevToolsApp */
        public static final int $mtrl_checkbox_button_icon_checked_unchecked__2 = 2131165203;
        /* added by DevToolsApp */
        public static final int $mtrl_checkbox_button_icon_indeterminate_checked__0 = 2131165204;
        /* added by DevToolsApp */
        public static final int $mtrl_checkbox_button_icon_indeterminate_unchecked__0 = 2131165205;
        /* added by DevToolsApp */
        public static final int $mtrl_checkbox_button_icon_indeterminate_unchecked__1 = 2131165206;
        /* added by DevToolsApp */
        public static final int $mtrl_checkbox_button_icon_indeterminate_unchecked__2 = 2131165207;
        /* added by DevToolsApp */
        public static final int $mtrl_checkbox_button_icon_unchecked_checked__0 = 2131165208;
        /* added by DevToolsApp */
        public static final int $mtrl_checkbox_button_icon_unchecked_checked__1 = 2131165209;
        /* added by DevToolsApp */
        public static final int $mtrl_checkbox_button_icon_unchecked_checked__2 = 2131165210;
        /* added by DevToolsApp */
        public static final int $mtrl_checkbox_button_icon_unchecked_indeterminate__0 = 2131165211;
        /* added by DevToolsApp */
        public static final int $mtrl_checkbox_button_icon_unchecked_indeterminate__1 = 2131165212;
        /* added by DevToolsApp */
        public static final int $mtrl_checkbox_button_icon_unchecked_indeterminate__2 = 2131165213;
        /* added by DevToolsApp */
        public static final int $mtrl_checkbox_button_unchecked_checked__0 = 2131165214;
        /* added by DevToolsApp */
        public static final int $mtrl_checkbox_button_unchecked_checked__1 = 2131165215;
        /* added by DevToolsApp */
        public static final int $mtrl_checkbox_button_unchecked_checked__2 = 2131165216;
        /* added by DevToolsApp */
        public static final int $mtrl_switch_thumb_checked_pressed__0 = 2131165217;
        /* added by DevToolsApp */
        public static final int $mtrl_switch_thumb_checked_unchecked__0 = 2131165218;
        /* added by DevToolsApp */
        public static final int $mtrl_switch_thumb_checked_unchecked__1 = 2131165219;
        /* added by DevToolsApp */
        public static final int $mtrl_switch_thumb_pressed_checked__0 = 2131165220;
        /* added by DevToolsApp */
        public static final int $mtrl_switch_thumb_pressed_unchecked__0 = 2131165221;
        /* added by DevToolsApp */
        public static final int $mtrl_switch_thumb_unchecked_checked__0 = 2131165222;
        /* added by DevToolsApp */
        public static final int $mtrl_switch_thumb_unchecked_checked__1 = 2131165223;
        /* added by DevToolsApp */
        public static final int $mtrl_switch_thumb_unchecked_pressed__0 = 2131165224;
        /* added by DevToolsApp */
        public static final int abc_ab_share_pack_mtrl_alpha = 2131165225;
        /* added by DevToolsApp */
        public static final int abc_action_bar_item_background_material = 2131165226;
        /* added by DevToolsApp */
        public static final int abc_btn_borderless_material = 2131165227;
        /* added by DevToolsApp */
        public static final int abc_btn_check_material = 2131165228;
        /* added by DevToolsApp */
        public static final int abc_btn_check_material_anim = 2131165229;
        /* added by DevToolsApp */
        public static final int abc_btn_check_to_on_mtrl_000 = 2131165230;
        /* added by DevToolsApp */
        public static final int abc_btn_check_to_on_mtrl_015 = 2131165231;
        /* added by DevToolsApp */
        public static final int abc_btn_colored_material = 2131165232;
        /* added by DevToolsApp */
        public static final int abc_btn_default_mtrl_shape = 2131165233;
        /* added by DevToolsApp */
        public static final int abc_btn_radio_material = 2131165234;
        /* added by DevToolsApp */
        public static final int abc_btn_radio_material_anim = 2131165235;
        /* added by DevToolsApp */
        public static final int abc_btn_radio_to_on_mtrl_000 = 2131165236;
        /* added by DevToolsApp */
        public static final int abc_btn_radio_to_on_mtrl_015 = 2131165237;
        /* added by DevToolsApp */
        public static final int abc_btn_switch_to_on_mtrl_00001 = 2131165238;
        /* added by DevToolsApp */
        public static final int abc_btn_switch_to_on_mtrl_00012 = 2131165239;
        /* added by DevToolsApp */
        public static final int abc_cab_background_internal_bg = 2131165240;
        /* added by DevToolsApp */
        public static final int abc_cab_background_top_material = 2131165241;
        /* added by DevToolsApp */
        public static final int abc_cab_background_top_mtrl_alpha = 2131165242;
        /* added by DevToolsApp */
        public static final int abc_control_background_material = 2131165243;
        /* added by DevToolsApp */
        public static final int abc_dialog_material_background = 2131165244;
        /* added by DevToolsApp */
        public static final int abc_edit_text_material = 2131165245;
        /* added by DevToolsApp */
        public static final int abc_ic_ab_back_material = 2131165246;
        /* added by DevToolsApp */
        public static final int abc_ic_arrow_drop_right_black_24dp = 2131165247;
        /* added by DevToolsApp */
        public static final int abc_ic_clear_material = 2131165248;
        /* added by DevToolsApp */
        public static final int abc_ic_commit_search_api_mtrl_alpha = 2131165249;
        /* added by DevToolsApp */
        public static final int abc_ic_go_search_api_material = 2131165250;
        /* added by DevToolsApp */
        public static final int abc_ic_menu_copy_mtrl_am_alpha = 2131165251;
        /* added by DevToolsApp */
        public static final int abc_ic_menu_cut_mtrl_alpha = 2131165252;
        /* added by DevToolsApp */
        public static final int abc_ic_menu_overflow_material = 2131165253;
        /* added by DevToolsApp */
        public static final int abc_ic_menu_paste_mtrl_am_alpha = 2131165254;
        /* added by DevToolsApp */
        public static final int abc_ic_menu_selectall_mtrl_alpha = 2131165255;
        /* added by DevToolsApp */
        public static final int abc_ic_menu_share_mtrl_alpha = 2131165256;
        /* added by DevToolsApp */
        public static final int abc_ic_search_api_material = 2131165257;
        /* added by DevToolsApp */
        public static final int abc_ic_voice_search_api_material = 2131165258;
        /* added by DevToolsApp */
        public static final int abc_item_background_holo_dark = 2131165259;
        /* added by DevToolsApp */
        public static final int abc_item_background_holo_light = 2131165260;
        /* added by DevToolsApp */
        public static final int abc_list_divider_material = 2131165261;
        /* added by DevToolsApp */
        public static final int abc_list_divider_mtrl_alpha = 2131165262;
        /* added by DevToolsApp */
        public static final int abc_list_focused_holo = 2131165263;
        /* added by DevToolsApp */
        public static final int abc_list_longpressed_holo = 2131165264;
        /* added by DevToolsApp */
        public static final int abc_list_pressed_holo_dark = 2131165265;
        /* added by DevToolsApp */
        public static final int abc_list_pressed_holo_light = 2131165266;
        /* added by DevToolsApp */
        public static final int abc_list_selector_background_transition_holo_dark = 2131165267;
        /* added by DevToolsApp */
        public static final int abc_list_selector_background_transition_holo_light = 2131165268;
        /* added by DevToolsApp */
        public static final int abc_list_selector_disabled_holo_dark = 2131165269;
        /* added by DevToolsApp */
        public static final int abc_list_selector_disabled_holo_light = 2131165270;
        /* added by DevToolsApp */
        public static final int abc_list_selector_holo_dark = 2131165271;
        /* added by DevToolsApp */
        public static final int abc_list_selector_holo_light = 2131165272;
        /* added by DevToolsApp */
        public static final int abc_menu_hardkey_panel_mtrl_mult = 2131165273;
        /* added by DevToolsApp */
        public static final int abc_popup_background_mtrl_mult = 2131165274;
        /* added by DevToolsApp */
        public static final int abc_ratingbar_indicator_material = 2131165275;
        /* added by DevToolsApp */
        public static final int abc_ratingbar_material = 2131165276;
        /* added by DevToolsApp */
        public static final int abc_ratingbar_small_material = 2131165277;
        /* added by DevToolsApp */
        public static final int abc_scrubber_control_off_mtrl_alpha = 2131165278;
        /* added by DevToolsApp */
        public static final int abc_scrubber_control_to_pressed_mtrl_000 = 2131165279;
        /* added by DevToolsApp */
        public static final int abc_scrubber_control_to_pressed_mtrl_005 = 2131165280;
        /* added by DevToolsApp */
        public static final int abc_scrubber_primary_mtrl_alpha = 2131165281;
        /* added by DevToolsApp */
        public static final int abc_scrubber_track_mtrl_alpha = 2131165282;
        /* added by DevToolsApp */
        public static final int abc_seekbar_thumb_material = 2131165283;
        /* added by DevToolsApp */
        public static final int abc_seekbar_tick_mark_material = 2131165284;
        /* added by DevToolsApp */
        public static final int abc_seekbar_track_material = 2131165285;
        /* added by DevToolsApp */
        public static final int abc_spinner_mtrl_am_alpha = 2131165286;
        /* added by DevToolsApp */
        public static final int abc_spinner_textfield_background_material = 2131165287;
        /* added by DevToolsApp */
        public static final int abc_star_black_48dp = 2131165288;
        /* added by DevToolsApp */
        public static final int abc_star_half_black_48dp = 2131165289;
        /* added by DevToolsApp */
        public static final int abc_switch_thumb_material = 2131165290;
        /* added by DevToolsApp */
        public static final int abc_switch_track_mtrl_alpha = 2131165291;
        /* added by DevToolsApp */
        public static final int abc_tab_indicator_material = 2131165292;
        /* added by DevToolsApp */
        public static final int abc_tab_indicator_mtrl_alpha = 2131165293;
        /* added by DevToolsApp */
        public static final int abc_text_cursor_material = 2131165294;
        /* added by DevToolsApp */
        public static final int abc_text_select_handle_left_mtrl = 2131165295;
        /* added by DevToolsApp */
        public static final int abc_text_select_handle_middle_mtrl = 2131165296;
        /* added by DevToolsApp */
        public static final int abc_text_select_handle_right_mtrl = 2131165297;
        /* added by DevToolsApp */
        public static final int abc_textfield_activated_mtrl_alpha = 2131165298;
        /* added by DevToolsApp */
        public static final int abc_textfield_default_mtrl_alpha = 2131165299;
        /* added by DevToolsApp */
        public static final int abc_textfield_search_activated_mtrl_alpha = 2131165300;
        /* added by DevToolsApp */
        public static final int abc_textfield_search_default_mtrl_alpha = 2131165301;
        /* added by DevToolsApp */
        public static final int abc_textfield_search_material = 2131165302;
        /* added by DevToolsApp */
        public static final int abc_vector_test = 2131165303;
        /* added by DevToolsApp */
        public static final int avd_hide_password = 2131165307;
        /* added by DevToolsApp */
        public static final int avd_show_password = 2131165308;
        /* added by DevToolsApp */
        public static final int btn_checkbox_checked_mtrl = 2131165311;
        /* added by DevToolsApp */
        public static final int btn_checkbox_checked_to_unchecked_mtrl_animation = 2131165312;
        /* added by DevToolsApp */
        public static final int btn_checkbox_unchecked_mtrl = 2131165313;
        /* added by DevToolsApp */
        public static final int btn_checkbox_unchecked_to_checked_mtrl_animation = 2131165314;
        /* added by DevToolsApp */
        public static final int btn_radio_off_mtrl = 2131165315;
        /* added by DevToolsApp */
        public static final int btn_radio_off_to_on_mtrl_animation = 2131165316;
        /* added by DevToolsApp */
        public static final int btn_radio_on_mtrl = 2131165317;
        /* added by DevToolsApp */
        public static final int btn_radio_on_to_off_mtrl_animation = 2131165318;
        /* added by DevToolsApp */
        public static final int common_full_open_on_phone = 2131165324;
        /* added by DevToolsApp */
        public static final int common_google_signin_btn_icon_dark = 2131165325;
        /* added by DevToolsApp */
        public static final int common_google_signin_btn_icon_dark_focused = 2131165326;
        /* added by DevToolsApp */
        public static final int common_google_signin_btn_icon_dark_normal = 2131165327;
        /* added by DevToolsApp */
        public static final int common_google_signin_btn_icon_dark_normal_background = 2131165328;
        /* added by DevToolsApp */
        public static final int common_google_signin_btn_icon_disabled = 2131165329;
        /* added by DevToolsApp */
        public static final int common_google_signin_btn_icon_light = 2131165330;
        /* added by DevToolsApp */
        public static final int common_google_signin_btn_icon_light_focused = 2131165331;
        /* added by DevToolsApp */
        public static final int common_google_signin_btn_icon_light_normal = 2131165332;
        /* added by DevToolsApp */
        public static final int common_google_signin_btn_icon_light_normal_background = 2131165333;
        /* added by DevToolsApp */
        public static final int common_google_signin_btn_text_dark = 2131165334;
        /* added by DevToolsApp */
        public static final int common_google_signin_btn_text_dark_focused = 2131165335;
        /* added by DevToolsApp */
        public static final int common_google_signin_btn_text_dark_normal = 2131165336;
        /* added by DevToolsApp */
        public static final int common_google_signin_btn_text_dark_normal_background = 2131165337;
        /* added by DevToolsApp */
        public static final int common_google_signin_btn_text_disabled = 2131165338;
        /* added by DevToolsApp */
        public static final int common_google_signin_btn_text_light = 2131165339;
        /* added by DevToolsApp */
        public static final int common_google_signin_btn_text_light_focused = 2131165340;
        /* added by DevToolsApp */
        public static final int common_google_signin_btn_text_light_normal = 2131165341;
        /* added by DevToolsApp */
        public static final int common_google_signin_btn_text_light_normal_background = 2131165342;
        /* added by DevToolsApp */
        public static final int design_fab_background = 2131165345;
        /* added by DevToolsApp */
        public static final int design_ic_visibility = 2131165346;
        /* added by DevToolsApp */
        public static final int design_ic_visibility_off = 2131165347;
        /* added by DevToolsApp */
        public static final int design_password_eye = 2131165348;
        /* added by DevToolsApp */
        public static final int design_snackbar_background = 2131165349;
        /* added by DevToolsApp */
        public static final int googleg_disabled_color_18 = 2131165354;
        /* added by DevToolsApp */
        public static final int googleg_standard_color_18 = 2131165355;
        /* added by DevToolsApp */
        public static final int ic_arrow_back_black_24 = 2131165357;
        /* added by DevToolsApp */
        public static final int ic_call_answer = 2131165358;
        /* added by DevToolsApp */
        public static final int ic_call_answer_low = 2131165359;
        /* added by DevToolsApp */
        public static final int ic_call_answer_video = 2131165360;
        /* added by DevToolsApp */
        public static final int ic_call_answer_video_low = 2131165361;
        /* added by DevToolsApp */
        public static final int ic_call_decline = 2131165362;
        /* added by DevToolsApp */
        public static final int ic_call_decline_low = 2131165363;
        /* added by DevToolsApp */
        public static final int ic_clear_black_24 = 2131165364;
        /* added by DevToolsApp */
        public static final int ic_clock_black_24dp = 2131165365;
        /* added by DevToolsApp */
        public static final int ic_keyboard_black_24dp = 2131165366;
        /* added by DevToolsApp */
        public static final int ic_m3_chip_check = 2131165369;
        /* added by DevToolsApp */
        public static final int ic_m3_chip_checked_circle = 2131165370;
        /* added by DevToolsApp */
        public static final int ic_m3_chip_close = 2131165371;
        /* added by DevToolsApp */
        public static final int ic_mtrl_checked_circle = 2131165372;
        /* added by DevToolsApp */
        public static final int ic_mtrl_chip_checked_black = 2131165373;
        /* added by DevToolsApp */
        public static final int ic_mtrl_chip_checked_circle = 2131165374;
        /* added by DevToolsApp */
        public static final int ic_mtrl_chip_close_circle = 2131165375;
        /* added by DevToolsApp */
        public static final int ic_search_black_24 = 2131165376;
        /* added by DevToolsApp */
        public static final int indeterminate_static = 2131165378;
        /* added by DevToolsApp */
        public static final int m3_avd_hide_password = 2131165380;
        /* added by DevToolsApp */
        public static final int m3_avd_show_password = 2131165381;
        /* added by DevToolsApp */
        public static final int m3_bottom_sheet_drag_handle = 2131165382;
        /* added by DevToolsApp */
        public static final int m3_password_eye = 2131165383;
        /* added by DevToolsApp */
        public static final int m3_popupmenu_background_overlay = 2131165384;
        /* added by DevToolsApp */
        public static final int m3_radiobutton_ripple = 2131165385;
        /* added by DevToolsApp */
        public static final int m3_selection_control_ripple = 2131165386;
        /* added by DevToolsApp */
        public static final int m3_tabs_background = 2131165387;
        /* added by DevToolsApp */
        public static final int m3_tabs_line_indicator = 2131165388;
        /* added by DevToolsApp */
        public static final int m3_tabs_rounded_line_indicator = 2131165389;
        /* added by DevToolsApp */
        public static final int m3_tabs_transparent_background = 2131165390;
        /* added by DevToolsApp */
        public static final int material_cursor_drawable = 2131165391;
        /* added by DevToolsApp */
        public static final int material_ic_calendar_black_24dp = 2131165392;
        /* added by DevToolsApp */
        public static final int material_ic_clear_black_24dp = 2131165393;
        /* added by DevToolsApp */
        public static final int material_ic_edit_black_24dp = 2131165394;
        /* added by DevToolsApp */
        public static final int material_ic_keyboard_arrow_left_black_24dp = 2131165395;
        /* added by DevToolsApp */
        public static final int material_ic_keyboard_arrow_next_black_24dp = 2131165396;
        /* added by DevToolsApp */
        public static final int material_ic_keyboard_arrow_previous_black_24dp = 2131165397;
        /* added by DevToolsApp */
        public static final int material_ic_keyboard_arrow_right_black_24dp = 2131165398;
        /* added by DevToolsApp */
        public static final int material_ic_menu_arrow_down_black_24dp = 2131165399;
        /* added by DevToolsApp */
        public static final int material_ic_menu_arrow_up_black_24dp = 2131165400;
        /* added by DevToolsApp */
        public static final int mtrl_bottomsheet_drag_handle = 2131165401;
        /* added by DevToolsApp */
        public static final int mtrl_checkbox_button = 2131165402;
        /* added by DevToolsApp */
        public static final int mtrl_checkbox_button_checked_unchecked = 2131165403;
        /* added by DevToolsApp */
        public static final int mtrl_checkbox_button_icon = 2131165404;
        /* added by DevToolsApp */
        public static final int mtrl_checkbox_button_icon_checked_indeterminate = 2131165405;
        /* added by DevToolsApp */
        public static final int mtrl_checkbox_button_icon_checked_unchecked = 2131165406;
        /* added by DevToolsApp */
        public static final int mtrl_checkbox_button_icon_indeterminate_checked = 2131165407;
        /* added by DevToolsApp */
        public static final int mtrl_checkbox_button_icon_indeterminate_unchecked = 2131165408;
        /* added by DevToolsApp */
        public static final int mtrl_checkbox_button_icon_unchecked_checked = 2131165409;
        /* added by DevToolsApp */
        public static final int mtrl_checkbox_button_icon_unchecked_indeterminate = 2131165410;
        /* added by DevToolsApp */
        public static final int mtrl_checkbox_button_unchecked_checked = 2131165411;
        /* added by DevToolsApp */
        public static final int mtrl_dialog_background = 2131165412;
        /* added by DevToolsApp */
        public static final int mtrl_dropdown_arrow = 2131165413;
        /* added by DevToolsApp */
        public static final int mtrl_ic_arrow_drop_down = 2131165414;
        /* added by DevToolsApp */
        public static final int mtrl_ic_arrow_drop_up = 2131165415;
        /* added by DevToolsApp */
        public static final int mtrl_ic_cancel = 2131165416;
        /* added by DevToolsApp */
        public static final int mtrl_ic_check_mark = 2131165417;
        /* added by DevToolsApp */
        public static final int mtrl_ic_checkbox_checked = 2131165418;
        /* added by DevToolsApp */
        public static final int mtrl_ic_checkbox_unchecked = 2131165419;
        /* added by DevToolsApp */
        public static final int mtrl_ic_error = 2131165420;
        /* added by DevToolsApp */
        public static final int mtrl_ic_indeterminate = 2131165421;
        /* added by DevToolsApp */
        public static final int mtrl_navigation_bar_item_background = 2131165422;
        /* added by DevToolsApp */
        public static final int mtrl_popupmenu_background = 2131165423;
        /* added by DevToolsApp */
        public static final int mtrl_popupmenu_background_overlay = 2131165424;
        /* added by DevToolsApp */
        public static final int mtrl_switch_thumb = 2131165425;
        /* added by DevToolsApp */
        public static final int mtrl_switch_thumb_checked = 2131165426;
        /* added by DevToolsApp */
        public static final int mtrl_switch_thumb_checked_pressed = 2131165427;
        /* added by DevToolsApp */
        public static final int mtrl_switch_thumb_checked_unchecked = 2131165428;
        /* added by DevToolsApp */
        public static final int mtrl_switch_thumb_pressed = 2131165429;
        /* added by DevToolsApp */
        public static final int mtrl_switch_thumb_pressed_checked = 2131165430;
        /* added by DevToolsApp */
        public static final int mtrl_switch_thumb_pressed_unchecked = 2131165431;
        /* added by DevToolsApp */
        public static final int mtrl_switch_thumb_unchecked = 2131165432;
        /* added by DevToolsApp */
        public static final int mtrl_switch_thumb_unchecked_checked = 2131165433;
        /* added by DevToolsApp */
        public static final int mtrl_switch_thumb_unchecked_pressed = 2131165434;
        /* added by DevToolsApp */
        public static final int mtrl_switch_track = 2131165435;
        /* added by DevToolsApp */
        public static final int mtrl_switch_track_decoration = 2131165436;
        /* added by DevToolsApp */
        public static final int mtrl_tabs_default_indicator = 2131165437;
        /* added by DevToolsApp */
        public static final int navigation_empty_icon = 2131165438;
        /* added by DevToolsApp */
        public static final int notification_action_background = 2131165441;
        /* added by DevToolsApp */
        public static final int notification_bg = 2131165442;
        /* added by DevToolsApp */
        public static final int notification_bg_low = 2131165443;
        /* added by DevToolsApp */
        public static final int notification_bg_low_normal = 2131165444;
        /* added by DevToolsApp */
        public static final int notification_bg_low_pressed = 2131165445;
        /* added by DevToolsApp */
        public static final int notification_bg_normal = 2131165446;
        /* added by DevToolsApp */
        public static final int notification_bg_normal_pressed = 2131165447;
        /* added by DevToolsApp */
        public static final int notification_icon_background = 2131165448;
        /* added by DevToolsApp */
        public static final int notification_oversize_large_icon_bg = 2131165449;
        /* added by DevToolsApp */
        public static final int notification_template_icon_bg = 2131165450;
        /* added by DevToolsApp */
        public static final int notification_template_icon_low_bg = 2131165451;
        /* added by DevToolsApp */
        public static final int notification_tile_bg = 2131165452;
        /* added by DevToolsApp */
        public static final int notify_panel_notification_icon_bg = 2131165453;
        /* added by DevToolsApp */
        public static final int test_level_drawable = 2131165457;
        /* added by DevToolsApp */
        public static final int tooltip_frame_dark = 2131165458;
        /* added by DevToolsApp */
        public static final int tooltip_frame_light = 2131165459;

        private drawable() {
        }
    }

    public static final class font {
        public static int app_font = 2131230720;

        private font() {
        }
    }

    public static final class id {
        public static int CountryTxt = 2131296260;
        public static int appName = 2131296340;
        public static int btnUpdateNow = 2131296361;
        public static int btn_BuyKey = 2131296362;
        public static int btn_CheckKey = 2131296363;
        public static int btn_SkipKey = 2131296364;
        public static int btn_interstitial = 2131296365;
        public static int btn_joinTL = 2131296366;
        public static int btn_rewarded = 2131296367;
        public static int btn_subscribeYT = 2131296368;
        public static int countryImg = 2131296403;
        public static int dialogLayout = 2131296422;
        public static int imageView = 2131296497;
        public static int imageView2 = 2131296498;
        public static int imageView3 = 2131296499;
        public static int ipConnection = 2131296506;
        public static int isVpnConnectedTxt = 2131296507;
        public static int linearLayout = 2131296521;
        public static int linearLayout2 = 2131296522;
        public static int linearLayout3 = 2131296523;
        public static int linearLayout4 = 2131296524;
        public static int ll_vpnInfo = 2131296527;
        public static int main = 2131296529;
        public static int parentTxt = 2131296632;
        public static int progressBar = 2131296643;
        public static int txt_adCondition = 2131296767;
        public static int txt_adWatched = 2131296768;
        public static int txt_developerInfo = 2131296769;
        public static int txt_ecpm = 2131296770;
        public static int txt_loadingVpnInfo = 2131296771;
        public static int txt_logs = 2131296772;
        public static int txt_lowECPM = 2131296773;
        public static int txt_unityID = 2131296774;
        public static int txt_vpnInfo = 2131296775;
        public static int txt_vpnInfo1 = 2131296776;
        public static int txt_vpnInfo3 = 2131296777;
        public static int updateMessage = 2131296782;
        public static int updateTitle = 2131296783;
        public static int username_edittext = 2131296785;
        /* added by DevToolsApp */
        public static final int ALT = 2131296256;
        /* added by DevToolsApp */
        public static final int BOTTOM_END = 2131296257;
        /* added by DevToolsApp */
        public static final int BOTTOM_START = 2131296258;
        /* added by DevToolsApp */
        public static final int CTRL = 2131296259;
        /* added by DevToolsApp */
        public static final int FUNCTION = 2131296261;
        /* added by DevToolsApp */
        public static final int META = 2131296262;
        /* added by DevToolsApp */
        public static final int NO_DEBUG = 2131296263;
        /* added by DevToolsApp */
        public static final int SHIFT = 2131296264;
        /* added by DevToolsApp */
        public static final int SHOW_ALL = 2131296265;
        /* added by DevToolsApp */
        public static final int SHOW_PATH = 2131296266;
        /* added by DevToolsApp */
        public static final int SHOW_PROGRESS = 2131296267;
        /* added by DevToolsApp */
        public static final int SYM = 2131296268;
        /* added by DevToolsApp */
        public static final int TOP_END = 2131296269;
        /* added by DevToolsApp */
        public static final int TOP_START = 2131296270;
        /* added by DevToolsApp */
        public static final int above = 2131296271;
        /* added by DevToolsApp */
        public static final int accelerate = 2131296272;
        /* added by DevToolsApp */
        public static final int accessibility_action_clickable_span = 2131296273;
        /* added by DevToolsApp */
        public static final int accessibility_custom_action_0 = 2131296274;
        /* added by DevToolsApp */
        public static final int accessibility_custom_action_1 = 2131296275;
        /* added by DevToolsApp */
        public static final int accessibility_custom_action_10 = 2131296276;
        /* added by DevToolsApp */
        public static final int accessibility_custom_action_11 = 2131296277;
        /* added by DevToolsApp */
        public static final int accessibility_custom_action_12 = 2131296278;
        /* added by DevToolsApp */
        public static final int accessibility_custom_action_13 = 2131296279;
        /* added by DevToolsApp */
        public static final int accessibility_custom_action_14 = 2131296280;
        /* added by DevToolsApp */
        public static final int accessibility_custom_action_15 = 2131296281;
        /* added by DevToolsApp */
        public static final int accessibility_custom_action_16 = 2131296282;
        /* added by DevToolsApp */
        public static final int accessibility_custom_action_17 = 2131296283;
        /* added by DevToolsApp */
        public static final int accessibility_custom_action_18 = 2131296284;
        /* added by DevToolsApp */
        public static final int accessibility_custom_action_19 = 2131296285;
        /* added by DevToolsApp */
        public static final int accessibility_custom_action_2 = 2131296286;
        /* added by DevToolsApp */
        public static final int accessibility_custom_action_20 = 2131296287;
        /* added by DevToolsApp */
        public static final int accessibility_custom_action_21 = 2131296288;
        /* added by DevToolsApp */
        public static final int accessibility_custom_action_22 = 2131296289;
        /* added by DevToolsApp */
        public static final int accessibility_custom_action_23 = 2131296290;
        /* added by DevToolsApp */
        public static final int accessibility_custom_action_24 = 2131296291;
        /* added by DevToolsApp */
        public static final int accessibility_custom_action_25 = 2131296292;
        /* added by DevToolsApp */
        public static final int accessibility_custom_action_26 = 2131296293;
        /* added by DevToolsApp */
        public static final int accessibility_custom_action_27 = 2131296294;
        /* added by DevToolsApp */
        public static final int accessibility_custom_action_28 = 2131296295;
        /* added by DevToolsApp */
        public static final int accessibility_custom_action_29 = 2131296296;
        /* added by DevToolsApp */
        public static final int accessibility_custom_action_3 = 2131296297;
        /* added by DevToolsApp */
        public static final int accessibility_custom_action_30 = 2131296298;
        /* added by DevToolsApp */
        public static final int accessibility_custom_action_31 = 2131296299;
        /* added by DevToolsApp */
        public static final int accessibility_custom_action_4 = 2131296300;
        /* added by DevToolsApp */
        public static final int accessibility_custom_action_5 = 2131296301;
        /* added by DevToolsApp */
        public static final int accessibility_custom_action_6 = 2131296302;
        /* added by DevToolsApp */
        public static final int accessibility_custom_action_7 = 2131296303;
        /* added by DevToolsApp */
        public static final int accessibility_custom_action_8 = 2131296304;
        /* added by DevToolsApp */
        public static final int accessibility_custom_action_9 = 2131296305;
        /* added by DevToolsApp */
        public static final int actionDown = 2131296306;
        /* added by DevToolsApp */
        public static final int actionDownUp = 2131296307;
        /* added by DevToolsApp */
        public static final int actionUp = 2131296308;
        /* added by DevToolsApp */
        public static final int action_bar = 2131296309;
        /* added by DevToolsApp */
        public static final int action_bar_activity_content = 2131296310;
        /* added by DevToolsApp */
        public static final int action_bar_container = 2131296311;
        /* added by DevToolsApp */
        public static final int action_bar_root = 2131296312;
        /* added by DevToolsApp */
        public static final int action_bar_spinner = 2131296313;
        /* added by DevToolsApp */
        public static final int action_bar_subtitle = 2131296314;
        /* added by DevToolsApp */
        public static final int action_bar_title = 2131296315;
        /* added by DevToolsApp */
        public static final int action_container = 2131296316;
        /* added by DevToolsApp */
        public static final int action_context_bar = 2131296317;
        /* added by DevToolsApp */
        public static final int action_divider = 2131296318;
        /* added by DevToolsApp */
        public static final int action_image = 2131296319;
        /* added by DevToolsApp */
        public static final int action_menu_divider = 2131296320;
        /* added by DevToolsApp */
        public static final int action_menu_presenter = 2131296321;
        /* added by DevToolsApp */
        public static final int action_mode_bar = 2131296322;
        /* added by DevToolsApp */
        public static final int action_mode_bar_stub = 2131296323;
        /* added by DevToolsApp */
        public static final int action_mode_close_button = 2131296324;
        /* added by DevToolsApp */
        public static final int action_text = 2131296325;
        /* added by DevToolsApp */
        public static final int actions = 2131296326;
        /* added by DevToolsApp */
        public static final int activity_chooser_view_content = 2131296327;
        /* added by DevToolsApp */
        public static final int add = 2131296328;
        /* added by DevToolsApp */
        public static final int adjust_height = 2131296329;
        /* added by DevToolsApp */
        public static final int adjust_width = 2131296330;
        /* added by DevToolsApp */
        public static final int alertTitle = 2131296331;
        /* added by DevToolsApp */
        public static final int aligned = 2131296332;
        /* added by DevToolsApp */
        public static final int all = 2131296333;
        /* added by DevToolsApp */
        public static final int allStates = 2131296334;
        /* added by DevToolsApp */
        public static final int always = 2131296335;
        /* added by DevToolsApp */
        public static final int animateToEnd = 2131296336;
        /* added by DevToolsApp */
        public static final int animateToStart = 2131296337;
        /* added by DevToolsApp */
        public static final int antiClockwise = 2131296338;
        /* added by DevToolsApp */
        public static final int anticipate = 2131296339;
        /* added by DevToolsApp */
        public static final int arc = 2131296341;
        /* added by DevToolsApp */
        public static final int asConfigured = 2131296342;
        /* added by DevToolsApp */
        public static final int async = 2131296343;
        /* added by DevToolsApp */
        public static final int auto = 2131296344;
        /* added by DevToolsApp */
        public static final int autoComplete = 2131296345;
        /* added by DevToolsApp */
        public static final int autoCompleteToEnd = 2131296346;
        /* added by DevToolsApp */
        public static final int autoCompleteToStart = 2131296347;
        /* added by DevToolsApp */
        public static final int axisRelative = 2131296348;
        /* added by DevToolsApp */
        public static final int barrier = 2131296349;
        /* added by DevToolsApp */
        public static final int baseline = 2131296350;
        /* added by DevToolsApp */
        public static final int beginOnFirstDraw = 2131296351;
        /* added by DevToolsApp */
        public static final int beginning = 2131296352;
        /* added by DevToolsApp */
        public static final int below = 2131296353;
        /* added by DevToolsApp */
        public static final int bestChoice = 2131296354;
        /* added by DevToolsApp */
        public static final int blocking = 2131296355;
        /* added by DevToolsApp */
        public static final int bottom = 2131296356;
        /* added by DevToolsApp */
        public static final int bounce = 2131296357;
        /* added by DevToolsApp */
        public static final int bounceBoth = 2131296358;
        /* added by DevToolsApp */
        public static final int bounceEnd = 2131296359;
        /* added by DevToolsApp */
        public static final int bounceStart = 2131296360;
        /* added by DevToolsApp */
        public static final int buttonPanel = 2131296369;
        /* added by DevToolsApp */
        public static final int cache_measures = 2131296370;
        /* added by DevToolsApp */
        public static final int callMeasure = 2131296371;
        /* added by DevToolsApp */
        public static final int cancel_button = 2131296372;
        /* added by DevToolsApp */
        public static final int carryVelocity = 2131296373;
        /* added by DevToolsApp */
        public static final int center = 2131296374;
        /* added by DevToolsApp */
        public static final int centerCrop = 2131296375;
        /* added by DevToolsApp */
        public static final int centerInside = 2131296376;
        /* added by DevToolsApp */
        public static final int center_horizontal = 2131296377;
        /* added by DevToolsApp */
        public static final int center_vertical = 2131296378;
        /* added by DevToolsApp */
        public static final int chain = 2131296379;
        /* added by DevToolsApp */
        public static final int chain2 = 2131296380;
        /* added by DevToolsApp */
        public static final int chains = 2131296381;
        /* added by DevToolsApp */
        public static final int checkbox = 2131296382;
        /* added by DevToolsApp */
        public static final int checked = 2131296383;
        /* added by DevToolsApp */
        public static final int chronometer = 2131296384;
        /* added by DevToolsApp */
        public static final int circle_center = 2131296385;
        /* added by DevToolsApp */
        public static final int clear_text = 2131296386;
        /* added by DevToolsApp */
        public static final int clip_horizontal = 2131296387;
        /* added by DevToolsApp */
        public static final int clip_vertical = 2131296388;
        /* added by DevToolsApp */
        public static final int clockwise = 2131296389;
        /* added by DevToolsApp */
        public static final int closest = 2131296390;
        /* added by DevToolsApp */
        public static final int collapseActionView = 2131296391;
        /* added by DevToolsApp */
        public static final int compress = 2131296392;
        /* added by DevToolsApp */
        public static final int confirm_button = 2131296393;
        /* added by DevToolsApp */
        public static final int constraint = 2131296394;
        /* added by DevToolsApp */
        public static final int container = 2131296395;
        /* added by DevToolsApp */
        public static final int content = 2131296396;
        /* added by DevToolsApp */
        public static final int contentPanel = 2131296397;
        /* added by DevToolsApp */
        public static final int contiguous = 2131296398;
        /* added by DevToolsApp */
        public static final int continuousVelocity = 2131296399;
        /* added by DevToolsApp */
        public static final int coordinator = 2131296400;
        /* added by DevToolsApp */
        public static final int cos = 2131296401;
        /* added by DevToolsApp */
        public static final int counterclockwise = 2131296402;
        /* added by DevToolsApp */
        public static final int cradle = 2131296404;
        /* added by DevToolsApp */
        public static final int currentState = 2131296405;
        /* added by DevToolsApp */
        public static final int custom = 2131296406;
        /* added by DevToolsApp */
        public static final int customPanel = 2131296407;
        /* added by DevToolsApp */
        public static final int cut = 2131296408;
        /* added by DevToolsApp */
        public static final int dark = 2131296409;
        /* added by DevToolsApp */
        public static final int date_picker_actions = 2131296410;
        /* added by DevToolsApp */
        public static final int decelerate = 2131296411;
        /* added by DevToolsApp */
        public static final int decelerateAndComplete = 2131296412;
        /* added by DevToolsApp */
        public static final int decor_content_parent = 2131296413;
        /* added by DevToolsApp */
        public static final int default_activity_button = 2131296414;
        /* added by DevToolsApp */
        public static final int deltaRelative = 2131296415;
        /* added by DevToolsApp */
        public static final int dependency_ordering = 2131296416;
        /* added by DevToolsApp */
        public static final int design_bottom_sheet = 2131296417;
        /* added by DevToolsApp */
        public static final int design_menu_item_action_area = 2131296418;
        /* added by DevToolsApp */
        public static final int design_menu_item_action_area_stub = 2131296419;
        /* added by DevToolsApp */
        public static final int design_menu_item_text = 2131296420;
        /* added by DevToolsApp */
        public static final int design_navigation_view = 2131296421;
        /* added by DevToolsApp */
        public static final int dialog_button = 2131296423;
        /* added by DevToolsApp */
        public static final int dimensions = 2131296424;
        /* added by DevToolsApp */
        public static final int direct = 2131296425;
        /* added by DevToolsApp */
        public static final int disableHome = 2131296426;
        /* added by DevToolsApp */
        public static final int disableIntraAutoTransition = 2131296427;
        /* added by DevToolsApp */
        public static final int disablePostScroll = 2131296428;
        /* added by DevToolsApp */
        public static final int disableScroll = 2131296429;
        /* added by DevToolsApp */
        public static final int disjoint = 2131296430;
        /* added by DevToolsApp */
        public static final int dragAnticlockwise = 2131296431;
        /* added by DevToolsApp */
        public static final int dragClockwise = 2131296432;
        /* added by DevToolsApp */
        public static final int dragDown = 2131296433;
        /* added by DevToolsApp */
        public static final int dragEnd = 2131296434;
        /* added by DevToolsApp */
        public static final int dragLeft = 2131296435;
        /* added by DevToolsApp */
        public static final int dragRight = 2131296436;
        /* added by DevToolsApp */
        public static final int dragStart = 2131296437;
        /* added by DevToolsApp */
        public static final int dragUp = 2131296438;
        /* added by DevToolsApp */
        public static final int dropdown_menu = 2131296439;
        /* added by DevToolsApp */
        public static final int easeIn = 2131296440;
        /* added by DevToolsApp */
        public static final int easeInOut = 2131296441;
        /* added by DevToolsApp */
        public static final int easeOut = 2131296442;
        /* added by DevToolsApp */
        public static final int east = 2131296443;
        /* added by DevToolsApp */
        public static final int edge = 2131296444;
        /* added by DevToolsApp */
        public static final int edit_query = 2131296445;
        /* added by DevToolsApp */
        public static final int edit_text_id = 2131296446;
        /* added by DevToolsApp */
        public static final int elastic = 2131296447;
        /* added by DevToolsApp */
        public static final int embed = 2131296448;
        /* added by DevToolsApp */
        public static final int end = 2131296449;
        /* added by DevToolsApp */
        public static final int endToStart = 2131296450;
        /* added by DevToolsApp */
        public static final int enterAlways = 2131296451;
        /* added by DevToolsApp */
        public static final int enterAlwaysCollapsed = 2131296452;
        /* added by DevToolsApp */
        public static final int escape = 2131296453;
        /* added by DevToolsApp */
        public static final int exitUntilCollapsed = 2131296454;
        /* added by DevToolsApp */
        public static final int expand_activities_button = 2131296455;
        /* added by DevToolsApp */
        public static final int expanded_menu = 2131296456;
        /* added by DevToolsApp */
        public static final int fade = 2131296457;
        /* added by DevToolsApp */
        public static final int fill = 2131296458;
        /* added by DevToolsApp */
        public static final int fill_horizontal = 2131296459;
        /* added by DevToolsApp */
        public static final int fill_vertical = 2131296460;
        /* added by DevToolsApp */
        public static final int filled = 2131296461;
        /* added by DevToolsApp */
        public static final int fitCenter = 2131296462;
        /* added by DevToolsApp */
        public static final int fitEnd = 2131296463;
        /* added by DevToolsApp */
        public static final int fitStart = 2131296464;
        /* added by DevToolsApp */
        public static final int fitToContents = 2131296465;
        /* added by DevToolsApp */
        public static final int fitXY = 2131296466;
        /* added by DevToolsApp */
        public static final int fixed = 2131296467;
        /* added by DevToolsApp */
        public static final int flip = 2131296468;
        /* added by DevToolsApp */
        public static final int floating = 2131296469;
        /* added by DevToolsApp */
        public static final int forever = 2131296470;
        /* added by DevToolsApp */
        public static final int fragment_container_view_tag = 2131296471;
        /* added by DevToolsApp */
        public static final int frost = 2131296472;
        /* added by DevToolsApp */
        public static final int fullscreen_header = 2131296473;
        /* added by DevToolsApp */
        public static final int ghost_view = 2131296474;
        /* added by DevToolsApp */
        public static final int ghost_view_holder = 2131296475;
        /* added by DevToolsApp */
        public static final int gone = 2131296476;
        /* added by DevToolsApp */
        public static final int graph = 2131296477;
        /* added by DevToolsApp */
        public static final int graph_wrap = 2131296478;
        /* added by DevToolsApp */
        public static final int group_divider = 2131296479;
        /* added by DevToolsApp */
        public static final int grouping = 2131296480;
        /* added by DevToolsApp */
        public static final int groups = 2131296481;
        /* added by DevToolsApp */
        public static final int header_title = 2131296482;
        /* added by DevToolsApp */
        public static final int hide_ime_id = 2131296483;
        /* added by DevToolsApp */
        public static final int hideable = 2131296484;
        /* added by DevToolsApp */
        public static final int home = 2131296485;
        /* added by DevToolsApp */
        public static final int homeAsUp = 2131296486;
        /* added by DevToolsApp */
        public static final int honorRequest = 2131296487;
        /* added by DevToolsApp */
        public static final int horizontal = 2131296488;
        /* added by DevToolsApp */
        public static final int horizontal_only = 2131296489;
        /* added by DevToolsApp */
        public static final int icon = 2131296490;
        /* added by DevToolsApp */
        public static final int icon_group = 2131296491;
        /* added by DevToolsApp */
        public static final int icon_only = 2131296492;
        /* added by DevToolsApp */
        public static final int ifRoom = 2131296493;
        /* added by DevToolsApp */
        public static final int ignore = 2131296494;
        /* added by DevToolsApp */
        public static final int ignoreRequest = 2131296495;
        /* added by DevToolsApp */
        public static final int image = 2131296496;
        /* added by DevToolsApp */
        public static final int immediateStop = 2131296500;
        /* added by DevToolsApp */
        public static final int included = 2131296501;
        /* added by DevToolsApp */
        public static final int indeterminate = 2131296502;
        /* added by DevToolsApp */
        public static final int info = 2131296503;
        /* added by DevToolsApp */
        public static final int invisible = 2131296504;
        /* added by DevToolsApp */
        public static final int inward = 2131296505;
        /* added by DevToolsApp */
        public static final int italic = 2131296508;
        /* added by DevToolsApp */
        public static final int item_touch_helper_previous_elevation = 2131296509;
        /* added by DevToolsApp */
        public static final int jumpToEnd = 2131296510;
        /* added by DevToolsApp */
        public static final int jumpToStart = 2131296511;
        /* added by DevToolsApp */
        public static final int labeled = 2131296512;
        /* added by DevToolsApp */
        public static final int layout = 2131296513;
        /* added by DevToolsApp */
        public static final int left = 2131296514;
        /* added by DevToolsApp */
        public static final int leftToRight = 2131296515;
        /* added by DevToolsApp */
        public static final int legacy = 2131296516;
        /* added by DevToolsApp */
        public static final int light = 2131296517;
        /* added by DevToolsApp */
        public static final int line1 = 2131296518;
        /* added by DevToolsApp */
        public static final int line3 = 2131296519;
        /* added by DevToolsApp */
        public static final int linear = 2131296520;
        /* added by DevToolsApp */
        public static final int listMode = 2131296525;
        /* added by DevToolsApp */
        public static final int list_item = 2131296526;
        /* added by DevToolsApp */
        public static final int m3_side_sheet = 2131296528;
        /* added by DevToolsApp */
        public static final int marquee = 2131296530;
        /* added by DevToolsApp */
        public static final int masked = 2131296531;
        /* added by DevToolsApp */
        public static final int match_constraint = 2131296532;
        /* added by DevToolsApp */
        public static final int match_parent = 2131296533;
        /* added by DevToolsApp */
        public static final int material_clock_display = 2131296534;
        /* added by DevToolsApp */
        public static final int material_clock_display_and_toggle = 2131296535;
        /* added by DevToolsApp */
        public static final int material_clock_face = 2131296536;
        /* added by DevToolsApp */
        public static final int material_clock_hand = 2131296537;
        /* added by DevToolsApp */
        public static final int material_clock_level = 2131296538;
        /* added by DevToolsApp */
        public static final int material_clock_period_am_button = 2131296539;
        /* added by DevToolsApp */
        public static final int material_clock_period_pm_button = 2131296540;
        /* added by DevToolsApp */
        public static final int material_clock_period_toggle = 2131296541;
        /* added by DevToolsApp */
        public static final int material_hour_text_input = 2131296542;
        /* added by DevToolsApp */
        public static final int material_hour_tv = 2131296543;
        /* added by DevToolsApp */
        public static final int material_label = 2131296544;
        /* added by DevToolsApp */
        public static final int material_minute_text_input = 2131296545;
        /* added by DevToolsApp */
        public static final int material_minute_tv = 2131296546;
        /* added by DevToolsApp */
        public static final int material_textinput_timepicker = 2131296547;
        /* added by DevToolsApp */
        public static final int material_timepicker_cancel_button = 2131296548;
        /* added by DevToolsApp */
        public static final int material_timepicker_container = 2131296549;
        /* added by DevToolsApp */
        public static final int material_timepicker_mode_button = 2131296550;
        /* added by DevToolsApp */
        public static final int material_timepicker_ok_button = 2131296551;
        /* added by DevToolsApp */
        public static final int material_timepicker_view = 2131296552;
        /* added by DevToolsApp */
        public static final int material_value_index = 2131296553;
        /* added by DevToolsApp */
        public static final int matrix = 2131296554;
        /* added by DevToolsApp */
        public static final int message = 2131296555;
        /* added by DevToolsApp */
        public static final int middle = 2131296556;
        /* added by DevToolsApp */
        public static final int mini = 2131296557;
        /* added by DevToolsApp */
        public static final int month_grid = 2131296558;
        /* added by DevToolsApp */
        public static final int month_navigation_bar = 2131296559;
        /* added by DevToolsApp */
        public static final int month_navigation_fragment_toggle = 2131296560;
        /* added by DevToolsApp */
        public static final int month_navigation_next = 2131296561;
        /* added by DevToolsApp */
        public static final int month_navigation_previous = 2131296562;
        /* added by DevToolsApp */
        public static final int month_title = 2131296563;
        /* added by DevToolsApp */
        public static final int motion_base = 2131296564;
        /* added by DevToolsApp */
        public static final int mtrl_anchor_parent = 2131296565;
        /* added by DevToolsApp */
        public static final int mtrl_calendar_day_selector_frame = 2131296566;
        /* added by DevToolsApp */
        public static final int mtrl_calendar_days_of_week = 2131296567;
        /* added by DevToolsApp */
        public static final int mtrl_calendar_frame = 2131296568;
        /* added by DevToolsApp */
        public static final int mtrl_calendar_main_pane = 2131296569;
        /* added by DevToolsApp */
        public static final int mtrl_calendar_months = 2131296570;
        /* added by DevToolsApp */
        public static final int mtrl_calendar_selection_frame = 2131296571;
        /* added by DevToolsApp */
        public static final int mtrl_calendar_text_input_frame = 2131296572;
        /* added by DevToolsApp */
        public static final int mtrl_calendar_year_selector_frame = 2131296573;
        /* added by DevToolsApp */
        public static final int mtrl_card_checked_layer_id = 2131296574;
        /* added by DevToolsApp */
        public static final int mtrl_child_content_container = 2131296575;
        /* added by DevToolsApp */
        public static final int mtrl_internal_children_alpha_tag = 2131296576;
        /* added by DevToolsApp */
        public static final int mtrl_motion_snapshot_view = 2131296577;
        /* added by DevToolsApp */
        public static final int mtrl_picker_fullscreen = 2131296578;
        /* added by DevToolsApp */
        public static final int mtrl_picker_header = 2131296579;
        /* added by DevToolsApp */
        public static final int mtrl_picker_header_selection_text = 2131296580;
        /* added by DevToolsApp */
        public static final int mtrl_picker_header_title_and_selection = 2131296581;
        /* added by DevToolsApp */
        public static final int mtrl_picker_header_toggle = 2131296582;
        /* added by DevToolsApp */
        public static final int mtrl_picker_text_input_date = 2131296583;
        /* added by DevToolsApp */
        public static final int mtrl_picker_text_input_range_end = 2131296584;
        /* added by DevToolsApp */
        public static final int mtrl_picker_text_input_range_start = 2131296585;
        /* added by DevToolsApp */
        public static final int mtrl_picker_title_text = 2131296586;
        /* added by DevToolsApp */
        public static final int mtrl_view_tag_bottom_padding = 2131296587;
        /* added by DevToolsApp */
        public static final int multiply = 2131296588;
        /* added by DevToolsApp */
        public static final int navigation_bar_item_active_indicator_view = 2131296589;
        /* added by DevToolsApp */
        public static final int navigation_bar_item_icon_container = 2131296590;
        /* added by DevToolsApp */
        public static final int navigation_bar_item_icon_view = 2131296591;
        /* added by DevToolsApp */
        public static final int navigation_bar_item_labels_group = 2131296592;
        /* added by DevToolsApp */
        public static final int navigation_bar_item_large_label_view = 2131296593;
        /* added by DevToolsApp */
        public static final int navigation_bar_item_small_label_view = 2131296594;
        /* added by DevToolsApp */
        public static final int navigation_header_container = 2131296595;
        /* added by DevToolsApp */
        public static final int never = 2131296596;
        /* added by DevToolsApp */
        public static final int neverCompleteToEnd = 2131296597;
        /* added by DevToolsApp */
        public static final int neverCompleteToStart = 2131296598;
        /* added by DevToolsApp */
        public static final int noScroll = 2131296599;
        /* added by DevToolsApp */
        public static final int noState = 2131296600;
        /* added by DevToolsApp */
        public static final int none = 2131296601;
        /* added by DevToolsApp */
        public static final int normal = 2131296602;
        /* added by DevToolsApp */
        public static final int north = 2131296603;
        /* added by DevToolsApp */
        public static final int notification_background = 2131296604;
        /* added by DevToolsApp */
        public static final int notification_main_column = 2131296605;
        /* added by DevToolsApp */
        public static final int notification_main_column_container = 2131296606;
        /* added by DevToolsApp */
        public static final int off = 2131296607;
        /* added by DevToolsApp */
        public static final int on = 2131296608;
        /* added by DevToolsApp */
        public static final int onInterceptTouchReturnSwipe = 2131296609;
        /* added by DevToolsApp */
        public static final int open_search_bar_text_view = 2131296610;
        /* added by DevToolsApp */
        public static final int open_search_view_background = 2131296611;
        /* added by DevToolsApp */
        public static final int open_search_view_clear_button = 2131296612;
        /* added by DevToolsApp */
        public static final int open_search_view_content_container = 2131296613;
        /* added by DevToolsApp */
        public static final int open_search_view_divider = 2131296614;
        /* added by DevToolsApp */
        public static final int open_search_view_dummy_toolbar = 2131296615;
        /* added by DevToolsApp */
        public static final int open_search_view_edit_text = 2131296616;
        /* added by DevToolsApp */
        public static final int open_search_view_header_container = 2131296617;
        /* added by DevToolsApp */
        public static final int open_search_view_root = 2131296618;
        /* added by DevToolsApp */
        public static final int open_search_view_scrim = 2131296619;
        /* added by DevToolsApp */
        public static final int open_search_view_search_prefix = 2131296620;
        /* added by DevToolsApp */
        public static final int open_search_view_status_bar_spacer = 2131296621;
        /* added by DevToolsApp */
        public static final int open_search_view_toolbar = 2131296622;
        /* added by DevToolsApp */
        public static final int open_search_view_toolbar_container = 2131296623;
        /* added by DevToolsApp */
        public static final int outline = 2131296624;
        /* added by DevToolsApp */
        public static final int outward = 2131296625;
        /* added by DevToolsApp */
        public static final int overshoot = 2131296626;
        /* added by DevToolsApp */
        public static final int packed = 2131296627;
        /* added by DevToolsApp */
        public static final int parallax = 2131296628;
        /* added by DevToolsApp */
        public static final int parent = 2131296629;
        /* added by DevToolsApp */
        public static final int parentPanel = 2131296630;
        /* added by DevToolsApp */
        public static final int parentRelative = 2131296631;
        /* added by DevToolsApp */
        public static final int parent_matrix = 2131296633;
        /* added by DevToolsApp */
        public static final int password_toggle = 2131296634;
        /* added by DevToolsApp */
        public static final int path = 2131296635;
        /* added by DevToolsApp */
        public static final int pathRelative = 2131296636;
        /* added by DevToolsApp */
        public static final int peekHeight = 2131296637;
        /* added by DevToolsApp */
        public static final int percent = 2131296638;
        /* added by DevToolsApp */
        public static final int pin = 2131296639;
        /* added by DevToolsApp */
        public static final int position = 2131296640;
        /* added by DevToolsApp */
        public static final int postLayout = 2131296641;
        /* added by DevToolsApp */
        public static final int pressed = 2131296642;
        /* added by DevToolsApp */
        public static final int progress_circular = 2131296644;
        /* added by DevToolsApp */
        public static final int progress_horizontal = 2131296645;
        /* added by DevToolsApp */
        public static final int radio = 2131296646;
        /* added by DevToolsApp */
        public static final int ratio = 2131296647;
        /* added by DevToolsApp */
        public static final int rectangles = 2131296648;
        /* added by DevToolsApp */
        public static final int report_drawn = 2131296649;
        /* added by DevToolsApp */
        public static final int reverseSawtooth = 2131296650;
        /* added by DevToolsApp */
        public static final int right = 2131296651;
        /* added by DevToolsApp */
        public static final int rightToLeft = 2131296652;
        /* added by DevToolsApp */
        public static final int right_icon = 2131296653;
        /* added by DevToolsApp */
        public static final int right_side = 2131296654;
        /* added by DevToolsApp */
        public static final int rounded = 2131296655;
        /* added by DevToolsApp */
        public static final int row_index_key = 2131296656;
        /* added by DevToolsApp */
        public static final int save_non_transition_alpha = 2131296657;
        /* added by DevToolsApp */
        public static final int save_overlay_view = 2131296658;
        /* added by DevToolsApp */
        public static final int sawtooth = 2131296659;
        /* added by DevToolsApp */
        public static final int scale = 2131296660;
        /* added by DevToolsApp */
        public static final int screen = 2131296661;
        /* added by DevToolsApp */
        public static final int scroll = 2131296662;
        /* added by DevToolsApp */
        public static final int scrollIndicatorDown = 2131296663;
        /* added by DevToolsApp */
        public static final int scrollIndicatorUp = 2131296664;
        /* added by DevToolsApp */
        public static final int scrollView = 2131296665;
        /* added by DevToolsApp */
        public static final int scrollable = 2131296666;
        /* added by DevToolsApp */
        public static final int search_badge = 2131296667;
        /* added by DevToolsApp */
        public static final int search_bar = 2131296668;
        /* added by DevToolsApp */
        public static final int search_button = 2131296669;
        /* added by DevToolsApp */
        public static final int search_close_btn = 2131296670;
        /* added by DevToolsApp */
        public static final int search_edit_frame = 2131296671;
        /* added by DevToolsApp */
        public static final int search_go_btn = 2131296672;
        /* added by DevToolsApp */
        public static final int search_mag_icon = 2131296673;
        /* added by DevToolsApp */
        public static final int search_plate = 2131296674;
        /* added by DevToolsApp */
        public static final int search_src_text = 2131296675;
        /* added by DevToolsApp */
        public static final int search_voice_btn = 2131296676;
        /* added by DevToolsApp */
        public static final int select_dialog_listview = 2131296677;
        /* added by DevToolsApp */
        public static final int selected = 2131296678;
        /* added by DevToolsApp */
        public static final int selection_type = 2131296679;
        /* added by DevToolsApp */
        public static final int sharedValueSet = 2131296680;
        /* added by DevToolsApp */
        public static final int sharedValueUnset = 2131296681;
        /* added by DevToolsApp */
        public static final int shortcut = 2131296682;
        /* added by DevToolsApp */
        public static final int showCustom = 2131296683;
        /* added by DevToolsApp */
        public static final int showHome = 2131296684;
        /* added by DevToolsApp */
        public static final int showTitle = 2131296685;
        /* added by DevToolsApp */
        public static final int sin = 2131296686;
        /* added by DevToolsApp */
        public static final int skipCollapsed = 2131296687;
        /* added by DevToolsApp */
        public static final int skipped = 2131296688;
        /* added by DevToolsApp */
        public static final int slide = 2131296689;
        /* added by DevToolsApp */
        public static final int snackbar_action = 2131296690;
        /* added by DevToolsApp */
        public static final int snackbar_text = 2131296691;
        /* added by DevToolsApp */
        public static final int snap = 2131296692;
        /* added by DevToolsApp */
        public static final int snapMargins = 2131296693;
        /* added by DevToolsApp */
        public static final int south = 2131296694;
        /* added by DevToolsApp */
        public static final int spacer = 2131296695;
        /* added by DevToolsApp */
        public static final int special_effects_controller_view_tag = 2131296696;
        /* added by DevToolsApp */
        public static final int spline = 2131296697;
        /* added by DevToolsApp */
        public static final int split_action_bar = 2131296698;
        /* added by DevToolsApp */
        public static final int spread = 2131296699;
        /* added by DevToolsApp */
        public static final int spread_inside = 2131296700;
        /* added by DevToolsApp */
        public static final int spring = 2131296701;
        /* added by DevToolsApp */
        public static final int square = 2131296702;
        /* added by DevToolsApp */
        public static final int src_atop = 2131296703;
        /* added by DevToolsApp */
        public static final int src_in = 2131296704;
        /* added by DevToolsApp */
        public static final int src_over = 2131296705;
        /* added by DevToolsApp */
        public static final int standard = 2131296706;
        /* added by DevToolsApp */
        public static final int start = 2131296707;
        /* added by DevToolsApp */
        public static final int startHorizontal = 2131296708;
        /* added by DevToolsApp */
        public static final int startToEnd = 2131296709;
        /* added by DevToolsApp */
        public static final int startVertical = 2131296710;
        /* added by DevToolsApp */
        public static final int staticLayout = 2131296711;
        /* added by DevToolsApp */
        public static final int staticPostLayout = 2131296712;
        /* added by DevToolsApp */
        public static final int stop = 2131296713;
        /* added by DevToolsApp */
        public static final int stretch = 2131296714;
        /* added by DevToolsApp */
        public static final int submenuarrow = 2131296715;
        /* added by DevToolsApp */
        public static final int submit_area = 2131296716;
        /* added by DevToolsApp */
        public static final int supportScrollUp = 2131296717;
        /* added by DevToolsApp */
        public static final int tabMode = 2131296718;
        /* added by DevToolsApp */
        public static final int tag_accessibility_actions = 2131296719;
        /* added by DevToolsApp */
        public static final int tag_accessibility_clickable_spans = 2131296720;
        /* added by DevToolsApp */
        public static final int tag_accessibility_heading = 2131296721;
        /* added by DevToolsApp */
        public static final int tag_accessibility_pane_title = 2131296722;
        /* added by DevToolsApp */
        public static final int tag_on_apply_window_listener = 2131296723;
        /* added by DevToolsApp */
        public static final int tag_on_receive_content_listener = 2131296724;
        /* added by DevToolsApp */
        public static final int tag_on_receive_content_mime_types = 2131296725;
        /* added by DevToolsApp */
        public static final int tag_screen_reader_focusable = 2131296726;
        /* added by DevToolsApp */
        public static final int tag_state_description = 2131296727;
        /* added by DevToolsApp */
        public static final int tag_transition_group = 2131296728;
        /* added by DevToolsApp */
        public static final int tag_unhandled_key_event_manager = 2131296729;
        /* added by DevToolsApp */
        public static final int tag_unhandled_key_listeners = 2131296730;
        /* added by DevToolsApp */
        public static final int tag_window_insets_animation_callback = 2131296731;
        /* added by DevToolsApp */
        public static final int text = 2131296732;
        /* added by DevToolsApp */
        public static final int text2 = 2131296733;
        /* added by DevToolsApp */
        public static final int textEnd = 2131296734;
        /* added by DevToolsApp */
        public static final int textSpacerNoButtons = 2131296735;
        /* added by DevToolsApp */
        public static final int textSpacerNoTitle = 2131296736;
        /* added by DevToolsApp */
        public static final int textStart = 2131296737;
        /* added by DevToolsApp */
        public static final int textTop = 2131296738;
        /* added by DevToolsApp */
        public static final int text_input_end_icon = 2131296739;
        /* added by DevToolsApp */
        public static final int text_input_error_icon = 2131296740;
        /* added by DevToolsApp */
        public static final int text_input_start_icon = 2131296741;
        /* added by DevToolsApp */
        public static final int textinput_counter = 2131296742;
        /* added by DevToolsApp */
        public static final int textinput_error = 2131296743;
        /* added by DevToolsApp */
        public static final int textinput_helper_text = 2131296744;
        /* added by DevToolsApp */
        public static final int textinput_placeholder = 2131296745;
        /* added by DevToolsApp */
        public static final int textinput_prefix_text = 2131296746;
        /* added by DevToolsApp */
        public static final int textinput_suffix_text = 2131296747;
        /* added by DevToolsApp */
        public static final int time = 2131296748;
        /* added by DevToolsApp */
        public static final int title = 2131296749;
        /* added by DevToolsApp */
        public static final int titleDividerNoCustom = 2131296750;
        /* added by DevToolsApp */
        public static final int title_template = 2131296751;
        /* added by DevToolsApp */
        public static final int toggle = 2131296752;
        /* added by DevToolsApp */
        public static final int top = 2131296753;
        /* added by DevToolsApp */
        public static final int topPanel = 2131296754;
        /* added by DevToolsApp */
        public static final int touch_outside = 2131296755;
        /* added by DevToolsApp */
        public static final int transitionToEnd = 2131296756;
        /* added by DevToolsApp */
        public static final int transitionToStart = 2131296757;
        /* added by DevToolsApp */
        public static final int transition_clip = 2131296758;
        /* added by DevToolsApp */
        public static final int transition_current_scene = 2131296759;
        /* added by DevToolsApp */
        public static final int transition_image_transform = 2131296760;
        /* added by DevToolsApp */
        public static final int transition_layout_save = 2131296761;
        /* added by DevToolsApp */
        public static final int transition_pause_alpha = 2131296762;
        /* added by DevToolsApp */
        public static final int transition_position = 2131296763;
        /* added by DevToolsApp */
        public static final int transition_scene_layoutid_cache = 2131296764;
        /* added by DevToolsApp */
        public static final int transition_transform = 2131296765;
        /* added by DevToolsApp */
        public static final int triangle = 2131296766;
        /* added by DevToolsApp */
        public static final int unchecked = 2131296778;
        /* added by DevToolsApp */
        public static final int uniform = 2131296779;
        /* added by DevToolsApp */
        public static final int unlabeled = 2131296780;
        /* added by DevToolsApp */
        public static final int up = 2131296781;
        /* added by DevToolsApp */
        public static final int useLogo = 2131296784;
        /* added by DevToolsApp */
        public static final int vertical = 2131296786;
        /* added by DevToolsApp */
        public static final int vertical_only = 2131296787;
        /* added by DevToolsApp */
        public static final int view_offset_helper = 2131296788;
        /* added by DevToolsApp */
        public static final int view_transition = 2131296789;
        /* added by DevToolsApp */
        public static final int view_tree_disjoint_parent = 2131296790;
        /* added by DevToolsApp */
        public static final int view_tree_lifecycle_owner = 2131296791;
        /* added by DevToolsApp */
        public static final int view_tree_on_back_pressed_dispatcher_owner = 2131296792;
        /* added by DevToolsApp */
        public static final int view_tree_saved_state_registry_owner = 2131296793;
        /* added by DevToolsApp */
        public static final int view_tree_view_model_store_owner = 2131296794;
        /* added by DevToolsApp */
        public static final int visible = 2131296795;
        /* added by DevToolsApp */
        public static final int visible_removing_fragment_view_tag = 2131296796;
        /* added by DevToolsApp */
        public static final int west = 2131296797;
        /* added by DevToolsApp */
        public static final int wide = 2131296798;
        /* added by DevToolsApp */
        public static final int withText = 2131296799;
        /* added by DevToolsApp */
        public static final int with_icon = 2131296800;
        /* added by DevToolsApp */
        public static final int withinBounds = 2131296801;
        /* added by DevToolsApp */
        public static final int wrap = 2131296802;
        /* added by DevToolsApp */
        public static final int wrap_content = 2131296803;
        /* added by DevToolsApp */
        public static final int wrap_content_constrained = 2131296804;
        /* added by DevToolsApp */
        public static final int x_left = 2131296805;
        /* added by DevToolsApp */
        public static final int x_right = 2131296806;

        private id() {
        }
    }

    public static final class layout {
        public static int activity_authentication = 2131492892;
        public static int activity_dashboard = 2131492893;
        public static int activity_main = 2131492894;
        public static int item_buy_app = 2131492913;
        public static int progress_dialog = 2131492971;
        public static int update_layout = 2131492976;
        /* added by DevToolsApp */
        public static final int abc_action_bar_title_item = 2131492864;
        /* added by DevToolsApp */
        public static final int abc_action_bar_up_container = 2131492865;
        /* added by DevToolsApp */
        public static final int abc_action_menu_item_layout = 2131492866;
        /* added by DevToolsApp */
        public static final int abc_action_menu_layout = 2131492867;
        /* added by DevToolsApp */
        public static final int abc_action_mode_bar = 2131492868;
        /* added by DevToolsApp */
        public static final int abc_action_mode_close_item_material = 2131492869;
        /* added by DevToolsApp */
        public static final int abc_activity_chooser_view = 2131492870;
        /* added by DevToolsApp */
        public static final int abc_activity_chooser_view_list_item = 2131492871;
        /* added by DevToolsApp */
        public static final int abc_alert_dialog_button_bar_material = 2131492872;
        /* added by DevToolsApp */
        public static final int abc_alert_dialog_material = 2131492873;
        /* added by DevToolsApp */
        public static final int abc_alert_dialog_title_material = 2131492874;
        /* added by DevToolsApp */
        public static final int abc_cascading_menu_item_layout = 2131492875;
        /* added by DevToolsApp */
        public static final int abc_dialog_title_material = 2131492876;
        /* added by DevToolsApp */
        public static final int abc_expanded_menu_layout = 2131492877;
        /* added by DevToolsApp */
        public static final int abc_list_menu_item_checkbox = 2131492878;
        /* added by DevToolsApp */
        public static final int abc_list_menu_item_icon = 2131492879;
        /* added by DevToolsApp */
        public static final int abc_list_menu_item_layout = 2131492880;
        /* added by DevToolsApp */
        public static final int abc_list_menu_item_radio = 2131492881;
        /* added by DevToolsApp */
        public static final int abc_popup_menu_header_item_layout = 2131492882;
        /* added by DevToolsApp */
        public static final int abc_popup_menu_item_layout = 2131492883;
        /* added by DevToolsApp */
        public static final int abc_screen_content_include = 2131492884;
        /* added by DevToolsApp */
        public static final int abc_screen_simple = 2131492885;
        /* added by DevToolsApp */
        public static final int abc_screen_simple_overlay_action_mode = 2131492886;
        /* added by DevToolsApp */
        public static final int abc_screen_toolbar = 2131492887;
        /* added by DevToolsApp */
        public static final int abc_search_dropdown_item_icons_2line = 2131492888;
        /* added by DevToolsApp */
        public static final int abc_search_view = 2131492889;
        /* added by DevToolsApp */
        public static final int abc_select_dialog_material = 2131492890;
        /* added by DevToolsApp */
        public static final int abc_tooltip = 2131492891;
        /* added by DevToolsApp */
        public static final int custom_dialog = 2131492895;
        /* added by DevToolsApp */
        public static final int design_bottom_navigation_item = 2131492896;
        /* added by DevToolsApp */
        public static final int design_bottom_sheet_dialog = 2131492897;
        /* added by DevToolsApp */
        public static final int design_layout_snackbar = 2131492898;
        /* added by DevToolsApp */
        public static final int design_layout_snackbar_include = 2131492899;
        /* added by DevToolsApp */
        public static final int design_layout_tab_icon = 2131492900;
        /* added by DevToolsApp */
        public static final int design_layout_tab_text = 2131492901;
        /* added by DevToolsApp */
        public static final int design_menu_item_action_area = 2131492902;
        /* added by DevToolsApp */
        public static final int design_navigation_item = 2131492903;
        /* added by DevToolsApp */
        public static final int design_navigation_item_header = 2131492904;
        /* added by DevToolsApp */
        public static final int design_navigation_item_separator = 2131492905;
        /* added by DevToolsApp */
        public static final int design_navigation_item_subheader = 2131492906;
        /* added by DevToolsApp */
        public static final int design_navigation_menu = 2131492907;
        /* added by DevToolsApp */
        public static final int design_navigation_menu_item = 2131492908;
        /* added by DevToolsApp */
        public static final int design_text_input_end_icon = 2131492909;
        /* added by DevToolsApp */
        public static final int design_text_input_start_icon = 2131492910;
        /* added by DevToolsApp */
        public static final int ime_base_split_test_activity = 2131492911;
        /* added by DevToolsApp */
        public static final int ime_secondary_split_test_activity = 2131492912;
        /* added by DevToolsApp */
        public static final int m3_alert_dialog = 2131492914;
        /* added by DevToolsApp */
        public static final int m3_alert_dialog_actions = 2131492915;
        /* added by DevToolsApp */
        public static final int m3_alert_dialog_title = 2131492916;
        /* added by DevToolsApp */
        public static final int m3_auto_complete_simple_item = 2131492917;
        /* added by DevToolsApp */
        public static final int m3_side_sheet_dialog = 2131492918;
        /* added by DevToolsApp */
        public static final int material_chip_input_combo = 2131492919;
        /* added by DevToolsApp */
        public static final int material_clock_display = 2131492920;
        /* added by DevToolsApp */
        public static final int material_clock_display_divider = 2131492921;
        /* added by DevToolsApp */
        public static final int material_clock_period_toggle = 2131492922;
        /* added by DevToolsApp */
        public static final int material_clock_period_toggle_land = 2131492923;
        /* added by DevToolsApp */
        public static final int material_clockface_textview = 2131492924;
        /* added by DevToolsApp */
        public static final int material_clockface_view = 2131492925;
        /* added by DevToolsApp */
        public static final int material_radial_view_group = 2131492926;
        /* added by DevToolsApp */
        public static final int material_textinput_timepicker = 2131492927;
        /* added by DevToolsApp */
        public static final int material_time_chip = 2131492928;
        /* added by DevToolsApp */
        public static final int material_time_input = 2131492929;
        /* added by DevToolsApp */
        public static final int material_timepicker = 2131492930;
        /* added by DevToolsApp */
        public static final int material_timepicker_dialog = 2131492931;
        /* added by DevToolsApp */
        public static final int material_timepicker_textinput_display = 2131492932;
        /* added by DevToolsApp */
        public static final int mtrl_alert_dialog = 2131492933;
        /* added by DevToolsApp */
        public static final int mtrl_alert_dialog_actions = 2131492934;
        /* added by DevToolsApp */
        public static final int mtrl_alert_dialog_title = 2131492935;
        /* added by DevToolsApp */
        public static final int mtrl_alert_select_dialog_item = 2131492936;
        /* added by DevToolsApp */
        public static final int mtrl_alert_select_dialog_multichoice = 2131492937;
        /* added by DevToolsApp */
        public static final int mtrl_alert_select_dialog_singlechoice = 2131492938;
        /* added by DevToolsApp */
        public static final int mtrl_auto_complete_simple_item = 2131492939;
        /* added by DevToolsApp */
        public static final int mtrl_calendar_day = 2131492940;
        /* added by DevToolsApp */
        public static final int mtrl_calendar_day_of_week = 2131492941;
        /* added by DevToolsApp */
        public static final int mtrl_calendar_days_of_week = 2131492942;
        /* added by DevToolsApp */
        public static final int mtrl_calendar_horizontal = 2131492943;
        /* added by DevToolsApp */
        public static final int mtrl_calendar_month = 2131492944;
        /* added by DevToolsApp */
        public static final int mtrl_calendar_month_labeled = 2131492945;
        /* added by DevToolsApp */
        public static final int mtrl_calendar_month_navigation = 2131492946;
        /* added by DevToolsApp */
        public static final int mtrl_calendar_months = 2131492947;
        /* added by DevToolsApp */
        public static final int mtrl_calendar_vertical = 2131492948;
        /* added by DevToolsApp */
        public static final int mtrl_calendar_year = 2131492949;
        /* added by DevToolsApp */
        public static final int mtrl_layout_snackbar = 2131492950;
        /* added by DevToolsApp */
        public static final int mtrl_layout_snackbar_include = 2131492951;
        /* added by DevToolsApp */
        public static final int mtrl_navigation_rail_item = 2131492952;
        /* added by DevToolsApp */
        public static final int mtrl_picker_actions = 2131492953;
        /* added by DevToolsApp */
        public static final int mtrl_picker_dialog = 2131492954;
        /* added by DevToolsApp */
        public static final int mtrl_picker_fullscreen = 2131492955;
        /* added by DevToolsApp */
        public static final int mtrl_picker_header_dialog = 2131492956;
        /* added by DevToolsApp */
        public static final int mtrl_picker_header_fullscreen = 2131492957;
        /* added by DevToolsApp */
        public static final int mtrl_picker_header_selection_text = 2131492958;
        /* added by DevToolsApp */
        public static final int mtrl_picker_header_title_text = 2131492959;
        /* added by DevToolsApp */
        public static final int mtrl_picker_header_toggle = 2131492960;
        /* added by DevToolsApp */
        public static final int mtrl_picker_text_input_date = 2131492961;
        /* added by DevToolsApp */
        public static final int mtrl_picker_text_input_date_range = 2131492962;
        /* added by DevToolsApp */
        public static final int mtrl_search_bar = 2131492963;
        /* added by DevToolsApp */
        public static final int mtrl_search_view = 2131492964;
        /* added by DevToolsApp */
        public static final int notification_action = 2131492965;
        /* added by DevToolsApp */
        public static final int notification_action_tombstone = 2131492966;
        /* added by DevToolsApp */
        public static final int notification_template_custom_big = 2131492967;
        /* added by DevToolsApp */
        public static final int notification_template_icon_group = 2131492968;
        /* added by DevToolsApp */
        public static final int notification_template_part_chronometer = 2131492969;
        /* added by DevToolsApp */
        public static final int notification_template_part_time = 2131492970;
        /* added by DevToolsApp */
        public static final int select_dialog_item_material = 2131492972;
        /* added by DevToolsApp */
        public static final int select_dialog_multichoice_material = 2131492973;
        /* added by DevToolsApp */
        public static final int select_dialog_singlechoice_material = 2131492974;
        /* added by DevToolsApp */
        public static final int support_simple_spinner_dropdown_item = 2131492975;

        private layout() {
        }
    }

    public static final class mipmap {
        public static int ic_launcher = 2131623936;
        public static int ic_launcher_foreground = 2131623937;
        public static int ic_launcher_round = 2131623938;

        private mipmap() {
        }
    }

    public static final class string {
        public static int app_name = 2131820573;
        public static int gcm_defaultSenderId = 2131820615;
        public static int google_api_key = 2131820616;
        public static int google_app_id = 2131820617;
        public static int google_crash_reporting_api_key = 2131820618;
        public static int google_storage_bucket = 2131820619;
        public static int project_id = 2131820728;
        /* added by DevToolsApp */
        public static final int CronetProviderClassName = 2131820544;
        /* added by DevToolsApp */
        public static final int abc_action_bar_home_description = 2131820545;
        /* added by DevToolsApp */
        public static final int abc_action_bar_up_description = 2131820546;
        /* added by DevToolsApp */
        public static final int abc_action_menu_overflow_description = 2131820547;
        /* added by DevToolsApp */
        public static final int abc_action_mode_done = 2131820548;
        /* added by DevToolsApp */
        public static final int abc_activity_chooser_view_see_all = 2131820549;
        /* added by DevToolsApp */
        public static final int abc_activitychooserview_choose_application = 2131820550;
        /* added by DevToolsApp */
        public static final int abc_capital_off = 2131820551;
        /* added by DevToolsApp */
        public static final int abc_capital_on = 2131820552;
        /* added by DevToolsApp */
        public static final int abc_menu_alt_shortcut_label = 2131820553;
        /* added by DevToolsApp */
        public static final int abc_menu_ctrl_shortcut_label = 2131820554;
        /* added by DevToolsApp */
        public static final int abc_menu_delete_shortcut_label = 2131820555;
        /* added by DevToolsApp */
        public static final int abc_menu_enter_shortcut_label = 2131820556;
        /* added by DevToolsApp */
        public static final int abc_menu_function_shortcut_label = 2131820557;
        /* added by DevToolsApp */
        public static final int abc_menu_meta_shortcut_label = 2131820558;
        /* added by DevToolsApp */
        public static final int abc_menu_shift_shortcut_label = 2131820559;
        /* added by DevToolsApp */
        public static final int abc_menu_space_shortcut_label = 2131820560;
        /* added by DevToolsApp */
        public static final int abc_menu_sym_shortcut_label = 2131820561;
        /* added by DevToolsApp */
        public static final int abc_prepend_shortcut_label = 2131820562;
        /* added by DevToolsApp */
        public static final int abc_search_hint = 2131820563;
        /* added by DevToolsApp */
        public static final int abc_searchview_description_clear = 2131820564;
        /* added by DevToolsApp */
        public static final int abc_searchview_description_query = 2131820565;
        /* added by DevToolsApp */
        public static final int abc_searchview_description_search = 2131820566;
        /* added by DevToolsApp */
        public static final int abc_searchview_description_submit = 2131820567;
        /* added by DevToolsApp */
        public static final int abc_searchview_description_voice = 2131820568;
        /* added by DevToolsApp */
        public static final int abc_shareactionprovider_share_with = 2131820569;
        /* added by DevToolsApp */
        public static final int abc_shareactionprovider_share_with_application = 2131820570;
        /* added by DevToolsApp */
        public static final int abc_toolbar_collapse_description = 2131820571;
        /* added by DevToolsApp */
        public static final int androidx_startup = 2131820572;
        /* added by DevToolsApp */
        public static final int appbar_scrolling_view_behavior = 2131820574;
        /* added by DevToolsApp */
        public static final int bottom_sheet_behavior = 2131820575;
        /* added by DevToolsApp */
        public static final int bottomsheet_action_collapse = 2131820576;
        /* added by DevToolsApp */
        public static final int bottomsheet_action_expand = 2131820577;
        /* added by DevToolsApp */
        public static final int bottomsheet_action_expand_halfway = 2131820578;
        /* added by DevToolsApp */
        public static final int bottomsheet_drag_handle_clicked = 2131820579;
        /* added by DevToolsApp */
        public static final int bottomsheet_drag_handle_content_description = 2131820580;
        /* added by DevToolsApp */
        public static final int call_notification_answer_action = 2131820581;
        /* added by DevToolsApp */
        public static final int call_notification_answer_video_action = 2131820582;
        /* added by DevToolsApp */
        public static final int call_notification_decline_action = 2131820583;
        /* added by DevToolsApp */
        public static final int call_notification_hang_up_action = 2131820584;
        /* added by DevToolsApp */
        public static final int call_notification_incoming_text = 2131820585;
        /* added by DevToolsApp */
        public static final int call_notification_ongoing_text = 2131820586;
        /* added by DevToolsApp */
        public static final int call_notification_screening_text = 2131820587;
        /* added by DevToolsApp */
        public static final int character_counter_content_description = 2131820588;
        /* added by DevToolsApp */
        public static final int character_counter_overflowed_content_description = 2131820589;
        /* added by DevToolsApp */
        public static final int character_counter_pattern = 2131820590;
        /* added by DevToolsApp */
        public static final int clear_text_end_icon_content_description = 2131820591;
        /* added by DevToolsApp */
        public static final int common_google_play_services_enable_button = 2131820592;
        /* added by DevToolsApp */
        public static final int common_google_play_services_enable_text = 2131820593;
        /* added by DevToolsApp */
        public static final int common_google_play_services_enable_title = 2131820594;
        /* added by DevToolsApp */
        public static final int common_google_play_services_install_button = 2131820595;
        /* added by DevToolsApp */
        public static final int common_google_play_services_install_text = 2131820596;
        /* added by DevToolsApp */
        public static final int common_google_play_services_install_title = 2131820597;
        /* added by DevToolsApp */
        public static final int common_google_play_services_notification_channel_name = 2131820598;
        /* added by DevToolsApp */
        public static final int common_google_play_services_notification_ticker = 2131820599;
        /* added by DevToolsApp */
        public static final int common_google_play_services_unknown_issue = 2131820600;
        /* added by DevToolsApp */
        public static final int common_google_play_services_unsupported_text = 2131820601;
        /* added by DevToolsApp */
        public static final int common_google_play_services_update_button = 2131820602;
        /* added by DevToolsApp */
        public static final int common_google_play_services_update_text = 2131820603;
        /* added by DevToolsApp */
        public static final int common_google_play_services_update_title = 2131820604;
        /* added by DevToolsApp */
        public static final int common_google_play_services_updating_text = 2131820605;
        /* added by DevToolsApp */
        public static final int common_google_play_services_wear_update_text = 2131820606;
        /* added by DevToolsApp */
        public static final int common_open_on_phone = 2131820607;
        /* added by DevToolsApp */
        public static final int common_signin_button_text = 2131820608;
        /* added by DevToolsApp */
        public static final int common_signin_button_text_long = 2131820609;
        /* added by DevToolsApp */
        public static final int error_a11y_label = 2131820610;
        /* added by DevToolsApp */
        public static final int error_icon_content_description = 2131820611;
        /* added by DevToolsApp */
        public static final int exposed_dropdown_menu_content_description = 2131820612;
        /* added by DevToolsApp */
        public static final int fab_transformation_scrim_behavior = 2131820613;
        /* added by DevToolsApp */
        public static final int fab_transformation_sheet_behavior = 2131820614;
        /* added by DevToolsApp */
        public static final int hide_bottom_view_on_scroll_behavior = 2131820620;
        /* added by DevToolsApp */
        public static final int icon_content_description = 2131820621;
        /* added by DevToolsApp */
        public static final int item_view_role_description = 2131820622;
        /* added by DevToolsApp */
        public static final int m3_exceed_max_badge_text_suffix = 2131820623;
        /* added by DevToolsApp */
        public static final int m3_ref_typeface_brand_medium = 2131820624;
        /* added by DevToolsApp */
        public static final int m3_ref_typeface_brand_regular = 2131820625;
        /* added by DevToolsApp */
        public static final int m3_ref_typeface_plain_medium = 2131820626;
        /* added by DevToolsApp */
        public static final int m3_ref_typeface_plain_regular = 2131820627;
        /* added by DevToolsApp */
        public static final int m3_sys_motion_easing_emphasized = 2131820628;
        /* added by DevToolsApp */
        public static final int m3_sys_motion_easing_emphasized_accelerate = 2131820629;
        /* added by DevToolsApp */
        public static final int m3_sys_motion_easing_emphasized_decelerate = 2131820630;
        /* added by DevToolsApp */
        public static final int m3_sys_motion_easing_emphasized_path_data = 2131820631;
        /* added by DevToolsApp */
        public static final int m3_sys_motion_easing_legacy = 2131820632;
        /* added by DevToolsApp */
        public static final int m3_sys_motion_easing_legacy_accelerate = 2131820633;
        /* added by DevToolsApp */
        public static final int m3_sys_motion_easing_legacy_decelerate = 2131820634;
        /* added by DevToolsApp */
        public static final int m3_sys_motion_easing_linear = 2131820635;
        /* added by DevToolsApp */
        public static final int m3_sys_motion_easing_standard = 2131820636;
        /* added by DevToolsApp */
        public static final int m3_sys_motion_easing_standard_accelerate = 2131820637;
        /* added by DevToolsApp */
        public static final int m3_sys_motion_easing_standard_decelerate = 2131820638;
        /* added by DevToolsApp */
        public static final int material_clock_display_divider = 2131820639;
        /* added by DevToolsApp */
        public static final int material_clock_toggle_content_description = 2131820640;
        /* added by DevToolsApp */
        public static final int material_hour_24h_suffix = 2131820641;
        /* added by DevToolsApp */
        public static final int material_hour_selection = 2131820642;
        /* added by DevToolsApp */
        public static final int material_hour_suffix = 2131820643;
        /* added by DevToolsApp */
        public static final int material_minute_selection = 2131820644;
        /* added by DevToolsApp */
        public static final int material_minute_suffix = 2131820645;
        /* added by DevToolsApp */
        public static final int material_motion_easing_accelerated = 2131820646;
        /* added by DevToolsApp */
        public static final int material_motion_easing_decelerated = 2131820647;
        /* added by DevToolsApp */
        public static final int material_motion_easing_emphasized = 2131820648;
        /* added by DevToolsApp */
        public static final int material_motion_easing_linear = 2131820649;
        /* added by DevToolsApp */
        public static final int material_motion_easing_standard = 2131820650;
        /* added by DevToolsApp */
        public static final int material_slider_range_end = 2131820651;
        /* added by DevToolsApp */
        public static final int material_slider_range_start = 2131820652;
        /* added by DevToolsApp */
        public static final int material_slider_value = 2131820653;
        /* added by DevToolsApp */
        public static final int material_timepicker_am = 2131820654;
        /* added by DevToolsApp */
        public static final int material_timepicker_clock_mode_description = 2131820655;
        /* added by DevToolsApp */
        public static final int material_timepicker_hour = 2131820656;
        /* added by DevToolsApp */
        public static final int material_timepicker_minute = 2131820657;
        /* added by DevToolsApp */
        public static final int material_timepicker_pm = 2131820658;
        /* added by DevToolsApp */
        public static final int material_timepicker_select_time = 2131820659;
        /* added by DevToolsApp */
        public static final int material_timepicker_text_input_mode_description = 2131820660;
        /* added by DevToolsApp */
        public static final int mtrl_badge_numberless_content_description = 2131820661;
        /* added by DevToolsApp */
        public static final int mtrl_checkbox_button_icon_path_checked = 2131820662;
        /* added by DevToolsApp */
        public static final int mtrl_checkbox_button_icon_path_group_name = 2131820663;
        /* added by DevToolsApp */
        public static final int mtrl_checkbox_button_icon_path_indeterminate = 2131820664;
        /* added by DevToolsApp */
        public static final int mtrl_checkbox_button_icon_path_name = 2131820665;
        /* added by DevToolsApp */
        public static final int mtrl_checkbox_button_path_checked = 2131820666;
        /* added by DevToolsApp */
        public static final int mtrl_checkbox_button_path_group_name = 2131820667;
        /* added by DevToolsApp */
        public static final int mtrl_checkbox_button_path_name = 2131820668;
        /* added by DevToolsApp */
        public static final int mtrl_checkbox_button_path_unchecked = 2131820669;
        /* added by DevToolsApp */
        public static final int mtrl_checkbox_state_description_checked = 2131820670;
        /* added by DevToolsApp */
        public static final int mtrl_checkbox_state_description_indeterminate = 2131820671;
        /* added by DevToolsApp */
        public static final int mtrl_checkbox_state_description_unchecked = 2131820672;
        /* added by DevToolsApp */
        public static final int mtrl_chip_close_icon_content_description = 2131820673;
        /* added by DevToolsApp */
        public static final int mtrl_exceed_max_badge_number_content_description = 2131820674;
        /* added by DevToolsApp */
        public static final int mtrl_exceed_max_badge_number_suffix = 2131820675;
        /* added by DevToolsApp */
        public static final int mtrl_picker_a11y_next_month = 2131820676;
        /* added by DevToolsApp */
        public static final int mtrl_picker_a11y_prev_month = 2131820677;
        /* added by DevToolsApp */
        public static final int mtrl_picker_announce_current_range_selection = 2131820678;
        /* added by DevToolsApp */
        public static final int mtrl_picker_announce_current_selection = 2131820679;
        /* added by DevToolsApp */
        public static final int mtrl_picker_announce_current_selection_none = 2131820680;
        /* added by DevToolsApp */
        public static final int mtrl_picker_cancel = 2131820681;
        /* added by DevToolsApp */
        public static final int mtrl_picker_confirm = 2131820682;
        /* added by DevToolsApp */
        public static final int mtrl_picker_date_header_selected = 2131820683;
        /* added by DevToolsApp */
        public static final int mtrl_picker_date_header_title = 2131820684;
        /* added by DevToolsApp */
        public static final int mtrl_picker_date_header_unselected = 2131820685;
        /* added by DevToolsApp */
        public static final int mtrl_picker_day_of_week_column_header = 2131820686;
        /* added by DevToolsApp */
        public static final int mtrl_picker_end_date_description = 2131820687;
        /* added by DevToolsApp */
        public static final int mtrl_picker_invalid_format = 2131820688;
        /* added by DevToolsApp */
        public static final int mtrl_picker_invalid_format_example = 2131820689;
        /* added by DevToolsApp */
        public static final int mtrl_picker_invalid_format_use = 2131820690;
        /* added by DevToolsApp */
        public static final int mtrl_picker_invalid_range = 2131820691;
        /* added by DevToolsApp */
        public static final int mtrl_picker_navigate_to_current_year_description = 2131820692;
        /* added by DevToolsApp */
        public static final int mtrl_picker_navigate_to_year_description = 2131820693;
        /* added by DevToolsApp */
        public static final int mtrl_picker_out_of_range = 2131820694;
        /* added by DevToolsApp */
        public static final int mtrl_picker_range_header_only_end_selected = 2131820695;
        /* added by DevToolsApp */
        public static final int mtrl_picker_range_header_only_start_selected = 2131820696;
        /* added by DevToolsApp */
        public static final int mtrl_picker_range_header_selected = 2131820697;
        /* added by DevToolsApp */
        public static final int mtrl_picker_range_header_title = 2131820698;
        /* added by DevToolsApp */
        public static final int mtrl_picker_range_header_unselected = 2131820699;
        /* added by DevToolsApp */
        public static final int mtrl_picker_save = 2131820700;
        /* added by DevToolsApp */
        public static final int mtrl_picker_start_date_description = 2131820701;
        /* added by DevToolsApp */
        public static final int mtrl_picker_text_input_date_hint = 2131820702;
        /* added by DevToolsApp */
        public static final int mtrl_picker_text_input_date_range_end_hint = 2131820703;
        /* added by DevToolsApp */
        public static final int mtrl_picker_text_input_date_range_start_hint = 2131820704;
        /* added by DevToolsApp */
        public static final int mtrl_picker_text_input_day_abbr = 2131820705;
        /* added by DevToolsApp */
        public static final int mtrl_picker_text_input_month_abbr = 2131820706;
        /* added by DevToolsApp */
        public static final int mtrl_picker_text_input_year_abbr = 2131820707;
        /* added by DevToolsApp */
        public static final int mtrl_picker_today_description = 2131820708;
        /* added by DevToolsApp */
        public static final int mtrl_picker_toggle_to_calendar_input_mode = 2131820709;
        /* added by DevToolsApp */
        public static final int mtrl_picker_toggle_to_day_selection = 2131820710;
        /* added by DevToolsApp */
        public static final int mtrl_picker_toggle_to_text_input_mode = 2131820711;
        /* added by DevToolsApp */
        public static final int mtrl_picker_toggle_to_year_selection = 2131820712;
        /* added by DevToolsApp */
        public static final int mtrl_switch_thumb_group_name = 2131820713;
        /* added by DevToolsApp */
        public static final int mtrl_switch_thumb_path_checked = 2131820714;
        /* added by DevToolsApp */
        public static final int mtrl_switch_thumb_path_morphing = 2131820715;
        /* added by DevToolsApp */
        public static final int mtrl_switch_thumb_path_name = 2131820716;
        /* added by DevToolsApp */
        public static final int mtrl_switch_thumb_path_pressed = 2131820717;
        /* added by DevToolsApp */
        public static final int mtrl_switch_thumb_path_unchecked = 2131820718;
        /* added by DevToolsApp */
        public static final int mtrl_switch_track_decoration_path = 2131820719;
        /* added by DevToolsApp */
        public static final int mtrl_switch_track_path = 2131820720;
        /* added by DevToolsApp */
        public static final int mtrl_timepicker_cancel = 2131820721;
        /* added by DevToolsApp */
        public static final int mtrl_timepicker_confirm = 2131820722;
        /* added by DevToolsApp */
        public static final int password_toggle_content_description = 2131820723;
        /* added by DevToolsApp */
        public static final int path_password_eye = 2131820724;
        /* added by DevToolsApp */
        public static final int path_password_eye_mask_strike_through = 2131820725;
        /* added by DevToolsApp */
        public static final int path_password_eye_mask_visible = 2131820726;
        /* added by DevToolsApp */
        public static final int path_password_strike_through = 2131820727;
        /* added by DevToolsApp */
        public static final int search_menu_title = 2131820729;
        /* added by DevToolsApp */
        public static final int searchbar_scrolling_view_behavior = 2131820730;
        /* added by DevToolsApp */
        public static final int searchview_clear_text_content_description = 2131820731;
        /* added by DevToolsApp */
        public static final int searchview_navigation_content_description = 2131820732;
        /* added by DevToolsApp */
        public static final int side_sheet_accessibility_pane_title = 2131820733;
        /* added by DevToolsApp */
        public static final int side_sheet_behavior = 2131820734;
        /* added by DevToolsApp */
        public static final int status_bar_notification_info_overflow = 2131820735;

        private string() {
        }
    }

    public static final class style {
        public static int Base_Theme_SuperAdsPro = 2131886200;
        public static int Theme_SuperAdsPro = 2131886709;
        /* added by DevToolsApp */
        /* renamed from: AlertDialog.AppCompat */
        public static final int f0AlertDialog.AppCompat = 2131886080;
        /* added by DevToolsApp */
        /* renamed from: AlertDialog.AppCompat.Light */
        public static final int f1AlertDialog.AppCompat.Light = 2131886081;
        /* added by DevToolsApp */
        /* renamed from: Animation.AppCompat.Dialog */
        public static final int f2Animation.AppCompat.Dialog = 2131886082;
        /* added by DevToolsApp */
        /* renamed from: Animation.AppCompat.DropDownUp */
        public static final int f3Animation.AppCompat.DropDownUp = 2131886083;
        /* added by DevToolsApp */
        /* renamed from: Animation.AppCompat.Tooltip */
        public static final int f4Animation.AppCompat.Tooltip = 2131886084;
        /* added by DevToolsApp */
        /* renamed from: Animation.Design.BottomSheetDialog */
        public static final int f5Animation.Design.BottomSheetDialog = 2131886085;
        /* added by DevToolsApp */
        /* renamed from: Animation.Material3.BottomSheetDialog */
        public static final int f6Animation.Material3.BottomSheetDialog = 2131886086;
        /* added by DevToolsApp */
        /* renamed from: Animation.Material3.SideSheetDialog */
        public static final int f7Animation.Material3.SideSheetDialog = 2131886087;
        /* added by DevToolsApp */
        /* renamed from: Animation.Material3.SideSheetDialog.Left */
        public static final int f8Animation.Material3.SideSheetDialog.Left = 2131886088;
        /* added by DevToolsApp */
        /* renamed from: Animation.Material3.SideSheetDialog.Right */
        public static final int f9Animation.Material3.SideSheetDialog.Right = 2131886089;
        /* added by DevToolsApp */
        /* renamed from: Animation.MaterialComponents.BottomSheetDialog */
        public static final int f10Animation.MaterialComponents.BottomSheetDialog = 2131886090;
        /* added by DevToolsApp */
        /* renamed from: Base.AlertDialog.AppCompat */
        public static final int f11Base.AlertDialog.AppCompat = 2131886091;
        /* added by DevToolsApp */
        /* renamed from: Base.AlertDialog.AppCompat.Light */
        public static final int f12Base.AlertDialog.AppCompat.Light = 2131886092;
        /* added by DevToolsApp */
        /* renamed from: Base.Animation.AppCompat.Dialog */
        public static final int f13Base.Animation.AppCompat.Dialog = 2131886093;
        /* added by DevToolsApp */
        /* renamed from: Base.Animation.AppCompat.DropDownUp */
        public static final int f14Base.Animation.AppCompat.DropDownUp = 2131886094;
        /* added by DevToolsApp */
        /* renamed from: Base.Animation.AppCompat.Tooltip */
        public static final int f15Base.Animation.AppCompat.Tooltip = 2131886095;
        /* added by DevToolsApp */
        /* renamed from: Base.CardView */
        public static final int f16Base.CardView = 2131886096;
        /* added by DevToolsApp */
        /* renamed from: Base.DialogWindowTitle.AppCompat */
        public static final int f17Base.DialogWindowTitle.AppCompat = 2131886097;
        /* added by DevToolsApp */
        /* renamed from: Base.DialogWindowTitleBackground.AppCompat */
        public static final int f18Base.DialogWindowTitleBackground.AppCompat = 2131886098;
        /* added by DevToolsApp */
        /* renamed from: Base.MaterialAlertDialog.MaterialComponents.Title.Icon */
        public static final int f19Base.MaterialAlertDialog.MaterialComponents.Title.Icon = 2131886099;
        /* added by DevToolsApp */
        /* renamed from: Base.MaterialAlertDialog.MaterialComponents.Title.Panel */
        public static final int f20Base.MaterialAlertDialog.MaterialComponents.Title.Panel = 2131886100;
        /* added by DevToolsApp */
        /* renamed from: Base.MaterialAlertDialog.MaterialComponents.Title.Text */
        public static final int f21Base.MaterialAlertDialog.MaterialComponents.Title.Text = 2131886101;
        /* added by DevToolsApp */
        /* renamed from: Base.TextAppearance.AppCompat */
        public static final int f22Base.TextAppearance.AppCompat = 2131886102;
        /* added by DevToolsApp */
        /* renamed from: Base.TextAppearance.AppCompat.Body1 */
        public static final int f23Base.TextAppearance.AppCompat.Body1 = 2131886103;
        /* added by DevToolsApp */
        /* renamed from: Base.TextAppearance.AppCompat.Body2 */
        public static final int f24Base.TextAppearance.AppCompat.Body2 = 2131886104;
        /* added by DevToolsApp */
        /* renamed from: Base.TextAppearance.AppCompat.Button */
        public static final int f25Base.TextAppearance.AppCompat.Button = 2131886105;
        /* added by DevToolsApp */
        /* renamed from: Base.TextAppearance.AppCompat.Caption */
        public static final int f26Base.TextAppearance.AppCompat.Caption = 2131886106;
        /* added by DevToolsApp */
        /* renamed from: Base.TextAppearance.AppCompat.Display1 */
        public static final int f27Base.TextAppearance.AppCompat.Display1 = 2131886107;
        /* added by DevToolsApp */
        /* renamed from: Base.TextAppearance.AppCompat.Display2 */
        public static final int f28Base.TextAppearance.AppCompat.Display2 = 2131886108;
        /* added by DevToolsApp */
        /* renamed from: Base.TextAppearance.AppCompat.Display3 */
        public static final int f29Base.TextAppearance.AppCompat.Display3 = 2131886109;
        /* added by DevToolsApp */
        /* renamed from: Base.TextAppearance.AppCompat.Display4 */
        public static final int f30Base.TextAppearance.AppCompat.Display4 = 2131886110;
        /* added by DevToolsApp */
        /* renamed from: Base.TextAppearance.AppCompat.Headline */
        public static final int f31Base.TextAppearance.AppCompat.Headline = 2131886111;
        /* added by DevToolsApp */
        /* renamed from: Base.TextAppearance.AppCompat.Inverse */
        public static final int f32Base.TextAppearance.AppCompat.Inverse = 2131886112;
        /* added by DevToolsApp */
        /* renamed from: Base.TextAppearance.AppCompat.Large */
        public static final int f33Base.TextAppearance.AppCompat.Large = 2131886113;
        /* added by DevToolsApp */
        /* renamed from: Base.TextAppearance.AppCompat.Large.Inverse */
        public static final int f34Base.TextAppearance.AppCompat.Large.Inverse = 2131886114;
        /* added by DevToolsApp */
        /* renamed from: Base.TextAppearance.AppCompat.Light.Widget.PopupMenu.Large */
        public static final int f35Base.TextAppearance.AppCompat.Light.Widget.PopupMenu.Large = 2131886115;
        /* added by DevToolsApp */
        /* renamed from: Base.TextAppearance.AppCompat.Light.Widget.PopupMenu.Small */
        public static final int f36Base.TextAppearance.AppCompat.Light.Widget.PopupMenu.Small = 2131886116;
        /* added by DevToolsApp */
        /* renamed from: Base.TextAppearance.AppCompat.Medium */
        public static final int f37Base.TextAppearance.AppCompat.Medium = 2131886117;
        /* added by DevToolsApp */
        /* renamed from: Base.TextAppearance.AppCompat.Medium.Inverse */
        public static final int f38Base.TextAppearance.AppCompat.Medium.Inverse = 2131886118;
        /* added by DevToolsApp */
        /* renamed from: Base.TextAppearance.AppCompat.Menu */
        public static final int f39Base.TextAppearance.AppCompat.Menu = 2131886119;
        /* added by DevToolsApp */
        /* renamed from: Base.TextAppearance.AppCompat.SearchResult */
        public static final int f40Base.TextAppearance.AppCompat.SearchResult = 2131886120;
        /* added by DevToolsApp */
        /* renamed from: Base.TextAppearance.AppCompat.SearchResult.Subtitle */
        public static final int f41Base.TextAppearance.AppCompat.SearchResult.Subtitle = 2131886121;
        /* added by DevToolsApp */
        /* renamed from: Base.TextAppearance.AppCompat.SearchResult.Title */
        public static final int f42Base.TextAppearance.AppCompat.SearchResult.Title = 2131886122;
        /* added by DevToolsApp */
        /* renamed from: Base.TextAppearance.AppCompat.Small */
        public static final int f43Base.TextAppearance.AppCompat.Small = 2131886123;
        /* added by DevToolsApp */
        /* renamed from: Base.TextAppearance.AppCompat.Small.Inverse */
        public static final int f44Base.TextAppearance.AppCompat.Small.Inverse = 2131886124;
        /* added by DevToolsApp */
        /* renamed from: Base.TextAppearance.AppCompat.Subhead */
        public static final int f45Base.TextAppearance.AppCompat.Subhead = 2131886125;
        /* added by DevToolsApp */
        /* renamed from: Base.TextAppearance.AppCompat.Subhead.Inverse */
        public static final int f46Base.TextAppearance.AppCompat.Subhead.Inverse = 2131886126;
        /* added by DevToolsApp */
        /* renamed from: Base.TextAppearance.AppCompat.Title */
        public static final int f47Base.TextAppearance.AppCompat.Title = 2131886127;
        /* added by DevToolsApp */
        /* renamed from: Base.TextAppearance.AppCompat.Title.Inverse */
        public static final int f48Base.TextAppearance.AppCompat.Title.Inverse = 2131886128;
        /* added by DevToolsApp */
        /* renamed from: Base.TextAppearance.AppCompat.Tooltip */
        public static final int f49Base.TextAppearance.AppCompat.Tooltip = 2131886129;
        /* added by DevToolsApp */
        /* renamed from: Base.TextAppearance.AppCompat.Widget.ActionBar.Menu */
        public static final int f50Base.TextAppearance.AppCompat.Widget.ActionBar.Menu = 2131886130;
        /* added by DevToolsApp */
        /* renamed from: Base.TextAppearance.AppCompat.Widget.ActionBar.Subtitle */
        public static final int f51Base.TextAppearance.AppCompat.Widget.ActionBar.Subtitle = 2131886131;
        /* added by DevToolsApp */
        /* renamed from: Base.TextAppearance.AppCompat.Widget.ActionBar.Subtitle.Inverse */
        public static final int f52Base.TextAppearance.AppCompat.Widget.ActionBar.Subtitle.Inverse = 2131886132;
        /* added by DevToolsApp */
        /* renamed from: Base.TextAppearance.AppCompat.Widget.ActionBar.Title */
        public static final int f53Base.TextAppearance.AppCompat.Widget.ActionBar.Title = 2131886133;
        /* added by DevToolsApp */
        /* renamed from: Base.TextAppearance.AppCompat.Widget.ActionBar.Title.Inverse */
        public static final int f54Base.TextAppearance.AppCompat.Widget.ActionBar.Title.Inverse = 2131886134;
        /* added by DevToolsApp */
        /* renamed from: Base.TextAppearance.AppCompat.Widget.ActionMode.Subtitle */
        public static final int f55Base.TextAppearance.AppCompat.Widget.ActionMode.Subtitle = 2131886135;
        /* added by DevToolsApp */
        /* renamed from: Base.TextAppearance.AppCompat.Widget.ActionMode.Title */
        public static final int f56Base.TextAppearance.AppCompat.Widget.ActionMode.Title = 2131886136;
        /* added by DevToolsApp */
        /* renamed from: Base.TextAppearance.AppCompat.Widget.Button */
        public static final int f57Base.TextAppearance.AppCompat.Widget.Button = 2131886137;
        /* added by DevToolsApp */
        /* renamed from: Base.TextAppearance.AppCompat.Widget.Button.Borderless.Colored */
        public static final int f58Base.TextAppearance.AppCompat.Widget.Button.Borderless.Colored = 2131886138;
        /* added by DevToolsApp */
        /* renamed from: Base.TextAppearance.AppCompat.Widget.Button.Colored */
        public static final int f59Base.TextAppearance.AppCompat.Widget.Button.Colored = 2131886139;
        /* added by DevToolsApp */
        /* renamed from: Base.TextAppearance.AppCompat.Widget.Button.Inverse */
        public static final int f60Base.TextAppearance.AppCompat.Widget.Button.Inverse = 2131886140;
        /* added by DevToolsApp */
        /* renamed from: Base.TextAppearance.AppCompat.Widget.DropDownItem */
        public static final int f61Base.TextAppearance.AppCompat.Widget.DropDownItem = 2131886141;
        /* added by DevToolsApp */
        /* renamed from: Base.TextAppearance.AppCompat.Widget.PopupMenu.Header */
        public static final int f62Base.TextAppearance.AppCompat.Widget.PopupMenu.Header = 2131886142;
        /* added by DevToolsApp */
        /* renamed from: Base.TextAppearance.AppCompat.Widget.PopupMenu.Large */
        public static final int f63Base.TextAppearance.AppCompat.Widget.PopupMenu.Large = 2131886143;
        /* added by DevToolsApp */
        /* renamed from: Base.TextAppearance.AppCompat.Widget.PopupMenu.Small */
        public static final int f64Base.TextAppearance.AppCompat.Widget.PopupMenu.Small = 2131886144;
        /* added by DevToolsApp */
        /* renamed from: Base.TextAppearance.AppCompat.Widget.Switch */
        public static final int f65Base.TextAppearance.AppCompat.Widget.Switch = 2131886145;
        /* added by DevToolsApp */
        /* renamed from: Base.TextAppearance.AppCompat.Widget.TextView.SpinnerItem */
        public static final int f66Base.TextAppearance.AppCompat.Widget.TextView.SpinnerItem = 2131886146;
        /* added by DevToolsApp */
        /* renamed from: Base.TextAppearance.Material3.Search */
        public static final int f67Base.TextAppearance.Material3.Search = 2131886147;
        /* added by DevToolsApp */
        /* renamed from: Base.TextAppearance.MaterialComponents.Badge */
        public static final int f68Base.TextAppearance.MaterialComponents.Badge = 2131886148;
        /* added by DevToolsApp */
        /* renamed from: Base.TextAppearance.MaterialComponents.Button */
        public static final int f69Base.TextAppearance.MaterialComponents.Button = 2131886149;
        /* added by DevToolsApp */
        /* renamed from: Base.TextAppearance.MaterialComponents.Headline6 */
        public static final int f70Base.TextAppearance.MaterialComponents.Headline6 = 2131886150;
        /* added by DevToolsApp */
        /* renamed from: Base.TextAppearance.MaterialComponents.Subtitle2 */
        public static final int f71Base.TextAppearance.MaterialComponents.Subtitle2 = 2131886151;
        /* added by DevToolsApp */
        /* renamed from: Base.TextAppearance.Widget.AppCompat.ExpandedMenu.Item */
        public static final int f72Base.TextAppearance.Widget.AppCompat.ExpandedMenu.Item = 2131886152;
        /* added by DevToolsApp */
        /* renamed from: Base.TextAppearance.Widget.AppCompat.Toolbar.Subtitle */
        public static final int f73Base.TextAppearance.Widget.AppCompat.Toolbar.Subtitle = 2131886153;
        /* added by DevToolsApp */
        /* renamed from: Base.TextAppearance.Widget.AppCompat.Toolbar.Title */
        public static final int f74Base.TextAppearance.Widget.AppCompat.Toolbar.Title = 2131886154;
        /* added by DevToolsApp */
        /* renamed from: Base.Theme.AppCompat */
        public static final int f75Base.Theme.AppCompat = 2131886155;
        /* added by DevToolsApp */
        /* renamed from: Base.Theme.AppCompat.CompactMenu */
        public static final int f76Base.Theme.AppCompat.CompactMenu = 2131886156;
        /* added by DevToolsApp */
        /* renamed from: Base.Theme.AppCompat.Dialog */
        public static final int f77Base.Theme.AppCompat.Dialog = 2131886157;
        /* added by DevToolsApp */
        /* renamed from: Base.Theme.AppCompat.Dialog.Alert */
        public static final int f78Base.Theme.AppCompat.Dialog.Alert = 2131886158;
        /* added by DevToolsApp */
        /* renamed from: Base.Theme.AppCompat.Dialog.FixedSize */
        public static final int f79Base.Theme.AppCompat.Dialog.FixedSize = 2131886159;
        /* added by DevToolsApp */
        /* renamed from: Base.Theme.AppCompat.Dialog.MinWidth */
        public static final int f80Base.Theme.AppCompat.Dialog.MinWidth = 2131886160;
        /* added by DevToolsApp */
        /* renamed from: Base.Theme.AppCompat.DialogWhenLarge */
        public static final int f81Base.Theme.AppCompat.DialogWhenLarge = 2131886161;
        /* added by DevToolsApp */
        /* renamed from: Base.Theme.AppCompat.Light */
        public static final int f82Base.Theme.AppCompat.Light = 2131886162;
        /* added by DevToolsApp */
        /* renamed from: Base.Theme.AppCompat.Light.DarkActionBar */
        public static final int f83Base.Theme.AppCompat.Light.DarkActionBar = 2131886163;
        /* added by DevToolsApp */
        /* renamed from: Base.Theme.AppCompat.Light.Dialog */
        public static final int f84Base.Theme.AppCompat.Light.Dialog = 2131886164;
        /* added by DevToolsApp */
        /* renamed from: Base.Theme.AppCompat.Light.Dialog.Alert */
        public static final int f85Base.Theme.AppCompat.Light.Dialog.Alert = 2131886165;
        /* added by DevToolsApp */
        /* renamed from: Base.Theme.AppCompat.Light.Dialog.FixedSize */
        public static final int f86Base.Theme.AppCompat.Light.Dialog.FixedSize = 2131886166;
        /* added by DevToolsApp */
        /* renamed from: Base.Theme.AppCompat.Light.Dialog.MinWidth */
        public static final int f87Base.Theme.AppCompat.Light.Dialog.MinWidth = 2131886167;
        /* added by DevToolsApp */
        /* renamed from: Base.Theme.AppCompat.Light.DialogWhenLarge */
        public static final int f88Base.Theme.AppCompat.Light.DialogWhenLarge = 2131886168;
        /* added by DevToolsApp */
        /* renamed from: Base.Theme.Material3.Dark */
        public static final int f89Base.Theme.Material3.Dark = 2131886169;
        /* added by DevToolsApp */
        /* renamed from: Base.Theme.Material3.Dark.BottomSheetDialog */
        public static final int f90Base.Theme.Material3.Dark.BottomSheetDialog = 2131886170;
        /* added by DevToolsApp */
        /* renamed from: Base.Theme.Material3.Dark.Dialog */
        public static final int f91Base.Theme.Material3.Dark.Dialog = 2131886171;
        /* added by DevToolsApp */
        /* renamed from: Base.Theme.Material3.Dark.Dialog.FixedSize */
        public static final int f92Base.Theme.Material3.Dark.Dialog.FixedSize = 2131886172;
        /* added by DevToolsApp */
        /* renamed from: Base.Theme.Material3.Dark.DialogWhenLarge */
        public static final int f93Base.Theme.Material3.Dark.DialogWhenLarge = 2131886173;
        /* added by DevToolsApp */
        /* renamed from: Base.Theme.Material3.Dark.SideSheetDialog */
        public static final int f94Base.Theme.Material3.Dark.SideSheetDialog = 2131886174;
        /* added by DevToolsApp */
        /* renamed from: Base.Theme.Material3.Light */
        public static final int f95Base.Theme.Material3.Light = 2131886175;
        /* added by DevToolsApp */
        /* renamed from: Base.Theme.Material3.Light.BottomSheetDialog */
        public static final int f96Base.Theme.Material3.Light.BottomSheetDialog = 2131886176;
        /* added by DevToolsApp */
        /* renamed from: Base.Theme.Material3.Light.Dialog */
        public static final int f97Base.Theme.Material3.Light.Dialog = 2131886177;
        /* added by DevToolsApp */
        /* renamed from: Base.Theme.Material3.Light.Dialog.FixedSize */
        public static final int f98Base.Theme.Material3.Light.Dialog.FixedSize = 2131886178;
        /* added by DevToolsApp */
        /* renamed from: Base.Theme.Material3.Light.DialogWhenLarge */
        public static final int f99Base.Theme.Material3.Light.DialogWhenLarge = 2131886179;
        /* added by DevToolsApp */
        /* renamed from: Base.Theme.Material3.Light.SideSheetDialog */
        public static final int f100Base.Theme.Material3.Light.SideSheetDialog = 2131886180;
        /* added by DevToolsApp */
        /* renamed from: Base.Theme.MaterialComponents */
        public static final int f101Base.Theme.MaterialComponents = 2131886181;
        /* added by DevToolsApp */
        /* renamed from: Base.Theme.MaterialComponents.Bridge */
        public static final int f102Base.Theme.MaterialComponents.Bridge = 2131886182;
        /* added by DevToolsApp */
        /* renamed from: Base.Theme.MaterialComponents.CompactMenu */
        public static final int f103Base.Theme.MaterialComponents.CompactMenu = 2131886183;
        /* added by DevToolsApp */
        /* renamed from: Base.Theme.MaterialComponents.Dialog */
        public static final int f104Base.Theme.MaterialComponents.Dialog = 2131886184;
        /* added by DevToolsApp */
        /* renamed from: Base.Theme.MaterialComponents.Dialog.Alert */
        public static final int f105Base.Theme.MaterialComponents.Dialog.Alert = 2131886185;
        /* added by DevToolsApp */
        /* renamed from: Base.Theme.MaterialComponents.Dialog.Bridge */
        public static final int f106Base.Theme.MaterialComponents.Dialog.Bridge = 2131886186;
        /* added by DevToolsApp */
        /* renamed from: Base.Theme.MaterialComponents.Dialog.FixedSize */
        public static final int f107Base.Theme.MaterialComponents.Dialog.FixedSize = 2131886187;
        /* added by DevToolsApp */
        /* renamed from: Base.Theme.MaterialComponents.Dialog.MinWidth */
        public static final int f108Base.Theme.MaterialComponents.Dialog.MinWidth = 2131886188;
        /* added by DevToolsApp */
        /* renamed from: Base.Theme.MaterialComponents.DialogWhenLarge */
        public static final int f109Base.Theme.MaterialComponents.DialogWhenLarge = 2131886189;
        /* added by DevToolsApp */
        /* renamed from: Base.Theme.MaterialComponents.Light */
        public static final int f110Base.Theme.MaterialComponents.Light = 2131886190;
        /* added by DevToolsApp */
        /* renamed from: Base.Theme.MaterialComponents.Light.Bridge */
        public static final int f111Base.Theme.MaterialComponents.Light.Bridge = 2131886191;
        /* added by DevToolsApp */
        /* renamed from: Base.Theme.MaterialComponents.Light.DarkActionBar */
        public static final int f112Base.Theme.MaterialComponents.Light.DarkActionBar = 2131886192;
        /* added by DevToolsApp */
        /* renamed from: Base.Theme.MaterialComponents.Light.DarkActionBar.Bridge */
        public static final int f113Base.Theme.MaterialComponents.Light.DarkActionBar.Bridge = 2131886193;
        /* added by DevToolsApp */
        /* renamed from: Base.Theme.MaterialComponents.Light.Dialog */
        public static final int f114Base.Theme.MaterialComponents.Light.Dialog = 2131886194;
        /* added by DevToolsApp */
        /* renamed from: Base.Theme.MaterialComponents.Light.Dialog.Alert */
        public static final int f115Base.Theme.MaterialComponents.Light.Dialog.Alert = 2131886195;
        /* added by DevToolsApp */
        /* renamed from: Base.Theme.MaterialComponents.Light.Dialog.Bridge */
        public static final int f116Base.Theme.MaterialComponents.Light.Dialog.Bridge = 2131886196;
        /* added by DevToolsApp */
        /* renamed from: Base.Theme.MaterialComponents.Light.Dialog.FixedSize */
        public static final int f117Base.Theme.MaterialComponents.Light.Dialog.FixedSize = 2131886197;
        /* added by DevToolsApp */
        /* renamed from: Base.Theme.MaterialComponents.Light.Dialog.MinWidth */
        public static final int f118Base.Theme.MaterialComponents.Light.Dialog.MinWidth = 2131886198;
        /* added by DevToolsApp */
        /* renamed from: Base.Theme.MaterialComponents.Light.DialogWhenLarge */
        public static final int f119Base.Theme.MaterialComponents.Light.DialogWhenLarge = 2131886199;
        /* added by DevToolsApp */
        /* renamed from: Base.Theme.SuperAdsPro */
        public static final int f120Base.Theme.SuperAdsPro = 2131886200;
        /* added by DevToolsApp */
        /* renamed from: Base.ThemeOverlay.AppCompat */
        public static final int f121Base.ThemeOverlay.AppCompat = 2131886201;
        /* added by DevToolsApp */
        /* renamed from: Base.ThemeOverlay.AppCompat.ActionBar */
        public static final int f122Base.ThemeOverlay.AppCompat.ActionBar = 2131886202;
        /* added by DevToolsApp */
        /* renamed from: Base.ThemeOverlay.AppCompat.Dark */
        public static final int f123Base.ThemeOverlay.AppCompat.Dark = 2131886203;
        /* added by DevToolsApp */
        /* renamed from: Base.ThemeOverlay.AppCompat.Dark.ActionBar */
        public static final int f124Base.ThemeOverlay.AppCompat.Dark.ActionBar = 2131886204;
        /* added by DevToolsApp */
        /* renamed from: Base.ThemeOverlay.AppCompat.Dialog */
        public static final int f125Base.ThemeOverlay.AppCompat.Dialog = 2131886205;
        /* added by DevToolsApp */
        /* renamed from: Base.ThemeOverlay.AppCompat.Dialog.Alert */
        public static final int f126Base.ThemeOverlay.AppCompat.Dialog.Alert = 2131886206;
        /* added by DevToolsApp */
        /* renamed from: Base.ThemeOverlay.AppCompat.Light */
        public static final int f127Base.ThemeOverlay.AppCompat.Light = 2131886207;
        /* added by DevToolsApp */
        /* renamed from: Base.ThemeOverlay.Material3.AutoCompleteTextView */
        public static final int f128Base.ThemeOverlay.Material3.AutoCompleteTextView = 2131886208;
        /* added by DevToolsApp */
        /* renamed from: Base.ThemeOverlay.Material3.BottomSheetDialog */
        public static final int f129Base.ThemeOverlay.Material3.BottomSheetDialog = 2131886209;
        /* added by DevToolsApp */
        /* renamed from: Base.ThemeOverlay.Material3.Dialog */
        public static final int f130Base.ThemeOverlay.Material3.Dialog = 2131886210;
        /* added by DevToolsApp */
        /* renamed from: Base.ThemeOverlay.Material3.SideSheetDialog */
        public static final int f131Base.ThemeOverlay.Material3.SideSheetDialog = 2131886211;
        /* added by DevToolsApp */
        /* renamed from: Base.ThemeOverlay.Material3.TextInputEditText */
        public static final int f132Base.ThemeOverlay.Material3.TextInputEditText = 2131886212;
        /* added by DevToolsApp */
        /* renamed from: Base.ThemeOverlay.MaterialComponents.Dialog */
        public static final int f133Base.ThemeOverlay.MaterialComponents.Dialog = 2131886213;
        /* added by DevToolsApp */
        /* renamed from: Base.ThemeOverlay.MaterialComponents.Dialog.Alert */
        public static final int f134Base.ThemeOverlay.MaterialComponents.Dialog.Alert = 2131886214;
        /* added by DevToolsApp */
        /* renamed from: Base.ThemeOverlay.MaterialComponents.Dialog.Alert.Framework */
        public static final int f135Base.ThemeOverlay.MaterialComponents.Dialog.Alert.Framework = 2131886215;
        /* added by DevToolsApp */
        /* renamed from: Base.ThemeOverlay.MaterialComponents.Light.Dialog.Alert.Framework */
        public static final int f136Base.ThemeOverlay.MaterialComponents.Light.Dialog.Alert.Framework = 2131886216;
        /* added by DevToolsApp */
        /* renamed from: Base.ThemeOverlay.MaterialComponents.MaterialAlertDialog */
        public static final int f137Base.ThemeOverlay.MaterialComponents.MaterialAlertDialog = 2131886217;
        /* added by DevToolsApp */
        /* renamed from: Base.V14.Theme.Material3.Dark */
        public static final int f138Base.V14.Theme.Material3.Dark = 2131886218;
        /* added by DevToolsApp */
        /* renamed from: Base.V14.Theme.Material3.Dark.BottomSheetDialog */
        public static final int f139Base.V14.Theme.Material3.Dark.BottomSheetDialog = 2131886219;
        /* added by DevToolsApp */
        /* renamed from: Base.V14.Theme.Material3.Dark.Dialog */
        public static final int f140Base.V14.Theme.Material3.Dark.Dialog = 2131886220;
        /* added by DevToolsApp */
        /* renamed from: Base.V14.Theme.Material3.Dark.SideSheetDialog */
        public static final int f141Base.V14.Theme.Material3.Dark.SideSheetDialog = 2131886221;
        /* added by DevToolsApp */
        /* renamed from: Base.V14.Theme.Material3.Light */
        public static final int f142Base.V14.Theme.Material3.Light = 2131886222;
        /* added by DevToolsApp */
        /* renamed from: Base.V14.Theme.Material3.Light.BottomSheetDialog */
        public static final int f143Base.V14.Theme.Material3.Light.BottomSheetDialog = 2131886223;
        /* added by DevToolsApp */
        /* renamed from: Base.V14.Theme.Material3.Light.Dialog */
        public static final int f144Base.V14.Theme.Material3.Light.Dialog = 2131886224;
        /* added by DevToolsApp */
        /* renamed from: Base.V14.Theme.Material3.Light.SideSheetDialog */
        public static final int f145Base.V14.Theme.Material3.Light.SideSheetDialog = 2131886225;
        /* added by DevToolsApp */
        /* renamed from: Base.V14.Theme.MaterialComponents */
        public static final int f146Base.V14.Theme.MaterialComponents = 2131886226;
        /* added by DevToolsApp */
        /* renamed from: Base.V14.Theme.MaterialComponents.Bridge */
        public static final int f147Base.V14.Theme.MaterialComponents.Bridge = 2131886227;
        /* added by DevToolsApp */
        /* renamed from: Base.V14.Theme.MaterialComponents.Dialog */
        public static final int f148Base.V14.Theme.MaterialComponents.Dialog = 2131886228;
        /* added by DevToolsApp */
        /* renamed from: Base.V14.Theme.MaterialComponents.Dialog.Bridge */
        public static final int f149Base.V14.Theme.MaterialComponents.Dialog.Bridge = 2131886229;
        /* added by DevToolsApp */
        /* renamed from: Base.V14.Theme.MaterialComponents.Light */
        public static final int f150Base.V14.Theme.MaterialComponents.Light = 2131886230;
        /* added by DevToolsApp */
        /* renamed from: Base.V14.Theme.MaterialComponents.Light.Bridge */
        public static final int f151Base.V14.Theme.MaterialComponents.Light.Bridge = 2131886231;
        /* added by DevToolsApp */
        /* renamed from: Base.V14.Theme.MaterialComponents.Light.DarkActionBar.Bridge */
        public static final int f152Base.V14.Theme.MaterialComponents.Light.DarkActionBar.Bridge = 2131886232;
        /* added by DevToolsApp */
        /* renamed from: Base.V14.Theme.MaterialComponents.Light.Dialog */
        public static final int f153Base.V14.Theme.MaterialComponents.Light.Dialog = 2131886233;
        /* added by DevToolsApp */
        /* renamed from: Base.V14.Theme.MaterialComponents.Light.Dialog.Bridge */
        public static final int f154Base.V14.Theme.MaterialComponents.Light.Dialog.Bridge = 2131886234;
        /* added by DevToolsApp */
        /* renamed from: Base.V14.ThemeOverlay.Material3.BottomSheetDialog */
        public static final int f155Base.V14.ThemeOverlay.Material3.BottomSheetDialog = 2131886235;
        /* added by DevToolsApp */
        /* renamed from: Base.V14.ThemeOverlay.Material3.SideSheetDialog */
        public static final int f156Base.V14.ThemeOverlay.Material3.SideSheetDialog = 2131886236;
        /* added by DevToolsApp */
        /* renamed from: Base.V14.ThemeOverlay.MaterialComponents.BottomSheetDialog */
        public static final int f157Base.V14.ThemeOverlay.MaterialComponents.BottomSheetDialog = 2131886237;
        /* added by DevToolsApp */
        /* renamed from: Base.V14.ThemeOverlay.MaterialComponents.Dialog */
        public static final int f158Base.V14.ThemeOverlay.MaterialComponents.Dialog = 2131886238;
        /* added by DevToolsApp */
        /* renamed from: Base.V14.ThemeOverlay.MaterialComponents.Dialog.Alert */
        public static final int f159Base.V14.ThemeOverlay.MaterialComponents.Dialog.Alert = 2131886239;
        /* added by DevToolsApp */
        /* renamed from: Base.V14.ThemeOverlay.MaterialComponents.MaterialAlertDialog */
        public static final int f160Base.V14.ThemeOverlay.MaterialComponents.MaterialAlertDialog = 2131886240;
        /* added by DevToolsApp */
        /* renamed from: Base.V14.Widget.MaterialComponents.AutoCompleteTextView */
        public static final int f161Base.V14.Widget.MaterialComponents.AutoCompleteTextView = 2131886241;
        /* added by DevToolsApp */
        /* renamed from: Base.V21.Theme.AppCompat */
        public static final int f162Base.V21.Theme.AppCompat = 2131886242;
        /* added by DevToolsApp */
        /* renamed from: Base.V21.Theme.AppCompat.Dialog */
        public static final int f163Base.V21.Theme.AppCompat.Dialog = 2131886243;
        /* added by DevToolsApp */
        /* renamed from: Base.V21.Theme.AppCompat.Light */
        public static final int f164Base.V21.Theme.AppCompat.Light = 2131886244;
        /* added by DevToolsApp */
        /* renamed from: Base.V21.Theme.AppCompat.Light.Dialog */
        public static final int f165Base.V21.Theme.AppCompat.Light.Dialog = 2131886245;
        /* added by DevToolsApp */
        /* renamed from: Base.V21.Theme.MaterialComponents */
        public static final int f166Base.V21.Theme.MaterialComponents = 2131886246;
        /* added by DevToolsApp */
        /* renamed from: Base.V21.Theme.MaterialComponents.Dialog */
        public static final int f167Base.V21.Theme.MaterialComponents.Dialog = 2131886247;
        /* added by DevToolsApp */
        /* renamed from: Base.V21.Theme.MaterialComponents.Light */
        public static final int f168Base.V21.Theme.MaterialComponents.Light = 2131886248;
        /* added by DevToolsApp */
        /* renamed from: Base.V21.Theme.MaterialComponents.Light.Dialog */
        public static final int f169Base.V21.Theme.MaterialComponents.Light.Dialog = 2131886249;
        /* added by DevToolsApp */
        /* renamed from: Base.V21.ThemeOverlay.AppCompat.Dialog */
        public static final int f170Base.V21.ThemeOverlay.AppCompat.Dialog = 2131886250;
        /* added by DevToolsApp */
        /* renamed from: Base.V21.ThemeOverlay.Material3.BottomSheetDialog */
        public static final int f171Base.V21.ThemeOverlay.Material3.BottomSheetDialog = 2131886251;
        /* added by DevToolsApp */
        /* renamed from: Base.V21.ThemeOverlay.Material3.SideSheetDialog */
        public static final int f172Base.V21.ThemeOverlay.Material3.SideSheetDialog = 2131886252;
        /* added by DevToolsApp */
        /* renamed from: Base.V21.ThemeOverlay.MaterialComponents.BottomSheetDialog */
        public static final int f173Base.V21.ThemeOverlay.MaterialComponents.BottomSheetDialog = 2131886253;
        /* added by DevToolsApp */
        /* renamed from: Base.V22.Theme.AppCompat */
        public static final int f174Base.V22.Theme.AppCompat = 2131886254;
        /* added by DevToolsApp */
        /* renamed from: Base.V22.Theme.AppCompat.Light */
        public static final int f175Base.V22.Theme.AppCompat.Light = 2131886255;
        /* added by DevToolsApp */
        /* renamed from: Base.V23.Theme.AppCompat */
        public static final int f176Base.V23.Theme.AppCompat = 2131886256;
        /* added by DevToolsApp */
        /* renamed from: Base.V23.Theme.AppCompat.Light */
        public static final int f177Base.V23.Theme.AppCompat.Light = 2131886257;
        /* added by DevToolsApp */
        /* renamed from: Base.V24.Theme.Material3.Dark */
        public static final int f178Base.V24.Theme.Material3.Dark = 2131886258;
        /* added by DevToolsApp */
        /* renamed from: Base.V24.Theme.Material3.Dark.Dialog */
        public static final int f179Base.V24.Theme.Material3.Dark.Dialog = 2131886259;
        /* added by DevToolsApp */
        /* renamed from: Base.V24.Theme.Material3.Light */
        public static final int f180Base.V24.Theme.Material3.Light = 2131886260;
        /* added by DevToolsApp */
        /* renamed from: Base.V24.Theme.Material3.Light.Dialog */
        public static final int f181Base.V24.Theme.Material3.Light.Dialog = 2131886261;
        /* added by DevToolsApp */
        /* renamed from: Base.V26.Theme.AppCompat */
        public static final int f182Base.V26.Theme.AppCompat = 2131886262;
        /* added by DevToolsApp */
        /* renamed from: Base.V26.Theme.AppCompat.Light */
        public static final int f183Base.V26.Theme.AppCompat.Light = 2131886263;
        /* added by DevToolsApp */
        /* renamed from: Base.V26.Widget.AppCompat.Toolbar */
        public static final int f184Base.V26.Widget.AppCompat.Toolbar = 2131886264;
        /* added by DevToolsApp */
        /* renamed from: Base.V28.Theme.AppCompat */
        public static final int f185Base.V28.Theme.AppCompat = 2131886265;
        /* added by DevToolsApp */
        /* renamed from: Base.V28.Theme.AppCompat.Light */
        public static final int f186Base.V28.Theme.AppCompat.Light = 2131886266;
        /* added by DevToolsApp */
        /* renamed from: Base.V7.Theme.AppCompat */
        public static final int f187Base.V7.Theme.AppCompat = 2131886267;
        /* added by DevToolsApp */
        /* renamed from: Base.V7.Theme.AppCompat.Dialog */
        public static final int f188Base.V7.Theme.AppCompat.Dialog = 2131886268;
        /* added by DevToolsApp */
        /* renamed from: Base.V7.Theme.AppCompat.Light */
        public static final int f189Base.V7.Theme.AppCompat.Light = 2131886269;
        /* added by DevToolsApp */
        /* renamed from: Base.V7.Theme.AppCompat.Light.Dialog */
        public static final int f190Base.V7.Theme.AppCompat.Light.Dialog = 2131886270;
        /* added by DevToolsApp */
        /* renamed from: Base.V7.ThemeOverlay.AppCompat.Dialog */
        public static final int f191Base.V7.ThemeOverlay.AppCompat.Dialog = 2131886271;
        /* added by DevToolsApp */
        /* renamed from: Base.V7.Widget.AppCompat.AutoCompleteTextView */
        public static final int f192Base.V7.Widget.AppCompat.AutoCompleteTextView = 2131886272;
        /* added by DevToolsApp */
        /* renamed from: Base.V7.Widget.AppCompat.EditText */
        public static final int f193Base.V7.Widget.AppCompat.EditText = 2131886273;
        /* added by DevToolsApp */
        /* renamed from: Base.V7.Widget.AppCompat.Toolbar */
        public static final int f194Base.V7.Widget.AppCompat.Toolbar = 2131886274;
        /* added by DevToolsApp */
        /* renamed from: Base.Widget.AppCompat.ActionBar */
        public static final int f195Base.Widget.AppCompat.ActionBar = 2131886275;
        /* added by DevToolsApp */
        /* renamed from: Base.Widget.AppCompat.ActionBar.Solid */
        public static final int f196Base.Widget.AppCompat.ActionBar.Solid = 2131886276;
        /* added by DevToolsApp */
        /* renamed from: Base.Widget.AppCompat.ActionBar.TabBar */
        public static final int f197Base.Widget.AppCompat.ActionBar.TabBar = 2131886277;
        /* added by DevToolsApp */
        /* renamed from: Base.Widget.AppCompat.ActionBar.TabText */
        public static final int f198Base.Widget.AppCompat.ActionBar.TabText = 2131886278;
        /* added by DevToolsApp */
        /* renamed from: Base.Widget.AppCompat.ActionBar.TabView */
        public static final int f199Base.Widget.AppCompat.ActionBar.TabView = 2131886279;
        /* added by DevToolsApp */
        /* renamed from: Base.Widget.AppCompat.ActionButton */
        public static final int f200Base.Widget.AppCompat.ActionButton = 2131886280;
        /* added by DevToolsApp */
        /* renamed from: Base.Widget.AppCompat.ActionButton.CloseMode */
        public static final int f201Base.Widget.AppCompat.ActionButton.CloseMode = 2131886281;
        /* added by DevToolsApp */
        /* renamed from: Base.Widget.AppCompat.ActionButton.Overflow */
        public static final int f202Base.Widget.AppCompat.ActionButton.Overflow = 2131886282;
        /* added by DevToolsApp */
        /* renamed from: Base.Widget.AppCompat.ActionMode */
        public static final int f203Base.Widget.AppCompat.ActionMode = 2131886283;
        /* added by DevToolsApp */
        /* renamed from: Base.Widget.AppCompat.ActivityChooserView */
        public static final int f204Base.Widget.AppCompat.ActivityChooserView = 2131886284;
        /* added by DevToolsApp */
        /* renamed from: Base.Widget.AppCompat.AutoCompleteTextView */
        public static final int f205Base.Widget.AppCompat.AutoCompleteTextView = 2131886285;
        /* added by DevToolsApp */
        /* renamed from: Base.Widget.AppCompat.Button */
        public static final int f206Base.Widget.AppCompat.Button = 2131886286;
        /* added by DevToolsApp */
        /* renamed from: Base.Widget.AppCompat.Button.Borderless */
        public static final int f207Base.Widget.AppCompat.Button.Borderless = 2131886287;
        /* added by DevToolsApp */
        /* renamed from: Base.Widget.AppCompat.Button.Borderless.Colored */
        public static final int f208Base.Widget.AppCompat.Button.Borderless.Colored = 2131886288;
        /* added by DevToolsApp */
        /* renamed from: Base.Widget.AppCompat.Button.ButtonBar.AlertDialog */
        public static final int f209Base.Widget.AppCompat.Button.ButtonBar.AlertDialog = 2131886289;
        /* added by DevToolsApp */
        /* renamed from: Base.Widget.AppCompat.Button.Colored */
        public static final int f210Base.Widget.AppCompat.Button.Colored = 2131886290;
        /* added by DevToolsApp */
        /* renamed from: Base.Widget.AppCompat.Button.Small */
        public static final int f211Base.Widget.AppCompat.Button.Small = 2131886291;
        /* added by DevToolsApp */
        /* renamed from: Base.Widget.AppCompat.ButtonBar */
        public static final int f212Base.Widget.AppCompat.ButtonBar = 2131886292;
        /* added by DevToolsApp */
        /* renamed from: Base.Widget.AppCompat.ButtonBar.AlertDialog */
        public static final int f213Base.Widget.AppCompat.ButtonBar.AlertDialog = 2131886293;
        /* added by DevToolsApp */
        /* renamed from: Base.Widget.AppCompat.CompoundButton.CheckBox */
        public static final int f214Base.Widget.AppCompat.CompoundButton.CheckBox = 2131886294;
        /* added by DevToolsApp */
        /* renamed from: Base.Widget.AppCompat.CompoundButton.RadioButton */
        public static final int f215Base.Widget.AppCompat.CompoundButton.RadioButton = 2131886295;
        /* added by DevToolsApp */
        /* renamed from: Base.Widget.AppCompat.CompoundButton.Switch */
        public static final int f216Base.Widget.AppCompat.CompoundButton.Switch = 2131886296;
        /* added by DevToolsApp */
        /* renamed from: Base.Widget.AppCompat.DrawerArrowToggle */
        public static final int f217Base.Widget.AppCompat.DrawerArrowToggle = 2131886297;
        /* added by DevToolsApp */
        /* renamed from: Base.Widget.AppCompat.DrawerArrowToggle.Common */
        public static final int f218Base.Widget.AppCompat.DrawerArrowToggle.Common = 2131886298;
        /* added by DevToolsApp */
        /* renamed from: Base.Widget.AppCompat.DropDownItem.Spinner */
        public static final int f219Base.Widget.AppCompat.DropDownItem.Spinner = 2131886299;
        /* added by DevToolsApp */
        /* renamed from: Base.Widget.AppCompat.EditText */
        public static final int f220Base.Widget.AppCompat.EditText = 2131886300;
        /* added by DevToolsApp */
        /* renamed from: Base.Widget.AppCompat.ImageButton */
        public static final int f221Base.Widget.AppCompat.ImageButton = 2131886301;
        /* added by DevToolsApp */
        /* renamed from: Base.Widget.AppCompat.Light.ActionBar */
        public static final int f222Base.Widget.AppCompat.Light.ActionBar = 2131886302;
        /* added by DevToolsApp */
        /* renamed from: Base.Widget.AppCompat.Light.ActionBar.Solid */
        public static final int f223Base.Widget.AppCompat.Light.ActionBar.Solid = 2131886303;
        /* added by DevToolsApp */
        /* renamed from: Base.Widget.AppCompat.Light.ActionBar.TabBar */
        public static final int f224Base.Widget.AppCompat.Light.ActionBar.TabBar = 2131886304;
        /* added by DevToolsApp */
        /* renamed from: Base.Widget.AppCompat.Light.ActionBar.TabText */
        public static final int f225Base.Widget.AppCompat.Light.ActionBar.TabText = 2131886305;
        /* added by DevToolsApp */
        /* renamed from: Base.Widget.AppCompat.Light.ActionBar.TabText.Inverse */
        public static final int f226Base.Widget.AppCompat.Light.ActionBar.TabText.Inverse = 2131886306;
        /* added by DevToolsApp */
        /* renamed from: Base.Widget.AppCompat.Light.ActionBar.TabView */
        public static final int f227Base.Widget.AppCompat.Light.ActionBar.TabView = 2131886307;
        /* added by DevToolsApp */
        /* renamed from: Base.Widget.AppCompat.Light.PopupMenu */
        public static final int f228Base.Widget.AppCompat.Light.PopupMenu = 2131886308;
        /* added by DevToolsApp */
        /* renamed from: Base.Widget.AppCompat.Light.PopupMenu.Overflow */
        public static final int f229Base.Widget.AppCompat.Light.PopupMenu.Overflow = 2131886309;
        /* added by DevToolsApp */
        /* renamed from: Base.Widget.AppCompat.ListMenuView */
        public static final int f230Base.Widget.AppCompat.ListMenuView = 2131886310;
        /* added by DevToolsApp */
        /* renamed from: Base.Widget.AppCompat.ListPopupWindow */
        public static final int f231Base.Widget.AppCompat.ListPopupWindow = 2131886311;
        /* added by DevToolsApp */
        /* renamed from: Base.Widget.AppCompat.ListView */
        public static final int f232Base.Widget.AppCompat.ListView = 2131886312;
        /* added by DevToolsApp */
        /* renamed from: Base.Widget.AppCompat.ListView.DropDown */
        public static final int f233Base.Widget.AppCompat.ListView.DropDown = 2131886313;
        /* added by DevToolsApp */
        /* renamed from: Base.Widget.AppCompat.ListView.Menu */
        public static final int f234Base.Widget.AppCompat.ListView.Menu = 2131886314;
        /* added by DevToolsApp */
        /* renamed from: Base.Widget.AppCompat.PopupMenu */
        public static final int f235Base.Widget.AppCompat.PopupMenu = 2131886315;
        /* added by DevToolsApp */
        /* renamed from: Base.Widget.AppCompat.PopupMenu.Overflow */
        public static final int f236Base.Widget.AppCompat.PopupMenu.Overflow = 2131886316;
        /* added by DevToolsApp */
        /* renamed from: Base.Widget.AppCompat.PopupWindow */
        public static final int f237Base.Widget.AppCompat.PopupWindow = 2131886317;
        /* added by DevToolsApp */
        /* renamed from: Base.Widget.AppCompat.ProgressBar */
        public static final int f238Base.Widget.AppCompat.ProgressBar = 2131886318;
        /* added by DevToolsApp */
        /* renamed from: Base.Widget.AppCompat.ProgressBar.Horizontal */
        public static final int f239Base.Widget.AppCompat.ProgressBar.Horizontal = 2131886319;
        /* added by DevToolsApp */
        /* renamed from: Base.Widget.AppCompat.RatingBar */
        public static final int f240Base.Widget.AppCompat.RatingBar = 2131886320;
        /* added by DevToolsApp */
        /* renamed from: Base.Widget.AppCompat.RatingBar.Indicator */
        public static final int f241Base.Widget.AppCompat.RatingBar.Indicator = 2131886321;
        /* added by DevToolsApp */
        /* renamed from: Base.Widget.AppCompat.RatingBar.Small */
        public static final int f242Base.Widget.AppCompat.RatingBar.Small = 2131886322;
        /* added by DevToolsApp */
        /* renamed from: Base.Widget.AppCompat.SearchView */
        public static final int f243Base.Widget.AppCompat.SearchView = 2131886323;
        /* added by DevToolsApp */
        /* renamed from: Base.Widget.AppCompat.SearchView.ActionBar */
        public static final int f244Base.Widget.AppCompat.SearchView.ActionBar = 2131886324;
        /* added by DevToolsApp */
        /* renamed from: Base.Widget.AppCompat.SeekBar */
        public static final int f245Base.Widget.AppCompat.SeekBar = 2131886325;
        /* added by DevToolsApp */
        /* renamed from: Base.Widget.AppCompat.SeekBar.Discrete */
        public static final int f246Base.Widget.AppCompat.SeekBar.Discrete = 2131886326;
        /* added by DevToolsApp */
        /* renamed from: Base.Widget.AppCompat.Spinner */
        public static final int f247Base.Widget.AppCompat.Spinner = 2131886327;
        /* added by DevToolsApp */
        /* renamed from: Base.Widget.AppCompat.Spinner.Underlined */
        public static final int f248Base.Widget.AppCompat.Spinner.Underlined = 2131886328;
        /* added by DevToolsApp */
        /* renamed from: Base.Widget.AppCompat.TextView */
        public static final int f249Base.Widget.AppCompat.TextView = 2131886329;
        /* added by DevToolsApp */
        /* renamed from: Base.Widget.AppCompat.TextView.SpinnerItem */
        public static final int f250Base.Widget.AppCompat.TextView.SpinnerItem = 2131886330;
        /* added by DevToolsApp */
        /* renamed from: Base.Widget.AppCompat.Toolbar */
        public static final int f251Base.Widget.AppCompat.Toolbar = 2131886331;
        /* added by DevToolsApp */
        /* renamed from: Base.Widget.AppCompat.Toolbar.Button.Navigation */
        public static final int f252Base.Widget.AppCompat.Toolbar.Button.Navigation = 2131886332;
        /* added by DevToolsApp */
        /* renamed from: Base.Widget.Design.TabLayout */
        public static final int f253Base.Widget.Design.TabLayout = 2131886333;
        /* added by DevToolsApp */
        /* renamed from: Base.Widget.Material3.ActionBar.Solid */
        public static final int f254Base.Widget.Material3.ActionBar.Solid = 2131886334;
        /* added by DevToolsApp */
        /* renamed from: Base.Widget.Material3.ActionMode */
        public static final int f255Base.Widget.Material3.ActionMode = 2131886335;
        /* added by DevToolsApp */
        /* renamed from: Base.Widget.Material3.BottomNavigationView */
        public static final int f256Base.Widget.Material3.BottomNavigationView = 2131886336;
        /* added by DevToolsApp */
        /* renamed from: Base.Widget.Material3.CardView */
        public static final int f257Base.Widget.Material3.CardView = 2131886337;
        /* added by DevToolsApp */
        /* renamed from: Base.Widget.Material3.Chip */
        public static final int f258Base.Widget.Material3.Chip = 2131886338;
        /* added by DevToolsApp */
        /* renamed from: Base.Widget.Material3.CollapsingToolbar */
        public static final int f259Base.Widget.Material3.CollapsingToolbar = 2131886339;
        /* added by DevToolsApp */
        /* renamed from: Base.Widget.Material3.CompoundButton.CheckBox */
        public static final int f260Base.Widget.Material3.CompoundButton.CheckBox = 2131886340;
        /* added by DevToolsApp */
        /* renamed from: Base.Widget.Material3.CompoundButton.RadioButton */
        public static final int f261Base.Widget.Material3.CompoundButton.RadioButton = 2131886341;
        /* added by DevToolsApp */
        /* renamed from: Base.Widget.Material3.CompoundButton.Switch */
        public static final int f262Base.Widget.Material3.CompoundButton.Switch = 2131886342;
        /* added by DevToolsApp */
        /* renamed from: Base.Widget.Material3.ExtendedFloatingActionButton */
        public static final int f263Base.Widget.Material3.ExtendedFloatingActionButton = 2131886343;
        /* added by DevToolsApp */
        /* renamed from: Base.Widget.Material3.ExtendedFloatingActionButton.Icon */
        public static final int f264Base.Widget.Material3.ExtendedFloatingActionButton.Icon = 2131886344;
        /* added by DevToolsApp */
        /* renamed from: Base.Widget.Material3.FloatingActionButton */
        public static final int f265Base.Widget.Material3.FloatingActionButton = 2131886345;
        /* added by DevToolsApp */
        /* renamed from: Base.Widget.Material3.FloatingActionButton.Large */
        public static final int f266Base.Widget.Material3.FloatingActionButton.Large = 2131886346;
        /* added by DevToolsApp */
        /* renamed from: Base.Widget.Material3.FloatingActionButton.Small */
        public static final int f267Base.Widget.Material3.FloatingActionButton.Small = 2131886347;
        /* added by DevToolsApp */
        /* renamed from: Base.Widget.Material3.Light.ActionBar.Solid */
        public static final int f268Base.Widget.Material3.Light.ActionBar.Solid = 2131886348;
        /* added by DevToolsApp */
        /* renamed from: Base.Widget.Material3.MaterialCalendar.NavigationButton */
        public static final int f269Base.Widget.Material3.MaterialCalendar.NavigationButton = 2131886349;
        /* added by DevToolsApp */
        /* renamed from: Base.Widget.Material3.Snackbar */
        public static final int f270Base.Widget.Material3.Snackbar = 2131886350;
        /* added by DevToolsApp */
        /* renamed from: Base.Widget.Material3.TabLayout */
        public static final int f271Base.Widget.Material3.TabLayout = 2131886351;
        /* added by DevToolsApp */
        /* renamed from: Base.Widget.Material3.TabLayout.OnSurface */
        public static final int f272Base.Widget.Material3.TabLayout.OnSurface = 2131886352;
        /* added by DevToolsApp */
        /* renamed from: Base.Widget.Material3.TabLayout.Secondary */
        public static final int f273Base.Widget.Material3.TabLayout.Secondary = 2131886353;
        /* added by DevToolsApp */
        /* renamed from: Base.Widget.MaterialComponents.AutoCompleteTextView */
        public static final int f274Base.Widget.MaterialComponents.AutoCompleteTextView = 2131886354;
        /* added by DevToolsApp */
        /* renamed from: Base.Widget.MaterialComponents.CheckedTextView */
        public static final int f275Base.Widget.MaterialComponents.CheckedTextView = 2131886355;
        /* added by DevToolsApp */
        /* renamed from: Base.Widget.MaterialComponents.Chip */
        public static final int f276Base.Widget.MaterialComponents.Chip = 2131886356;
        /* added by DevToolsApp */
        /* renamed from: Base.Widget.MaterialComponents.MaterialCalendar.HeaderToggleButton */
        public static final int f277Base.Widget.MaterialComponents.MaterialCalendar.HeaderToggleButton = 2131886357;
        /* added by DevToolsApp */
        /* renamed from: Base.Widget.MaterialComponents.MaterialCalendar.NavigationButton */
        public static final int f278Base.Widget.MaterialComponents.MaterialCalendar.NavigationButton = 2131886358;
        /* added by DevToolsApp */
        /* renamed from: Base.Widget.MaterialComponents.PopupMenu */
        public static final int f279Base.Widget.MaterialComponents.PopupMenu = 2131886359;
        /* added by DevToolsApp */
        /* renamed from: Base.Widget.MaterialComponents.PopupMenu.ContextMenu */
        public static final int f280Base.Widget.MaterialComponents.PopupMenu.ContextMenu = 2131886360;
        /* added by DevToolsApp */
        /* renamed from: Base.Widget.MaterialComponents.PopupMenu.ListPopupWindow */
        public static final int f281Base.Widget.MaterialComponents.PopupMenu.ListPopupWindow = 2131886361;
        /* added by DevToolsApp */
        /* renamed from: Base.Widget.MaterialComponents.PopupMenu.Overflow */
        public static final int f282Base.Widget.MaterialComponents.PopupMenu.Overflow = 2131886362;
        /* added by DevToolsApp */
        /* renamed from: Base.Widget.MaterialComponents.Slider */
        public static final int f283Base.Widget.MaterialComponents.Slider = 2131886363;
        /* added by DevToolsApp */
        /* renamed from: Base.Widget.MaterialComponents.Snackbar */
        public static final int f284Base.Widget.MaterialComponents.Snackbar = 2131886364;
        /* added by DevToolsApp */
        /* renamed from: Base.Widget.MaterialComponents.TextInputEditText */
        public static final int f285Base.Widget.MaterialComponents.TextInputEditText = 2131886365;
        /* added by DevToolsApp */
        /* renamed from: Base.Widget.MaterialComponents.TextInputLayout */
        public static final int f286Base.Widget.MaterialComponents.TextInputLayout = 2131886366;
        /* added by DevToolsApp */
        /* renamed from: Base.Widget.MaterialComponents.TextView */
        public static final int f287Base.Widget.MaterialComponents.TextView = 2131886367;
        /* added by DevToolsApp */
        public static final int CardView = 2131886368;
        /* added by DevToolsApp */
        /* renamed from: CardView.Dark */
        public static final int f288CardView.Dark = 2131886369;
        /* added by DevToolsApp */
        /* renamed from: CardView.Light */
        public static final int f289CardView.Light = 2131886370;
        /* added by DevToolsApp */
        /* renamed from: MaterialAlertDialog.Material3 */
        public static final int f290MaterialAlertDialog.Material3 = 2131886371;
        /* added by DevToolsApp */
        /* renamed from: MaterialAlertDialog.Material3.Animation */
        public static final int f291MaterialAlertDialog.Material3.Animation = 2131886372;
        /* added by DevToolsApp */
        /* renamed from: MaterialAlertDialog.Material3.Body.Text */
        public static final int f292MaterialAlertDialog.Material3.Body.Text = 2131886373;
        /* added by DevToolsApp */
        /* renamed from: MaterialAlertDialog.Material3.Body.Text.CenterStacked */
        public static final int f293MaterialAlertDialog.Material3.Body.Text.CenterStacked = 2131886374;
        /* added by DevToolsApp */
        /* renamed from: MaterialAlertDialog.Material3.Title.Icon */
        public static final int f294MaterialAlertDialog.Material3.Title.Icon = 2131886375;
        /* added by DevToolsApp */
        /* renamed from: MaterialAlertDialog.Material3.Title.Icon.CenterStacked */
        public static final int f295MaterialAlertDialog.Material3.Title.Icon.CenterStacked = 2131886376;
        /* added by DevToolsApp */
        /* renamed from: MaterialAlertDialog.Material3.Title.Panel */
        public static final int f296MaterialAlertDialog.Material3.Title.Panel = 2131886377;
        /* added by DevToolsApp */
        /* renamed from: MaterialAlertDialog.Material3.Title.Panel.CenterStacked */
        public static final int f297MaterialAlertDialog.Material3.Title.Panel.CenterStacked = 2131886378;
        /* added by DevToolsApp */
        /* renamed from: MaterialAlertDialog.Material3.Title.Text */
        public static final int f298MaterialAlertDialog.Material3.Title.Text = 2131886379;
        /* added by DevToolsApp */
        /* renamed from: MaterialAlertDialog.Material3.Title.Text.CenterStacked */
        public static final int f299MaterialAlertDialog.Material3.Title.Text.CenterStacked = 2131886380;
        /* added by DevToolsApp */
        /* renamed from: MaterialAlertDialog.MaterialComponents */
        public static final int f300MaterialAlertDialog.MaterialComponents = 2131886381;
        /* added by DevToolsApp */
        /* renamed from: MaterialAlertDialog.MaterialComponents.Body.Text */
        public static final int f301MaterialAlertDialog.MaterialComponents.Body.Text = 2131886382;
        /* added by DevToolsApp */
        /* renamed from: MaterialAlertDialog.MaterialComponents.Picker.Date.Calendar */
        public static final int f302MaterialAlertDialog.MaterialComponents.Picker.Date.Calendar = 2131886383;
        /* added by DevToolsApp */
        /* renamed from: MaterialAlertDialog.MaterialComponents.Picker.Date.Spinner */
        public static final int f303MaterialAlertDialog.MaterialComponents.Picker.Date.Spinner = 2131886384;
        /* added by DevToolsApp */
        /* renamed from: MaterialAlertDialog.MaterialComponents.Title.Icon */
        public static final int f304MaterialAlertDialog.MaterialComponents.Title.Icon = 2131886385;
        /* added by DevToolsApp */
        /* renamed from: MaterialAlertDialog.MaterialComponents.Title.Icon.CenterStacked */
        public static final int f305MaterialAlertDialog.MaterialComponents.Title.Icon.CenterStacked = 2131886386;
        /* added by DevToolsApp */
        /* renamed from: MaterialAlertDialog.MaterialComponents.Title.Panel */
        public static final int f306MaterialAlertDialog.MaterialComponents.Title.Panel = 2131886387;
        /* added by DevToolsApp */
        /* renamed from: MaterialAlertDialog.MaterialComponents.Title.Panel.CenterStacked */
        public static final int f307MaterialAlertDialog.MaterialComponents.Title.Panel.CenterStacked = 2131886388;
        /* added by DevToolsApp */
        /* renamed from: MaterialAlertDialog.MaterialComponents.Title.Text */
        public static final int f308MaterialAlertDialog.MaterialComponents.Title.Text = 2131886389;
        /* added by DevToolsApp */
        /* renamed from: MaterialAlertDialog.MaterialComponents.Title.Text.CenterStacked */
        public static final int f309MaterialAlertDialog.MaterialComponents.Title.Text.CenterStacked = 2131886390;
        /* added by DevToolsApp */
        /* renamed from: Platform.AppCompat */
        public static final int f310Platform.AppCompat = 2131886391;
        /* added by DevToolsApp */
        /* renamed from: Platform.AppCompat.Light */
        public static final int f311Platform.AppCompat.Light = 2131886392;
        /* added by DevToolsApp */
        /* renamed from: Platform.MaterialComponents */
        public static final int f312Platform.MaterialComponents = 2131886393;
        /* added by DevToolsApp */
        /* renamed from: Platform.MaterialComponents.Dialog */
        public static final int f313Platform.MaterialComponents.Dialog = 2131886394;
        /* added by DevToolsApp */
        /* renamed from: Platform.MaterialComponents.Light */
        public static final int f314Platform.MaterialComponents.Light = 2131886395;
        /* added by DevToolsApp */
        /* renamed from: Platform.MaterialComponents.Light.Dialog */
        public static final int f315Platform.MaterialComponents.Light.Dialog = 2131886396;
        /* added by DevToolsApp */
        /* renamed from: Platform.ThemeOverlay.AppCompat */
        public static final int f316Platform.ThemeOverlay.AppCompat = 2131886397;
        /* added by DevToolsApp */
        /* renamed from: Platform.ThemeOverlay.AppCompat.Dark */
        public static final int f317Platform.ThemeOverlay.AppCompat.Dark = 2131886398;
        /* added by DevToolsApp */
        /* renamed from: Platform.ThemeOverlay.AppCompat.Light */
        public static final int f318Platform.ThemeOverlay.AppCompat.Light = 2131886399;
        /* added by DevToolsApp */
        /* renamed from: Platform.V21.AppCompat */
        public static final int f319Platform.V21.AppCompat = 2131886400;
        /* added by DevToolsApp */
        /* renamed from: Platform.V21.AppCompat.Light */
        public static final int f320Platform.V21.AppCompat.Light = 2131886401;
        /* added by DevToolsApp */
        /* renamed from: Platform.V25.AppCompat */
        public static final int f321Platform.V25.AppCompat = 2131886402;
        /* added by DevToolsApp */
        /* renamed from: Platform.V25.AppCompat.Light */
        public static final int f322Platform.V25.AppCompat.Light = 2131886403;
        /* added by DevToolsApp */
        /* renamed from: Platform.Widget.AppCompat.Spinner */
        public static final int f323Platform.Widget.AppCompat.Spinner = 2131886404;
        /* added by DevToolsApp */
        /* renamed from: RtlOverlay.DialogWindowTitle.AppCompat */
        public static final int f324RtlOverlay.DialogWindowTitle.AppCompat = 2131886405;
        /* added by DevToolsApp */
        /* renamed from: RtlOverlay.Widget.AppCompat.ActionBar.TitleItem */
        public static final int f325RtlOverlay.Widget.AppCompat.ActionBar.TitleItem = 2131886406;
        /* added by DevToolsApp */
        /* renamed from: RtlOverlay.Widget.AppCompat.DialogTitle.Icon */
        public static final int f326RtlOverlay.Widget.AppCompat.DialogTitle.Icon = 2131886407;
        /* added by DevToolsApp */
        /* renamed from: RtlOverlay.Widget.AppCompat.PopupMenuItem */
        public static final int f327RtlOverlay.Widget.AppCompat.PopupMenuItem = 2131886408;
        /* added by DevToolsApp */
        /* renamed from: RtlOverlay.Widget.AppCompat.PopupMenuItem.InternalGroup */
        public static final int f328RtlOverlay.Widget.AppCompat.PopupMenuItem.InternalGroup = 2131886409;
        /* added by DevToolsApp */
        /* renamed from: RtlOverlay.Widget.AppCompat.PopupMenuItem.Shortcut */
        public static final int f329RtlOverlay.Widget.AppCompat.PopupMenuItem.Shortcut = 2131886410;
        /* added by DevToolsApp */
        /* renamed from: RtlOverlay.Widget.AppCompat.PopupMenuItem.SubmenuArrow */
        public static final int f330RtlOverlay.Widget.AppCompat.PopupMenuItem.SubmenuArrow = 2131886411;
        /* added by DevToolsApp */
        /* renamed from: RtlOverlay.Widget.AppCompat.PopupMenuItem.Text */
        public static final int f331RtlOverlay.Widget.AppCompat.PopupMenuItem.Text = 2131886412;
        /* added by DevToolsApp */
        /* renamed from: RtlOverlay.Widget.AppCompat.PopupMenuItem.Title */
        public static final int f332RtlOverlay.Widget.AppCompat.PopupMenuItem.Title = 2131886413;
        /* added by DevToolsApp */
        /* renamed from: RtlOverlay.Widget.AppCompat.Search.DropDown */
        public static final int f333RtlOverlay.Widget.AppCompat.Search.DropDown = 2131886414;
        /* added by DevToolsApp */
        /* renamed from: RtlOverlay.Widget.AppCompat.Search.DropDown.Icon1 */
        public static final int f334RtlOverlay.Widget.AppCompat.Search.DropDown.Icon1 = 2131886415;
        /* added by DevToolsApp */
        /* renamed from: RtlOverlay.Widget.AppCompat.Search.DropDown.Icon2 */
        public static final int f335RtlOverlay.Widget.AppCompat.Search.DropDown.Icon2 = 2131886416;
        /* added by DevToolsApp */
        /* renamed from: RtlOverlay.Widget.AppCompat.Search.DropDown.Query */
        public static final int f336RtlOverlay.Widget.AppCompat.Search.DropDown.Query = 2131886417;
        /* added by DevToolsApp */
        /* renamed from: RtlOverlay.Widget.AppCompat.Search.DropDown.Text */
        public static final int f337RtlOverlay.Widget.AppCompat.Search.DropDown.Text = 2131886418;
        /* added by DevToolsApp */
        /* renamed from: RtlOverlay.Widget.AppCompat.SearchView.MagIcon */
        public static final int f338RtlOverlay.Widget.AppCompat.SearchView.MagIcon = 2131886419;
        /* added by DevToolsApp */
        /* renamed from: RtlUnderlay.Widget.AppCompat.ActionButton */
        public static final int f339RtlUnderlay.Widget.AppCompat.ActionButton = 2131886420;
        /* added by DevToolsApp */
        /* renamed from: RtlUnderlay.Widget.AppCompat.ActionButton.Overflow */
        public static final int f340RtlUnderlay.Widget.AppCompat.ActionButton.Overflow = 2131886421;
        /* added by DevToolsApp */
        /* renamed from: ShapeAppearance.M3.Comp.Badge.Large.Shape */
        public static final int f341ShapeAppearance.M3.Comp.Badge.Large.Shape = 2131886422;
        /* added by DevToolsApp */
        /* renamed from: ShapeAppearance.M3.Comp.Badge.Shape */
        public static final int f342ShapeAppearance.M3.Comp.Badge.Shape = 2131886423;
        /* added by DevToolsApp */
        /* renamed from: ShapeAppearance.M3.Comp.BottomAppBar.Container.Shape */
        public static final int f343ShapeAppearance.M3.Comp.BottomAppBar.Container.Shape = 2131886424;
        /* added by DevToolsApp */
        /* renamed from: ShapeAppearance.M3.Comp.DatePicker.Modal.Date.Container.Shape */
        public static final int f344ShapeAppearance.M3.Comp.DatePicker.Modal.Date.Container.Shape = 2131886425;
        /* added by DevToolsApp */
        /* renamed from: ShapeAppearance.M3.Comp.FilledButton.Container.Shape */
        public static final int f345ShapeAppearance.M3.Comp.FilledButton.Container.Shape = 2131886426;
        /* added by DevToolsApp */
        /* renamed from: ShapeAppearance.M3.Comp.NavigationBar.ActiveIndicator.Shape */
        public static final int f346ShapeAppearance.M3.Comp.NavigationBar.ActiveIndicator.Shape = 2131886427;
        /* added by DevToolsApp */
        /* renamed from: ShapeAppearance.M3.Comp.NavigationBar.Container.Shape */
        public static final int f347ShapeAppearance.M3.Comp.NavigationBar.Container.Shape = 2131886428;
        /* added by DevToolsApp */
        /* renamed from: ShapeAppearance.M3.Comp.NavigationDrawer.ActiveIndicator.Shape */
        public static final int f348ShapeAppearance.M3.Comp.NavigationDrawer.ActiveIndicator.Shape = 2131886429;
        /* added by DevToolsApp */
        /* renamed from: ShapeAppearance.M3.Comp.NavigationRail.ActiveIndicator.Shape */
        public static final int f349ShapeAppearance.M3.Comp.NavigationRail.ActiveIndicator.Shape = 2131886430;
        /* added by DevToolsApp */
        /* renamed from: ShapeAppearance.M3.Comp.NavigationRail.Container.Shape */
        public static final int f350ShapeAppearance.M3.Comp.NavigationRail.Container.Shape = 2131886431;
        /* added by DevToolsApp */
        /* renamed from: ShapeAppearance.M3.Comp.SearchBar.Avatar.Shape */
        public static final int f351ShapeAppearance.M3.Comp.SearchBar.Avatar.Shape = 2131886432;
        /* added by DevToolsApp */
        /* renamed from: ShapeAppearance.M3.Comp.SearchBar.Container.Shape */
        public static final int f352ShapeAppearance.M3.Comp.SearchBar.Container.Shape = 2131886433;
        /* added by DevToolsApp */
        /* renamed from: ShapeAppearance.M3.Comp.SearchView.FullScreen.Container.Shape */
        public static final int f353ShapeAppearance.M3.Comp.SearchView.FullScreen.Container.Shape = 2131886434;
        /* added by DevToolsApp */
        /* renamed from: ShapeAppearance.M3.Comp.Sheet.Side.Docked.Container.Shape */
        public static final int f354ShapeAppearance.M3.Comp.Sheet.Side.Docked.Container.Shape = 2131886435;
        /* added by DevToolsApp */
        /* renamed from: ShapeAppearance.M3.Comp.Switch.Handle.Shape */
        public static final int f355ShapeAppearance.M3.Comp.Switch.Handle.Shape = 2131886436;
        /* added by DevToolsApp */
        /* renamed from: ShapeAppearance.M3.Comp.Switch.StateLayer.Shape */
        public static final int f356ShapeAppearance.M3.Comp.Switch.StateLayer.Shape = 2131886437;
        /* added by DevToolsApp */
        /* renamed from: ShapeAppearance.M3.Comp.Switch.Track.Shape */
        public static final int f357ShapeAppearance.M3.Comp.Switch.Track.Shape = 2131886438;
        /* added by DevToolsApp */
        /* renamed from: ShapeAppearance.M3.Comp.TextButton.Container.Shape */
        public static final int f358ShapeAppearance.M3.Comp.TextButton.Container.Shape = 2131886439;
        /* added by DevToolsApp */
        /* renamed from: ShapeAppearance.M3.Sys.Shape.Corner.ExtraLarge */
        public static final int f359ShapeAppearance.M3.Sys.Shape.Corner.ExtraLarge = 2131886440;
        /* added by DevToolsApp */
        /* renamed from: ShapeAppearance.M3.Sys.Shape.Corner.ExtraSmall */
        public static final int f360ShapeAppearance.M3.Sys.Shape.Corner.ExtraSmall = 2131886441;
        /* added by DevToolsApp */
        /* renamed from: ShapeAppearance.M3.Sys.Shape.Corner.Full */
        public static final int f361ShapeAppearance.M3.Sys.Shape.Corner.Full = 2131886442;
        /* added by DevToolsApp */
        /* renamed from: ShapeAppearance.M3.Sys.Shape.Corner.Large */
        public static final int f362ShapeAppearance.M3.Sys.Shape.Corner.Large = 2131886443;
        /* added by DevToolsApp */
        /* renamed from: ShapeAppearance.M3.Sys.Shape.Corner.Medium */
        public static final int f363ShapeAppearance.M3.Sys.Shape.Corner.Medium = 2131886444;
        /* added by DevToolsApp */
        /* renamed from: ShapeAppearance.M3.Sys.Shape.Corner.None */
        public static final int f364ShapeAppearance.M3.Sys.Shape.Corner.None = 2131886445;
        /* added by DevToolsApp */
        /* renamed from: ShapeAppearance.M3.Sys.Shape.Corner.Small */
        public static final int f365ShapeAppearance.M3.Sys.Shape.Corner.Small = 2131886446;
        /* added by DevToolsApp */
        /* renamed from: ShapeAppearance.Material3.Corner.ExtraLarge */
        public static final int f366ShapeAppearance.Material3.Corner.ExtraLarge = 2131886447;
        /* added by DevToolsApp */
        /* renamed from: ShapeAppearance.Material3.Corner.ExtraSmall */
        public static final int f367ShapeAppearance.Material3.Corner.ExtraSmall = 2131886448;
        /* added by DevToolsApp */
        /* renamed from: ShapeAppearance.Material3.Corner.Full */
        public static final int f368ShapeAppearance.Material3.Corner.Full = 2131886449;
        /* added by DevToolsApp */
        /* renamed from: ShapeAppearance.Material3.Corner.Large */
        public static final int f369ShapeAppearance.Material3.Corner.Large = 2131886450;
        /* added by DevToolsApp */
        /* renamed from: ShapeAppearance.Material3.Corner.Medium */
        public static final int f370ShapeAppearance.Material3.Corner.Medium = 2131886451;
        /* added by DevToolsApp */
        /* renamed from: ShapeAppearance.Material3.Corner.None */
        public static final int f371ShapeAppearance.Material3.Corner.None = 2131886452;
        /* added by DevToolsApp */
        /* renamed from: ShapeAppearance.Material3.Corner.Small */
        public static final int f372ShapeAppearance.Material3.Corner.Small = 2131886453;
        /* added by DevToolsApp */
        /* renamed from: ShapeAppearance.Material3.LargeComponent */
        public static final int f373ShapeAppearance.Material3.LargeComponent = 2131886454;
        /* added by DevToolsApp */
        /* renamed from: ShapeAppearance.Material3.MediumComponent */
        public static final int f374ShapeAppearance.Material3.MediumComponent = 2131886455;
        /* added by DevToolsApp */
        /* renamed from: ShapeAppearance.Material3.NavigationBarView.ActiveIndicator */
        public static final int f375ShapeAppearance.Material3.NavigationBarView.ActiveIndicator = 2131886456;
        /* added by DevToolsApp */
        /* renamed from: ShapeAppearance.Material3.SmallComponent */
        public static final int f376ShapeAppearance.Material3.SmallComponent = 2131886457;
        /* added by DevToolsApp */
        /* renamed from: ShapeAppearance.Material3.Tooltip */
        public static final int f377ShapeAppearance.Material3.Tooltip = 2131886458;
        /* added by DevToolsApp */
        /* renamed from: ShapeAppearance.MaterialComponents */
        public static final int f378ShapeAppearance.MaterialComponents = 2131886459;
        /* added by DevToolsApp */
        /* renamed from: ShapeAppearance.MaterialComponents.Badge */
        public static final int f379ShapeAppearance.MaterialComponents.Badge = 2131886460;
        /* added by DevToolsApp */
        /* renamed from: ShapeAppearance.MaterialComponents.LargeComponent */
        public static final int f380ShapeAppearance.MaterialComponents.LargeComponent = 2131886461;
        /* added by DevToolsApp */
        /* renamed from: ShapeAppearance.MaterialComponents.MediumComponent */
        public static final int f381ShapeAppearance.MaterialComponents.MediumComponent = 2131886462;
        /* added by DevToolsApp */
        /* renamed from: ShapeAppearance.MaterialComponents.SmallComponent */
        public static final int f382ShapeAppearance.MaterialComponents.SmallComponent = 2131886463;
        /* added by DevToolsApp */
        /* renamed from: ShapeAppearance.MaterialComponents.Tooltip */
        public static final int f383ShapeAppearance.MaterialComponents.Tooltip = 2131886464;
        /* added by DevToolsApp */
        /* renamed from: ShapeAppearanceOverlay.Material3.Button */
        public static final int f384ShapeAppearanceOverlay.Material3.Button = 2131886465;
        /* added by DevToolsApp */
        /* renamed from: ShapeAppearanceOverlay.Material3.Chip */
        public static final int f385ShapeAppearanceOverlay.Material3.Chip = 2131886466;
        /* added by DevToolsApp */
        /* renamed from: ShapeAppearanceOverlay.Material3.Corner.Bottom */
        public static final int f386ShapeAppearanceOverlay.Material3.Corner.Bottom = 2131886467;
        /* added by DevToolsApp */
        /* renamed from: ShapeAppearanceOverlay.Material3.Corner.Left */
        public static final int f387ShapeAppearanceOverlay.Material3.Corner.Left = 2131886468;
        /* added by DevToolsApp */
        /* renamed from: ShapeAppearanceOverlay.Material3.Corner.Right */
        public static final int f388ShapeAppearanceOverlay.Material3.Corner.Right = 2131886469;
        /* added by DevToolsApp */
        /* renamed from: ShapeAppearanceOverlay.Material3.Corner.Top */
        public static final int f389ShapeAppearanceOverlay.Material3.Corner.Top = 2131886470;
        /* added by DevToolsApp */
        /* renamed from: ShapeAppearanceOverlay.Material3.FloatingActionButton */
        public static final int f390ShapeAppearanceOverlay.Material3.FloatingActionButton = 2131886471;
        /* added by DevToolsApp */
        /* renamed from: ShapeAppearanceOverlay.Material3.NavigationView.Item */
        public static final int f391ShapeAppearanceOverlay.Material3.NavigationView.Item = 2131886472;
        /* added by DevToolsApp */
        /* renamed from: ShapeAppearanceOverlay.Material3.SearchBar */
        public static final int f392ShapeAppearanceOverlay.Material3.SearchBar = 2131886473;
        /* added by DevToolsApp */
        /* renamed from: ShapeAppearanceOverlay.Material3.SearchView */
        public static final int f393ShapeAppearanceOverlay.Material3.SearchView = 2131886474;
        /* added by DevToolsApp */
        /* renamed from: ShapeAppearanceOverlay.MaterialAlertDialog.Material3 */
        public static final int f394ShapeAppearanceOverlay.MaterialAlertDialog.Material3 = 2131886475;
        /* added by DevToolsApp */
        /* renamed from: ShapeAppearanceOverlay.MaterialComponents.BottomSheet */
        public static final int f395ShapeAppearanceOverlay.MaterialComponents.BottomSheet = 2131886476;
        /* added by DevToolsApp */
        /* renamed from: ShapeAppearanceOverlay.MaterialComponents.Chip */
        public static final int f396ShapeAppearanceOverlay.MaterialComponents.Chip = 2131886477;
        /* added by DevToolsApp */
        /* renamed from: ShapeAppearanceOverlay.MaterialComponents.ExtendedFloatingActionButton */
        public static final int f397ShapeAppearanceOverlay.MaterialComponents.ExtendedFloatingActionButton = 2131886478;
        /* added by DevToolsApp */
        /* renamed from: ShapeAppearanceOverlay.MaterialComponents.FloatingActionButton */
        public static final int f398ShapeAppearanceOverlay.MaterialComponents.FloatingActionButton = 2131886479;
        /* added by DevToolsApp */
        /* renamed from: ShapeAppearanceOverlay.MaterialComponents.MaterialCalendar.Day */
        public static final int f399ShapeAppearanceOverlay.MaterialComponents.MaterialCalendar.Day = 2131886480;
        /* added by DevToolsApp */
        /* renamed from: ShapeAppearanceOverlay.MaterialComponents.MaterialCalendar.Window.Fullscreen */
        public static final int f400ShapeAppearanceOverlay.MaterialComponents.MaterialCalendar.Window.Fullscreen = 2131886481;
        /* added by DevToolsApp */
        /* renamed from: ShapeAppearanceOverlay.MaterialComponents.MaterialCalendar.Year */
        public static final int f401ShapeAppearanceOverlay.MaterialComponents.MaterialCalendar.Year = 2131886482;
        /* added by DevToolsApp */
        /* renamed from: ShapeAppearanceOverlay.MaterialComponents.TextInputLayout.FilledBox */
        public static final int f402ShapeAppearanceOverlay.MaterialComponents.TextInputLayout.FilledBox = 2131886483;
        /* added by DevToolsApp */
        /* renamed from: TextAppearance.AppCompat */
        public static final int f403TextAppearance.AppCompat = 2131886484;
        /* added by DevToolsApp */
        /* renamed from: TextAppearance.AppCompat.Body1 */
        public static final int f404TextAppearance.AppCompat.Body1 = 2131886485;
        /* added by DevToolsApp */
        /* renamed from: TextAppearance.AppCompat.Body2 */
        public static final int f405TextAppearance.AppCompat.Body2 = 2131886486;
        /* added by DevToolsApp */
        /* renamed from: TextAppearance.AppCompat.Button */
        public static final int f406TextAppearance.AppCompat.Button = 2131886487;
        /* added by DevToolsApp */
        /* renamed from: TextAppearance.AppCompat.Caption */
        public static final int f407TextAppearance.AppCompat.Caption = 2131886488;
        /* added by DevToolsApp */
        /* renamed from: TextAppearance.AppCompat.Display1 */
        public static final int f408TextAppearance.AppCompat.Display1 = 2131886489;
        /* added by DevToolsApp */
        /* renamed from: TextAppearance.AppCompat.Display2 */
        public static final int f409TextAppearance.AppCompat.Display2 = 2131886490;
        /* added by DevToolsApp */
        /* renamed from: TextAppearance.AppCompat.Display3 */
        public static final int f410TextAppearance.AppCompat.Display3 = 2131886491;
        /* added by DevToolsApp */
        /* renamed from: TextAppearance.AppCompat.Display4 */
        public static final int f411TextAppearance.AppCompat.Display4 = 2131886492;
        /* added by DevToolsApp */
        /* renamed from: TextAppearance.AppCompat.Headline */
        public static final int f412TextAppearance.AppCompat.Headline = 2131886493;
        /* added by DevToolsApp */
        /* renamed from: TextAppearance.AppCompat.Inverse */
        public static final int f413TextAppearance.AppCompat.Inverse = 2131886494;
        /* added by DevToolsApp */
        /* renamed from: TextAppearance.AppCompat.Large */
        public static final int f414TextAppearance.AppCompat.Large = 2131886495;
        /* added by DevToolsApp */
        /* renamed from: TextAppearance.AppCompat.Large.Inverse */
        public static final int f415TextAppearance.AppCompat.Large.Inverse = 2131886496;
        /* added by DevToolsApp */
        /* renamed from: TextAppearance.AppCompat.Light.SearchResult.Subtitle */
        public static final int f416TextAppearance.AppCompat.Light.SearchResult.Subtitle = 2131886497;
        /* added by DevToolsApp */
        /* renamed from: TextAppearance.AppCompat.Light.SearchResult.Title */
        public static final int f417TextAppearance.AppCompat.Light.SearchResult.Title = 2131886498;
        /* added by DevToolsApp */
        /* renamed from: TextAppearance.AppCompat.Light.Widget.PopupMenu.Large */
        public static final int f418TextAppearance.AppCompat.Light.Widget.PopupMenu.Large = 2131886499;
        /* added by DevToolsApp */
        /* renamed from: TextAppearance.AppCompat.Light.Widget.PopupMenu.Small */
        public static final int f419TextAppearance.AppCompat.Light.Widget.PopupMenu.Small = 2131886500;
        /* added by DevToolsApp */
        /* renamed from: TextAppearance.AppCompat.Medium */
        public static final int f420TextAppearance.AppCompat.Medium = 2131886501;
        /* added by DevToolsApp */
        /* renamed from: TextAppearance.AppCompat.Medium.Inverse */
        public static final int f421TextAppearance.AppCompat.Medium.Inverse = 2131886502;
        /* added by DevToolsApp */
        /* renamed from: TextAppearance.AppCompat.Menu */
        public static final int f422TextAppearance.AppCompat.Menu = 2131886503;
        /* added by DevToolsApp */
        /* renamed from: TextAppearance.AppCompat.SearchResult.Subtitle */
        public static final int f423TextAppearance.AppCompat.SearchResult.Subtitle = 2131886504;
        /* added by DevToolsApp */
        /* renamed from: TextAppearance.AppCompat.SearchResult.Title */
        public static final int f424TextAppearance.AppCompat.SearchResult.Title = 2131886505;
        /* added by DevToolsApp */
        /* renamed from: TextAppearance.AppCompat.Small */
        public static final int f425TextAppearance.AppCompat.Small = 2131886506;
        /* added by DevToolsApp */
        /* renamed from: TextAppearance.AppCompat.Small.Inverse */
        public static final int f426TextAppearance.AppCompat.Small.Inverse = 2131886507;
        /* added by DevToolsApp */
        /* renamed from: TextAppearance.AppCompat.Subhead */
        public static final int f427TextAppearance.AppCompat.Subhead = 2131886508;
        /* added by DevToolsApp */
        /* renamed from: TextAppearance.AppCompat.Subhead.Inverse */
        public static final int f428TextAppearance.AppCompat.Subhead.Inverse = 2131886509;
        /* added by DevToolsApp */
        /* renamed from: TextAppearance.AppCompat.Title */
        public static final int f429TextAppearance.AppCompat.Title = 2131886510;
        /* added by DevToolsApp */
        /* renamed from: TextAppearance.AppCompat.Title.Inverse */
        public static final int f430TextAppearance.AppCompat.Title.Inverse = 2131886511;
        /* added by DevToolsApp */
        /* renamed from: TextAppearance.AppCompat.Tooltip */
        public static final int f431TextAppearance.AppCompat.Tooltip = 2131886512;
        /* added by DevToolsApp */
        /* renamed from: TextAppearance.AppCompat.Widget.ActionBar.Menu */
        public static final int f432TextAppearance.AppCompat.Widget.ActionBar.Menu = 2131886513;
        /* added by DevToolsApp */
        /* renamed from: TextAppearance.AppCompat.Widget.ActionBar.Subtitle */
        public static final int f433TextAppearance.AppCompat.Widget.ActionBar.Subtitle = 2131886514;
        /* added by DevToolsApp */
        /* renamed from: TextAppearance.AppCompat.Widget.ActionBar.Subtitle.Inverse */
        public static final int f434TextAppearance.AppCompat.Widget.ActionBar.Subtitle.Inverse = 2131886515;
        /* added by DevToolsApp */
        /* renamed from: TextAppearance.AppCompat.Widget.ActionBar.Title */
        public static final int f435TextAppearance.AppCompat.Widget.ActionBar.Title = 2131886516;
        /* added by DevToolsApp */
        /* renamed from: TextAppearance.AppCompat.Widget.ActionBar.Title.Inverse */
        public static final int f436TextAppearance.AppCompat.Widget.ActionBar.Title.Inverse = 2131886517;
        /* added by DevToolsApp */
        /* renamed from: TextAppearance.AppCompat.Widget.ActionMode.Subtitle */
        public static final int f437TextAppearance.AppCompat.Widget.ActionMode.Subtitle = 2131886518;
        /* added by DevToolsApp */
        /* renamed from: TextAppearance.AppCompat.Widget.ActionMode.Subtitle.Inverse */
        public static final int f438TextAppearance.AppCompat.Widget.ActionMode.Subtitle.Inverse = 2131886519;
        /* added by DevToolsApp */
        /* renamed from: TextAppearance.AppCompat.Widget.ActionMode.Title */
        public static final int f439TextAppearance.AppCompat.Widget.ActionMode.Title = 2131886520;
        /* added by DevToolsApp */
        /* renamed from: TextAppearance.AppCompat.Widget.ActionMode.Title.Inverse */
        public static final int f440TextAppearance.AppCompat.Widget.ActionMode.Title.Inverse = 2131886521;
        /* added by DevToolsApp */
        /* renamed from: TextAppearance.AppCompat.Widget.Button */
        public static final int f441TextAppearance.AppCompat.Widget.Button = 2131886522;
        /* added by DevToolsApp */
        /* renamed from: TextAppearance.AppCompat.Widget.Button.Borderless.Colored */
        public static final int f442TextAppearance.AppCompat.Widget.Button.Borderless.Colored = 2131886523;
        /* added by DevToolsApp */
        /* renamed from: TextAppearance.AppCompat.Widget.Button.Colored */
        public static final int f443TextAppearance.AppCompat.Widget.Button.Colored = 2131886524;
        /* added by DevToolsApp */
        /* renamed from: TextAppearance.AppCompat.Widget.Button.Inverse */
        public static final int f444TextAppearance.AppCompat.Widget.Button.Inverse = 2131886525;
        /* added by DevToolsApp */
        /* renamed from: TextAppearance.AppCompat.Widget.DropDownItem */
        public static final int f445TextAppearance.AppCompat.Widget.DropDownItem = 2131886526;
        /* added by DevToolsApp */
        /* renamed from: TextAppearance.AppCompat.Widget.PopupMenu.Header */
        public static final int f446TextAppearance.AppCompat.Widget.PopupMenu.Header = 2131886527;
        /* added by DevToolsApp */
        /* renamed from: TextAppearance.AppCompat.Widget.PopupMenu.Large */
        public static final int f447TextAppearance.AppCompat.Widget.PopupMenu.Large = 2131886528;
        /* added by DevToolsApp */
        /* renamed from: TextAppearance.AppCompat.Widget.PopupMenu.Small */
        public static final int f448TextAppearance.AppCompat.Widget.PopupMenu.Small = 2131886529;
        /* added by DevToolsApp */
        /* renamed from: TextAppearance.AppCompat.Widget.Switch */
        public static final int f449TextAppearance.AppCompat.Widget.Switch = 2131886530;
        /* added by DevToolsApp */
        /* renamed from: TextAppearance.AppCompat.Widget.TextView.SpinnerItem */
        public static final int f450TextAppearance.AppCompat.Widget.TextView.SpinnerItem = 2131886531;
        /* added by DevToolsApp */
        /* renamed from: TextAppearance.Compat.Notification */
        public static final int f451TextAppearance.Compat.Notification = 2131886532;
        /* added by DevToolsApp */
        /* renamed from: TextAppearance.Compat.Notification.Info */
        public static final int f452TextAppearance.Compat.Notification.Info = 2131886533;
        /* added by DevToolsApp */
        /* renamed from: TextAppearance.Compat.Notification.Line2 */
        public static final int f453TextAppearance.Compat.Notification.Line2 = 2131886534;
        /* added by DevToolsApp */
        /* renamed from: TextAppearance.Compat.Notification.Time */
        public static final int f454TextAppearance.Compat.Notification.Time = 2131886535;
        /* added by DevToolsApp */
        /* renamed from: TextAppearance.Compat.Notification.Title */
        public static final int f455TextAppearance.Compat.Notification.Title = 2131886536;
        /* added by DevToolsApp */
        /* renamed from: TextAppearance.Design.CollapsingToolbar.Expanded */
        public static final int f456TextAppearance.Design.CollapsingToolbar.Expanded = 2131886537;
        /* added by DevToolsApp */
        /* renamed from: TextAppearance.Design.Counter */
        public static final int f457TextAppearance.Design.Counter = 2131886538;
        /* added by DevToolsApp */
        /* renamed from: TextAppearance.Design.Counter.Overflow */
        public static final int f458TextAppearance.Design.Counter.Overflow = 2131886539;
        /* added by DevToolsApp */
        /* renamed from: TextAppearance.Design.Error */
        public static final int f459TextAppearance.Design.Error = 2131886540;
        /* added by DevToolsApp */
        /* renamed from: TextAppearance.Design.HelperText */
        public static final int f460TextAppearance.Design.HelperText = 2131886541;
        /* added by DevToolsApp */
        /* renamed from: TextAppearance.Design.Hint */
        public static final int f461TextAppearance.Design.Hint = 2131886542;
        /* added by DevToolsApp */
        /* renamed from: TextAppearance.Design.Placeholder */
        public static final int f462TextAppearance.Design.Placeholder = 2131886543;
        /* added by DevToolsApp */
        /* renamed from: TextAppearance.Design.Prefix */
        public static final int f463TextAppearance.Design.Prefix = 2131886544;
        /* added by DevToolsApp */
        /* renamed from: TextAppearance.Design.Snackbar.Message */
        public static final int f464TextAppearance.Design.Snackbar.Message = 2131886545;
        /* added by DevToolsApp */
        /* renamed from: TextAppearance.Design.Suffix */
        public static final int f465TextAppearance.Design.Suffix = 2131886546;
        /* added by DevToolsApp */
        /* renamed from: TextAppearance.Design.Tab */
        public static final int f466TextAppearance.Design.Tab = 2131886547;
        /* added by DevToolsApp */
        /* renamed from: TextAppearance.M3.Sys.Typescale.BodyLarge */
        public static final int f467TextAppearance.M3.Sys.Typescale.BodyLarge = 2131886548;
        /* added by DevToolsApp */
        /* renamed from: TextAppearance.M3.Sys.Typescale.BodyMedium */
        public static final int f468TextAppearance.M3.Sys.Typescale.BodyMedium = 2131886549;
        /* added by DevToolsApp */
        /* renamed from: TextAppearance.M3.Sys.Typescale.BodySmall */
        public static final int f469TextAppearance.M3.Sys.Typescale.BodySmall = 2131886550;
        /* added by DevToolsApp */
        /* renamed from: TextAppearance.M3.Sys.Typescale.DisplayLarge */
        public static final int f470TextAppearance.M3.Sys.Typescale.DisplayLarge = 2131886551;
        /* added by DevToolsApp */
        /* renamed from: TextAppearance.M3.Sys.Typescale.DisplayMedium */
        public static final int f471TextAppearance.M3.Sys.Typescale.DisplayMedium = 2131886552;
        /* added by DevToolsApp */
        /* renamed from: TextAppearance.M3.Sys.Typescale.DisplaySmall */
        public static final int f472TextAppearance.M3.Sys.Typescale.DisplaySmall = 2131886553;
        /* added by DevToolsApp */
        /* renamed from: TextAppearance.M3.Sys.Typescale.HeadlineLarge */
        public static final int f473TextAppearance.M3.Sys.Typescale.HeadlineLarge = 2131886554;
        /* added by DevToolsApp */
        /* renamed from: TextAppearance.M3.Sys.Typescale.HeadlineMedium */
        public static final int f474TextAppearance.M3.Sys.Typescale.HeadlineMedium = 2131886555;
        /* added by DevToolsApp */
        /* renamed from: TextAppearance.M3.Sys.Typescale.HeadlineSmall */
        public static final int f475TextAppearance.M3.Sys.Typescale.HeadlineSmall = 2131886556;
        /* added by DevToolsApp */
        /* renamed from: TextAppearance.M3.Sys.Typescale.LabelLarge */
        public static final int f476TextAppearance.M3.Sys.Typescale.LabelLarge = 2131886557;
        /* added by DevToolsApp */
        /* renamed from: TextAppearance.M3.Sys.Typescale.LabelMedium */
        public static final int f477TextAppearance.M3.Sys.Typescale.LabelMedium = 2131886558;
        /* added by DevToolsApp */
        /* renamed from: TextAppearance.M3.Sys.Typescale.LabelSmall */
        public static final int f478TextAppearance.M3.Sys.Typescale.LabelSmall = 2131886559;
        /* added by DevToolsApp */
        /* renamed from: TextAppearance.M3.Sys.Typescale.TitleLarge */
        public static final int f479TextAppearance.M3.Sys.Typescale.TitleLarge = 2131886560;
        /* added by DevToolsApp */
        /* renamed from: TextAppearance.M3.Sys.Typescale.TitleMedium */
        public static final int f480TextAppearance.M3.Sys.Typescale.TitleMedium = 2131886561;
        /* added by DevToolsApp */
        /* renamed from: TextAppearance.M3.Sys.Typescale.TitleSmall */
        public static final int f481TextAppearance.M3.Sys.Typescale.TitleSmall = 2131886562;
        /* added by DevToolsApp */
        /* renamed from: TextAppearance.Material3.ActionBar.Subtitle */
        public static final int f482TextAppearance.Material3.ActionBar.Subtitle = 2131886563;
        /* added by DevToolsApp */
        /* renamed from: TextAppearance.Material3.ActionBar.Title */
        public static final int f483TextAppearance.Material3.ActionBar.Title = 2131886564;
        /* added by DevToolsApp */
        /* renamed from: TextAppearance.Material3.BodyLarge */
        public static final int f484TextAppearance.Material3.BodyLarge = 2131886565;
        /* added by DevToolsApp */
        /* renamed from: TextAppearance.Material3.BodyMedium */
        public static final int f485TextAppearance.Material3.BodyMedium = 2131886566;
        /* added by DevToolsApp */
        /* renamed from: TextAppearance.Material3.BodySmall */
        public static final int f486TextAppearance.Material3.BodySmall = 2131886567;
        /* added by DevToolsApp */
        /* renamed from: TextAppearance.Material3.DisplayLarge */
        public static final int f487TextAppearance.Material3.DisplayLarge = 2131886568;
        /* added by DevToolsApp */
        /* renamed from: TextAppearance.Material3.DisplayMedium */
        public static final int f488TextAppearance.Material3.DisplayMedium = 2131886569;
        /* added by DevToolsApp */
        /* renamed from: TextAppearance.Material3.DisplaySmall */
        public static final int f489TextAppearance.Material3.DisplaySmall = 2131886570;
        /* added by DevToolsApp */
        /* renamed from: TextAppearance.Material3.HeadlineLarge */
        public static final int f490TextAppearance.Material3.HeadlineLarge = 2131886571;
        /* added by DevToolsApp */
        /* renamed from: TextAppearance.Material3.HeadlineMedium */
        public static final int f491TextAppearance.Material3.HeadlineMedium = 2131886572;
        /* added by DevToolsApp */
        /* renamed from: TextAppearance.Material3.HeadlineSmall */
        public static final int f492TextAppearance.Material3.HeadlineSmall = 2131886573;
        /* added by DevToolsApp */
        /* renamed from: TextAppearance.Material3.LabelLarge */
        public static final int f493TextAppearance.Material3.LabelLarge = 2131886574;
        /* added by DevToolsApp */
        /* renamed from: TextAppearance.Material3.LabelMedium */
        public static final int f494TextAppearance.Material3.LabelMedium = 2131886575;
        /* added by DevToolsApp */
        /* renamed from: TextAppearance.Material3.LabelSmall */
        public static final int f495TextAppearance.Material3.LabelSmall = 2131886576;
        /* added by DevToolsApp */
        /* renamed from: TextAppearance.Material3.MaterialTimePicker.Title */
        public static final int f496TextAppearance.Material3.MaterialTimePicker.Title = 2131886577;
        /* added by DevToolsApp */
        /* renamed from: TextAppearance.Material3.SearchBar */
        public static final int f497TextAppearance.Material3.SearchBar = 2131886578;
        /* added by DevToolsApp */
        /* renamed from: TextAppearance.Material3.SearchView */
        public static final int f498TextAppearance.Material3.SearchView = 2131886579;
        /* added by DevToolsApp */
        /* renamed from: TextAppearance.Material3.SearchView.Prefix */
        public static final int f499TextAppearance.Material3.SearchView.Prefix = 2131886580;
        /* added by DevToolsApp */
        /* renamed from: TextAppearance.Material3.TitleLarge */
        public static final int f500TextAppearance.Material3.TitleLarge = 2131886581;
        /* added by DevToolsApp */
        /* renamed from: TextAppearance.Material3.TitleMedium */
        public static final int f501TextAppearance.Material3.TitleMedium = 2131886582;
        /* added by DevToolsApp */
        /* renamed from: TextAppearance.Material3.TitleSmall */
        public static final int f502TextAppearance.Material3.TitleSmall = 2131886583;
        /* added by DevToolsApp */
        /* renamed from: TextAppearance.MaterialComponents.Badge */
        public static final int f503TextAppearance.MaterialComponents.Badge = 2131886584;
        /* added by DevToolsApp */
        /* renamed from: TextAppearance.MaterialComponents.Body1 */
        public static final int f504TextAppearance.MaterialComponents.Body1 = 2131886585;
        /* added by DevToolsApp */
        /* renamed from: TextAppearance.MaterialComponents.Body2 */
        public static final int f505TextAppearance.MaterialComponents.Body2 = 2131886586;
        /* added by DevToolsApp */
        /* renamed from: TextAppearance.MaterialComponents.Button */
        public static final int f506TextAppearance.MaterialComponents.Button = 2131886587;
        /* added by DevToolsApp */
        /* renamed from: TextAppearance.MaterialComponents.Caption */
        public static final int f507TextAppearance.MaterialComponents.Caption = 2131886588;
        /* added by DevToolsApp */
        /* renamed from: TextAppearance.MaterialComponents.Chip */
        public static final int f508TextAppearance.MaterialComponents.Chip = 2131886589;
        /* added by DevToolsApp */
        /* renamed from: TextAppearance.MaterialComponents.Headline1 */
        public static final int f509TextAppearance.MaterialComponents.Headline1 = 2131886590;
        /* added by DevToolsApp */
        /* renamed from: TextAppearance.MaterialComponents.Headline2 */
        public static final int f510TextAppearance.MaterialComponents.Headline2 = 2131886591;
        /* added by DevToolsApp */
        /* renamed from: TextAppearance.MaterialComponents.Headline3 */
        public static final int f511TextAppearance.MaterialComponents.Headline3 = 2131886592;
        /* added by DevToolsApp */
        /* renamed from: TextAppearance.MaterialComponents.Headline4 */
        public static final int f512TextAppearance.MaterialComponents.Headline4 = 2131886593;
        /* added by DevToolsApp */
        /* renamed from: TextAppearance.MaterialComponents.Headline5 */
        public static final int f513TextAppearance.MaterialComponents.Headline5 = 2131886594;
        /* added by DevToolsApp */
        /* renamed from: TextAppearance.MaterialComponents.Headline6 */
        public static final int f514TextAppearance.MaterialComponents.Headline6 = 2131886595;
        /* added by DevToolsApp */
        /* renamed from: TextAppearance.MaterialComponents.Overline */
        public static final int f515TextAppearance.MaterialComponents.Overline = 2131886596;
        /* added by DevToolsApp */
        /* renamed from: TextAppearance.MaterialComponents.Subtitle1 */
        public static final int f516TextAppearance.MaterialComponents.Subtitle1 = 2131886597;
        /* added by DevToolsApp */
        /* renamed from: TextAppearance.MaterialComponents.Subtitle2 */
        public static final int f517TextAppearance.MaterialComponents.Subtitle2 = 2131886598;
        /* added by DevToolsApp */
        /* renamed from: TextAppearance.MaterialComponents.TimePicker.Title */
        public static final int f518TextAppearance.MaterialComponents.TimePicker.Title = 2131886599;
        /* added by DevToolsApp */
        /* renamed from: TextAppearance.MaterialComponents.Tooltip */
        public static final int f519TextAppearance.MaterialComponents.Tooltip = 2131886600;
        /* added by DevToolsApp */
        /* renamed from: TextAppearance.Widget.AppCompat.ExpandedMenu.Item */
        public static final int f520TextAppearance.Widget.AppCompat.ExpandedMenu.Item = 2131886601;
        /* added by DevToolsApp */
        /* renamed from: TextAppearance.Widget.AppCompat.Toolbar.Subtitle */
        public static final int f521TextAppearance.Widget.AppCompat.Toolbar.Subtitle = 2131886602;
        /* added by DevToolsApp */
        /* renamed from: TextAppearance.Widget.AppCompat.Toolbar.Title */
        public static final int f522TextAppearance.Widget.AppCompat.Toolbar.Title = 2131886603;
        /* added by DevToolsApp */
        /* renamed from: Theme.AppCompat */
        public static final int f523Theme.AppCompat = 2131886604;
        /* added by DevToolsApp */
        /* renamed from: Theme.AppCompat.CompactMenu */
        public static final int f524Theme.AppCompat.CompactMenu = 2131886605;
        /* added by DevToolsApp */
        /* renamed from: Theme.AppCompat.DayNight */
        public static final int f525Theme.AppCompat.DayNight = 2131886606;
        /* added by DevToolsApp */
        /* renamed from: Theme.AppCompat.DayNight.DarkActionBar */
        public static final int f526Theme.AppCompat.DayNight.DarkActionBar = 2131886607;
        /* added by DevToolsApp */
        /* renamed from: Theme.AppCompat.DayNight.Dialog */
        public static final int f527Theme.AppCompat.DayNight.Dialog = 2131886608;
        /* added by DevToolsApp */
        /* renamed from: Theme.AppCompat.DayNight.Dialog.Alert */
        public static final int f528Theme.AppCompat.DayNight.Dialog.Alert = 2131886609;
        /* added by DevToolsApp */
        /* renamed from: Theme.AppCompat.DayNight.Dialog.MinWidth */
        public static final int f529Theme.AppCompat.DayNight.Dialog.MinWidth = 2131886610;
        /* added by DevToolsApp */
        /* renamed from: Theme.AppCompat.DayNight.DialogWhenLarge */
        public static final int f530Theme.AppCompat.DayNight.DialogWhenLarge = 2131886611;
        /* added by DevToolsApp */
        /* renamed from: Theme.AppCompat.DayNight.NoActionBar */
        public static final int f531Theme.AppCompat.DayNight.NoActionBar = 2131886612;
        /* added by DevToolsApp */
        /* renamed from: Theme.AppCompat.Dialog */
        public static final int f532Theme.AppCompat.Dialog = 2131886613;
        /* added by DevToolsApp */
        /* renamed from: Theme.AppCompat.Dialog.Alert */
        public static final int f533Theme.AppCompat.Dialog.Alert = 2131886614;
        /* added by DevToolsApp */
        /* renamed from: Theme.AppCompat.Dialog.MinWidth */
        public static final int f534Theme.AppCompat.Dialog.MinWidth = 2131886615;
        /* added by DevToolsApp */
        /* renamed from: Theme.AppCompat.DialogWhenLarge */
        public static final int f535Theme.AppCompat.DialogWhenLarge = 2131886616;
        /* added by DevToolsApp */
        /* renamed from: Theme.AppCompat.Empty */
        public static final int f536Theme.AppCompat.Empty = 2131886617;
        /* added by DevToolsApp */
        /* renamed from: Theme.AppCompat.Light */
        public static final int f537Theme.AppCompat.Light = 2131886618;
        /* added by DevToolsApp */
        /* renamed from: Theme.AppCompat.Light.DarkActionBar */
        public static final int f538Theme.AppCompat.Light.DarkActionBar = 2131886619;
        /* added by DevToolsApp */
        /* renamed from: Theme.AppCompat.Light.Dialog */
        public static final int f539Theme.AppCompat.Light.Dialog = 2131886620;
        /* added by DevToolsApp */
        /* renamed from: Theme.AppCompat.Light.Dialog.Alert */
        public static final int f540Theme.AppCompat.Light.Dialog.Alert = 2131886621;
        /* added by DevToolsApp */
        /* renamed from: Theme.AppCompat.Light.Dialog.MinWidth */
        public static final int f541Theme.AppCompat.Light.Dialog.MinWidth = 2131886622;
        /* added by DevToolsApp */
        /* renamed from: Theme.AppCompat.Light.DialogWhenLarge */
        public static final int f542Theme.AppCompat.Light.DialogWhenLarge = 2131886623;
        /* added by DevToolsApp */
        /* renamed from: Theme.AppCompat.Light.NoActionBar */
        public static final int f543Theme.AppCompat.Light.NoActionBar = 2131886624;
        /* added by DevToolsApp */
        /* renamed from: Theme.AppCompat.NoActionBar */
        public static final int f544Theme.AppCompat.NoActionBar = 2131886625;
        /* added by DevToolsApp */
        /* renamed from: Theme.Design */
        public static final int f545Theme.Design = 2131886626;
        /* added by DevToolsApp */
        /* renamed from: Theme.Design.BottomSheetDialog */
        public static final int f546Theme.Design.BottomSheetDialog = 2131886627;
        /* added by DevToolsApp */
        /* renamed from: Theme.Design.Light */
        public static final int f547Theme.Design.Light = 2131886628;
        /* added by DevToolsApp */
        /* renamed from: Theme.Design.Light.BottomSheetDialog */
        public static final int f548Theme.Design.Light.BottomSheetDialog = 2131886629;
        /* added by DevToolsApp */
        /* renamed from: Theme.Design.Light.NoActionBar */
        public static final int f549Theme.Design.Light.NoActionBar = 2131886630;
        /* added by DevToolsApp */
        /* renamed from: Theme.Design.NoActionBar */
        public static final int f550Theme.Design.NoActionBar = 2131886631;
        /* added by DevToolsApp */
        /* renamed from: Theme.Material3.Dark */
        public static final int f551Theme.Material3.Dark = 2131886632;
        /* added by DevToolsApp */
        /* renamed from: Theme.Material3.Dark.BottomSheetDialog */
        public static final int f552Theme.Material3.Dark.BottomSheetDialog = 2131886633;
        /* added by DevToolsApp */
        /* renamed from: Theme.Material3.Dark.Dialog */
        public static final int f553Theme.Material3.Dark.Dialog = 2131886634;
        /* added by DevToolsApp */
        /* renamed from: Theme.Material3.Dark.Dialog.Alert */
        public static final int f554Theme.Material3.Dark.Dialog.Alert = 2131886635;
        /* added by DevToolsApp */
        /* renamed from: Theme.Material3.Dark.Dialog.MinWidth */
        public static final int f555Theme.Material3.Dark.Dialog.MinWidth = 2131886636;
        /* added by DevToolsApp */
        /* renamed from: Theme.Material3.Dark.DialogWhenLarge */
        public static final int f556Theme.Material3.Dark.DialogWhenLarge = 2131886637;
        /* added by DevToolsApp */
        /* renamed from: Theme.Material3.Dark.NoActionBar */
        public static final int f557Theme.Material3.Dark.NoActionBar = 2131886638;
        /* added by DevToolsApp */
        /* renamed from: Theme.Material3.Dark.SideSheetDialog */
        public static final int f558Theme.Material3.Dark.SideSheetDialog = 2131886639;
        /* added by DevToolsApp */
        /* renamed from: Theme.Material3.DayNight */
        public static final int f559Theme.Material3.DayNight = 2131886640;
        /* added by DevToolsApp */
        /* renamed from: Theme.Material3.DayNight.BottomSheetDialog */
        public static final int f560Theme.Material3.DayNight.BottomSheetDialog = 2131886641;
        /* added by DevToolsApp */
        /* renamed from: Theme.Material3.DayNight.Dialog */
        public static final int f561Theme.Material3.DayNight.Dialog = 2131886642;
        /* added by DevToolsApp */
        /* renamed from: Theme.Material3.DayNight.Dialog.Alert */
        public static final int f562Theme.Material3.DayNight.Dialog.Alert = 2131886643;
        /* added by DevToolsApp */
        /* renamed from: Theme.Material3.DayNight.Dialog.MinWidth */
        public static final int f563Theme.Material3.DayNight.Dialog.MinWidth = 2131886644;
        /* added by DevToolsApp */
        /* renamed from: Theme.Material3.DayNight.DialogWhenLarge */
        public static final int f564Theme.Material3.DayNight.DialogWhenLarge = 2131886645;
        /* added by DevToolsApp */
        /* renamed from: Theme.Material3.DayNight.NoActionBar */
        public static final int f565Theme.Material3.DayNight.NoActionBar = 2131886646;
        /* added by DevToolsApp */
        /* renamed from: Theme.Material3.DayNight.SideSheetDialog */
        public static final int f566Theme.Material3.DayNight.SideSheetDialog = 2131886647;
        /* added by DevToolsApp */
        /* renamed from: Theme.Material3.DynamicColors.Dark */
        public static final int f567Theme.Material3.DynamicColors.Dark = 2131886648;
        /* added by DevToolsApp */
        /* renamed from: Theme.Material3.DynamicColors.Dark.NoActionBar */
        public static final int f568Theme.Material3.DynamicColors.Dark.NoActionBar = 2131886649;
        /* added by DevToolsApp */
        /* renamed from: Theme.Material3.DynamicColors.DayNight */
        public static final int f569Theme.Material3.DynamicColors.DayNight = 2131886650;
        /* added by DevToolsApp */
        /* renamed from: Theme.Material3.DynamicColors.DayNight.NoActionBar */
        public static final int f570Theme.Material3.DynamicColors.DayNight.NoActionBar = 2131886651;
        /* added by DevToolsApp */
        /* renamed from: Theme.Material3.DynamicColors.Light */
        public static final int f571Theme.Material3.DynamicColors.Light = 2131886652;
        /* added by DevToolsApp */
        /* renamed from: Theme.Material3.DynamicColors.Light.NoActionBar */
        public static final int f572Theme.Material3.DynamicColors.Light.NoActionBar = 2131886653;
        /* added by DevToolsApp */
        /* renamed from: Theme.Material3.Light */
        public static final int f573Theme.Material3.Light = 2131886654;
        /* added by DevToolsApp */
        /* renamed from: Theme.Material3.Light.BottomSheetDialog */
        public static final int f574Theme.Material3.Light.BottomSheetDialog = 2131886655;
        /* added by DevToolsApp */
        /* renamed from: Theme.Material3.Light.Dialog */
        public static final int f575Theme.Material3.Light.Dialog = 2131886656;
        /* added by DevToolsApp */
        /* renamed from: Theme.Material3.Light.Dialog.Alert */
        public static final int f576Theme.Material3.Light.Dialog.Alert = 2131886657;
        /* added by DevToolsApp */
        /* renamed from: Theme.Material3.Light.Dialog.MinWidth */
        public static final int f577Theme.Material3.Light.Dialog.MinWidth = 2131886658;
        /* added by DevToolsApp */
        /* renamed from: Theme.Material3.Light.DialogWhenLarge */
        public static final int f578Theme.Material3.Light.DialogWhenLarge = 2131886659;
        /* added by DevToolsApp */
        /* renamed from: Theme.Material3.Light.NoActionBar */
        public static final int f579Theme.Material3.Light.NoActionBar = 2131886660;
        /* added by DevToolsApp */
        /* renamed from: Theme.Material3.Light.SideSheetDialog */
        public static final int f580Theme.Material3.Light.SideSheetDialog = 2131886661;
        /* added by DevToolsApp */
        /* renamed from: Theme.MaterialComponents */
        public static final int f581Theme.MaterialComponents = 2131886662;
        /* added by DevToolsApp */
        /* renamed from: Theme.MaterialComponents.BottomSheetDialog */
        public static final int f582Theme.MaterialComponents.BottomSheetDialog = 2131886663;
        /* added by DevToolsApp */
        /* renamed from: Theme.MaterialComponents.Bridge */
        public static final int f583Theme.MaterialComponents.Bridge = 2131886664;
        /* added by DevToolsApp */
        /* renamed from: Theme.MaterialComponents.CompactMenu */
        public static final int f584Theme.MaterialComponents.CompactMenu = 2131886665;
        /* added by DevToolsApp */
        /* renamed from: Theme.MaterialComponents.DayNight */
        public static final int f585Theme.MaterialComponents.DayNight = 2131886666;
        /* added by DevToolsApp */
        /* renamed from: Theme.MaterialComponents.DayNight.BottomSheetDialog */
        public static final int f586Theme.MaterialComponents.DayNight.BottomSheetDialog = 2131886667;
        /* added by DevToolsApp */
        /* renamed from: Theme.MaterialComponents.DayNight.Bridge */
        public static final int f587Theme.MaterialComponents.DayNight.Bridge = 2131886668;
        /* added by DevToolsApp */
        /* renamed from: Theme.MaterialComponents.DayNight.DarkActionBar */
        public static final int f588Theme.MaterialComponents.DayNight.DarkActionBar = 2131886669;
        /* added by DevToolsApp */
        /* renamed from: Theme.MaterialComponents.DayNight.DarkActionBar.Bridge */
        public static final int f589Theme.MaterialComponents.DayNight.DarkActionBar.Bridge = 2131886670;
        /* added by DevToolsApp */
        /* renamed from: Theme.MaterialComponents.DayNight.Dialog */
        public static final int f590Theme.MaterialComponents.DayNight.Dialog = 2131886671;
        /* added by DevToolsApp */
        /* renamed from: Theme.MaterialComponents.DayNight.Dialog.Alert */
        public static final int f591Theme.MaterialComponents.DayNight.Dialog.Alert = 2131886672;
        /* added by DevToolsApp */
        /* renamed from: Theme.MaterialComponents.DayNight.Dialog.Alert.Bridge */
        public static final int f592Theme.MaterialComponents.DayNight.Dialog.Alert.Bridge = 2131886673;
        /* added by DevToolsApp */
        /* renamed from: Theme.MaterialComponents.DayNight.Dialog.Bridge */
        public static final int f593Theme.MaterialComponents.DayNight.Dialog.Bridge = 2131886674;
        /* added by DevToolsApp */
        /* renamed from: Theme.MaterialComponents.DayNight.Dialog.FixedSize */
        public static final int f594Theme.MaterialComponents.DayNight.Dialog.FixedSize = 2131886675;
        /* added by DevToolsApp */
        /* renamed from: Theme.MaterialComponents.DayNight.Dialog.FixedSize.Bridge */
        public static final int f595Theme.MaterialComponents.DayNight.Dialog.FixedSize.Bridge = 2131886676;
        /* added by DevToolsApp */
        /* renamed from: Theme.MaterialComponents.DayNight.Dialog.MinWidth */
        public static final int f596Theme.MaterialComponents.DayNight.Dialog.MinWidth = 2131886677;
        /* added by DevToolsApp */
        /* renamed from: Theme.MaterialComponents.DayNight.Dialog.MinWidth.Bridge */
        public static final int f597Theme.MaterialComponents.DayNight.Dialog.MinWidth.Bridge = 2131886678;
        /* added by DevToolsApp */
        /* renamed from: Theme.MaterialComponents.DayNight.DialogWhenLarge */
        public static final int f598Theme.MaterialComponents.DayNight.DialogWhenLarge = 2131886679;
        /* added by DevToolsApp */
        /* renamed from: Theme.MaterialComponents.DayNight.NoActionBar */
        public static final int f599Theme.MaterialComponents.DayNight.NoActionBar = 2131886680;
        /* added by DevToolsApp */
        /* renamed from: Theme.MaterialComponents.DayNight.NoActionBar.Bridge */
        public static final int f600Theme.MaterialComponents.DayNight.NoActionBar.Bridge = 2131886681;
        /* added by DevToolsApp */
        /* renamed from: Theme.MaterialComponents.Dialog */
        public static final int f601Theme.MaterialComponents.Dialog = 2131886682;
        /* added by DevToolsApp */
        /* renamed from: Theme.MaterialComponents.Dialog.Alert */
        public static final int f602Theme.MaterialComponents.Dialog.Alert = 2131886683;
        /* added by DevToolsApp */
        /* renamed from: Theme.MaterialComponents.Dialog.Alert.Bridge */
        public static final int f603Theme.MaterialComponents.Dialog.Alert.Bridge = 2131886684;
        /* added by DevToolsApp */
        /* renamed from: Theme.MaterialComponents.Dialog.Bridge */
        public static final int f604Theme.MaterialComponents.Dialog.Bridge = 2131886685;
        /* added by DevToolsApp */
        /* renamed from: Theme.MaterialComponents.Dialog.FixedSize */
        public static final int f605Theme.MaterialComponents.Dialog.FixedSize = 2131886686;
        /* added by DevToolsApp */
        /* renamed from: Theme.MaterialComponents.Dialog.FixedSize.Bridge */
        public static final int f606Theme.MaterialComponents.Dialog.FixedSize.Bridge = 2131886687;
        /* added by DevToolsApp */
        /* renamed from: Theme.MaterialComponents.Dialog.MinWidth */
        public static final int f607Theme.MaterialComponents.Dialog.MinWidth = 2131886688;
        /* added by DevToolsApp */
        /* renamed from: Theme.MaterialComponents.Dialog.MinWidth.Bridge */
        public static final int f608Theme.MaterialComponents.Dialog.MinWidth.Bridge = 2131886689;
        /* added by DevToolsApp */
        /* renamed from: Theme.MaterialComponents.DialogWhenLarge */
        public static final int f609Theme.MaterialComponents.DialogWhenLarge = 2131886690;
        /* added by DevToolsApp */
        /* renamed from: Theme.MaterialComponents.Light */
        public static final int f610Theme.MaterialComponents.Light = 2131886691;
        /* added by DevToolsApp */
        /* renamed from: Theme.MaterialComponents.Light.BottomSheetDialog */
        public static final int f611Theme.MaterialComponents.Light.BottomSheetDialog = 2131886692;
        /* added by DevToolsApp */
        /* renamed from: Theme.MaterialComponents.Light.Bridge */
        public static final int f612Theme.MaterialComponents.Light.Bridge = 2131886693;
        /* added by DevToolsApp */
        /* renamed from: Theme.MaterialComponents.Light.DarkActionBar */
        public static final int f613Theme.MaterialComponents.Light.DarkActionBar = 2131886694;
        /* added by DevToolsApp */
        /* renamed from: Theme.MaterialComponents.Light.DarkActionBar.Bridge */
        public static final int f614Theme.MaterialComponents.Light.DarkActionBar.Bridge = 2131886695;
        /* added by DevToolsApp */
        /* renamed from: Theme.MaterialComponents.Light.Dialog */
        public static final int f615Theme.MaterialComponents.Light.Dialog = 2131886696;
        /* added by DevToolsApp */
        /* renamed from: Theme.MaterialComponents.Light.Dialog.Alert */
        public static final int f616Theme.MaterialComponents.Light.Dialog.Alert = 2131886697;
        /* added by DevToolsApp */
        /* renamed from: Theme.MaterialComponents.Light.Dialog.Alert.Bridge */
        public static final int f617Theme.MaterialComponents.Light.Dialog.Alert.Bridge = 2131886698;
        /* added by DevToolsApp */
        /* renamed from: Theme.MaterialComponents.Light.Dialog.Bridge */
        public static final int f618Theme.MaterialComponents.Light.Dialog.Bridge = 2131886699;
        /* added by DevToolsApp */
        /* renamed from: Theme.MaterialComponents.Light.Dialog.FixedSize */
        public static final int f619Theme.MaterialComponents.Light.Dialog.FixedSize = 2131886700;
        /* added by DevToolsApp */
        /* renamed from: Theme.MaterialComponents.Light.Dialog.FixedSize.Bridge */
        public static final int f620Theme.MaterialComponents.Light.Dialog.FixedSize.Bridge = 2131886701;
        /* added by DevToolsApp */
        /* renamed from: Theme.MaterialComponents.Light.Dialog.MinWidth */
        public static final int f621Theme.MaterialComponents.Light.Dialog.MinWidth = 2131886702;
        /* added by DevToolsApp */
        /* renamed from: Theme.MaterialComponents.Light.Dialog.MinWidth.Bridge */
        public static final int f622Theme.MaterialComponents.Light.Dialog.MinWidth.Bridge = 2131886703;
        /* added by DevToolsApp */
        /* renamed from: Theme.MaterialComponents.Light.DialogWhenLarge */
        public static final int f623Theme.MaterialComponents.Light.DialogWhenLarge = 2131886704;
        /* added by DevToolsApp */
        /* renamed from: Theme.MaterialComponents.Light.NoActionBar */
        public static final int f624Theme.MaterialComponents.Light.NoActionBar = 2131886705;
        /* added by DevToolsApp */
        /* renamed from: Theme.MaterialComponents.Light.NoActionBar.Bridge */
        public static final int f625Theme.MaterialComponents.Light.NoActionBar.Bridge = 2131886706;
        /* added by DevToolsApp */
        /* renamed from: Theme.MaterialComponents.NoActionBar */
        public static final int f626Theme.MaterialComponents.NoActionBar = 2131886707;
        /* added by DevToolsApp */
        /* renamed from: Theme.MaterialComponents.NoActionBar.Bridge */
        public static final int f627Theme.MaterialComponents.NoActionBar.Bridge = 2131886708;
        /* added by DevToolsApp */
        /* renamed from: Theme.SuperAdsPro */
        public static final int f628Theme.SuperAdsPro = 2131886709;
        /* added by DevToolsApp */
        /* renamed from: ThemeOverlay.AppCompat */
        public static final int f629ThemeOverlay.AppCompat = 2131886710;
        /* added by DevToolsApp */
        /* renamed from: ThemeOverlay.AppCompat.ActionBar */
        public static final int f630ThemeOverlay.AppCompat.ActionBar = 2131886711;
        /* added by DevToolsApp */
        /* renamed from: ThemeOverlay.AppCompat.Dark */
        public static final int f631ThemeOverlay.AppCompat.Dark = 2131886712;
        /* added by DevToolsApp */
        /* renamed from: ThemeOverlay.AppCompat.Dark.ActionBar */
        public static final int f632ThemeOverlay.AppCompat.Dark.ActionBar = 2131886713;
        /* added by DevToolsApp */
        /* renamed from: ThemeOverlay.AppCompat.DayNight */
        public static final int f633ThemeOverlay.AppCompat.DayNight = 2131886714;
        /* added by DevToolsApp */
        /* renamed from: ThemeOverlay.AppCompat.DayNight.ActionBar */
        public static final int f634ThemeOverlay.AppCompat.DayNight.ActionBar = 2131886715;
        /* added by DevToolsApp */
        /* renamed from: ThemeOverlay.AppCompat.Dialog */
        public static final int f635ThemeOverlay.AppCompat.Dialog = 2131886716;
        /* added by DevToolsApp */
        /* renamed from: ThemeOverlay.AppCompat.Dialog.Alert */
        public static final int f636ThemeOverlay.AppCompat.Dialog.Alert = 2131886717;
        /* added by DevToolsApp */
        /* renamed from: ThemeOverlay.AppCompat.Light */
        public static final int f637ThemeOverlay.AppCompat.Light = 2131886718;
        /* added by DevToolsApp */
        /* renamed from: ThemeOverlay.Design.TextInputEditText */
        public static final int f638ThemeOverlay.Design.TextInputEditText = 2131886719;
        /* added by DevToolsApp */
        /* renamed from: ThemeOverlay.Material3 */
        public static final int f639ThemeOverlay.Material3 = 2131886720;
        /* added by DevToolsApp */
        /* renamed from: ThemeOverlay.Material3.ActionBar */
        public static final int f640ThemeOverlay.Material3.ActionBar = 2131886721;
        /* added by DevToolsApp */
        /* renamed from: ThemeOverlay.Material3.AutoCompleteTextView */
        public static final int f641ThemeOverlay.Material3.AutoCompleteTextView = 2131886722;
        /* added by DevToolsApp */
        /* renamed from: ThemeOverlay.Material3.AutoCompleteTextView.FilledBox */
        public static final int f642ThemeOverlay.Material3.AutoCompleteTextView.FilledBox = 2131886723;
        /* added by DevToolsApp */
        /* renamed from: ThemeOverlay.Material3.AutoCompleteTextView.FilledBox.Dense */
        public static final int f643ThemeOverlay.Material3.AutoCompleteTextView.FilledBox.Dense = 2131886724;
        /* added by DevToolsApp */
        /* renamed from: ThemeOverlay.Material3.AutoCompleteTextView.OutlinedBox */
        public static final int f644ThemeOverlay.Material3.AutoCompleteTextView.OutlinedBox = 2131886725;
        /* added by DevToolsApp */
        /* renamed from: ThemeOverlay.Material3.AutoCompleteTextView.OutlinedBox.Dense */
        public static final int f645ThemeOverlay.Material3.AutoCompleteTextView.OutlinedBox.Dense = 2131886726;
        /* added by DevToolsApp */
        /* renamed from: ThemeOverlay.Material3.BottomAppBar */
        public static final int f646ThemeOverlay.Material3.BottomAppBar = 2131886727;
        /* added by DevToolsApp */
        /* renamed from: ThemeOverlay.Material3.BottomAppBar.Legacy */
        public static final int f647ThemeOverlay.Material3.BottomAppBar.Legacy = 2131886728;
        /* added by DevToolsApp */
        /* renamed from: ThemeOverlay.Material3.BottomNavigationView */
        public static final int f648ThemeOverlay.Material3.BottomNavigationView = 2131886729;
        /* added by DevToolsApp */
        /* renamed from: ThemeOverlay.Material3.BottomSheetDialog */
        public static final int f649ThemeOverlay.Material3.BottomSheetDialog = 2131886730;
        /* added by DevToolsApp */
        /* renamed from: ThemeOverlay.Material3.Button */
        public static final int f650ThemeOverlay.Material3.Button = 2131886731;
        /* added by DevToolsApp */
        /* renamed from: ThemeOverlay.Material3.Button.ElevatedButton */
        public static final int f651ThemeOverlay.Material3.Button.ElevatedButton = 2131886732;
        /* added by DevToolsApp */
        /* renamed from: ThemeOverlay.Material3.Button.IconButton */
        public static final int f652ThemeOverlay.Material3.Button.IconButton = 2131886733;
        /* added by DevToolsApp */
        /* renamed from: ThemeOverlay.Material3.Button.IconButton.Filled */
        public static final int f653ThemeOverlay.Material3.Button.IconButton.Filled = 2131886734;
        /* added by DevToolsApp */
        /* renamed from: ThemeOverlay.Material3.Button.IconButton.Filled.Tonal */
        public static final int f654ThemeOverlay.Material3.Button.IconButton.Filled.Tonal = 2131886735;
        /* added by DevToolsApp */
        /* renamed from: ThemeOverlay.Material3.Button.TextButton */
        public static final int f655ThemeOverlay.Material3.Button.TextButton = 2131886736;
        /* added by DevToolsApp */
        /* renamed from: ThemeOverlay.Material3.Button.TextButton.Snackbar */
        public static final int f656ThemeOverlay.Material3.Button.TextButton.Snackbar = 2131886737;
        /* added by DevToolsApp */
        /* renamed from: ThemeOverlay.Material3.Button.TonalButton */
        public static final int f657ThemeOverlay.Material3.Button.TonalButton = 2131886738;
        /* added by DevToolsApp */
        /* renamed from: ThemeOverlay.Material3.Chip */
        public static final int f658ThemeOverlay.Material3.Chip = 2131886739;
        /* added by DevToolsApp */
        /* renamed from: ThemeOverlay.Material3.Chip.Assist */
        public static final int f659ThemeOverlay.Material3.Chip.Assist = 2131886740;
        /* added by DevToolsApp */
        /* renamed from: ThemeOverlay.Material3.Dark */
        public static final int f660ThemeOverlay.Material3.Dark = 2131886741;
        /* added by DevToolsApp */
        /* renamed from: ThemeOverlay.Material3.Dark.ActionBar */
        public static final int f661ThemeOverlay.Material3.Dark.ActionBar = 2131886742;
        /* added by DevToolsApp */
        /* renamed from: ThemeOverlay.Material3.DayNight.BottomSheetDialog */
        public static final int f662ThemeOverlay.Material3.DayNight.BottomSheetDialog = 2131886743;
        /* added by DevToolsApp */
        /* renamed from: ThemeOverlay.Material3.DayNight.SideSheetDialog */
        public static final int f663ThemeOverlay.Material3.DayNight.SideSheetDialog = 2131886744;
        /* added by DevToolsApp */
        /* renamed from: ThemeOverlay.Material3.Dialog */
        public static final int f664ThemeOverlay.Material3.Dialog = 2131886745;
        /* added by DevToolsApp */
        /* renamed from: ThemeOverlay.Material3.Dialog.Alert */
        public static final int f665ThemeOverlay.Material3.Dialog.Alert = 2131886746;
        /* added by DevToolsApp */
        /* renamed from: ThemeOverlay.Material3.Dialog.Alert.Framework */
        public static final int f666ThemeOverlay.Material3.Dialog.Alert.Framework = 2131886747;
        /* added by DevToolsApp */
        /* renamed from: ThemeOverlay.Material3.DynamicColors.Dark */
        public static final int f667ThemeOverlay.Material3.DynamicColors.Dark = 2131886748;
        /* added by DevToolsApp */
        /* renamed from: ThemeOverlay.Material3.DynamicColors.DayNight */
        public static final int f668ThemeOverlay.Material3.DynamicColors.DayNight = 2131886749;
        /* added by DevToolsApp */
        /* renamed from: ThemeOverlay.Material3.DynamicColors.Light */
        public static final int f669ThemeOverlay.Material3.DynamicColors.Light = 2131886750;
        /* added by DevToolsApp */
        /* renamed from: ThemeOverlay.Material3.ExtendedFloatingActionButton.Primary */
        public static final int f670ThemeOverlay.Material3.ExtendedFloatingActionButton.Primary = 2131886751;
        /* added by DevToolsApp */
        /* renamed from: ThemeOverlay.Material3.ExtendedFloatingActionButton.Secondary */
        public static final int f671ThemeOverlay.Material3.ExtendedFloatingActionButton.Secondary = 2131886752;
        /* added by DevToolsApp */
        /* renamed from: ThemeOverlay.Material3.ExtendedFloatingActionButton.Surface */
        public static final int f672ThemeOverlay.Material3.ExtendedFloatingActionButton.Surface = 2131886753;
        /* added by DevToolsApp */
        /* renamed from: ThemeOverlay.Material3.ExtendedFloatingActionButton.Tertiary */
        public static final int f673ThemeOverlay.Material3.ExtendedFloatingActionButton.Tertiary = 2131886754;
        /* added by DevToolsApp */
        /* renamed from: ThemeOverlay.Material3.FloatingActionButton.Primary */
        public static final int f674ThemeOverlay.Material3.FloatingActionButton.Primary = 2131886755;
        /* added by DevToolsApp */
        /* renamed from: ThemeOverlay.Material3.FloatingActionButton.Secondary */
        public static final int f675ThemeOverlay.Material3.FloatingActionButton.Secondary = 2131886756;
        /* added by DevToolsApp */
        /* renamed from: ThemeOverlay.Material3.FloatingActionButton.Surface */
        public static final int f676ThemeOverlay.Material3.FloatingActionButton.Surface = 2131886757;
        /* added by DevToolsApp */
        /* renamed from: ThemeOverlay.Material3.FloatingActionButton.Tertiary */
        public static final int f677ThemeOverlay.Material3.FloatingActionButton.Tertiary = 2131886758;
        /* added by DevToolsApp */
        /* renamed from: ThemeOverlay.Material3.HarmonizedColors */
        public static final int f678ThemeOverlay.Material3.HarmonizedColors = 2131886759;
        /* added by DevToolsApp */
        /* renamed from: ThemeOverlay.Material3.HarmonizedColors.Empty */
        public static final int f679ThemeOverlay.Material3.HarmonizedColors.Empty = 2131886760;
        /* added by DevToolsApp */
        /* renamed from: ThemeOverlay.Material3.Light */
        public static final int f680ThemeOverlay.Material3.Light = 2131886761;
        /* added by DevToolsApp */
        /* renamed from: ThemeOverlay.Material3.Light.Dialog.Alert.Framework */
        public static final int f681ThemeOverlay.Material3.Light.Dialog.Alert.Framework = 2131886762;
        /* added by DevToolsApp */
        /* renamed from: ThemeOverlay.Material3.MaterialAlertDialog */
        public static final int f682ThemeOverlay.Material3.MaterialAlertDialog = 2131886763;
        /* added by DevToolsApp */
        /* renamed from: ThemeOverlay.Material3.MaterialAlertDialog.Centered */
        public static final int f683ThemeOverlay.Material3.MaterialAlertDialog.Centered = 2131886764;
        /* added by DevToolsApp */
        /* renamed from: ThemeOverlay.Material3.MaterialCalendar */
        public static final int f684ThemeOverlay.Material3.MaterialCalendar = 2131886765;
        /* added by DevToolsApp */
        /* renamed from: ThemeOverlay.Material3.MaterialCalendar.Fullscreen */
        public static final int f685ThemeOverlay.Material3.MaterialCalendar.Fullscreen = 2131886766;
        /* added by DevToolsApp */
        /* renamed from: ThemeOverlay.Material3.MaterialCalendar.HeaderCancelButton */
        public static final int f686ThemeOverlay.Material3.MaterialCalendar.HeaderCancelButton = 2131886767;
        /* added by DevToolsApp */
        /* renamed from: ThemeOverlay.Material3.MaterialTimePicker */
        public static final int f687ThemeOverlay.Material3.MaterialTimePicker = 2131886768;
        /* added by DevToolsApp */
        /* renamed from: ThemeOverlay.Material3.MaterialTimePicker.Display.TextInputEditText */
        public static final int f688ThemeOverlay.Material3.MaterialTimePicker.Display.TextInputEditText = 2131886769;
        /* added by DevToolsApp */
        /* renamed from: ThemeOverlay.Material3.NavigationRailView */
        public static final int f689ThemeOverlay.Material3.NavigationRailView = 2131886770;
        /* added by DevToolsApp */
        /* renamed from: ThemeOverlay.Material3.NavigationView */
        public static final int f690ThemeOverlay.Material3.NavigationView = 2131886771;
        /* added by DevToolsApp */
        /* renamed from: ThemeOverlay.Material3.PersonalizedColors */
        public static final int f691ThemeOverlay.Material3.PersonalizedColors = 2131886772;
        /* added by DevToolsApp */
        /* renamed from: ThemeOverlay.Material3.Search */
        public static final int f692ThemeOverlay.Material3.Search = 2131886773;
        /* added by DevToolsApp */
        /* renamed from: ThemeOverlay.Material3.SideSheetDialog */
        public static final int f693ThemeOverlay.Material3.SideSheetDialog = 2131886774;
        /* added by DevToolsApp */
        /* renamed from: ThemeOverlay.Material3.Snackbar */
        public static final int f694ThemeOverlay.Material3.Snackbar = 2131886775;
        /* added by DevToolsApp */
        /* renamed from: ThemeOverlay.Material3.TabLayout */
        public static final int f695ThemeOverlay.Material3.TabLayout = 2131886776;
        /* added by DevToolsApp */
        /* renamed from: ThemeOverlay.Material3.TextInputEditText */
        public static final int f696ThemeOverlay.Material3.TextInputEditText = 2131886777;
        /* added by DevToolsApp */
        /* renamed from: ThemeOverlay.Material3.TextInputEditText.FilledBox */
        public static final int f697ThemeOverlay.Material3.TextInputEditText.FilledBox = 2131886778;
        /* added by DevToolsApp */
        /* renamed from: ThemeOverlay.Material3.TextInputEditText.FilledBox.Dense */
        public static final int f698ThemeOverlay.Material3.TextInputEditText.FilledBox.Dense = 2131886779;
        /* added by DevToolsApp */
        /* renamed from: ThemeOverlay.Material3.TextInputEditText.OutlinedBox */
        public static final int f699ThemeOverlay.Material3.TextInputEditText.OutlinedBox = 2131886780;
        /* added by DevToolsApp */
        /* renamed from: ThemeOverlay.Material3.TextInputEditText.OutlinedBox.Dense */
        public static final int f700ThemeOverlay.Material3.TextInputEditText.OutlinedBox.Dense = 2131886781;
        /* added by DevToolsApp */
        /* renamed from: ThemeOverlay.Material3.Toolbar.Surface */
        public static final int f701ThemeOverlay.Material3.Toolbar.Surface = 2131886782;
        /* added by DevToolsApp */
        /* renamed from: ThemeOverlay.MaterialAlertDialog.Material3.Title.Icon */
        public static final int f702ThemeOverlay.MaterialAlertDialog.Material3.Title.Icon = 2131886783;
        /* added by DevToolsApp */
        /* renamed from: ThemeOverlay.MaterialComponents */
        public static final int f703ThemeOverlay.MaterialComponents = 2131886784;
        /* added by DevToolsApp */
        /* renamed from: ThemeOverlay.MaterialComponents.ActionBar */
        public static final int f704ThemeOverlay.MaterialComponents.ActionBar = 2131886785;
        /* added by DevToolsApp */
        /* renamed from: ThemeOverlay.MaterialComponents.ActionBar.Primary */
        public static final int f705ThemeOverlay.MaterialComponents.ActionBar.Primary = 2131886786;
        /* added by DevToolsApp */
        /* renamed from: ThemeOverlay.MaterialComponents.ActionBar.Surface */
        public static final int f706ThemeOverlay.MaterialComponents.ActionBar.Surface = 2131886787;
        /* added by DevToolsApp */
        /* renamed from: ThemeOverlay.MaterialComponents.AutoCompleteTextView */
        public static final int f707ThemeOverlay.MaterialComponents.AutoCompleteTextView = 2131886788;
        /* added by DevToolsApp */
        /* renamed from: ThemeOverlay.MaterialComponents.AutoCompleteTextView.FilledBox */
        public static final int f708ThemeOverlay.MaterialComponents.AutoCompleteTextView.FilledBox = 2131886789;
        /* added by DevToolsApp */
        /* renamed from: ThemeOverlay.MaterialComponents.AutoCompleteTextView.FilledBox.Dense */
        public static final int f709ThemeOverlay.MaterialComponents.AutoCompleteTextView.FilledBox.Dense = 2131886790;
        /* added by DevToolsApp */
        /* renamed from: ThemeOverlay.MaterialComponents.AutoCompleteTextView.OutlinedBox */
        public static final int f710ThemeOverlay.MaterialComponents.AutoCompleteTextView.OutlinedBox = 2131886791;
        /* added by DevToolsApp */
        /* renamed from: ThemeOverlay.MaterialComponents.AutoCompleteTextView.OutlinedBox.Dense */
        public static final int f711ThemeOverlay.MaterialComponents.AutoCompleteTextView.OutlinedBox.Dense = 2131886792;
        /* added by DevToolsApp */
        /* renamed from: ThemeOverlay.MaterialComponents.BottomAppBar.Primary */
        public static final int f712ThemeOverlay.MaterialComponents.BottomAppBar.Primary = 2131886793;
        /* added by DevToolsApp */
        /* renamed from: ThemeOverlay.MaterialComponents.BottomAppBar.Surface */
        public static final int f713ThemeOverlay.MaterialComponents.BottomAppBar.Surface = 2131886794;
        /* added by DevToolsApp */
        /* renamed from: ThemeOverlay.MaterialComponents.BottomSheetDialog */
        public static final int f714ThemeOverlay.MaterialComponents.BottomSheetDialog = 2131886795;
        /* added by DevToolsApp */
        /* renamed from: ThemeOverlay.MaterialComponents.Dark */
        public static final int f715ThemeOverlay.MaterialComponents.Dark = 2131886796;
        /* added by DevToolsApp */
        /* renamed from: ThemeOverlay.MaterialComponents.Dark.ActionBar */
        public static final int f716ThemeOverlay.MaterialComponents.Dark.ActionBar = 2131886797;
        /* added by DevToolsApp */
        /* renamed from: ThemeOverlay.MaterialComponents.DayNight.BottomSheetDialog */
        public static final int f717ThemeOverlay.MaterialComponents.DayNight.BottomSheetDialog = 2131886798;
        /* added by DevToolsApp */
        /* renamed from: ThemeOverlay.MaterialComponents.Dialog */
        public static final int f718ThemeOverlay.MaterialComponents.Dialog = 2131886799;
        /* added by DevToolsApp */
        /* renamed from: ThemeOverlay.MaterialComponents.Dialog.Alert */
        public static final int f719ThemeOverlay.MaterialComponents.Dialog.Alert = 2131886800;
        /* added by DevToolsApp */
        /* renamed from: ThemeOverlay.MaterialComponents.Dialog.Alert.Framework */
        public static final int f720ThemeOverlay.MaterialComponents.Dialog.Alert.Framework = 2131886801;
        /* added by DevToolsApp */
        /* renamed from: ThemeOverlay.MaterialComponents.Light */
        public static final int f721ThemeOverlay.MaterialComponents.Light = 2131886802;
        /* added by DevToolsApp */
        /* renamed from: ThemeOverlay.MaterialComponents.Light.Dialog.Alert.Framework */
        public static final int f722ThemeOverlay.MaterialComponents.Light.Dialog.Alert.Framework = 2131886803;
        /* added by DevToolsApp */
        /* renamed from: ThemeOverlay.MaterialComponents.MaterialAlertDialog */
        public static final int f723ThemeOverlay.MaterialComponents.MaterialAlertDialog = 2131886804;
        /* added by DevToolsApp */
        /* renamed from: ThemeOverlay.MaterialComponents.MaterialAlertDialog.Centered */
        public static final int f724ThemeOverlay.MaterialComponents.MaterialAlertDialog.Centered = 2131886805;
        /* added by DevToolsApp */
        /* renamed from: ThemeOverlay.MaterialComponents.MaterialAlertDialog.Picker.Date */
        public static final int f725ThemeOverlay.MaterialComponents.MaterialAlertDialog.Picker.Date = 2131886806;
        /* added by DevToolsApp */
        /* renamed from: ThemeOverlay.MaterialComponents.MaterialAlertDialog.Picker.Date.Calendar */
        public static final int f726ThemeOverlay.MaterialComponents.MaterialAlertDialog.Picker.Date.Calendar = 2131886807;
        /* added by DevToolsApp */
        /* renamed from: ThemeOverlay.MaterialComponents.MaterialAlertDialog.Picker.Date.Header.Text */
        public static final int f727ThemeOverlay.MaterialComponents.MaterialAlertDialog.Picker.Date.Header.Text = 2131886808;
        /* added by DevToolsApp */
        /* renamed from: ThemeOverlay.MaterialComponents.MaterialAlertDialog.Picker.Date.Header.Text.Day */
        public static final int f728ThemeOverlay.MaterialComponents.MaterialAlertDialog.Picker.Date.Header.Text.Day = 2131886809;
        /* added by DevToolsApp */
        /* renamed from: ThemeOverlay.MaterialComponents.MaterialAlertDialog.Picker.Date.Spinner */
        public static final int f729ThemeOverlay.MaterialComponents.MaterialAlertDialog.Picker.Date.Spinner = 2131886810;
        /* added by DevToolsApp */
        /* renamed from: ThemeOverlay.MaterialComponents.MaterialCalendar */
        public static final int f730ThemeOverlay.MaterialComponents.MaterialCalendar = 2131886811;
        /* added by DevToolsApp */
        /* renamed from: ThemeOverlay.MaterialComponents.MaterialCalendar.Fullscreen */
        public static final int f731ThemeOverlay.MaterialComponents.MaterialCalendar.Fullscreen = 2131886812;
        /* added by DevToolsApp */
        /* renamed from: ThemeOverlay.MaterialComponents.TextInputEditText */
        public static final int f732ThemeOverlay.MaterialComponents.TextInputEditText = 2131886813;
        /* added by DevToolsApp */
        /* renamed from: ThemeOverlay.MaterialComponents.TextInputEditText.FilledBox */
        public static final int f733ThemeOverlay.MaterialComponents.TextInputEditText.FilledBox = 2131886814;
        /* added by DevToolsApp */
        /* renamed from: ThemeOverlay.MaterialComponents.TextInputEditText.FilledBox.Dense */
        public static final int f734ThemeOverlay.MaterialComponents.TextInputEditText.FilledBox.Dense = 2131886815;
        /* added by DevToolsApp */
        /* renamed from: ThemeOverlay.MaterialComponents.TextInputEditText.OutlinedBox */
        public static final int f735ThemeOverlay.MaterialComponents.TextInputEditText.OutlinedBox = 2131886816;
        /* added by DevToolsApp */
        /* renamed from: ThemeOverlay.MaterialComponents.TextInputEditText.OutlinedBox.Dense */
        public static final int f736ThemeOverlay.MaterialComponents.TextInputEditText.OutlinedBox.Dense = 2131886817;
        /* added by DevToolsApp */
        /* renamed from: ThemeOverlay.MaterialComponents.TimePicker */
        public static final int f737ThemeOverlay.MaterialComponents.TimePicker = 2131886818;
        /* added by DevToolsApp */
        /* renamed from: ThemeOverlay.MaterialComponents.TimePicker.Display */
        public static final int f738ThemeOverlay.MaterialComponents.TimePicker.Display = 2131886819;
        /* added by DevToolsApp */
        /* renamed from: ThemeOverlay.MaterialComponents.TimePicker.Display.TextInputEditText */
        public static final int f739ThemeOverlay.MaterialComponents.TimePicker.Display.TextInputEditText = 2131886820;
        /* added by DevToolsApp */
        /* renamed from: ThemeOverlay.MaterialComponents.Toolbar.Popup.Primary */
        public static final int f740ThemeOverlay.MaterialComponents.Toolbar.Popup.Primary = 2131886821;
        /* added by DevToolsApp */
        /* renamed from: ThemeOverlay.MaterialComponents.Toolbar.Primary */
        public static final int f741ThemeOverlay.MaterialComponents.Toolbar.Primary = 2131886822;
        /* added by DevToolsApp */
        /* renamed from: ThemeOverlay.MaterialComponents.Toolbar.Surface */
        public static final int f742ThemeOverlay.MaterialComponents.Toolbar.Surface = 2131886823;
        /* added by DevToolsApp */
        /* renamed from: Widget.AppCompat.ActionBar */
        public static final int f743Widget.AppCompat.ActionBar = 2131886824;
        /* added by DevToolsApp */
        /* renamed from: Widget.AppCompat.ActionBar.Solid */
        public static final int f744Widget.AppCompat.ActionBar.Solid = 2131886825;
        /* added by DevToolsApp */
        /* renamed from: Widget.AppCompat.ActionBar.TabBar */
        public static final int f745Widget.AppCompat.ActionBar.TabBar = 2131886826;
        /* added by DevToolsApp */
        /* renamed from: Widget.AppCompat.ActionBar.TabText */
        public static final int f746Widget.AppCompat.ActionBar.TabText = 2131886827;
        /* added by DevToolsApp */
        /* renamed from: Widget.AppCompat.ActionBar.TabView */
        public static final int f747Widget.AppCompat.ActionBar.TabView = 2131886828;
        /* added by DevToolsApp */
        /* renamed from: Widget.AppCompat.ActionButton */
        public static final int f748Widget.AppCompat.ActionButton = 2131886829;
        /* added by DevToolsApp */
        /* renamed from: Widget.AppCompat.ActionButton.CloseMode */
        public static final int f749Widget.AppCompat.ActionButton.CloseMode = 2131886830;
        /* added by DevToolsApp */
        /* renamed from: Widget.AppCompat.ActionButton.Overflow */
        public static final int f750Widget.AppCompat.ActionButton.Overflow = 2131886831;
        /* added by DevToolsApp */
        /* renamed from: Widget.AppCompat.ActionMode */
        public static final int f751Widget.AppCompat.ActionMode = 2131886832;
        /* added by DevToolsApp */
        /* renamed from: Widget.AppCompat.ActivityChooserView */
        public static final int f752Widget.AppCompat.ActivityChooserView = 2131886833;
        /* added by DevToolsApp */
        /* renamed from: Widget.AppCompat.AutoCompleteTextView */
        public static final int f753Widget.AppCompat.AutoCompleteTextView = 2131886834;
        /* added by DevToolsApp */
        /* renamed from: Widget.AppCompat.Button */
        public static final int f754Widget.AppCompat.Button = 2131886835;
        /* added by DevToolsApp */
        /* renamed from: Widget.AppCompat.Button.Borderless */
        public static final int f755Widget.AppCompat.Button.Borderless = 2131886836;
        /* added by DevToolsApp */
        /* renamed from: Widget.AppCompat.Button.Borderless.Colored */
        public static final int f756Widget.AppCompat.Button.Borderless.Colored = 2131886837;
        /* added by DevToolsApp */
        /* renamed from: Widget.AppCompat.Button.ButtonBar.AlertDialog */
        public static final int f757Widget.AppCompat.Button.ButtonBar.AlertDialog = 2131886838;
        /* added by DevToolsApp */
        /* renamed from: Widget.AppCompat.Button.Colored */
        public static final int f758Widget.AppCompat.Button.Colored = 2131886839;
        /* added by DevToolsApp */
        /* renamed from: Widget.AppCompat.Button.Small */
        public static final int f759Widget.AppCompat.Button.Small = 2131886840;
        /* added by DevToolsApp */
        /* renamed from: Widget.AppCompat.ButtonBar */
        public static final int f760Widget.AppCompat.ButtonBar = 2131886841;
        /* added by DevToolsApp */
        /* renamed from: Widget.AppCompat.ButtonBar.AlertDialog */
        public static final int f761Widget.AppCompat.ButtonBar.AlertDialog = 2131886842;
        /* added by DevToolsApp */
        /* renamed from: Widget.AppCompat.CompoundButton.CheckBox */
        public static final int f762Widget.AppCompat.CompoundButton.CheckBox = 2131886843;
        /* added by DevToolsApp */
        /* renamed from: Widget.AppCompat.CompoundButton.RadioButton */
        public static final int f763Widget.AppCompat.CompoundButton.RadioButton = 2131886844;
        /* added by DevToolsApp */
        /* renamed from: Widget.AppCompat.CompoundButton.Switch */
        public static final int f764Widget.AppCompat.CompoundButton.Switch = 2131886845;
        /* added by DevToolsApp */
        /* renamed from: Widget.AppCompat.DrawerArrowToggle */
        public static final int f765Widget.AppCompat.DrawerArrowToggle = 2131886846;
        /* added by DevToolsApp */
        /* renamed from: Widget.AppCompat.DropDownItem.Spinner */
        public static final int f766Widget.AppCompat.DropDownItem.Spinner = 2131886847;
        /* added by DevToolsApp */
        /* renamed from: Widget.AppCompat.EditText */
        public static final int f767Widget.AppCompat.EditText = 2131886848;
        /* added by DevToolsApp */
        /* renamed from: Widget.AppCompat.ImageButton */
        public static final int f768Widget.AppCompat.ImageButton = 2131886849;
        /* added by DevToolsApp */
        /* renamed from: Widget.AppCompat.Light.ActionBar */
        public static final int f769Widget.AppCompat.Light.ActionBar = 2131886850;
        /* added by DevToolsApp */
        /* renamed from: Widget.AppCompat.Light.ActionBar.Solid */
        public static final int f770Widget.AppCompat.Light.ActionBar.Solid = 2131886851;
        /* added by DevToolsApp */
        /* renamed from: Widget.AppCompat.Light.ActionBar.Solid.Inverse */
        public static final int f771Widget.AppCompat.Light.ActionBar.Solid.Inverse = 2131886852;
        /* added by DevToolsApp */
        /* renamed from: Widget.AppCompat.Light.ActionBar.TabBar */
        public static final int f772Widget.AppCompat.Light.ActionBar.TabBar = 2131886853;
        /* added by DevToolsApp */
        /* renamed from: Widget.AppCompat.Light.ActionBar.TabBar.Inverse */
        public static final int f773Widget.AppCompat.Light.ActionBar.TabBar.Inverse = 2131886854;
        /* added by DevToolsApp */
        /* renamed from: Widget.AppCompat.Light.ActionBar.TabText */
        public static final int f774Widget.AppCompat.Light.ActionBar.TabText = 2131886855;
        /* added by DevToolsApp */
        /* renamed from: Widget.AppCompat.Light.ActionBar.TabText.Inverse */
        public static final int f775Widget.AppCompat.Light.ActionBar.TabText.Inverse = 2131886856;
        /* added by DevToolsApp */
        /* renamed from: Widget.AppCompat.Light.ActionBar.TabView */
        public static final int f776Widget.AppCompat.Light.ActionBar.TabView = 2131886857;
        /* added by DevToolsApp */
        /* renamed from: Widget.AppCompat.Light.ActionBar.TabView.Inverse */
        public static final int f777Widget.AppCompat.Light.ActionBar.TabView.Inverse = 2131886858;
        /* added by DevToolsApp */
        /* renamed from: Widget.AppCompat.Light.ActionButton */
        public static final int f778Widget.AppCompat.Light.ActionButton = 2131886859;
        /* added by DevToolsApp */
        /* renamed from: Widget.AppCompat.Light.ActionButton.CloseMode */
        public static final int f779Widget.AppCompat.Light.ActionButton.CloseMode = 2131886860;
        /* added by DevToolsApp */
        /* renamed from: Widget.AppCompat.Light.ActionButton.Overflow */
        public static final int f780Widget.AppCompat.Light.ActionButton.Overflow = 2131886861;
        /* added by DevToolsApp */
        /* renamed from: Widget.AppCompat.Light.ActionMode.Inverse */
        public static final int f781Widget.AppCompat.Light.ActionMode.Inverse = 2131886862;
        /* added by DevToolsApp */
        /* renamed from: Widget.AppCompat.Light.ActivityChooserView */
        public static final int f782Widget.AppCompat.Light.ActivityChooserView = 2131886863;
        /* added by DevToolsApp */
        /* renamed from: Widget.AppCompat.Light.AutoCompleteTextView */
        public static final int f783Widget.AppCompat.Light.AutoCompleteTextView = 2131886864;
        /* added by DevToolsApp */
        /* renamed from: Widget.AppCompat.Light.DropDownItem.Spinner */
        public static final int f784Widget.AppCompat.Light.DropDownItem.Spinner = 2131886865;
        /* added by DevToolsApp */
        /* renamed from: Widget.AppCompat.Light.ListPopupWindow */
        public static final int f785Widget.AppCompat.Light.ListPopupWindow = 2131886866;
        /* added by DevToolsApp */
        /* renamed from: Widget.AppCompat.Light.ListView.DropDown */
        public static final int f786Widget.AppCompat.Light.ListView.DropDown = 2131886867;
        /* added by DevToolsApp */
        /* renamed from: Widget.AppCompat.Light.PopupMenu */
        public static final int f787Widget.AppCompat.Light.PopupMenu = 2131886868;
        /* added by DevToolsApp */
        /* renamed from: Widget.AppCompat.Light.PopupMenu.Overflow */
        public static final int f788Widget.AppCompat.Light.PopupMenu.Overflow = 2131886869;
        /* added by DevToolsApp */
        /* renamed from: Widget.AppCompat.Light.SearchView */
        public static final int f789Widget.AppCompat.Light.SearchView = 2131886870;
        /* added by DevToolsApp */
        /* renamed from: Widget.AppCompat.Light.Spinner.DropDown.ActionBar */
        public static final int f790Widget.AppCompat.Light.Spinner.DropDown.ActionBar = 2131886871;
        /* added by DevToolsApp */
        /* renamed from: Widget.AppCompat.ListMenuView */
        public static final int f791Widget.AppCompat.ListMenuView = 2131886872;
        /* added by DevToolsApp */
        /* renamed from: Widget.AppCompat.ListPopupWindow */
        public static final int f792Widget.AppCompat.ListPopupWindow = 2131886873;
        /* added by DevToolsApp */
        /* renamed from: Widget.AppCompat.ListView */
        public static final int f793Widget.AppCompat.ListView = 2131886874;
        /* added by DevToolsApp */
        /* renamed from: Widget.AppCompat.ListView.DropDown */
        public static final int f794Widget.AppCompat.ListView.DropDown = 2131886875;
        /* added by DevToolsApp */
        /* renamed from: Widget.AppCompat.ListView.Menu */
        public static final int f795Widget.AppCompat.ListView.Menu = 2131886876;
        /* added by DevToolsApp */
        /* renamed from: Widget.AppCompat.PopupMenu */
        public static final int f796Widget.AppCompat.PopupMenu = 2131886877;
        /* added by DevToolsApp */
        /* renamed from: Widget.AppCompat.PopupMenu.Overflow */
        public static final int f797Widget.AppCompat.PopupMenu.Overflow = 2131886878;
        /* added by DevToolsApp */
        /* renamed from: Widget.AppCompat.PopupWindow */
        public static final int f798Widget.AppCompat.PopupWindow = 2131886879;
        /* added by DevToolsApp */
        /* renamed from: Widget.AppCompat.ProgressBar */
        public static final int f799Widget.AppCompat.ProgressBar = 2131886880;
        /* added by DevToolsApp */
        /* renamed from: Widget.AppCompat.ProgressBar.Horizontal */
        public static final int f800Widget.AppCompat.ProgressBar.Horizontal = 2131886881;
        /* added by DevToolsApp */
        /* renamed from: Widget.AppCompat.RatingBar */
        public static final int f801Widget.AppCompat.RatingBar = 2131886882;
        /* added by DevToolsApp */
        /* renamed from: Widget.AppCompat.RatingBar.Indicator */
        public static final int f802Widget.AppCompat.RatingBar.Indicator = 2131886883;
        /* added by DevToolsApp */
        /* renamed from: Widget.AppCompat.RatingBar.Small */
        public static final int f803Widget.AppCompat.RatingBar.Small = 2131886884;
        /* added by DevToolsApp */
        /* renamed from: Widget.AppCompat.SearchView */
        public static final int f804Widget.AppCompat.SearchView = 2131886885;
        /* added by DevToolsApp */
        /* renamed from: Widget.AppCompat.SearchView.ActionBar */
        public static final int f805Widget.AppCompat.SearchView.ActionBar = 2131886886;
        /* added by DevToolsApp */
        /* renamed from: Widget.AppCompat.SeekBar */
        public static final int f806Widget.AppCompat.SeekBar = 2131886887;
        /* added by DevToolsApp */
        /* renamed from: Widget.AppCompat.SeekBar.Discrete */
        public static final int f807Widget.AppCompat.SeekBar.Discrete = 2131886888;
        /* added by DevToolsApp */
        /* renamed from: Widget.AppCompat.Spinner */
        public static final int f808Widget.AppCompat.Spinner = 2131886889;
        /* added by DevToolsApp */
        /* renamed from: Widget.AppCompat.Spinner.DropDown */
        public static final int f809Widget.AppCompat.Spinner.DropDown = 2131886890;
        /* added by DevToolsApp */
        /* renamed from: Widget.AppCompat.Spinner.DropDown.ActionBar */
        public static final int f810Widget.AppCompat.Spinner.DropDown.ActionBar = 2131886891;
        /* added by DevToolsApp */
        /* renamed from: Widget.AppCompat.Spinner.Underlined */
        public static final int f811Widget.AppCompat.Spinner.Underlined = 2131886892;
        /* added by DevToolsApp */
        /* renamed from: Widget.AppCompat.TextView */
        public static final int f812Widget.AppCompat.TextView = 2131886893;
        /* added by DevToolsApp */
        /* renamed from: Widget.AppCompat.TextView.SpinnerItem */
        public static final int f813Widget.AppCompat.TextView.SpinnerItem = 2131886894;
        /* added by DevToolsApp */
        /* renamed from: Widget.AppCompat.Toolbar */
        public static final int f814Widget.AppCompat.Toolbar = 2131886895;
        /* added by DevToolsApp */
        /* renamed from: Widget.AppCompat.Toolbar.Button.Navigation */
        public static final int f815Widget.AppCompat.Toolbar.Button.Navigation = 2131886896;
        /* added by DevToolsApp */
        /* renamed from: Widget.Compat.NotificationActionContainer */
        public static final int f816Widget.Compat.NotificationActionContainer = 2131886897;
        /* added by DevToolsApp */
        /* renamed from: Widget.Compat.NotificationActionText */
        public static final int f817Widget.Compat.NotificationActionText = 2131886898;
        /* added by DevToolsApp */
        /* renamed from: Widget.Design.AppBarLayout */
        public static final int f818Widget.Design.AppBarLayout = 2131886899;
        /* added by DevToolsApp */
        /* renamed from: Widget.Design.BottomNavigationView */
        public static final int f819Widget.Design.BottomNavigationView = 2131886900;
        /* added by DevToolsApp */
        /* renamed from: Widget.Design.BottomSheet.Modal */
        public static final int f820Widget.Design.BottomSheet.Modal = 2131886901;
        /* added by DevToolsApp */
        /* renamed from: Widget.Design.CollapsingToolbar */
        public static final int f821Widget.Design.CollapsingToolbar = 2131886902;
        /* added by DevToolsApp */
        /* renamed from: Widget.Design.FloatingActionButton */
        public static final int f822Widget.Design.FloatingActionButton = 2131886903;
        /* added by DevToolsApp */
        /* renamed from: Widget.Design.NavigationView */
        public static final int f823Widget.Design.NavigationView = 2131886904;
        /* added by DevToolsApp */
        /* renamed from: Widget.Design.ScrimInsetsFrameLayout */
        public static final int f824Widget.Design.ScrimInsetsFrameLayout = 2131886905;
        /* added by DevToolsApp */
        /* renamed from: Widget.Design.Snackbar */
        public static final int f825Widget.Design.Snackbar = 2131886906;
        /* added by DevToolsApp */
        /* renamed from: Widget.Design.TabLayout */
        public static final int f826Widget.Design.TabLayout = 2131886907;
        /* added by DevToolsApp */
        /* renamed from: Widget.Design.TextInputEditText */
        public static final int f827Widget.Design.TextInputEditText = 2131886908;
        /* added by DevToolsApp */
        /* renamed from: Widget.Design.TextInputLayout */
        public static final int f828Widget.Design.TextInputLayout = 2131886909;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.ActionBar.Solid */
        public static final int f829Widget.Material3.ActionBar.Solid = 2131886910;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.ActionMode */
        public static final int f830Widget.Material3.ActionMode = 2131886911;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.AppBarLayout */
        public static final int f831Widget.Material3.AppBarLayout = 2131886912;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.AutoCompleteTextView.FilledBox */
        public static final int f832Widget.Material3.AutoCompleteTextView.FilledBox = 2131886913;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.AutoCompleteTextView.FilledBox.Dense */
        public static final int f833Widget.Material3.AutoCompleteTextView.FilledBox.Dense = 2131886914;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.AutoCompleteTextView.OutlinedBox */
        public static final int f834Widget.Material3.AutoCompleteTextView.OutlinedBox = 2131886915;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.AutoCompleteTextView.OutlinedBox.Dense */
        public static final int f835Widget.Material3.AutoCompleteTextView.OutlinedBox.Dense = 2131886916;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.Badge */
        public static final int f836Widget.Material3.Badge = 2131886917;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.Badge.AdjustToBounds */
        public static final int f837Widget.Material3.Badge.AdjustToBounds = 2131886918;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.BottomAppBar */
        public static final int f838Widget.Material3.BottomAppBar = 2131886919;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.BottomAppBar.Button.Navigation */
        public static final int f839Widget.Material3.BottomAppBar.Button.Navigation = 2131886920;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.BottomAppBar.Legacy */
        public static final int f840Widget.Material3.BottomAppBar.Legacy = 2131886921;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.BottomNavigation.Badge */
        public static final int f841Widget.Material3.BottomNavigation.Badge = 2131886922;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.BottomNavigationView */
        public static final int f842Widget.Material3.BottomNavigationView = 2131886923;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.BottomNavigationView.ActiveIndicator */
        public static final int f843Widget.Material3.BottomNavigationView.ActiveIndicator = 2131886924;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.BottomSheet */
        public static final int f844Widget.Material3.BottomSheet = 2131886925;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.BottomSheet.DragHandle */
        public static final int f845Widget.Material3.BottomSheet.DragHandle = 2131886926;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.BottomSheet.Modal */
        public static final int f846Widget.Material3.BottomSheet.Modal = 2131886927;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.Button */
        public static final int f847Widget.Material3.Button = 2131886928;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.Button.ElevatedButton */
        public static final int f848Widget.Material3.Button.ElevatedButton = 2131886929;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.Button.ElevatedButton.Icon */
        public static final int f849Widget.Material3.Button.ElevatedButton.Icon = 2131886930;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.Button.Icon */
        public static final int f850Widget.Material3.Button.Icon = 2131886931;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.Button.IconButton */
        public static final int f851Widget.Material3.Button.IconButton = 2131886932;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.Button.IconButton.Filled */
        public static final int f852Widget.Material3.Button.IconButton.Filled = 2131886933;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.Button.IconButton.Filled.Tonal */
        public static final int f853Widget.Material3.Button.IconButton.Filled.Tonal = 2131886934;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.Button.IconButton.Outlined */
        public static final int f854Widget.Material3.Button.IconButton.Outlined = 2131886935;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.Button.OutlinedButton */
        public static final int f855Widget.Material3.Button.OutlinedButton = 2131886936;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.Button.OutlinedButton.Icon */
        public static final int f856Widget.Material3.Button.OutlinedButton.Icon = 2131886937;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.Button.TextButton */
        public static final int f857Widget.Material3.Button.TextButton = 2131886938;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.Button.TextButton.Dialog */
        public static final int f858Widget.Material3.Button.TextButton.Dialog = 2131886939;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.Button.TextButton.Dialog.Flush */
        public static final int f859Widget.Material3.Button.TextButton.Dialog.Flush = 2131886940;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.Button.TextButton.Dialog.Icon */
        public static final int f860Widget.Material3.Button.TextButton.Dialog.Icon = 2131886941;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.Button.TextButton.Icon */
        public static final int f861Widget.Material3.Button.TextButton.Icon = 2131886942;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.Button.TextButton.Snackbar */
        public static final int f862Widget.Material3.Button.TextButton.Snackbar = 2131886943;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.Button.TonalButton */
        public static final int f863Widget.Material3.Button.TonalButton = 2131886944;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.Button.TonalButton.Icon */
        public static final int f864Widget.Material3.Button.TonalButton.Icon = 2131886945;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.Button.UnelevatedButton */
        public static final int f865Widget.Material3.Button.UnelevatedButton = 2131886946;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.CardView.Elevated */
        public static final int f866Widget.Material3.CardView.Elevated = 2131886947;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.CardView.Filled */
        public static final int f867Widget.Material3.CardView.Filled = 2131886948;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.CardView.Outlined */
        public static final int f868Widget.Material3.CardView.Outlined = 2131886949;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.CheckedTextView */
        public static final int f869Widget.Material3.CheckedTextView = 2131886950;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.Chip.Assist */
        public static final int f870Widget.Material3.Chip.Assist = 2131886951;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.Chip.Assist.Elevated */
        public static final int f871Widget.Material3.Chip.Assist.Elevated = 2131886952;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.Chip.Filter */
        public static final int f872Widget.Material3.Chip.Filter = 2131886953;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.Chip.Filter.Elevated */
        public static final int f873Widget.Material3.Chip.Filter.Elevated = 2131886954;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.Chip.Input */
        public static final int f874Widget.Material3.Chip.Input = 2131886955;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.Chip.Input.Elevated */
        public static final int f875Widget.Material3.Chip.Input.Elevated = 2131886956;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.Chip.Input.Icon */
        public static final int f876Widget.Material3.Chip.Input.Icon = 2131886957;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.Chip.Input.Icon.Elevated */
        public static final int f877Widget.Material3.Chip.Input.Icon.Elevated = 2131886958;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.Chip.Suggestion */
        public static final int f878Widget.Material3.Chip.Suggestion = 2131886959;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.Chip.Suggestion.Elevated */
        public static final int f879Widget.Material3.Chip.Suggestion.Elevated = 2131886960;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.ChipGroup */
        public static final int f880Widget.Material3.ChipGroup = 2131886961;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.CircularProgressIndicator */
        public static final int f881Widget.Material3.CircularProgressIndicator = 2131886962;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.CircularProgressIndicator.ExtraSmall */
        public static final int f882Widget.Material3.CircularProgressIndicator.ExtraSmall = 2131886963;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.CircularProgressIndicator.Legacy */
        public static final int f883Widget.Material3.CircularProgressIndicator.Legacy = 2131886964;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.CircularProgressIndicator.Legacy.ExtraSmall */
        public static final int f884Widget.Material3.CircularProgressIndicator.Legacy.ExtraSmall = 2131886965;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.CircularProgressIndicator.Legacy.Medium */
        public static final int f885Widget.Material3.CircularProgressIndicator.Legacy.Medium = 2131886966;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.CircularProgressIndicator.Legacy.Small */
        public static final int f886Widget.Material3.CircularProgressIndicator.Legacy.Small = 2131886967;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.CircularProgressIndicator.Medium */
        public static final int f887Widget.Material3.CircularProgressIndicator.Medium = 2131886968;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.CircularProgressIndicator.Small */
        public static final int f888Widget.Material3.CircularProgressIndicator.Small = 2131886969;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.CollapsingToolbar */
        public static final int f889Widget.Material3.CollapsingToolbar = 2131886970;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.CollapsingToolbar.Large */
        public static final int f890Widget.Material3.CollapsingToolbar.Large = 2131886971;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.CollapsingToolbar.Medium */
        public static final int f891Widget.Material3.CollapsingToolbar.Medium = 2131886972;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.CompoundButton.CheckBox */
        public static final int f892Widget.Material3.CompoundButton.CheckBox = 2131886973;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.CompoundButton.MaterialSwitch */
        public static final int f893Widget.Material3.CompoundButton.MaterialSwitch = 2131886974;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.CompoundButton.RadioButton */
        public static final int f894Widget.Material3.CompoundButton.RadioButton = 2131886975;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.CompoundButton.Switch */
        public static final int f895Widget.Material3.CompoundButton.Switch = 2131886976;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.DrawerLayout */
        public static final int f896Widget.Material3.DrawerLayout = 2131886977;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.ExtendedFloatingActionButton.Icon.Primary */
        public static final int f897Widget.Material3.ExtendedFloatingActionButton.Icon.Primary = 2131886978;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.ExtendedFloatingActionButton.Icon.Secondary */
        public static final int f898Widget.Material3.ExtendedFloatingActionButton.Icon.Secondary = 2131886979;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.ExtendedFloatingActionButton.Icon.Surface */
        public static final int f899Widget.Material3.ExtendedFloatingActionButton.Icon.Surface = 2131886980;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.ExtendedFloatingActionButton.Icon.Tertiary */
        public static final int f900Widget.Material3.ExtendedFloatingActionButton.Icon.Tertiary = 2131886981;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.ExtendedFloatingActionButton.Primary */
        public static final int f901Widget.Material3.ExtendedFloatingActionButton.Primary = 2131886982;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.ExtendedFloatingActionButton.Secondary */
        public static final int f902Widget.Material3.ExtendedFloatingActionButton.Secondary = 2131886983;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.ExtendedFloatingActionButton.Surface */
        public static final int f903Widget.Material3.ExtendedFloatingActionButton.Surface = 2131886984;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.ExtendedFloatingActionButton.Tertiary */
        public static final int f904Widget.Material3.ExtendedFloatingActionButton.Tertiary = 2131886985;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.FloatingActionButton.Large.Primary */
        public static final int f905Widget.Material3.FloatingActionButton.Large.Primary = 2131886986;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.FloatingActionButton.Large.Secondary */
        public static final int f906Widget.Material3.FloatingActionButton.Large.Secondary = 2131886987;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.FloatingActionButton.Large.Surface */
        public static final int f907Widget.Material3.FloatingActionButton.Large.Surface = 2131886988;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.FloatingActionButton.Large.Tertiary */
        public static final int f908Widget.Material3.FloatingActionButton.Large.Tertiary = 2131886989;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.FloatingActionButton.Primary */
        public static final int f909Widget.Material3.FloatingActionButton.Primary = 2131886990;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.FloatingActionButton.Secondary */
        public static final int f910Widget.Material3.FloatingActionButton.Secondary = 2131886991;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.FloatingActionButton.Small.Primary */
        public static final int f911Widget.Material3.FloatingActionButton.Small.Primary = 2131886992;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.FloatingActionButton.Small.Secondary */
        public static final int f912Widget.Material3.FloatingActionButton.Small.Secondary = 2131886993;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.FloatingActionButton.Small.Surface */
        public static final int f913Widget.Material3.FloatingActionButton.Small.Surface = 2131886994;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.FloatingActionButton.Small.Tertiary */
        public static final int f914Widget.Material3.FloatingActionButton.Small.Tertiary = 2131886995;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.FloatingActionButton.Surface */
        public static final int f915Widget.Material3.FloatingActionButton.Surface = 2131886996;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.FloatingActionButton.Tertiary */
        public static final int f916Widget.Material3.FloatingActionButton.Tertiary = 2131886997;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.Light.ActionBar.Solid */
        public static final int f917Widget.Material3.Light.ActionBar.Solid = 2131886998;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.LinearProgressIndicator */
        public static final int f918Widget.Material3.LinearProgressIndicator = 2131886999;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.LinearProgressIndicator.Legacy */
        public static final int f919Widget.Material3.LinearProgressIndicator.Legacy = 2131887000;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.MaterialButtonToggleGroup */
        public static final int f920Widget.Material3.MaterialButtonToggleGroup = 2131887001;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.MaterialCalendar */
        public static final int f921Widget.Material3.MaterialCalendar = 2131887002;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.MaterialCalendar.Day */
        public static final int f922Widget.Material3.MaterialCalendar.Day = 2131887003;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.MaterialCalendar.Day.Invalid */
        public static final int f923Widget.Material3.MaterialCalendar.Day.Invalid = 2131887004;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.MaterialCalendar.Day.Selected */
        public static final int f924Widget.Material3.MaterialCalendar.Day.Selected = 2131887005;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.MaterialCalendar.Day.Today */
        public static final int f925Widget.Material3.MaterialCalendar.Day.Today = 2131887006;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.MaterialCalendar.DayOfWeekLabel */
        public static final int f926Widget.Material3.MaterialCalendar.DayOfWeekLabel = 2131887007;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.MaterialCalendar.DayTextView */
        public static final int f927Widget.Material3.MaterialCalendar.DayTextView = 2131887008;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.MaterialCalendar.Fullscreen */
        public static final int f928Widget.Material3.MaterialCalendar.Fullscreen = 2131887009;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.MaterialCalendar.HeaderCancelButton */
        public static final int f929Widget.Material3.MaterialCalendar.HeaderCancelButton = 2131887010;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.MaterialCalendar.HeaderDivider */
        public static final int f930Widget.Material3.MaterialCalendar.HeaderDivider = 2131887011;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.MaterialCalendar.HeaderLayout */
        public static final int f931Widget.Material3.MaterialCalendar.HeaderLayout = 2131887012;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.MaterialCalendar.HeaderLayout.Fullscreen */
        public static final int f932Widget.Material3.MaterialCalendar.HeaderLayout.Fullscreen = 2131887013;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.MaterialCalendar.HeaderSelection */
        public static final int f933Widget.Material3.MaterialCalendar.HeaderSelection = 2131887014;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.MaterialCalendar.HeaderSelection.Fullscreen */
        public static final int f934Widget.Material3.MaterialCalendar.HeaderSelection.Fullscreen = 2131887015;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.MaterialCalendar.HeaderTitle */
        public static final int f935Widget.Material3.MaterialCalendar.HeaderTitle = 2131887016;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.MaterialCalendar.HeaderToggleButton */
        public static final int f936Widget.Material3.MaterialCalendar.HeaderToggleButton = 2131887017;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.MaterialCalendar.Item */
        public static final int f937Widget.Material3.MaterialCalendar.Item = 2131887018;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.MaterialCalendar.MonthNavigationButton */
        public static final int f938Widget.Material3.MaterialCalendar.MonthNavigationButton = 2131887019;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.MaterialCalendar.MonthTextView */
        public static final int f939Widget.Material3.MaterialCalendar.MonthTextView = 2131887020;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.MaterialCalendar.Year */
        public static final int f940Widget.Material3.MaterialCalendar.Year = 2131887021;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.MaterialCalendar.Year.Selected */
        public static final int f941Widget.Material3.MaterialCalendar.Year.Selected = 2131887022;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.MaterialCalendar.Year.Today */
        public static final int f942Widget.Material3.MaterialCalendar.Year.Today = 2131887023;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.MaterialCalendar.YearNavigationButton */
        public static final int f943Widget.Material3.MaterialCalendar.YearNavigationButton = 2131887024;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.MaterialDivider */
        public static final int f944Widget.Material3.MaterialDivider = 2131887025;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.MaterialDivider.Heavy */
        public static final int f945Widget.Material3.MaterialDivider.Heavy = 2131887026;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.MaterialTimePicker */
        public static final int f946Widget.Material3.MaterialTimePicker = 2131887027;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.MaterialTimePicker.Button */
        public static final int f947Widget.Material3.MaterialTimePicker.Button = 2131887028;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.MaterialTimePicker.Clock */
        public static final int f948Widget.Material3.MaterialTimePicker.Clock = 2131887029;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.MaterialTimePicker.Display */
        public static final int f949Widget.Material3.MaterialTimePicker.Display = 2131887030;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.MaterialTimePicker.Display.Divider */
        public static final int f950Widget.Material3.MaterialTimePicker.Display.Divider = 2131887031;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.MaterialTimePicker.Display.HelperText */
        public static final int f951Widget.Material3.MaterialTimePicker.Display.HelperText = 2131887032;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.MaterialTimePicker.Display.TextInputEditText */
        public static final int f952Widget.Material3.MaterialTimePicker.Display.TextInputEditText = 2131887033;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.MaterialTimePicker.Display.TextInputLayout */
        public static final int f953Widget.Material3.MaterialTimePicker.Display.TextInputLayout = 2131887034;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.MaterialTimePicker.ImageButton */
        public static final int f954Widget.Material3.MaterialTimePicker.ImageButton = 2131887035;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.NavigationRailView */
        public static final int f955Widget.Material3.NavigationRailView = 2131887036;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.NavigationRailView.ActiveIndicator */
        public static final int f956Widget.Material3.NavigationRailView.ActiveIndicator = 2131887037;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.NavigationRailView.Badge */
        public static final int f957Widget.Material3.NavigationRailView.Badge = 2131887038;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.NavigationView */
        public static final int f958Widget.Material3.NavigationView = 2131887039;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.PopupMenu */
        public static final int f959Widget.Material3.PopupMenu = 2131887040;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.PopupMenu.ContextMenu */
        public static final int f960Widget.Material3.PopupMenu.ContextMenu = 2131887041;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.PopupMenu.ListPopupWindow */
        public static final int f961Widget.Material3.PopupMenu.ListPopupWindow = 2131887042;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.PopupMenu.Overflow */
        public static final int f962Widget.Material3.PopupMenu.Overflow = 2131887043;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.Search.ActionButton.Overflow */
        public static final int f963Widget.Material3.Search.ActionButton.Overflow = 2131887044;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.Search.Toolbar.Button.Navigation */
        public static final int f964Widget.Material3.Search.Toolbar.Button.Navigation = 2131887045;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.SearchBar */
        public static final int f965Widget.Material3.SearchBar = 2131887046;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.SearchBar.Outlined */
        public static final int f966Widget.Material3.SearchBar.Outlined = 2131887047;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.SearchView */
        public static final int f967Widget.Material3.SearchView = 2131887048;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.SearchView.Prefix */
        public static final int f968Widget.Material3.SearchView.Prefix = 2131887049;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.SearchView.Toolbar */
        public static final int f969Widget.Material3.SearchView.Toolbar = 2131887050;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.SideSheet */
        public static final int f970Widget.Material3.SideSheet = 2131887051;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.SideSheet.Detached */
        public static final int f971Widget.Material3.SideSheet.Detached = 2131887052;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.SideSheet.Modal */
        public static final int f972Widget.Material3.SideSheet.Modal = 2131887053;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.SideSheet.Modal.Detached */
        public static final int f973Widget.Material3.SideSheet.Modal.Detached = 2131887054;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.Slider */
        public static final int f974Widget.Material3.Slider = 2131887055;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.Slider.Label */
        public static final int f975Widget.Material3.Slider.Label = 2131887056;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.Slider.Legacy */
        public static final int f976Widget.Material3.Slider.Legacy = 2131887057;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.Slider.Legacy.Label */
        public static final int f977Widget.Material3.Slider.Legacy.Label = 2131887058;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.Snackbar */
        public static final int f978Widget.Material3.Snackbar = 2131887059;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.Snackbar.FullWidth */
        public static final int f979Widget.Material3.Snackbar.FullWidth = 2131887060;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.Snackbar.TextView */
        public static final int f980Widget.Material3.Snackbar.TextView = 2131887061;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.TabLayout */
        public static final int f981Widget.Material3.TabLayout = 2131887062;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.TabLayout.OnSurface */
        public static final int f982Widget.Material3.TabLayout.OnSurface = 2131887063;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.TabLayout.Secondary */
        public static final int f983Widget.Material3.TabLayout.Secondary = 2131887064;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.TextInputEditText.FilledBox */
        public static final int f984Widget.Material3.TextInputEditText.FilledBox = 2131887065;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.TextInputEditText.FilledBox.Dense */
        public static final int f985Widget.Material3.TextInputEditText.FilledBox.Dense = 2131887066;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.TextInputEditText.OutlinedBox */
        public static final int f986Widget.Material3.TextInputEditText.OutlinedBox = 2131887067;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.TextInputEditText.OutlinedBox.Dense */
        public static final int f987Widget.Material3.TextInputEditText.OutlinedBox.Dense = 2131887068;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.TextInputLayout.FilledBox */
        public static final int f988Widget.Material3.TextInputLayout.FilledBox = 2131887069;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.TextInputLayout.FilledBox.Dense */
        public static final int f989Widget.Material3.TextInputLayout.FilledBox.Dense = 2131887070;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.TextInputLayout.FilledBox.Dense.ExposedDropdownMenu */
        public static final int f990Widget.Material3.TextInputLayout.FilledBox.Dense.ExposedDropdownMenu = 2131887071;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.TextInputLayout.FilledBox.ExposedDropdownMenu */
        public static final int f991Widget.Material3.TextInputLayout.FilledBox.ExposedDropdownMenu = 2131887072;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.TextInputLayout.OutlinedBox */
        public static final int f992Widget.Material3.TextInputLayout.OutlinedBox = 2131887073;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.TextInputLayout.OutlinedBox.Dense */
        public static final int f993Widget.Material3.TextInputLayout.OutlinedBox.Dense = 2131887074;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.TextInputLayout.OutlinedBox.Dense.ExposedDropdownMenu */
        public static final int f994Widget.Material3.TextInputLayout.OutlinedBox.Dense.ExposedDropdownMenu = 2131887075;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.TextInputLayout.OutlinedBox.ExposedDropdownMenu */
        public static final int f995Widget.Material3.TextInputLayout.OutlinedBox.ExposedDropdownMenu = 2131887076;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.Toolbar */
        public static final int f996Widget.Material3.Toolbar = 2131887077;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.Toolbar.OnSurface */
        public static final int f997Widget.Material3.Toolbar.OnSurface = 2131887078;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.Toolbar.Surface */
        public static final int f998Widget.Material3.Toolbar.Surface = 2131887079;
        /* added by DevToolsApp */
        /* renamed from: Widget.Material3.Tooltip */
        public static final int f999Widget.Material3.Tooltip = 2131887080;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.ActionBar.Primary */
        public static final int f1000Widget.MaterialComponents.ActionBar.Primary = 2131887081;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.ActionBar.PrimarySurface */
        public static final int f1001Widget.MaterialComponents.ActionBar.PrimarySurface = 2131887082;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.ActionBar.Solid */
        public static final int f1002Widget.MaterialComponents.ActionBar.Solid = 2131887083;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.ActionBar.Surface */
        public static final int f1003Widget.MaterialComponents.ActionBar.Surface = 2131887084;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.ActionMode */
        public static final int f1004Widget.MaterialComponents.ActionMode = 2131887085;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.AppBarLayout.Primary */
        public static final int f1005Widget.MaterialComponents.AppBarLayout.Primary = 2131887086;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.AppBarLayout.PrimarySurface */
        public static final int f1006Widget.MaterialComponents.AppBarLayout.PrimarySurface = 2131887087;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.AppBarLayout.Surface */
        public static final int f1007Widget.MaterialComponents.AppBarLayout.Surface = 2131887088;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.AutoCompleteTextView.FilledBox */
        public static final int f1008Widget.MaterialComponents.AutoCompleteTextView.FilledBox = 2131887089;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.AutoCompleteTextView.FilledBox.Dense */
        public static final int f1009Widget.MaterialComponents.AutoCompleteTextView.FilledBox.Dense = 2131887090;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.AutoCompleteTextView.OutlinedBox */
        public static final int f1010Widget.MaterialComponents.AutoCompleteTextView.OutlinedBox = 2131887091;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.AutoCompleteTextView.OutlinedBox.Dense */
        public static final int f1011Widget.MaterialComponents.AutoCompleteTextView.OutlinedBox.Dense = 2131887092;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.Badge */
        public static final int f1012Widget.MaterialComponents.Badge = 2131887093;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.BottomAppBar */
        public static final int f1013Widget.MaterialComponents.BottomAppBar = 2131887094;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.BottomAppBar.Colored */
        public static final int f1014Widget.MaterialComponents.BottomAppBar.Colored = 2131887095;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.BottomAppBar.PrimarySurface */
        public static final int f1015Widget.MaterialComponents.BottomAppBar.PrimarySurface = 2131887096;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.BottomNavigationView */
        public static final int f1016Widget.MaterialComponents.BottomNavigationView = 2131887097;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.BottomNavigationView.Colored */
        public static final int f1017Widget.MaterialComponents.BottomNavigationView.Colored = 2131887098;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.BottomNavigationView.PrimarySurface */
        public static final int f1018Widget.MaterialComponents.BottomNavigationView.PrimarySurface = 2131887099;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.BottomSheet */
        public static final int f1019Widget.MaterialComponents.BottomSheet = 2131887100;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.BottomSheet.Modal */
        public static final int f1020Widget.MaterialComponents.BottomSheet.Modal = 2131887101;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.Button */
        public static final int f1021Widget.MaterialComponents.Button = 2131887102;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.Button.Icon */
        public static final int f1022Widget.MaterialComponents.Button.Icon = 2131887103;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.Button.OutlinedButton */
        public static final int f1023Widget.MaterialComponents.Button.OutlinedButton = 2131887104;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.Button.OutlinedButton.Icon */
        public static final int f1024Widget.MaterialComponents.Button.OutlinedButton.Icon = 2131887105;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.Button.TextButton */
        public static final int f1025Widget.MaterialComponents.Button.TextButton = 2131887106;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.Button.TextButton.Dialog */
        public static final int f1026Widget.MaterialComponents.Button.TextButton.Dialog = 2131887107;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.Button.TextButton.Dialog.Flush */
        public static final int f1027Widget.MaterialComponents.Button.TextButton.Dialog.Flush = 2131887108;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.Button.TextButton.Dialog.Icon */
        public static final int f1028Widget.MaterialComponents.Button.TextButton.Dialog.Icon = 2131887109;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.Button.TextButton.Icon */
        public static final int f1029Widget.MaterialComponents.Button.TextButton.Icon = 2131887110;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.Button.TextButton.Snackbar */
        public static final int f1030Widget.MaterialComponents.Button.TextButton.Snackbar = 2131887111;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.Button.UnelevatedButton */
        public static final int f1031Widget.MaterialComponents.Button.UnelevatedButton = 2131887112;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.Button.UnelevatedButton.Icon */
        public static final int f1032Widget.MaterialComponents.Button.UnelevatedButton.Icon = 2131887113;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.CardView */
        public static final int f1033Widget.MaterialComponents.CardView = 2131887114;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.CheckedTextView */
        public static final int f1034Widget.MaterialComponents.CheckedTextView = 2131887115;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.Chip.Action */
        public static final int f1035Widget.MaterialComponents.Chip.Action = 2131887116;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.Chip.Choice */
        public static final int f1036Widget.MaterialComponents.Chip.Choice = 2131887117;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.Chip.Entry */
        public static final int f1037Widget.MaterialComponents.Chip.Entry = 2131887118;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.Chip.Filter */
        public static final int f1038Widget.MaterialComponents.Chip.Filter = 2131887119;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.ChipGroup */
        public static final int f1039Widget.MaterialComponents.ChipGroup = 2131887120;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.CircularProgressIndicator */
        public static final int f1040Widget.MaterialComponents.CircularProgressIndicator = 2131887121;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.CircularProgressIndicator.ExtraSmall */
        public static final int f1041Widget.MaterialComponents.CircularProgressIndicator.ExtraSmall = 2131887122;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.CircularProgressIndicator.Medium */
        public static final int f1042Widget.MaterialComponents.CircularProgressIndicator.Medium = 2131887123;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.CircularProgressIndicator.Small */
        public static final int f1043Widget.MaterialComponents.CircularProgressIndicator.Small = 2131887124;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.CollapsingToolbar */
        public static final int f1044Widget.MaterialComponents.CollapsingToolbar = 2131887125;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.CompoundButton.CheckBox */
        public static final int f1045Widget.MaterialComponents.CompoundButton.CheckBox = 2131887126;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.CompoundButton.RadioButton */
        public static final int f1046Widget.MaterialComponents.CompoundButton.RadioButton = 2131887127;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.CompoundButton.Switch */
        public static final int f1047Widget.MaterialComponents.CompoundButton.Switch = 2131887128;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.ExtendedFloatingActionButton */
        public static final int f1048Widget.MaterialComponents.ExtendedFloatingActionButton = 2131887129;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.ExtendedFloatingActionButton.Icon */
        public static final int f1049Widget.MaterialComponents.ExtendedFloatingActionButton.Icon = 2131887130;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.FloatingActionButton */
        public static final int f1050Widget.MaterialComponents.FloatingActionButton = 2131887131;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.Light.ActionBar.Solid */
        public static final int f1051Widget.MaterialComponents.Light.ActionBar.Solid = 2131887132;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.LinearProgressIndicator */
        public static final int f1052Widget.MaterialComponents.LinearProgressIndicator = 2131887133;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.MaterialButtonToggleGroup */
        public static final int f1053Widget.MaterialComponents.MaterialButtonToggleGroup = 2131887134;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.MaterialCalendar */
        public static final int f1054Widget.MaterialComponents.MaterialCalendar = 2131887135;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.MaterialCalendar.Day */
        public static final int f1055Widget.MaterialComponents.MaterialCalendar.Day = 2131887136;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.MaterialCalendar.Day.Invalid */
        public static final int f1056Widget.MaterialComponents.MaterialCalendar.Day.Invalid = 2131887137;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.MaterialCalendar.Day.Selected */
        public static final int f1057Widget.MaterialComponents.MaterialCalendar.Day.Selected = 2131887138;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.MaterialCalendar.Day.Today */
        public static final int f1058Widget.MaterialComponents.MaterialCalendar.Day.Today = 2131887139;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.MaterialCalendar.DayOfWeekLabel */
        public static final int f1059Widget.MaterialComponents.MaterialCalendar.DayOfWeekLabel = 2131887140;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.MaterialCalendar.DayTextView */
        public static final int f1060Widget.MaterialComponents.MaterialCalendar.DayTextView = 2131887141;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.MaterialCalendar.Fullscreen */
        public static final int f1061Widget.MaterialComponents.MaterialCalendar.Fullscreen = 2131887142;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.MaterialCalendar.HeaderCancelButton */
        public static final int f1062Widget.MaterialComponents.MaterialCalendar.HeaderCancelButton = 2131887143;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.MaterialCalendar.HeaderConfirmButton */
        public static final int f1063Widget.MaterialComponents.MaterialCalendar.HeaderConfirmButton = 2131887144;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.MaterialCalendar.HeaderDivider */
        public static final int f1064Widget.MaterialComponents.MaterialCalendar.HeaderDivider = 2131887145;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.MaterialCalendar.HeaderLayout */
        public static final int f1065Widget.MaterialComponents.MaterialCalendar.HeaderLayout = 2131887146;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.MaterialCalendar.HeaderLayout.Fullscreen */
        public static final int f1066Widget.MaterialComponents.MaterialCalendar.HeaderLayout.Fullscreen = 2131887147;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.MaterialCalendar.HeaderSelection */
        public static final int f1067Widget.MaterialComponents.MaterialCalendar.HeaderSelection = 2131887148;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.MaterialCalendar.HeaderSelection.Fullscreen */
        public static final int f1068Widget.MaterialComponents.MaterialCalendar.HeaderSelection.Fullscreen = 2131887149;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.MaterialCalendar.HeaderTitle */
        public static final int f1069Widget.MaterialComponents.MaterialCalendar.HeaderTitle = 2131887150;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.MaterialCalendar.HeaderToggleButton */
        public static final int f1070Widget.MaterialComponents.MaterialCalendar.HeaderToggleButton = 2131887151;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.MaterialCalendar.Item */
        public static final int f1071Widget.MaterialComponents.MaterialCalendar.Item = 2131887152;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.MaterialCalendar.MonthNavigationButton */
        public static final int f1072Widget.MaterialComponents.MaterialCalendar.MonthNavigationButton = 2131887153;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.MaterialCalendar.MonthTextView */
        public static final int f1073Widget.MaterialComponents.MaterialCalendar.MonthTextView = 2131887154;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.MaterialCalendar.Year */
        public static final int f1074Widget.MaterialComponents.MaterialCalendar.Year = 2131887155;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.MaterialCalendar.Year.Selected */
        public static final int f1075Widget.MaterialComponents.MaterialCalendar.Year.Selected = 2131887156;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.MaterialCalendar.Year.Today */
        public static final int f1076Widget.MaterialComponents.MaterialCalendar.Year.Today = 2131887157;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.MaterialCalendar.YearNavigationButton */
        public static final int f1077Widget.MaterialComponents.MaterialCalendar.YearNavigationButton = 2131887158;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.MaterialDivider */
        public static final int f1078Widget.MaterialComponents.MaterialDivider = 2131887159;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.NavigationRailView */
        public static final int f1079Widget.MaterialComponents.NavigationRailView = 2131887160;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.NavigationRailView.Colored */
        public static final int f1080Widget.MaterialComponents.NavigationRailView.Colored = 2131887161;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.NavigationRailView.Colored.Compact */
        public static final int f1081Widget.MaterialComponents.NavigationRailView.Colored.Compact = 2131887162;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.NavigationRailView.Compact */
        public static final int f1082Widget.MaterialComponents.NavigationRailView.Compact = 2131887163;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.NavigationRailView.PrimarySurface */
        public static final int f1083Widget.MaterialComponents.NavigationRailView.PrimarySurface = 2131887164;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.NavigationView */
        public static final int f1084Widget.MaterialComponents.NavigationView = 2131887165;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.PopupMenu */
        public static final int f1085Widget.MaterialComponents.PopupMenu = 2131887166;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.PopupMenu.ContextMenu */
        public static final int f1086Widget.MaterialComponents.PopupMenu.ContextMenu = 2131887167;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.PopupMenu.ListPopupWindow */
        public static final int f1087Widget.MaterialComponents.PopupMenu.ListPopupWindow = 2131887168;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.PopupMenu.Overflow */
        public static final int f1088Widget.MaterialComponents.PopupMenu.Overflow = 2131887169;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.ProgressIndicator */
        public static final int f1089Widget.MaterialComponents.ProgressIndicator = 2131887170;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.ShapeableImageView */
        public static final int f1090Widget.MaterialComponents.ShapeableImageView = 2131887171;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.Slider */
        public static final int f1091Widget.MaterialComponents.Slider = 2131887172;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.Snackbar */
        public static final int f1092Widget.MaterialComponents.Snackbar = 2131887173;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.Snackbar.FullWidth */
        public static final int f1093Widget.MaterialComponents.Snackbar.FullWidth = 2131887174;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.Snackbar.TextView */
        public static final int f1094Widget.MaterialComponents.Snackbar.TextView = 2131887175;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.TabLayout */
        public static final int f1095Widget.MaterialComponents.TabLayout = 2131887176;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.TabLayout.Colored */
        public static final int f1096Widget.MaterialComponents.TabLayout.Colored = 2131887177;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.TabLayout.PrimarySurface */
        public static final int f1097Widget.MaterialComponents.TabLayout.PrimarySurface = 2131887178;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.TextInputEditText.FilledBox */
        public static final int f1098Widget.MaterialComponents.TextInputEditText.FilledBox = 2131887179;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.TextInputEditText.FilledBox.Dense */
        public static final int f1099Widget.MaterialComponents.TextInputEditText.FilledBox.Dense = 2131887180;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.TextInputEditText.OutlinedBox */
        public static final int f1100Widget.MaterialComponents.TextInputEditText.OutlinedBox = 2131887181;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.TextInputEditText.OutlinedBox.Dense */
        public static final int f1101Widget.MaterialComponents.TextInputEditText.OutlinedBox.Dense = 2131887182;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.TextInputLayout.FilledBox */
        public static final int f1102Widget.MaterialComponents.TextInputLayout.FilledBox = 2131887183;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.TextInputLayout.FilledBox.Dense */
        public static final int f1103Widget.MaterialComponents.TextInputLayout.FilledBox.Dense = 2131887184;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.TextInputLayout.FilledBox.Dense.ExposedDropdownMenu */
        public static final int f1104Widget.MaterialComponents.TextInputLayout.FilledBox.Dense.ExposedDropdownMenu = 2131887185;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.TextInputLayout.FilledBox.ExposedDropdownMenu */
        public static final int f1105Widget.MaterialComponents.TextInputLayout.FilledBox.ExposedDropdownMenu = 2131887186;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.TextInputLayout.OutlinedBox */
        public static final int f1106Widget.MaterialComponents.TextInputLayout.OutlinedBox = 2131887187;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.TextInputLayout.OutlinedBox.Dense */
        public static final int f1107Widget.MaterialComponents.TextInputLayout.OutlinedBox.Dense = 2131887188;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.TextInputLayout.OutlinedBox.Dense.ExposedDropdownMenu */
        public static final int f1108Widget.MaterialComponents.TextInputLayout.OutlinedBox.Dense.ExposedDropdownMenu = 2131887189;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.TextInputLayout.OutlinedBox.ExposedDropdownMenu */
        public static final int f1109Widget.MaterialComponents.TextInputLayout.OutlinedBox.ExposedDropdownMenu = 2131887190;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.TextView */
        public static final int f1110Widget.MaterialComponents.TextView = 2131887191;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.TimePicker */
        public static final int f1111Widget.MaterialComponents.TimePicker = 2131887192;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.TimePicker.Button */
        public static final int f1112Widget.MaterialComponents.TimePicker.Button = 2131887193;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.TimePicker.Clock */
        public static final int f1113Widget.MaterialComponents.TimePicker.Clock = 2131887194;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.TimePicker.Display */
        public static final int f1114Widget.MaterialComponents.TimePicker.Display = 2131887195;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.TimePicker.Display.Divider */
        public static final int f1115Widget.MaterialComponents.TimePicker.Display.Divider = 2131887196;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.TimePicker.Display.HelperText */
        public static final int f1116Widget.MaterialComponents.TimePicker.Display.HelperText = 2131887197;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.TimePicker.Display.TextInputEditText */
        public static final int f1117Widget.MaterialComponents.TimePicker.Display.TextInputEditText = 2131887198;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.TimePicker.Display.TextInputLayout */
        public static final int f1118Widget.MaterialComponents.TimePicker.Display.TextInputLayout = 2131887199;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.TimePicker.ImageButton */
        public static final int f1119Widget.MaterialComponents.TimePicker.ImageButton = 2131887200;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.TimePicker.ImageButton.ShapeAppearance */
        public static final int f1120Widget.MaterialComponents.TimePicker.ImageButton.ShapeAppearance = 2131887201;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.Toolbar */
        public static final int f1121Widget.MaterialComponents.Toolbar = 2131887202;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.Toolbar.Primary */
        public static final int f1122Widget.MaterialComponents.Toolbar.Primary = 2131887203;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.Toolbar.PrimarySurface */
        public static final int f1123Widget.MaterialComponents.Toolbar.PrimarySurface = 2131887204;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.Toolbar.Surface */
        public static final int f1124Widget.MaterialComponents.Toolbar.Surface = 2131887205;
        /* added by DevToolsApp */
        /* renamed from: Widget.MaterialComponents.Tooltip */
        public static final int f1125Widget.MaterialComponents.Tooltip = 2131887206;
        /* added by DevToolsApp */
        /* renamed from: Widget.Support.CoordinatorLayout */
        public static final int f1126Widget.Support.CoordinatorLayout = 2131887207;

        private style() {
        }
    }

    public static final class xml {
        public static int backup_rules = 2132017152;
        public static int data_extraction_rules = 2132017153;

        private xml() {
        }
    }

    /* added by DevToolsApp */
    public static final class anim {
        /* added by DevToolsApp */
        public static final int abc_fade_in = 2130771968;
        /* added by DevToolsApp */
        public static final int abc_fade_out = 2130771969;
        /* added by DevToolsApp */
        public static final int abc_grow_fade_in_from_bottom = 2130771970;
        /* added by DevToolsApp */
        public static final int abc_popup_enter = 2130771971;
        /* added by DevToolsApp */
        public static final int abc_popup_exit = 2130771972;
        /* added by DevToolsApp */
        public static final int abc_shrink_fade_out_from_bottom = 2130771973;
        /* added by DevToolsApp */
        public static final int abc_slide_in_bottom = 2130771974;
        /* added by DevToolsApp */
        public static final int abc_slide_in_top = 2130771975;
        /* added by DevToolsApp */
        public static final int abc_slide_out_bottom = 2130771976;
        /* added by DevToolsApp */
        public static final int abc_slide_out_top = 2130771977;
        /* added by DevToolsApp */
        public static final int abc_tooltip_enter = 2130771978;
        /* added by DevToolsApp */
        public static final int abc_tooltip_exit = 2130771979;
        /* added by DevToolsApp */
        public static final int btn_checkbox_to_checked_box_inner_merged_animation = 2130771980;
        /* added by DevToolsApp */
        public static final int btn_checkbox_to_checked_box_outer_merged_animation = 2130771981;
        /* added by DevToolsApp */
        public static final int btn_checkbox_to_checked_icon_null_animation = 2130771982;
        /* added by DevToolsApp */
        public static final int btn_checkbox_to_unchecked_box_inner_merged_animation = 2130771983;
        /* added by DevToolsApp */
        public static final int btn_checkbox_to_unchecked_check_path_merged_animation = 2130771984;
        /* added by DevToolsApp */
        public static final int btn_checkbox_to_unchecked_icon_null_animation = 2130771985;
        /* added by DevToolsApp */
        public static final int btn_radio_to_off_mtrl_dot_group_animation = 2130771986;
        /* added by DevToolsApp */
        public static final int btn_radio_to_off_mtrl_ring_outer_animation = 2130771987;
        /* added by DevToolsApp */
        public static final int btn_radio_to_off_mtrl_ring_outer_path_animation = 2130771988;
        /* added by DevToolsApp */
        public static final int btn_radio_to_on_mtrl_dot_group_animation = 2130771989;
        /* added by DevToolsApp */
        public static final int btn_radio_to_on_mtrl_ring_outer_animation = 2130771990;
        /* added by DevToolsApp */
        public static final int btn_radio_to_on_mtrl_ring_outer_path_animation = 2130771991;
        /* added by DevToolsApp */
        public static final int design_bottom_sheet_slide_in = 2130771992;
        /* added by DevToolsApp */
        public static final int design_bottom_sheet_slide_out = 2130771993;
        /* added by DevToolsApp */
        public static final int design_snackbar_in = 2130771994;
        /* added by DevToolsApp */
        public static final int design_snackbar_out = 2130771995;
        /* added by DevToolsApp */
        public static final int fragment_fast_out_extra_slow_in = 2130771996;
        /* added by DevToolsApp */
        public static final int linear_indeterminate_line1_head_interpolator = 2130771997;
        /* added by DevToolsApp */
        public static final int linear_indeterminate_line1_tail_interpolator = 2130771998;
        /* added by DevToolsApp */
        public static final int linear_indeterminate_line2_head_interpolator = 2130771999;
        /* added by DevToolsApp */
        public static final int linear_indeterminate_line2_tail_interpolator = 2130772000;
        /* added by DevToolsApp */
        public static final int m3_bottom_sheet_slide_in = 2130772001;
        /* added by DevToolsApp */
        public static final int m3_bottom_sheet_slide_out = 2130772002;
        /* added by DevToolsApp */
        public static final int m3_motion_fade_enter = 2130772003;
        /* added by DevToolsApp */
        public static final int m3_motion_fade_exit = 2130772004;
        /* added by DevToolsApp */
        public static final int m3_side_sheet_enter_from_left = 2130772005;
        /* added by DevToolsApp */
        public static final int m3_side_sheet_enter_from_right = 2130772006;
        /* added by DevToolsApp */
        public static final int m3_side_sheet_exit_to_left = 2130772007;
        /* added by DevToolsApp */
        public static final int m3_side_sheet_exit_to_right = 2130772008;
        /* added by DevToolsApp */
        public static final int mtrl_bottom_sheet_slide_in = 2130772009;
        /* added by DevToolsApp */
        public static final int mtrl_bottom_sheet_slide_out = 2130772010;
        /* added by DevToolsApp */
        public static final int mtrl_card_lowers_interpolator = 2130772011;
    }

    /* added by DevToolsApp */
    public static final class animator {
        /* added by DevToolsApp */
        public static final int design_appbar_state_list_animator = 2130837504;
        /* added by DevToolsApp */
        public static final int design_fab_hide_motion_spec = 2130837505;
        /* added by DevToolsApp */
        public static final int design_fab_show_motion_spec = 2130837506;
        /* added by DevToolsApp */
        public static final int fragment_close_enter = 2130837507;
        /* added by DevToolsApp */
        public static final int fragment_close_exit = 2130837508;
        /* added by DevToolsApp */
        public static final int fragment_fade_enter = 2130837509;
        /* added by DevToolsApp */
        public static final int fragment_fade_exit = 2130837510;
        /* added by DevToolsApp */
        public static final int fragment_open_enter = 2130837511;
        /* added by DevToolsApp */
        public static final int fragment_open_exit = 2130837512;
        /* added by DevToolsApp */
        public static final int m3_appbar_state_list_animator = 2130837513;
        /* added by DevToolsApp */
        public static final int m3_btn_elevated_btn_state_list_anim = 2130837514;
        /* added by DevToolsApp */
        public static final int m3_btn_state_list_anim = 2130837515;
        /* added by DevToolsApp */
        public static final int m3_card_elevated_state_list_anim = 2130837516;
        /* added by DevToolsApp */
        public static final int m3_card_state_list_anim = 2130837517;
        /* added by DevToolsApp */
        public static final int m3_chip_state_list_anim = 2130837518;
        /* added by DevToolsApp */
        public static final int m3_elevated_chip_state_list_anim = 2130837519;
        /* added by DevToolsApp */
        public static final int m3_extended_fab_change_size_collapse_motion_spec = 2130837520;
        /* added by DevToolsApp */
        public static final int m3_extended_fab_change_size_expand_motion_spec = 2130837521;
        /* added by DevToolsApp */
        public static final int m3_extended_fab_hide_motion_spec = 2130837522;
        /* added by DevToolsApp */
        public static final int m3_extended_fab_show_motion_spec = 2130837523;
        /* added by DevToolsApp */
        public static final int m3_extended_fab_state_list_animator = 2130837524;
        /* added by DevToolsApp */
        public static final int mtrl_btn_state_list_anim = 2130837525;
        /* added by DevToolsApp */
        public static final int mtrl_btn_unelevated_state_list_anim = 2130837526;
        /* added by DevToolsApp */
        public static final int mtrl_card_state_list_anim = 2130837527;
        /* added by DevToolsApp */
        public static final int mtrl_chip_state_list_anim = 2130837528;
        /* added by DevToolsApp */
        public static final int mtrl_extended_fab_change_size_collapse_motion_spec = 2130837529;
        /* added by DevToolsApp */
        public static final int mtrl_extended_fab_change_size_expand_motion_spec = 2130837530;
        /* added by DevToolsApp */
        public static final int mtrl_extended_fab_hide_motion_spec = 2130837531;
        /* added by DevToolsApp */
        public static final int mtrl_extended_fab_show_motion_spec = 2130837532;
        /* added by DevToolsApp */
        public static final int mtrl_extended_fab_state_list_animator = 2130837533;
        /* added by DevToolsApp */
        public static final int mtrl_fab_hide_motion_spec = 2130837534;
        /* added by DevToolsApp */
        public static final int mtrl_fab_show_motion_spec = 2130837535;
        /* added by DevToolsApp */
        public static final int mtrl_fab_transformation_sheet_collapse_spec = 2130837536;
        /* added by DevToolsApp */
        public static final int mtrl_fab_transformation_sheet_expand_spec = 2130837537;
    }

    /* added by DevToolsApp */
    public static final class attr {
        /* added by DevToolsApp */
        public static final int SharedValue = 2130903040;
        /* added by DevToolsApp */
        public static final int SharedValueId = 2130903041;
        /* added by DevToolsApp */
        public static final int actionBarDivider = 2130903042;
        /* added by DevToolsApp */
        public static final int actionBarItemBackground = 2130903043;
        /* added by DevToolsApp */
        public static final int actionBarPopupTheme = 2130903044;
        /* added by DevToolsApp */
        public static final int actionBarSize = 2130903045;
        /* added by DevToolsApp */
        public static final int actionBarSplitStyle = 2130903046;
        /* added by DevToolsApp */
        public static final int actionBarStyle = 2130903047;
        /* added by DevToolsApp */
        public static final int actionBarTabBarStyle = 2130903048;
        /* added by DevToolsApp */
        public static final int actionBarTabStyle = 2130903049;
        /* added by DevToolsApp */
        public static final int actionBarTabTextStyle = 2130903050;
        /* added by DevToolsApp */
        public static final int actionBarTheme = 2130903051;
        /* added by DevToolsApp */
        public static final int actionBarWidgetTheme = 2130903052;
        /* added by DevToolsApp */
        public static final int actionButtonStyle = 2130903053;
        /* added by DevToolsApp */
        public static final int actionDropDownStyle = 2130903054;
        /* added by DevToolsApp */
        public static final int actionLayout = 2130903055;
        /* added by DevToolsApp */
        public static final int actionMenuTextAppearance = 2130903056;
        /* added by DevToolsApp */
        public static final int actionMenuTextColor = 2130903057;
        /* added by DevToolsApp */
        public static final int actionModeBackground = 2130903058;
        /* added by DevToolsApp */
        public static final int actionModeCloseButtonStyle = 2130903059;
        /* added by DevToolsApp */
        public static final int actionModeCloseContentDescription = 2130903060;
        /* added by DevToolsApp */
        public static final int actionModeCloseDrawable = 2130903061;
        /* added by DevToolsApp */
        public static final int actionModeCopyDrawable = 2130903062;
        /* added by DevToolsApp */
        public static final int actionModeCutDrawable = 2130903063;
        /* added by DevToolsApp */
        public static final int actionModeFindDrawable = 2130903064;
        /* added by DevToolsApp */
        public static final int actionModePasteDrawable = 2130903065;
        /* added by DevToolsApp */
        public static final int actionModePopupWindowStyle = 2130903066;
        /* added by DevToolsApp */
        public static final int actionModeSelectAllDrawable = 2130903067;
        /* added by DevToolsApp */
        public static final int actionModeShareDrawable = 2130903068;
        /* added by DevToolsApp */
        public static final int actionModeSplitBackground = 2130903069;
        /* added by DevToolsApp */
        public static final int actionModeStyle = 2130903070;
        /* added by DevToolsApp */
        public static final int actionModeTheme = 2130903071;
        /* added by DevToolsApp */
        public static final int actionModeWebSearchDrawable = 2130903072;
        /* added by DevToolsApp */
        public static final int actionOverflowButtonStyle = 2130903073;
        /* added by DevToolsApp */
        public static final int actionOverflowMenuStyle = 2130903074;
        /* added by DevToolsApp */
        public static final int actionProviderClass = 2130903075;
        /* added by DevToolsApp */
        public static final int actionTextColorAlpha = 2130903076;
        /* added by DevToolsApp */
        public static final int actionViewClass = 2130903077;
        /* added by DevToolsApp */
        public static final int activeIndicatorLabelPadding = 2130903078;
        /* added by DevToolsApp */
        public static final int activityChooserViewStyle = 2130903079;
        /* added by DevToolsApp */
        public static final int addElevationShadow = 2130903080;
        /* added by DevToolsApp */
        public static final int alertDialogButtonGroupStyle = 2130903081;
        /* added by DevToolsApp */
        public static final int alertDialogCenterButtons = 2130903082;
        /* added by DevToolsApp */
        public static final int alertDialogStyle = 2130903083;
        /* added by DevToolsApp */
        public static final int alertDialogTheme = 2130903084;
        /* added by DevToolsApp */
        public static final int allowStacking = 2130903085;
        /* added by DevToolsApp */
        public static final int alpha = 2130903086;
        /* added by DevToolsApp */
        public static final int alphabeticModifiers = 2130903087;
        /* added by DevToolsApp */
        public static final int altSrc = 2130903088;
        /* added by DevToolsApp */
        public static final int animateCircleAngleTo = 2130903089;
        /* added by DevToolsApp */
        public static final int animateMenuItems = 2130903090;
        /* added by DevToolsApp */
        public static final int animateNavigationIcon = 2130903091;
        /* added by DevToolsApp */
        public static final int animateRelativeTo = 2130903092;
        /* added by DevToolsApp */
        public static final int animationMode = 2130903093;
        /* added by DevToolsApp */
        public static final int appBarLayoutStyle = 2130903094;
        /* added by DevToolsApp */
        public static final int applyMotionScene = 2130903095;
        /* added by DevToolsApp */
        public static final int arcMode = 2130903096;
        /* added by DevToolsApp */
        public static final int arrowHeadLength = 2130903097;
        /* added by DevToolsApp */
        public static final int arrowShaftLength = 2130903098;
        /* added by DevToolsApp */
        public static final int attributeName = 2130903099;
        /* added by DevToolsApp */
        public static final int autoAdjustToWithinGrandparentBounds = 2130903100;
        /* added by DevToolsApp */
        public static final int autoCompleteMode = 2130903101;
        /* added by DevToolsApp */
        public static final int autoCompleteTextViewStyle = 2130903102;
        /* added by DevToolsApp */
        public static final int autoShowKeyboard = 2130903103;
        /* added by DevToolsApp */
        public static final int autoSizeMaxTextSize = 2130903104;
        /* added by DevToolsApp */
        public static final int autoSizeMinTextSize = 2130903105;
        /* added by DevToolsApp */
        public static final int autoSizePresetSizes = 2130903106;
        /* added by DevToolsApp */
        public static final int autoSizeStepGranularity = 2130903107;
        /* added by DevToolsApp */
        public static final int autoSizeTextType = 2130903108;
        /* added by DevToolsApp */
        public static final int autoTransition = 2130903109;
        /* added by DevToolsApp */
        public static final int backHandlingEnabled = 2130903110;
        /* added by DevToolsApp */
        public static final int background = 2130903111;
        /* added by DevToolsApp */
        public static final int backgroundColor = 2130903112;
        /* added by DevToolsApp */
        public static final int backgroundInsetBottom = 2130903113;
        /* added by DevToolsApp */
        public static final int backgroundInsetEnd = 2130903114;
        /* added by DevToolsApp */
        public static final int backgroundInsetStart = 2130903115;
        /* added by DevToolsApp */
        public static final int backgroundInsetTop = 2130903116;
        /* added by DevToolsApp */
        public static final int backgroundOverlayColorAlpha = 2130903117;
        /* added by DevToolsApp */
        public static final int backgroundSplit = 2130903118;
        /* added by DevToolsApp */
        public static final int backgroundStacked = 2130903119;
        /* added by DevToolsApp */
        public static final int backgroundTint = 2130903120;
        /* added by DevToolsApp */
        public static final int backgroundTintMode = 2130903121;
        /* added by DevToolsApp */
        public static final int badgeGravity = 2130903122;
        /* added by DevToolsApp */
        public static final int badgeHeight = 2130903123;
        /* added by DevToolsApp */
        public static final int badgeRadius = 2130903124;
        /* added by DevToolsApp */
        public static final int badgeShapeAppearance = 2130903125;
        /* added by DevToolsApp */
        public static final int badgeShapeAppearanceOverlay = 2130903126;
        /* added by DevToolsApp */
        public static final int badgeStyle = 2130903127;
        /* added by DevToolsApp */
        public static final int badgeText = 2130903128;
        /* added by DevToolsApp */
        public static final int badgeTextAppearance = 2130903129;
        /* added by DevToolsApp */
        public static final int badgeTextColor = 2130903130;
        /* added by DevToolsApp */
        public static final int badgeVerticalPadding = 2130903131;
        /* added by DevToolsApp */
        public static final int badgeWidePadding = 2130903132;
        /* added by DevToolsApp */
        public static final int badgeWidth = 2130903133;
        /* added by DevToolsApp */
        public static final int badgeWithTextHeight = 2130903134;
        /* added by DevToolsApp */
        public static final int badgeWithTextRadius = 2130903135;
        /* added by DevToolsApp */
        public static final int badgeWithTextShapeAppearance = 2130903136;
        /* added by DevToolsApp */
        public static final int badgeWithTextShapeAppearanceOverlay = 2130903137;
        /* added by DevToolsApp */
        public static final int badgeWithTextWidth = 2130903138;
        /* added by DevToolsApp */
        public static final int barLength = 2130903139;
        /* added by DevToolsApp */
        public static final int barrierAllowsGoneWidgets = 2130903140;
        /* added by DevToolsApp */
        public static final int barrierDirection = 2130903141;
        /* added by DevToolsApp */
        public static final int barrierMargin = 2130903142;
        /* added by DevToolsApp */
        public static final int behavior_autoHide = 2130903143;
        /* added by DevToolsApp */
        public static final int behavior_autoShrink = 2130903144;
        /* added by DevToolsApp */
        public static final int behavior_draggable = 2130903145;
        /* added by DevToolsApp */
        public static final int behavior_expandedOffset = 2130903146;
        /* added by DevToolsApp */
        public static final int behavior_fitToContents = 2130903147;
        /* added by DevToolsApp */
        public static final int behavior_halfExpandedRatio = 2130903148;
        /* added by DevToolsApp */
        public static final int behavior_hideable = 2130903149;
        /* added by DevToolsApp */
        public static final int behavior_overlapTop = 2130903150;
        /* added by DevToolsApp */
        public static final int behavior_peekHeight = 2130903151;
        /* added by DevToolsApp */
        public static final int behavior_saveFlags = 2130903152;
        /* added by DevToolsApp */
        public static final int behavior_significantVelocityThreshold = 2130903153;
        /* added by DevToolsApp */
        public static final int behavior_skipCollapsed = 2130903154;
        /* added by DevToolsApp */
        public static final int blendSrc = 2130903155;
        /* added by DevToolsApp */
        public static final int borderRound = 2130903156;
        /* added by DevToolsApp */
        public static final int borderRoundPercent = 2130903157;
        /* added by DevToolsApp */
        public static final int borderWidth = 2130903158;
        /* added by DevToolsApp */
        public static final int borderlessButtonStyle = 2130903159;
        /* added by DevToolsApp */
        public static final int bottomAppBarStyle = 2130903160;
        /* added by DevToolsApp */
        public static final int bottomInsetScrimEnabled = 2130903161;
        /* added by DevToolsApp */
        public static final int bottomNavigationStyle = 2130903162;
        /* added by DevToolsApp */
        public static final int bottomSheetDialogTheme = 2130903163;
        /* added by DevToolsApp */
        public static final int bottomSheetDragHandleStyle = 2130903164;
        /* added by DevToolsApp */
        public static final int bottomSheetStyle = 2130903165;
        /* added by DevToolsApp */
        public static final int boxBackgroundColor = 2130903166;
        /* added by DevToolsApp */
        public static final int boxBackgroundMode = 2130903167;
        /* added by DevToolsApp */
        public static final int boxCollapsedPaddingTop = 2130903168;
        /* added by DevToolsApp */
        public static final int boxCornerRadiusBottomEnd = 2130903169;
        /* added by DevToolsApp */
        public static final int boxCornerRadiusBottomStart = 2130903170;
        /* added by DevToolsApp */
        public static final int boxCornerRadiusTopEnd = 2130903171;
        /* added by DevToolsApp */
        public static final int boxCornerRadiusTopStart = 2130903172;
        /* added by DevToolsApp */
        public static final int boxStrokeColor = 2130903173;
        /* added by DevToolsApp */
        public static final int boxStrokeErrorColor = 2130903174;
        /* added by DevToolsApp */
        public static final int boxStrokeWidth = 2130903175;
        /* added by DevToolsApp */
        public static final int boxStrokeWidthFocused = 2130903176;
        /* added by DevToolsApp */
        public static final int brightness = 2130903177;
        /* added by DevToolsApp */
        public static final int buttonBarButtonStyle = 2130903178;
        /* added by DevToolsApp */
        public static final int buttonBarNegativeButtonStyle = 2130903179;
        /* added by DevToolsApp */
        public static final int buttonBarNeutralButtonStyle = 2130903180;
        /* added by DevToolsApp */
        public static final int buttonBarPositiveButtonStyle = 2130903181;
        /* added by DevToolsApp */
        public static final int buttonBarStyle = 2130903182;
        /* added by DevToolsApp */
        public static final int buttonCompat = 2130903183;
        /* added by DevToolsApp */
        public static final int buttonGravity = 2130903184;
        /* added by DevToolsApp */
        public static final int buttonIcon = 2130903185;
        /* added by DevToolsApp */
        public static final int buttonIconDimen = 2130903186;
        /* added by DevToolsApp */
        public static final int buttonIconTint = 2130903187;
        /* added by DevToolsApp */
        public static final int buttonIconTintMode = 2130903188;
        /* added by DevToolsApp */
        public static final int buttonPanelSideLayout = 2130903189;
        /* added by DevToolsApp */
        public static final int buttonSize = 2130903190;
        /* added by DevToolsApp */
        public static final int buttonStyle = 2130903191;
        /* added by DevToolsApp */
        public static final int buttonStyleSmall = 2130903192;
        /* added by DevToolsApp */
        public static final int buttonTint = 2130903193;
        /* added by DevToolsApp */
        public static final int buttonTintMode = 2130903194;
        /* added by DevToolsApp */
        public static final int cardBackgroundColor = 2130903195;
        /* added by DevToolsApp */
        public static final int cardCornerRadius = 2130903196;
        /* added by DevToolsApp */
        public static final int cardElevation = 2130903197;
        /* added by DevToolsApp */
        public static final int cardForegroundColor = 2130903198;
        /* added by DevToolsApp */
        public static final int cardMaxElevation = 2130903199;
        /* added by DevToolsApp */
        public static final int cardPreventCornerOverlap = 2130903200;
        /* added by DevToolsApp */
        public static final int cardUseCompatPadding = 2130903201;
        /* added by DevToolsApp */
        public static final int cardViewStyle = 2130903202;
        /* added by DevToolsApp */
        public static final int carousel_alignment = 2130903203;
        /* added by DevToolsApp */
        public static final int carousel_backwardTransition = 2130903204;
        /* added by DevToolsApp */
        public static final int carousel_emptyViewsBehavior = 2130903205;
        /* added by DevToolsApp */
        public static final int carousel_firstView = 2130903206;
        /* added by DevToolsApp */
        public static final int carousel_forwardTransition = 2130903207;
        /* added by DevToolsApp */
        public static final int carousel_infinite = 2130903208;
        /* added by DevToolsApp */
        public static final int carousel_nextState = 2130903209;
        /* added by DevToolsApp */
        public static final int carousel_previousState = 2130903210;
        /* added by DevToolsApp */
        public static final int carousel_touchUpMode = 2130903211;
        /* added by DevToolsApp */
        public static final int carousel_touchUp_dampeningFactor = 2130903212;
        /* added by DevToolsApp */
        public static final int carousel_touchUp_velocityThreshold = 2130903213;
        /* added by DevToolsApp */
        public static final int centerIfNoTextEnabled = 2130903214;
        /* added by DevToolsApp */
        public static final int chainUseRtl = 2130903215;
        /* added by DevToolsApp */
        public static final int checkMarkCompat = 2130903216;
        /* added by DevToolsApp */
        public static final int checkMarkTint = 2130903217;
        /* added by DevToolsApp */
        public static final int checkMarkTintMode = 2130903218;
        /* added by DevToolsApp */
        public static final int checkboxStyle = 2130903219;
        /* added by DevToolsApp */
        public static final int checkedButton = 2130903220;
        /* added by DevToolsApp */
        public static final int checkedChip = 2130903221;
        /* added by DevToolsApp */
        public static final int checkedIcon = 2130903222;
        /* added by DevToolsApp */
        public static final int checkedIconEnabled = 2130903223;
        /* added by DevToolsApp */
        public static final int checkedIconGravity = 2130903224;
        /* added by DevToolsApp */
        public static final int checkedIconMargin = 2130903225;
        /* added by DevToolsApp */
        public static final int checkedIconSize = 2130903226;
        /* added by DevToolsApp */
        public static final int checkedIconTint = 2130903227;
        /* added by DevToolsApp */
        public static final int checkedIconVisible = 2130903228;
        /* added by DevToolsApp */
        public static final int checkedState = 2130903229;
        /* added by DevToolsApp */
        public static final int checkedTextViewStyle = 2130903230;
        /* added by DevToolsApp */
        public static final int chipBackgroundColor = 2130903231;
        /* added by DevToolsApp */
        public static final int chipCornerRadius = 2130903232;
        /* added by DevToolsApp */
        public static final int chipEndPadding = 2130903233;
        /* added by DevToolsApp */
        public static final int chipGroupStyle = 2130903234;
        /* added by DevToolsApp */
        public static final int chipIcon = 2130903235;
        /* added by DevToolsApp */
        public static final int chipIconEnabled = 2130903236;
        /* added by DevToolsApp */
        public static final int chipIconSize = 2130903237;
        /* added by DevToolsApp */
        public static final int chipIconTint = 2130903238;
        /* added by DevToolsApp */
        public static final int chipIconVisible = 2130903239;
        /* added by DevToolsApp */
        public static final int chipMinHeight = 2130903240;
        /* added by DevToolsApp */
        public static final int chipMinTouchTargetSize = 2130903241;
        /* added by DevToolsApp */
        public static final int chipSpacing = 2130903242;
        /* added by DevToolsApp */
        public static final int chipSpacingHorizontal = 2130903243;
        /* added by DevToolsApp */
        public static final int chipSpacingVertical = 2130903244;
        /* added by DevToolsApp */
        public static final int chipStandaloneStyle = 2130903245;
        /* added by DevToolsApp */
        public static final int chipStartPadding = 2130903246;
        /* added by DevToolsApp */
        public static final int chipStrokeColor = 2130903247;
        /* added by DevToolsApp */
        public static final int chipStrokeWidth = 2130903248;
        /* added by DevToolsApp */
        public static final int chipStyle = 2130903249;
        /* added by DevToolsApp */
        public static final int chipSurfaceColor = 2130903250;
        /* added by DevToolsApp */
        public static final int circleCrop = 2130903251;
        /* added by DevToolsApp */
        public static final int circleRadius = 2130903252;
        /* added by DevToolsApp */
        public static final int circularProgressIndicatorStyle = 2130903253;
        /* added by DevToolsApp */
        public static final int circularflow_angles = 2130903254;
        /* added by DevToolsApp */
        public static final int circularflow_defaultAngle = 2130903255;
        /* added by DevToolsApp */
        public static final int circularflow_defaultRadius = 2130903256;
        /* added by DevToolsApp */
        public static final int circularflow_radiusInDP = 2130903257;
        /* added by DevToolsApp */
        public static final int circularflow_viewCenter = 2130903258;
        /* added by DevToolsApp */
        public static final int clearsTag = 2130903259;
        /* added by DevToolsApp */
        public static final int clickAction = 2130903260;
        /* added by DevToolsApp */
        public static final int clockFaceBackgroundColor = 2130903261;
        /* added by DevToolsApp */
        public static final int clockHandColor = 2130903262;
        /* added by DevToolsApp */
        public static final int clockIcon = 2130903263;
        /* added by DevToolsApp */
        public static final int clockNumberTextColor = 2130903264;
        /* added by DevToolsApp */
        public static final int closeIcon = 2130903265;
        /* added by DevToolsApp */
        public static final int closeIconEnabled = 2130903266;
        /* added by DevToolsApp */
        public static final int closeIconEndPadding = 2130903267;
        /* added by DevToolsApp */
        public static final int closeIconSize = 2130903268;
        /* added by DevToolsApp */
        public static final int closeIconStartPadding = 2130903269;
        /* added by DevToolsApp */
        public static final int closeIconTint = 2130903270;
        /* added by DevToolsApp */
        public static final int closeIconVisible = 2130903271;
        /* added by DevToolsApp */
        public static final int closeItemLayout = 2130903272;
        /* added by DevToolsApp */
        public static final int collapseContentDescription = 2130903273;
        /* added by DevToolsApp */
        public static final int collapseIcon = 2130903274;
        /* added by DevToolsApp */
        public static final int collapsedSize = 2130903275;
        /* added by DevToolsApp */
        public static final int collapsedTitleGravity = 2130903276;
        /* added by DevToolsApp */
        public static final int collapsedTitleTextAppearance = 2130903277;
        /* added by DevToolsApp */
        public static final int collapsedTitleTextColor = 2130903278;
        /* added by DevToolsApp */
        public static final int collapsingToolbarLayoutLargeSize = 2130903279;
        /* added by DevToolsApp */
        public static final int collapsingToolbarLayoutLargeStyle = 2130903280;
        /* added by DevToolsApp */
        public static final int collapsingToolbarLayoutMediumSize = 2130903281;
        /* added by DevToolsApp */
        public static final int collapsingToolbarLayoutMediumStyle = 2130903282;
        /* added by DevToolsApp */
        public static final int collapsingToolbarLayoutStyle = 2130903283;
        /* added by DevToolsApp */
        public static final int color = 2130903284;
        /* added by DevToolsApp */
        public static final int colorAccent = 2130903285;
        /* added by DevToolsApp */
        public static final int colorBackgroundFloating = 2130903286;
        /* added by DevToolsApp */
        public static final int colorButtonNormal = 2130903287;
        /* added by DevToolsApp */
        public static final int colorContainer = 2130903288;
        /* added by DevToolsApp */
        public static final int colorControlActivated = 2130903289;
        /* added by DevToolsApp */
        public static final int colorControlHighlight = 2130903290;
        /* added by DevToolsApp */
        public static final int colorControlNormal = 2130903291;
        /* added by DevToolsApp */
        public static final int colorError = 2130903292;
        /* added by DevToolsApp */
        public static final int colorErrorContainer = 2130903293;
        /* added by DevToolsApp */
        public static final int colorOnBackground = 2130903294;
        /* added by DevToolsApp */
        public static final int colorOnContainer = 2130903295;
        /* added by DevToolsApp */
        public static final int colorOnContainerUnchecked = 2130903296;
        /* added by DevToolsApp */
        public static final int colorOnError = 2130903297;
        /* added by DevToolsApp */
        public static final int colorOnErrorContainer = 2130903298;
        /* added by DevToolsApp */
        public static final int colorOnPrimary = 2130903299;
        /* added by DevToolsApp */
        public static final int colorOnPrimaryContainer = 2130903300;
        /* added by DevToolsApp */
        public static final int colorOnPrimaryFixed = 2130903301;
        /* added by DevToolsApp */
        public static final int colorOnPrimaryFixedVariant = 2130903302;
        /* added by DevToolsApp */
        public static final int colorOnPrimarySurface = 2130903303;
        /* added by DevToolsApp */
        public static final int colorOnSecondary = 2130903304;
        /* added by DevToolsApp */
        public static final int colorOnSecondaryContainer = 2130903305;
        /* added by DevToolsApp */
        public static final int colorOnSecondaryFixed = 2130903306;
        /* added by DevToolsApp */
        public static final int colorOnSecondaryFixedVariant = 2130903307;
        /* added by DevToolsApp */
        public static final int colorOnSurface = 2130903308;
        /* added by DevToolsApp */
        public static final int colorOnSurfaceInverse = 2130903309;
        /* added by DevToolsApp */
        public static final int colorOnSurfaceVariant = 2130903310;
        /* added by DevToolsApp */
        public static final int colorOnTertiary = 2130903311;
        /* added by DevToolsApp */
        public static final int colorOnTertiaryContainer = 2130903312;
        /* added by DevToolsApp */
        public static final int colorOnTertiaryFixed = 2130903313;
        /* added by DevToolsApp */
        public static final int colorOnTertiaryFixedVariant = 2130903314;
        /* added by DevToolsApp */
        public static final int colorOutline = 2130903315;
        /* added by DevToolsApp */
        public static final int colorOutlineVariant = 2130903316;
        /* added by DevToolsApp */
        public static final int colorPrimary = 2130903317;
        /* added by DevToolsApp */
        public static final int colorPrimaryContainer = 2130903318;
        /* added by DevToolsApp */
        public static final int colorPrimaryDark = 2130903319;
        /* added by DevToolsApp */
        public static final int colorPrimaryFixed = 2130903320;
        /* added by DevToolsApp */
        public static final int colorPrimaryFixedDim = 2130903321;
        /* added by DevToolsApp */
        public static final int colorPrimaryInverse = 2130903322;
        /* added by DevToolsApp */
        public static final int colorPrimarySurface = 2130903323;
        /* added by DevToolsApp */
        public static final int colorPrimaryVariant = 2130903324;
        /* added by DevToolsApp */
        public static final int colorScheme = 2130903325;
        /* added by DevToolsApp */
        public static final int colorSecondary = 2130903326;
        /* added by DevToolsApp */
        public static final int colorSecondaryContainer = 2130903327;
        /* added by DevToolsApp */
        public static final int colorSecondaryFixed = 2130903328;
        /* added by DevToolsApp */
        public static final int colorSecondaryFixedDim = 2130903329;
        /* added by DevToolsApp */
        public static final int colorSecondaryVariant = 2130903330;
        /* added by DevToolsApp */
        public static final int colorSurface = 2130903331;
        /* added by DevToolsApp */
        public static final int colorSurfaceBright = 2130903332;
        /* added by DevToolsApp */
        public static final int colorSurfaceContainer = 2130903333;
        /* added by DevToolsApp */
        public static final int colorSurfaceContainerHigh = 2130903334;
        /* added by DevToolsApp */
        public static final int colorSurfaceContainerHighest = 2130903335;
        /* added by DevToolsApp */
        public static final int colorSurfaceContainerLow = 2130903336;
        /* added by DevToolsApp */
        public static final int colorSurfaceContainerLowest = 2130903337;
        /* added by DevToolsApp */
        public static final int colorSurfaceDim = 2130903338;
        /* added by DevToolsApp */
        public static final int colorSurfaceInverse = 2130903339;
        /* added by DevToolsApp */
        public static final int colorSurfaceVariant = 2130903340;
        /* added by DevToolsApp */
        public static final int colorSwitchThumbNormal = 2130903341;
        /* added by DevToolsApp */
        public static final int colorTertiary = 2130903342;
        /* added by DevToolsApp */
        public static final int colorTertiaryContainer = 2130903343;
        /* added by DevToolsApp */
        public static final int colorTertiaryFixed = 2130903344;
        /* added by DevToolsApp */
        public static final int colorTertiaryFixedDim = 2130903345;
        /* added by DevToolsApp */
        public static final int commitIcon = 2130903346;
        /* added by DevToolsApp */
        public static final int compatShadowEnabled = 2130903347;
        /* added by DevToolsApp */
        public static final int constraintRotate = 2130903348;
        /* added by DevToolsApp */
        public static final int constraintSet = 2130903349;
        /* added by DevToolsApp */
        public static final int constraintSetEnd = 2130903350;
        /* added by DevToolsApp */
        public static final int constraintSetStart = 2130903351;
        /* added by DevToolsApp */
        public static final int constraint_referenced_ids = 2130903352;
        /* added by DevToolsApp */
        public static final int constraint_referenced_tags = 2130903353;
        /* added by DevToolsApp */
        public static final int constraints = 2130903354;
        /* added by DevToolsApp */
        public static final int content = 2130903355;
        /* added by DevToolsApp */
        public static final int contentDescription = 2130903356;
        /* added by DevToolsApp */
        public static final int contentInsetEnd = 2130903357;
        /* added by DevToolsApp */
        public static final int contentInsetEndWithActions = 2130903358;
        /* added by DevToolsApp */
        public static final int contentInsetLeft = 2130903359;
        /* added by DevToolsApp */
        public static final int contentInsetRight = 2130903360;
        /* added by DevToolsApp */
        public static final int contentInsetStart = 2130903361;
        /* added by DevToolsApp */
        public static final int contentInsetStartWithNavigation = 2130903362;
        /* added by DevToolsApp */
        public static final int contentPadding = 2130903363;
        /* added by DevToolsApp */
        public static final int contentPaddingBottom = 2130903364;
        /* added by DevToolsApp */
        public static final int contentPaddingEnd = 2130903365;
        /* added by DevToolsApp */
        public static final int contentPaddingLeft = 2130903366;
        /* added by DevToolsApp */
        public static final int contentPaddingRight = 2130903367;
        /* added by DevToolsApp */
        public static final int contentPaddingStart = 2130903368;
        /* added by DevToolsApp */
        public static final int contentPaddingTop = 2130903369;
        /* added by DevToolsApp */
        public static final int contentScrim = 2130903370;
        /* added by DevToolsApp */
        public static final int contrast = 2130903371;
        /* added by DevToolsApp */
        public static final int controlBackground = 2130903372;
        /* added by DevToolsApp */
        public static final int coordinatorLayoutStyle = 2130903373;
        /* added by DevToolsApp */
        public static final int coplanarSiblingViewId = 2130903374;
        /* added by DevToolsApp */
        public static final int cornerFamily = 2130903375;
        /* added by DevToolsApp */
        public static final int cornerFamilyBottomLeft = 2130903376;
        /* added by DevToolsApp */
        public static final int cornerFamilyBottomRight = 2130903377;
        /* added by DevToolsApp */
        public static final int cornerFamilyTopLeft = 2130903378;
        /* added by DevToolsApp */
        public static final int cornerFamilyTopRight = 2130903379;
        /* added by DevToolsApp */
        public static final int cornerRadius = 2130903380;
        /* added by DevToolsApp */
        public static final int cornerSize = 2130903381;
        /* added by DevToolsApp */
        public static final int cornerSizeBottomLeft = 2130903382;
        /* added by DevToolsApp */
        public static final int cornerSizeBottomRight = 2130903383;
        /* added by DevToolsApp */
        public static final int cornerSizeTopLeft = 2130903384;
        /* added by DevToolsApp */
        public static final int cornerSizeTopRight = 2130903385;
        /* added by DevToolsApp */
        public static final int counterEnabled = 2130903386;
        /* added by DevToolsApp */
        public static final int counterMaxLength = 2130903387;
        /* added by DevToolsApp */
        public static final int counterOverflowTextAppearance = 2130903388;
        /* added by DevToolsApp */
        public static final int counterOverflowTextColor = 2130903389;
        /* added by DevToolsApp */
        public static final int counterTextAppearance = 2130903390;
        /* added by DevToolsApp */
        public static final int counterTextColor = 2130903391;
        /* added by DevToolsApp */
        public static final int crossfade = 2130903392;
        /* added by DevToolsApp */
        public static final int currentState = 2130903393;
        /* added by DevToolsApp */
        public static final int cursorColor = 2130903394;
        /* added by DevToolsApp */
        public static final int cursorErrorColor = 2130903395;
        /* added by DevToolsApp */
        public static final int curveFit = 2130903396;
        /* added by DevToolsApp */
        public static final int customBoolean = 2130903397;
        /* added by DevToolsApp */
        public static final int customColorDrawableValue = 2130903398;
        /* added by DevToolsApp */
        public static final int customColorValue = 2130903399;
        /* added by DevToolsApp */
        public static final int customDimension = 2130903400;
        /* added by DevToolsApp */
        public static final int customFloatValue = 2130903401;
        /* added by DevToolsApp */
        public static final int customIntegerValue = 2130903402;
        /* added by DevToolsApp */
        public static final int customNavigationLayout = 2130903403;
        /* added by DevToolsApp */
        public static final int customPixelDimension = 2130903404;
        /* added by DevToolsApp */
        public static final int customReference = 2130903405;
        /* added by DevToolsApp */
        public static final int customStringValue = 2130903406;
        /* added by DevToolsApp */
        public static final int dayInvalidStyle = 2130903407;
        /* added by DevToolsApp */
        public static final int daySelectedStyle = 2130903408;
        /* added by DevToolsApp */
        public static final int dayStyle = 2130903409;
        /* added by DevToolsApp */
        public static final int dayTodayStyle = 2130903410;
        /* added by DevToolsApp */
        public static final int defaultDuration = 2130903411;
        /* added by DevToolsApp */
        public static final int defaultMarginsEnabled = 2130903412;
        /* added by DevToolsApp */
        public static final int defaultQueryHint = 2130903413;
        /* added by DevToolsApp */
        public static final int defaultScrollFlagsEnabled = 2130903414;
        /* added by DevToolsApp */
        public static final int defaultState = 2130903415;
        /* added by DevToolsApp */
        public static final int deltaPolarAngle = 2130903416;
        /* added by DevToolsApp */
        public static final int deltaPolarRadius = 2130903417;
        /* added by DevToolsApp */
        public static final int deriveConstraintsFrom = 2130903418;
        /* added by DevToolsApp */
        public static final int dialogCornerRadius = 2130903419;
        /* added by DevToolsApp */
        public static final int dialogPreferredPadding = 2130903420;
        /* added by DevToolsApp */
        public static final int dialogTheme = 2130903421;
        /* added by DevToolsApp */
        public static final int displayOptions = 2130903422;
        /* added by DevToolsApp */
        public static final int divider = 2130903423;
        /* added by DevToolsApp */
        public static final int dividerColor = 2130903424;
        /* added by DevToolsApp */
        public static final int dividerHorizontal = 2130903425;
        /* added by DevToolsApp */
        public static final int dividerInsetEnd = 2130903426;
        /* added by DevToolsApp */
        public static final int dividerInsetStart = 2130903427;
        /* added by DevToolsApp */
        public static final int dividerPadding = 2130903428;
        /* added by DevToolsApp */
        public static final int dividerThickness = 2130903429;
        /* added by DevToolsApp */
        public static final int dividerVertical = 2130903430;
        /* added by DevToolsApp */
        public static final int dragDirection = 2130903431;
        /* added by DevToolsApp */
        public static final int dragScale = 2130903432;
        /* added by DevToolsApp */
        public static final int dragThreshold = 2130903433;
        /* added by DevToolsApp */
        public static final int drawPath = 2130903434;
        /* added by DevToolsApp */
        public static final int drawableBottomCompat = 2130903435;
        /* added by DevToolsApp */
        public static final int drawableEndCompat = 2130903436;
        /* added by DevToolsApp */
        public static final int drawableLeftCompat = 2130903437;
        /* added by DevToolsApp */
        public static final int drawableRightCompat = 2130903438;
        /* added by DevToolsApp */
        public static final int drawableSize = 2130903439;
        /* added by DevToolsApp */
        public static final int drawableStartCompat = 2130903440;
        /* added by DevToolsApp */
        public static final int drawableTint = 2130903441;
        /* added by DevToolsApp */
        public static final int drawableTintMode = 2130903442;
        /* added by DevToolsApp */
        public static final int drawableTopCompat = 2130903443;
        /* added by DevToolsApp */
        public static final int drawerArrowStyle = 2130903444;
        /* added by DevToolsApp */
        public static final int drawerLayoutCornerSize = 2130903445;
        /* added by DevToolsApp */
        public static final int drawerLayoutStyle = 2130903446;
        /* added by DevToolsApp */
        public static final int dropDownBackgroundTint = 2130903447;
        /* added by DevToolsApp */
        public static final int dropDownListViewStyle = 2130903448;
        /* added by DevToolsApp */
        public static final int dropdownListPreferredItemHeight = 2130903449;
        /* added by DevToolsApp */
        public static final int duration = 2130903450;
        /* added by DevToolsApp */
        public static final int dynamicColorThemeOverlay = 2130903451;
        /* added by DevToolsApp */
        public static final int editTextBackground = 2130903452;
        /* added by DevToolsApp */
        public static final int editTextColor = 2130903453;
        /* added by DevToolsApp */
        public static final int editTextStyle = 2130903454;
        /* added by DevToolsApp */
        public static final int elevation = 2130903455;
        /* added by DevToolsApp */
        public static final int elevationOverlayAccentColor = 2130903456;
        /* added by DevToolsApp */
        public static final int elevationOverlayColor = 2130903457;
        /* added by DevToolsApp */
        public static final int elevationOverlayEnabled = 2130903458;
        /* added by DevToolsApp */
        public static final int emojiCompatEnabled = 2130903459;
        /* added by DevToolsApp */
        public static final int enableEdgeToEdge = 2130903460;
        /* added by DevToolsApp */
        public static final int endIconCheckable = 2130903461;
        /* added by DevToolsApp */
        public static final int endIconContentDescription = 2130903462;
        /* added by DevToolsApp */
        public static final int endIconDrawable = 2130903463;
        /* added by DevToolsApp */
        public static final int endIconMinSize = 2130903464;
        /* added by DevToolsApp */
        public static final int endIconMode = 2130903465;
        /* added by DevToolsApp */
        public static final int endIconScaleType = 2130903466;
        /* added by DevToolsApp */
        public static final int endIconTint = 2130903467;
        /* added by DevToolsApp */
        public static final int endIconTintMode = 2130903468;
        /* added by DevToolsApp */
        public static final int enforceMaterialTheme = 2130903469;
        /* added by DevToolsApp */
        public static final int enforceTextAppearance = 2130903470;
        /* added by DevToolsApp */
        public static final int ensureMinTouchTargetSize = 2130903471;
        /* added by DevToolsApp */
        public static final int errorAccessibilityLabel = 2130903472;
        /* added by DevToolsApp */
        public static final int errorAccessibilityLiveRegion = 2130903473;
        /* added by DevToolsApp */
        public static final int errorContentDescription = 2130903474;
        /* added by DevToolsApp */
        public static final int errorEnabled = 2130903475;
        /* added by DevToolsApp */
        public static final int errorIconDrawable = 2130903476;
        /* added by DevToolsApp */
        public static final int errorIconTint = 2130903477;
        /* added by DevToolsApp */
        public static final int errorIconTintMode = 2130903478;
        /* added by DevToolsApp */
        public static final int errorShown = 2130903479;
        /* added by DevToolsApp */
        public static final int errorTextAppearance = 2130903480;
        /* added by DevToolsApp */
        public static final int errorTextColor = 2130903481;
        /* added by DevToolsApp */
        public static final int expandActivityOverflowButtonDrawable = 2130903482;
        /* added by DevToolsApp */
        public static final int expanded = 2130903483;
        /* added by DevToolsApp */
        public static final int expandedHintEnabled = 2130903484;
        /* added by DevToolsApp */
        public static final int expandedTitleGravity = 2130903485;
        /* added by DevToolsApp */
        public static final int expandedTitleMargin = 2130903486;
        /* added by DevToolsApp */
        public static final int expandedTitleMarginBottom = 2130903487;
        /* added by DevToolsApp */
        public static final int expandedTitleMarginEnd = 2130903488;
        /* added by DevToolsApp */
        public static final int expandedTitleMarginStart = 2130903489;
        /* added by DevToolsApp */
        public static final int expandedTitleMarginTop = 2130903490;
        /* added by DevToolsApp */
        public static final int expandedTitleTextAppearance = 2130903491;
        /* added by DevToolsApp */
        public static final int expandedTitleTextColor = 2130903492;
        /* added by DevToolsApp */
        public static final int extendMotionSpec = 2130903493;
        /* added by DevToolsApp */
        public static final int extendStrategy = 2130903494;
        /* added by DevToolsApp */
        public static final int extendedFloatingActionButtonPrimaryStyle = 2130903495;
        /* added by DevToolsApp */
        public static final int extendedFloatingActionButtonSecondaryStyle = 2130903496;
        /* added by DevToolsApp */
        public static final int extendedFloatingActionButtonStyle = 2130903497;
        /* added by DevToolsApp */
        public static final int extendedFloatingActionButtonSurfaceStyle = 2130903498;
        /* added by DevToolsApp */
        public static final int extendedFloatingActionButtonTertiaryStyle = 2130903499;
        /* added by DevToolsApp */
        public static final int extraMultilineHeightEnabled = 2130903500;
        /* added by DevToolsApp */
        public static final int fabAlignmentMode = 2130903501;
        /* added by DevToolsApp */
        public static final int fabAlignmentModeEndMargin = 2130903502;
        /* added by DevToolsApp */
        public static final int fabAnchorMode = 2130903503;
        /* added by DevToolsApp */
        public static final int fabAnimationMode = 2130903504;
        /* added by DevToolsApp */
        public static final int fabCradleMargin = 2130903505;
        /* added by DevToolsApp */
        public static final int fabCradleRoundedCornerRadius = 2130903506;
        /* added by DevToolsApp */
        public static final int fabCradleVerticalOffset = 2130903507;
        /* added by DevToolsApp */
        public static final int fabCustomSize = 2130903508;
        /* added by DevToolsApp */
        public static final int fabSize = 2130903509;
        /* added by DevToolsApp */
        public static final int fastScrollEnabled = 2130903510;
        /* added by DevToolsApp */
        public static final int fastScrollHorizontalThumbDrawable = 2130903511;
        /* added by DevToolsApp */
        public static final int fastScrollHorizontalTrackDrawable = 2130903512;
        /* added by DevToolsApp */
        public static final int fastScrollVerticalThumbDrawable = 2130903513;
        /* added by DevToolsApp */
        public static final int fastScrollVerticalTrackDrawable = 2130903514;
        /* added by DevToolsApp */
        public static final int firstBaselineToTopHeight = 2130903515;
        /* added by DevToolsApp */
        public static final int floatingActionButtonLargePrimaryStyle = 2130903516;
        /* added by DevToolsApp */
        public static final int floatingActionButtonLargeSecondaryStyle = 2130903517;
        /* added by DevToolsApp */
        public static final int floatingActionButtonLargeStyle = 2130903518;
        /* added by DevToolsApp */
        public static final int floatingActionButtonLargeSurfaceStyle = 2130903519;
        /* added by DevToolsApp */
        public static final int floatingActionButtonLargeTertiaryStyle = 2130903520;
        /* added by DevToolsApp */
        public static final int floatingActionButtonPrimaryStyle = 2130903521;
        /* added by DevToolsApp */
        public static final int floatingActionButtonSecondaryStyle = 2130903522;
        /* added by DevToolsApp */
        public static final int floatingActionButtonSmallPrimaryStyle = 2130903523;
        /* added by DevToolsApp */
        public static final int floatingActionButtonSmallSecondaryStyle = 2130903524;
        /* added by DevToolsApp */
        public static final int floatingActionButtonSmallStyle = 2130903525;
        /* added by DevToolsApp */
        public static final int floatingActionButtonSmallSurfaceStyle = 2130903526;
        /* added by DevToolsApp */
        public static final int floatingActionButtonSmallTertiaryStyle = 2130903527;
        /* added by DevToolsApp */
        public static final int floatingActionButtonStyle = 2130903528;
        /* added by DevToolsApp */
        public static final int floatingActionButtonSurfaceStyle = 2130903529;
        /* added by DevToolsApp */
        public static final int floatingActionButtonTertiaryStyle = 2130903530;
        /* added by DevToolsApp */
        public static final int flow_firstHorizontalBias = 2130903531;
        /* added by DevToolsApp */
        public static final int flow_firstHorizontalStyle = 2130903532;
        /* added by DevToolsApp */
        public static final int flow_firstVerticalBias = 2130903533;
        /* added by DevToolsApp */
        public static final int flow_firstVerticalStyle = 2130903534;
        /* added by DevToolsApp */
        public static final int flow_horizontalAlign = 2130903535;
        /* added by DevToolsApp */
        public static final int flow_horizontalBias = 2130903536;
        /* added by DevToolsApp */
        public static final int flow_horizontalGap = 2130903537;
        /* added by DevToolsApp */
        public static final int flow_horizontalStyle = 2130903538;
        /* added by DevToolsApp */
        public static final int flow_lastHorizontalBias = 2130903539;
        /* added by DevToolsApp */
        public static final int flow_lastHorizontalStyle = 2130903540;
        /* added by DevToolsApp */
        public static final int flow_lastVerticalBias = 2130903541;
        /* added by DevToolsApp */
        public static final int flow_lastVerticalStyle = 2130903542;
        /* added by DevToolsApp */
        public static final int flow_maxElementsWrap = 2130903543;
        /* added by DevToolsApp */
        public static final int flow_padding = 2130903544;
        /* added by DevToolsApp */
        public static final int flow_verticalAlign = 2130903545;
        /* added by DevToolsApp */
        public static final int flow_verticalBias = 2130903546;
        /* added by DevToolsApp */
        public static final int flow_verticalGap = 2130903547;
        /* added by DevToolsApp */
        public static final int flow_verticalStyle = 2130903548;
        /* added by DevToolsApp */
        public static final int flow_wrapMode = 2130903549;
        /* added by DevToolsApp */
        public static final int font = 2130903550;
        /* added by DevToolsApp */
        public static final int fontFamily = 2130903551;
        /* added by DevToolsApp */
        public static final int fontProviderAuthority = 2130903552;
        /* added by DevToolsApp */
        public static final int fontProviderCerts = 2130903553;
        /* added by DevToolsApp */
        public static final int fontProviderFetchStrategy = 2130903554;
        /* added by DevToolsApp */
        public static final int fontProviderFetchTimeout = 2130903555;
        /* added by DevToolsApp */
        public static final int fontProviderPackage = 2130903556;
        /* added by DevToolsApp */
        public static final int fontProviderQuery = 2130903557;
        /* added by DevToolsApp */
        public static final int fontProviderSystemFontFamily = 2130903558;
        /* added by DevToolsApp */
        public static final int fontStyle = 2130903559;
        /* added by DevToolsApp */
        public static final int fontVariationSettings = 2130903560;
        /* added by DevToolsApp */
        public static final int fontWeight = 2130903561;
        /* added by DevToolsApp */
        public static final int forceApplySystemWindowInsetTop = 2130903562;
        /* added by DevToolsApp */
        public static final int forceDefaultNavigationOnClickListener = 2130903563;
        /* added by DevToolsApp */
        public static final int foregroundInsidePadding = 2130903564;
        /* added by DevToolsApp */
        public static final int framePosition = 2130903565;
        /* added by DevToolsApp */
        public static final int gapBetweenBars = 2130903566;
        /* added by DevToolsApp */
        public static final int gestureInsetBottomIgnored = 2130903567;
        /* added by DevToolsApp */
        public static final int goIcon = 2130903568;
        /* added by DevToolsApp */
        public static final int grid_columnWeights = 2130903569;
        /* added by DevToolsApp */
        public static final int grid_columns = 2130903570;
        /* added by DevToolsApp */
        public static final int grid_horizontalGaps = 2130903571;
        /* added by DevToolsApp */
        public static final int grid_orientation = 2130903572;
        /* added by DevToolsApp */
        public static final int grid_rowWeights = 2130903573;
        /* added by DevToolsApp */
        public static final int grid_rows = 2130903574;
        /* added by DevToolsApp */
        public static final int grid_skips = 2130903575;
        /* added by DevToolsApp */
        public static final int grid_spans = 2130903576;
        /* added by DevToolsApp */
        public static final int grid_useRtl = 2130903577;
        /* added by DevToolsApp */
        public static final int grid_validateInputs = 2130903578;
        /* added by DevToolsApp */
        public static final int grid_verticalGaps = 2130903579;
        /* added by DevToolsApp */
        public static final int guidelineUseRtl = 2130903580;
        /* added by DevToolsApp */
        public static final int haloColor = 2130903581;
        /* added by DevToolsApp */
        public static final int haloRadius = 2130903582;
        /* added by DevToolsApp */
        public static final int headerLayout = 2130903583;
        /* added by DevToolsApp */
        public static final int height = 2130903584;
        /* added by DevToolsApp */
        public static final int helperText = 2130903585;
        /* added by DevToolsApp */
        public static final int helperTextEnabled = 2130903586;
        /* added by DevToolsApp */
        public static final int helperTextTextAppearance = 2130903587;
        /* added by DevToolsApp */
        public static final int helperTextTextColor = 2130903588;
        /* added by DevToolsApp */
        public static final int hideAnimationBehavior = 2130903589;
        /* added by DevToolsApp */
        public static final int hideMotionSpec = 2130903590;
        /* added by DevToolsApp */
        public static final int hideNavigationIcon = 2130903591;
        /* added by DevToolsApp */
        public static final int hideOnContentScroll = 2130903592;
        /* added by DevToolsApp */
        public static final int hideOnScroll = 2130903593;
        /* added by DevToolsApp */
        public static final int hintAnimationEnabled = 2130903594;
        /* added by DevToolsApp */
        public static final int hintEnabled = 2130903595;
        /* added by DevToolsApp */
        public static final int hintTextAppearance = 2130903596;
        /* added by DevToolsApp */
        public static final int hintTextColor = 2130903597;
        /* added by DevToolsApp */
        public static final int homeAsUpIndicator = 2130903598;
        /* added by DevToolsApp */
        public static final int homeLayout = 2130903599;
        /* added by DevToolsApp */
        public static final int horizontalOffset = 2130903600;
        /* added by DevToolsApp */
        public static final int horizontalOffsetWithText = 2130903601;
        /* added by DevToolsApp */
        public static final int hoveredFocusedTranslationZ = 2130903602;
        /* added by DevToolsApp */
        public static final int icon = 2130903603;
        /* added by DevToolsApp */
        public static final int iconEndPadding = 2130903604;
        /* added by DevToolsApp */
        public static final int iconGravity = 2130903605;
        /* added by DevToolsApp */
        public static final int iconPadding = 2130903606;
        /* added by DevToolsApp */
        public static final int iconSize = 2130903607;
        /* added by DevToolsApp */
        public static final int iconStartPadding = 2130903608;
        /* added by DevToolsApp */
        public static final int iconTint = 2130903609;
        /* added by DevToolsApp */
        public static final int iconTintMode = 2130903610;
        /* added by DevToolsApp */
        public static final int iconifiedByDefault = 2130903611;
        /* added by DevToolsApp */
        public static final int ifTagNotSet = 2130903612;
        /* added by DevToolsApp */
        public static final int ifTagSet = 2130903613;
        /* added by DevToolsApp */
        public static final int imageAspectRatio = 2130903614;
        /* added by DevToolsApp */
        public static final int imageAspectRatioAdjust = 2130903615;
        /* added by DevToolsApp */
        public static final int imageButtonStyle = 2130903616;
        /* added by DevToolsApp */
        public static final int imagePanX = 2130903617;
        /* added by DevToolsApp */
        public static final int imagePanY = 2130903618;
        /* added by DevToolsApp */
        public static final int imageRotate = 2130903619;
        /* added by DevToolsApp */
        public static final int imageZoom = 2130903620;
        /* added by DevToolsApp */
        public static final int indeterminateAnimationType = 2130903621;
        /* added by DevToolsApp */
        public static final int indeterminateProgressStyle = 2130903622;
        /* added by DevToolsApp */
        public static final int indicatorColor = 2130903623;
        /* added by DevToolsApp */
        public static final int indicatorDirectionCircular = 2130903624;
        /* added by DevToolsApp */
        public static final int indicatorDirectionLinear = 2130903625;
        /* added by DevToolsApp */
        public static final int indicatorInset = 2130903626;
        /* added by DevToolsApp */
        public static final int indicatorSize = 2130903627;
        /* added by DevToolsApp */
        public static final int indicatorTrackGapSize = 2130903628;
        /* added by DevToolsApp */
        public static final int initialActivityCount = 2130903629;
        /* added by DevToolsApp */
        public static final int insetForeground = 2130903630;
        /* added by DevToolsApp */
        public static final int isLightTheme = 2130903631;
        /* added by DevToolsApp */
        public static final int isMaterial3DynamicColorApplied = 2130903632;
        /* added by DevToolsApp */
        public static final int isMaterial3Theme = 2130903633;
        /* added by DevToolsApp */
        public static final int isMaterialTheme = 2130903634;
        /* added by DevToolsApp */
        public static final int itemActiveIndicatorStyle = 2130903635;
        /* added by DevToolsApp */
        public static final int itemBackground = 2130903636;
        /* added by DevToolsApp */
        public static final int itemFillColor = 2130903637;
        /* added by DevToolsApp */
        public static final int itemHorizontalPadding = 2130903638;
        /* added by DevToolsApp */
        public static final int itemHorizontalTranslationEnabled = 2130903639;
        /* added by DevToolsApp */
        public static final int itemIconPadding = 2130903640;
        /* added by DevToolsApp */
        public static final int itemIconSize = 2130903641;
        /* added by DevToolsApp */
        public static final int itemIconTint = 2130903642;
        /* added by DevToolsApp */
        public static final int itemMaxLines = 2130903643;
        /* added by DevToolsApp */
        public static final int itemMinHeight = 2130903644;
        /* added by DevToolsApp */
        public static final int itemPadding = 2130903645;
        /* added by DevToolsApp */
        public static final int itemPaddingBottom = 2130903646;
        /* added by DevToolsApp */
        public static final int itemPaddingTop = 2130903647;
        /* added by DevToolsApp */
        public static final int itemRippleColor = 2130903648;
        /* added by DevToolsApp */
        public static final int itemShapeAppearance = 2130903649;
        /* added by DevToolsApp */
        public static final int itemShapeAppearanceOverlay = 2130903650;
        /* added by DevToolsApp */
        public static final int itemShapeFillColor = 2130903651;
        /* added by DevToolsApp */
        public static final int itemShapeInsetBottom = 2130903652;
        /* added by DevToolsApp */
        public static final int itemShapeInsetEnd = 2130903653;
        /* added by DevToolsApp */
        public static final int itemShapeInsetStart = 2130903654;
        /* added by DevToolsApp */
        public static final int itemShapeInsetTop = 2130903655;
        /* added by DevToolsApp */
        public static final int itemSpacing = 2130903656;
        /* added by DevToolsApp */
        public static final int itemStrokeColor = 2130903657;
        /* added by DevToolsApp */
        public static final int itemStrokeWidth = 2130903658;
        /* added by DevToolsApp */
        public static final int itemTextAppearance = 2130903659;
        /* added by DevToolsApp */
        public static final int itemTextAppearanceActive = 2130903660;
        /* added by DevToolsApp */
        public static final int itemTextAppearanceActiveBoldEnabled = 2130903661;
        /* added by DevToolsApp */
        public static final int itemTextAppearanceInactive = 2130903662;
        /* added by DevToolsApp */
        public static final int itemTextColor = 2130903663;
        /* added by DevToolsApp */
        public static final int itemVerticalPadding = 2130903664;
        /* added by DevToolsApp */
        public static final int keyPositionType = 2130903665;
        /* added by DevToolsApp */
        public static final int keyboardIcon = 2130903666;
        /* added by DevToolsApp */
        public static final int keylines = 2130903667;
        /* added by DevToolsApp */
        public static final int lStar = 2130903668;
        /* added by DevToolsApp */
        public static final int labelBehavior = 2130903669;
        /* added by DevToolsApp */
        public static final int labelStyle = 2130903670;
        /* added by DevToolsApp */
        public static final int labelVisibilityMode = 2130903671;
        /* added by DevToolsApp */
        public static final int largeFontVerticalOffsetAdjustment = 2130903672;
        /* added by DevToolsApp */
        public static final int lastBaselineToBottomHeight = 2130903673;
        /* added by DevToolsApp */
        public static final int lastItemDecorated = 2130903674;
        /* added by DevToolsApp */
        public static final int layout = 2130903675;
        /* added by DevToolsApp */
        public static final int layoutDescription = 2130903676;
        /* added by DevToolsApp */
        public static final int layoutDuringTransition = 2130903677;
        /* added by DevToolsApp */
        public static final int layoutManager = 2130903678;
        /* added by DevToolsApp */
        public static final int layout_anchor = 2130903679;
        /* added by DevToolsApp */
        public static final int layout_anchorGravity = 2130903680;
        /* added by DevToolsApp */
        public static final int layout_behavior = 2130903681;
        /* added by DevToolsApp */
        public static final int layout_collapseMode = 2130903682;
        /* added by DevToolsApp */
        public static final int layout_collapseParallaxMultiplier = 2130903683;
        /* added by DevToolsApp */
        public static final int layout_constrainedHeight = 2130903684;
        /* added by DevToolsApp */
        public static final int layout_constrainedWidth = 2130903685;
        /* added by DevToolsApp */
        public static final int layout_constraintBaseline_creator = 2130903686;
        /* added by DevToolsApp */
        public static final int layout_constraintBaseline_toBaselineOf = 2130903687;
        /* added by DevToolsApp */
        public static final int layout_constraintBaseline_toBottomOf = 2130903688;
        /* added by DevToolsApp */
        public static final int layout_constraintBaseline_toTopOf = 2130903689;
        /* added by DevToolsApp */
        public static final int layout_constraintBottom_creator = 2130903690;
        /* added by DevToolsApp */
        public static final int layout_constraintBottom_toBottomOf = 2130903691;
        /* added by DevToolsApp */
        public static final int layout_constraintBottom_toTopOf = 2130903692;
        /* added by DevToolsApp */
        public static final int layout_constraintCircle = 2130903693;
        /* added by DevToolsApp */
        public static final int layout_constraintCircleAngle = 2130903694;
        /* added by DevToolsApp */
        public static final int layout_constraintCircleRadius = 2130903695;
        /* added by DevToolsApp */
        public static final int layout_constraintDimensionRatio = 2130903696;
        /* added by DevToolsApp */
        public static final int layout_constraintEnd_toEndOf = 2130903697;
        /* added by DevToolsApp */
        public static final int layout_constraintEnd_toStartOf = 2130903698;
        /* added by DevToolsApp */
        public static final int layout_constraintGuide_begin = 2130903699;
        /* added by DevToolsApp */
        public static final int layout_constraintGuide_end = 2130903700;
        /* added by DevToolsApp */
        public static final int layout_constraintGuide_percent = 2130903701;
        /* added by DevToolsApp */
        public static final int layout_constraintHeight = 2130903702;
        /* added by DevToolsApp */
        public static final int layout_constraintHeight_default = 2130903703;
        /* added by DevToolsApp */
        public static final int layout_constraintHeight_max = 2130903704;
        /* added by DevToolsApp */
        public static final int layout_constraintHeight_min = 2130903705;
        /* added by DevToolsApp */
        public static final int layout_constraintHeight_percent = 2130903706;
        /* added by DevToolsApp */
        public static final int layout_constraintHorizontal_bias = 2130903707;
        /* added by DevToolsApp */
        public static final int layout_constraintHorizontal_chainStyle = 2130903708;
        /* added by DevToolsApp */
        public static final int layout_constraintHorizontal_weight = 2130903709;
        /* added by DevToolsApp */
        public static final int layout_constraintLeft_creator = 2130903710;
        /* added by DevToolsApp */
        public static final int layout_constraintLeft_toLeftOf = 2130903711;
        /* added by DevToolsApp */
        public static final int layout_constraintLeft_toRightOf = 2130903712;
        /* added by DevToolsApp */
        public static final int layout_constraintRight_creator = 2130903713;
        /* added by DevToolsApp */
        public static final int layout_constraintRight_toLeftOf = 2130903714;
        /* added by DevToolsApp */
        public static final int layout_constraintRight_toRightOf = 2130903715;
        /* added by DevToolsApp */
        public static final int layout_constraintStart_toEndOf = 2130903716;
        /* added by DevToolsApp */
        public static final int layout_constraintStart_toStartOf = 2130903717;
        /* added by DevToolsApp */
        public static final int layout_constraintTag = 2130903718;
        /* added by DevToolsApp */
        public static final int layout_constraintTop_creator = 2130903719;
        /* added by DevToolsApp */
        public static final int layout_constraintTop_toBottomOf = 2130903720;
        /* added by DevToolsApp */
        public static final int layout_constraintTop_toTopOf = 2130903721;
        /* added by DevToolsApp */
        public static final int layout_constraintVertical_bias = 2130903722;
        /* added by DevToolsApp */
        public static final int layout_constraintVertical_chainStyle = 2130903723;
        /* added by DevToolsApp */
        public static final int layout_constraintVertical_weight = 2130903724;
        /* added by DevToolsApp */
        public static final int layout_constraintWidth = 2130903725;
        /* added by DevToolsApp */
        public static final int layout_constraintWidth_default = 2130903726;
        /* added by DevToolsApp */
        public static final int layout_constraintWidth_max = 2130903727;
        /* added by DevToolsApp */
        public static final int layout_constraintWidth_min = 2130903728;
        /* added by DevToolsApp */
        public static final int layout_constraintWidth_percent = 2130903729;
        /* added by DevToolsApp */
        public static final int layout_dodgeInsetEdges = 2130903730;
        /* added by DevToolsApp */
        public static final int layout_editor_absoluteX = 2130903731;
        /* added by DevToolsApp */
        public static final int layout_editor_absoluteY = 2130903732;
        /* added by DevToolsApp */
        public static final int layout_goneMarginBaseline = 2130903733;
        /* added by DevToolsApp */
        public static final int layout_goneMarginBottom = 2130903734;
        /* added by DevToolsApp */
        public static final int layout_goneMarginEnd = 2130903735;
        /* added by DevToolsApp */
        public static final int layout_goneMarginLeft = 2130903736;
        /* added by DevToolsApp */
        public static final int layout_goneMarginRight = 2130903737;
        /* added by DevToolsApp */
        public static final int layout_goneMarginStart = 2130903738;
        /* added by DevToolsApp */
        public static final int layout_goneMarginTop = 2130903739;
        /* added by DevToolsApp */
        public static final int layout_insetEdge = 2130903740;
        /* added by DevToolsApp */
        public static final int layout_keyline = 2130903741;
        /* added by DevToolsApp */
        public static final int layout_marginBaseline = 2130903742;
        /* added by DevToolsApp */
        public static final int layout_optimizationLevel = 2130903743;
        /* added by DevToolsApp */
        public static final int layout_scrollEffect = 2130903744;
        /* added by DevToolsApp */
        public static final int layout_scrollFlags = 2130903745;
        /* added by DevToolsApp */
        public static final int layout_scrollInterpolator = 2130903746;
        /* added by DevToolsApp */
        public static final int layout_wrapBehaviorInParent = 2130903747;
        /* added by DevToolsApp */
        public static final int liftOnScroll = 2130903748;
        /* added by DevToolsApp */
        public static final int liftOnScrollColor = 2130903749;
        /* added by DevToolsApp */
        public static final int liftOnScrollTargetViewId = 2130903750;
        /* added by DevToolsApp */
        public static final int limitBoundsTo = 2130903751;
        /* added by DevToolsApp */
        public static final int lineHeight = 2130903752;
        /* added by DevToolsApp */
        public static final int lineSpacing = 2130903753;
        /* added by DevToolsApp */
        public static final int linearProgressIndicatorStyle = 2130903754;
        /* added by DevToolsApp */
        public static final int listChoiceBackgroundIndicator = 2130903755;
        /* added by DevToolsApp */
        public static final int listChoiceIndicatorMultipleAnimated = 2130903756;
        /* added by DevToolsApp */
        public static final int listChoiceIndicatorSingleAnimated = 2130903757;
        /* added by DevToolsApp */
        public static final int listDividerAlertDialog = 2130903758;
        /* added by DevToolsApp */
        public static final int listItemLayout = 2130903759;
        /* added by DevToolsApp */
        public static final int listLayout = 2130903760;
        /* added by DevToolsApp */
        public static final int listMenuViewStyle = 2130903761;
        /* added by DevToolsApp */
        public static final int listPopupWindowStyle = 2130903762;
        /* added by DevToolsApp */
        public static final int listPreferredItemHeight = 2130903763;
        /* added by DevToolsApp */
        public static final int listPreferredItemHeightLarge = 2130903764;
        /* added by DevToolsApp */
        public static final int listPreferredItemHeightSmall = 2130903765;
        /* added by DevToolsApp */
        public static final int listPreferredItemPaddingEnd = 2130903766;
        /* added by DevToolsApp */
        public static final int listPreferredItemPaddingLeft = 2130903767;
        /* added by DevToolsApp */
        public static final int listPreferredItemPaddingRight = 2130903768;
        /* added by DevToolsApp */
        public static final int listPreferredItemPaddingStart = 2130903769;
        /* added by DevToolsApp */
        public static final int logo = 2130903770;
        /* added by DevToolsApp */
        public static final int logoAdjustViewBounds = 2130903771;
        /* added by DevToolsApp */
        public static final int logoDescription = 2130903772;
        /* added by DevToolsApp */
        public static final int logoScaleType = 2130903773;
        /* added by DevToolsApp */
        public static final int marginHorizontal = 2130903774;
        /* added by DevToolsApp */
        public static final int marginLeftSystemWindowInsets = 2130903775;
        /* added by DevToolsApp */
        public static final int marginRightSystemWindowInsets = 2130903776;
        /* added by DevToolsApp */
        public static final int marginTopSystemWindowInsets = 2130903777;
        /* added by DevToolsApp */
        public static final int materialAlertDialogBodyTextStyle = 2130903778;
        /* added by DevToolsApp */
        public static final int materialAlertDialogButtonSpacerVisibility = 2130903779;
        /* added by DevToolsApp */
        public static final int materialAlertDialogTheme = 2130903780;
        /* added by DevToolsApp */
        public static final int materialAlertDialogTitleIconStyle = 2130903781;
        /* added by DevToolsApp */
        public static final int materialAlertDialogTitlePanelStyle = 2130903782;
        /* added by DevToolsApp */
        public static final int materialAlertDialogTitleTextStyle = 2130903783;
        /* added by DevToolsApp */
        public static final int materialButtonOutlinedStyle = 2130903784;
        /* added by DevToolsApp */
        public static final int materialButtonStyle = 2130903785;
        /* added by DevToolsApp */
        public static final int materialButtonToggleGroupStyle = 2130903786;
        /* added by DevToolsApp */
        public static final int materialCalendarDay = 2130903787;
        /* added by DevToolsApp */
        public static final int materialCalendarDayOfWeekLabel = 2130903788;
        /* added by DevToolsApp */
        public static final int materialCalendarFullscreenTheme = 2130903789;
        /* added by DevToolsApp */
        public static final int materialCalendarHeaderCancelButton = 2130903790;
        /* added by DevToolsApp */
        public static final int materialCalendarHeaderConfirmButton = 2130903791;
        /* added by DevToolsApp */
        public static final int materialCalendarHeaderDivider = 2130903792;
        /* added by DevToolsApp */
        public static final int materialCalendarHeaderLayout = 2130903793;
        /* added by DevToolsApp */
        public static final int materialCalendarHeaderSelection = 2130903794;
        /* added by DevToolsApp */
        public static final int materialCalendarHeaderTitle = 2130903795;
        /* added by DevToolsApp */
        public static final int materialCalendarHeaderToggleButton = 2130903796;
        /* added by DevToolsApp */
        public static final int materialCalendarMonth = 2130903797;
        /* added by DevToolsApp */
        public static final int materialCalendarMonthNavigationButton = 2130903798;
        /* added by DevToolsApp */
        public static final int materialCalendarStyle = 2130903799;
        /* added by DevToolsApp */
        public static final int materialCalendarTheme = 2130903800;
        /* added by DevToolsApp */
        public static final int materialCalendarYearNavigationButton = 2130903801;
        /* added by DevToolsApp */
        public static final int materialCardViewElevatedStyle = 2130903802;
        /* added by DevToolsApp */
        public static final int materialCardViewFilledStyle = 2130903803;
        /* added by DevToolsApp */
        public static final int materialCardViewOutlinedStyle = 2130903804;
        /* added by DevToolsApp */
        public static final int materialCardViewStyle = 2130903805;
        /* added by DevToolsApp */
        public static final int materialCircleRadius = 2130903806;
        /* added by DevToolsApp */
        public static final int materialClockStyle = 2130903807;
        /* added by DevToolsApp */
        public static final int materialDisplayDividerStyle = 2130903808;
        /* added by DevToolsApp */
        public static final int materialDividerHeavyStyle = 2130903809;
        /* added by DevToolsApp */
        public static final int materialDividerStyle = 2130903810;
        /* added by DevToolsApp */
        public static final int materialIconButtonFilledStyle = 2130903811;
        /* added by DevToolsApp */
        public static final int materialIconButtonFilledTonalStyle = 2130903812;
        /* added by DevToolsApp */
        public static final int materialIconButtonOutlinedStyle = 2130903813;
        /* added by DevToolsApp */
        public static final int materialIconButtonStyle = 2130903814;
        /* added by DevToolsApp */
        public static final int materialSearchBarStyle = 2130903815;
        /* added by DevToolsApp */
        public static final int materialSearchViewPrefixStyle = 2130903816;
        /* added by DevToolsApp */
        public static final int materialSearchViewStyle = 2130903817;
        /* added by DevToolsApp */
        public static final int materialSearchViewToolbarHeight = 2130903818;
        /* added by DevToolsApp */
        public static final int materialSearchViewToolbarStyle = 2130903819;
        /* added by DevToolsApp */
        public static final int materialSwitchStyle = 2130903820;
        /* added by DevToolsApp */
        public static final int materialThemeOverlay = 2130903821;
        /* added by DevToolsApp */
        public static final int materialTimePickerStyle = 2130903822;
        /* added by DevToolsApp */
        public static final int materialTimePickerTheme = 2130903823;
        /* added by DevToolsApp */
        public static final int materialTimePickerTitleStyle = 2130903824;
        /* added by DevToolsApp */
        public static final int maxAcceleration = 2130903825;
        /* added by DevToolsApp */
        public static final int maxActionInlineWidth = 2130903826;
        /* added by DevToolsApp */
        public static final int maxButtonHeight = 2130903827;
        /* added by DevToolsApp */
        public static final int maxCharacterCount = 2130903828;
        /* added by DevToolsApp */
        public static final int maxHeight = 2130903829;
        /* added by DevToolsApp */
        public static final int maxImageSize = 2130903830;
        /* added by DevToolsApp */
        public static final int maxLines = 2130903831;
        /* added by DevToolsApp */
        public static final int maxNumber = 2130903832;
        /* added by DevToolsApp */
        public static final int maxVelocity = 2130903833;
        /* added by DevToolsApp */
        public static final int maxWidth = 2130903834;
        /* added by DevToolsApp */
        public static final int measureWithLargestChild = 2130903835;
        /* added by DevToolsApp */
        public static final int menu = 2130903836;
        /* added by DevToolsApp */
        public static final int menuAlignmentMode = 2130903837;
        /* added by DevToolsApp */
        public static final int menuGravity = 2130903838;
        /* added by DevToolsApp */
        public static final int methodName = 2130903839;
        /* added by DevToolsApp */
        public static final int minHeight = 2130903840;
        /* added by DevToolsApp */
        public static final int minHideDelay = 2130903841;
        /* added by DevToolsApp */
        public static final int minSeparation = 2130903842;
        /* added by DevToolsApp */
        public static final int minTouchTargetSize = 2130903843;
        /* added by DevToolsApp */
        public static final int minWidth = 2130903844;
        /* added by DevToolsApp */
        public static final int mock_diagonalsColor = 2130903845;
        /* added by DevToolsApp */
        public static final int mock_label = 2130903846;
        /* added by DevToolsApp */
        public static final int mock_labelBackgroundColor = 2130903847;
        /* added by DevToolsApp */
        public static final int mock_labelColor = 2130903848;
        /* added by DevToolsApp */
        public static final int mock_showDiagonals = 2130903849;
        /* added by DevToolsApp */
        public static final int mock_showLabel = 2130903850;
        /* added by DevToolsApp */
        public static final int motionDebug = 2130903851;
        /* added by DevToolsApp */
        public static final int motionDurationExtraLong1 = 2130903852;
        /* added by DevToolsApp */
        public static final int motionDurationExtraLong2 = 2130903853;
        /* added by DevToolsApp */
        public static final int motionDurationExtraLong3 = 2130903854;
        /* added by DevToolsApp */
        public static final int motionDurationExtraLong4 = 2130903855;
        /* added by DevToolsApp */
        public static final int motionDurationLong1 = 2130903856;
        /* added by DevToolsApp */
        public static final int motionDurationLong2 = 2130903857;
        /* added by DevToolsApp */
        public static final int motionDurationLong3 = 2130903858;
        /* added by DevToolsApp */
        public static final int motionDurationLong4 = 2130903859;
        /* added by DevToolsApp */
        public static final int motionDurationMedium1 = 2130903860;
        /* added by DevToolsApp */
        public static final int motionDurationMedium2 = 2130903861;
        /* added by DevToolsApp */
        public static final int motionDurationMedium3 = 2130903862;
        /* added by DevToolsApp */
        public static final int motionDurationMedium4 = 2130903863;
        /* added by DevToolsApp */
        public static final int motionDurationShort1 = 2130903864;
        /* added by DevToolsApp */
        public static final int motionDurationShort2 = 2130903865;
        /* added by DevToolsApp */
        public static final int motionDurationShort3 = 2130903866;
        /* added by DevToolsApp */
        public static final int motionDurationShort4 = 2130903867;
        /* added by DevToolsApp */
        public static final int motionEasingAccelerated = 2130903868;
        /* added by DevToolsApp */
        public static final int motionEasingDecelerated = 2130903869;
        /* added by DevToolsApp */
        public static final int motionEasingEmphasized = 2130903870;
        /* added by DevToolsApp */
        public static final int motionEasingEmphasizedAccelerateInterpolator = 2130903871;
        /* added by DevToolsApp */
        public static final int motionEasingEmphasizedDecelerateInterpolator = 2130903872;
        /* added by DevToolsApp */
        public static final int motionEasingEmphasizedInterpolator = 2130903873;
        /* added by DevToolsApp */
        public static final int motionEasingLinear = 2130903874;
        /* added by DevToolsApp */
        public static final int motionEasingLinearInterpolator = 2130903875;
        /* added by DevToolsApp */
        public static final int motionEasingStandard = 2130903876;
        /* added by DevToolsApp */
        public static final int motionEasingStandardAccelerateInterpolator = 2130903877;
        /* added by DevToolsApp */
        public static final int motionEasingStandardDecelerateInterpolator = 2130903878;
        /* added by DevToolsApp */
        public static final int motionEasingStandardInterpolator = 2130903879;
        /* added by DevToolsApp */
        public static final int motionEffect_alpha = 2130903880;
        /* added by DevToolsApp */
        public static final int motionEffect_end = 2130903881;
        /* added by DevToolsApp */
        public static final int motionEffect_move = 2130903882;
        /* added by DevToolsApp */
        public static final int motionEffect_start = 2130903883;
        /* added by DevToolsApp */
        public static final int motionEffect_strict = 2130903884;
        /* added by DevToolsApp */
        public static final int motionEffect_translationX = 2130903885;
        /* added by DevToolsApp */
        public static final int motionEffect_translationY = 2130903886;
        /* added by DevToolsApp */
        public static final int motionEffect_viewTransition = 2130903887;
        /* added by DevToolsApp */
        public static final int motionInterpolator = 2130903888;
        /* added by DevToolsApp */
        public static final int motionPath = 2130903889;
        /* added by DevToolsApp */
        public static final int motionPathRotate = 2130903890;
        /* added by DevToolsApp */
        public static final int motionProgress = 2130903891;
        /* added by DevToolsApp */
        public static final int motionStagger = 2130903892;
        /* added by DevToolsApp */
        public static final int motionTarget = 2130903893;
        /* added by DevToolsApp */
        public static final int motion_postLayoutCollision = 2130903894;
        /* added by DevToolsApp */
        public static final int motion_triggerOnCollision = 2130903895;
        /* added by DevToolsApp */
        public static final int moveWhenScrollAtTop = 2130903896;
        /* added by DevToolsApp */
        public static final int multiChoiceItemLayout = 2130903897;
        /* added by DevToolsApp */
        public static final int navigationContentDescription = 2130903898;
        /* added by DevToolsApp */
        public static final int navigationIcon = 2130903899;
        /* added by DevToolsApp */
        public static final int navigationIconTint = 2130903900;
        /* added by DevToolsApp */
        public static final int navigationMode = 2130903901;
        /* added by DevToolsApp */
        public static final int navigationRailStyle = 2130903902;
        /* added by DevToolsApp */
        public static final int navigationViewStyle = 2130903903;
        /* added by DevToolsApp */
        public static final int nestedScrollFlags = 2130903904;
        /* added by DevToolsApp */
        public static final int nestedScrollViewStyle = 2130903905;
        /* added by DevToolsApp */
        public static final int nestedScrollable = 2130903906;
        /* added by DevToolsApp */
        public static final int number = 2130903907;
        /* added by DevToolsApp */
        public static final int numericModifiers = 2130903908;
        /* added by DevToolsApp */
        public static final int offsetAlignmentMode = 2130903909;
        /* added by DevToolsApp */
        public static final int onCross = 2130903910;
        /* added by DevToolsApp */
        public static final int onHide = 2130903911;
        /* added by DevToolsApp */
        public static final int onNegativeCross = 2130903912;
        /* added by DevToolsApp */
        public static final int onPositiveCross = 2130903913;
        /* added by DevToolsApp */
        public static final int onShow = 2130903914;
        /* added by DevToolsApp */
        public static final int onStateTransition = 2130903915;
        /* added by DevToolsApp */
        public static final int onTouchUp = 2130903916;
        /* added by DevToolsApp */
        public static final int overlapAnchor = 2130903917;
        /* added by DevToolsApp */
        public static final int overlay = 2130903918;
        /* added by DevToolsApp */
        public static final int paddingBottomNoButtons = 2130903919;
        /* added by DevToolsApp */
        public static final int paddingBottomSystemWindowInsets = 2130903920;
        /* added by DevToolsApp */
        public static final int paddingEnd = 2130903921;
        /* added by DevToolsApp */
        public static final int paddingLeftSystemWindowInsets = 2130903922;
        /* added by DevToolsApp */
        public static final int paddingRightSystemWindowInsets = 2130903923;
        /* added by DevToolsApp */
        public static final int paddingStart = 2130903924;
        /* added by DevToolsApp */
        public static final int paddingStartSystemWindowInsets = 2130903925;
        /* added by DevToolsApp */
        public static final int paddingTopNoTitle = 2130903926;
        /* added by DevToolsApp */
        public static final int paddingTopSystemWindowInsets = 2130903927;
        /* added by DevToolsApp */
        public static final int panelBackground = 2130903928;
        /* added by DevToolsApp */
        public static final int panelMenuListTheme = 2130903929;
        /* added by DevToolsApp */
        public static final int panelMenuListWidth = 2130903930;
        /* added by DevToolsApp */
        public static final int passwordToggleContentDescription = 2130903931;
        /* added by DevToolsApp */
        public static final int passwordToggleDrawable = 2130903932;
        /* added by DevToolsApp */
        public static final int passwordToggleEnabled = 2130903933;
        /* added by DevToolsApp */
        public static final int passwordToggleTint = 2130903934;
        /* added by DevToolsApp */
        public static final int passwordToggleTintMode = 2130903935;
        /* added by DevToolsApp */
        public static final int pathMotionArc = 2130903936;
        /* added by DevToolsApp */
        public static final int path_percent = 2130903937;
        /* added by DevToolsApp */
        public static final int percentHeight = 2130903938;
        /* added by DevToolsApp */
        public static final int percentWidth = 2130903939;
        /* added by DevToolsApp */
        public static final int percentX = 2130903940;
        /* added by DevToolsApp */
        public static final int percentY = 2130903941;
        /* added by DevToolsApp */
        public static final int perpendicularPath_percent = 2130903942;
        /* added by DevToolsApp */
        public static final int pivotAnchor = 2130903943;
        /* added by DevToolsApp */
        public static final int placeholderText = 2130903944;
        /* added by DevToolsApp */
        public static final int placeholderTextAppearance = 2130903945;
        /* added by DevToolsApp */
        public static final int placeholderTextColor = 2130903946;
        /* added by DevToolsApp */
        public static final int placeholder_emptyVisibility = 2130903947;
        /* added by DevToolsApp */
        public static final int polarRelativeTo = 2130903948;
        /* added by DevToolsApp */
        public static final int popupMenuBackground = 2130903949;
        /* added by DevToolsApp */
        public static final int popupMenuStyle = 2130903950;
        /* added by DevToolsApp */
        public static final int popupTheme = 2130903951;
        /* added by DevToolsApp */
        public static final int popupWindowStyle = 2130903952;
        /* added by DevToolsApp */
        public static final int prefixText = 2130903953;
        /* added by DevToolsApp */
        public static final int prefixTextAppearance = 2130903954;
        /* added by DevToolsApp */
        public static final int prefixTextColor = 2130903955;
        /* added by DevToolsApp */
        public static final int preserveIconSpacing = 2130903956;
        /* added by DevToolsApp */
        public static final int pressedTranslationZ = 2130903957;
        /* added by DevToolsApp */
        public static final int progressBarPadding = 2130903958;
        /* added by DevToolsApp */
        public static final int progressBarStyle = 2130903959;
        /* added by DevToolsApp */
        public static final int quantizeMotionInterpolator = 2130903960;
        /* added by DevToolsApp */
        public static final int quantizeMotionPhase = 2130903961;
        /* added by DevToolsApp */
        public static final int quantizeMotionSteps = 2130903962;
        /* added by DevToolsApp */
        public static final int queryBackground = 2130903963;
        /* added by DevToolsApp */
        public static final int queryHint = 2130903964;
        /* added by DevToolsApp */
        public static final int queryPatterns = 2130903965;
        /* added by DevToolsApp */
        public static final int radioButtonStyle = 2130903966;
        /* added by DevToolsApp */
        public static final int rangeFillColor = 2130903967;
        /* added by DevToolsApp */
        public static final int ratingBarStyle = 2130903968;
        /* added by DevToolsApp */
        public static final int ratingBarStyleIndicator = 2130903969;
        /* added by DevToolsApp */
        public static final int ratingBarStyleSmall = 2130903970;
        /* added by DevToolsApp */
        public static final int reactiveGuide_animateChange = 2130903971;
        /* added by DevToolsApp */
        public static final int reactiveGuide_applyToAllConstraintSets = 2130903972;
        /* added by DevToolsApp */
        public static final int reactiveGuide_applyToConstraintSet = 2130903973;
        /* added by DevToolsApp */
        public static final int reactiveGuide_valueId = 2130903974;
        /* added by DevToolsApp */
        public static final int recyclerViewStyle = 2130903975;
        /* added by DevToolsApp */
        public static final int region_heightLessThan = 2130903976;
        /* added by DevToolsApp */
        public static final int region_heightMoreThan = 2130903977;
        /* added by DevToolsApp */
        public static final int region_widthLessThan = 2130903978;
        /* added by DevToolsApp */
        public static final int region_widthMoreThan = 2130903979;
        /* added by DevToolsApp */
        public static final int removeEmbeddedFabElevation = 2130903980;
        /* added by DevToolsApp */
        public static final int reverseLayout = 2130903981;
        /* added by DevToolsApp */
        public static final int rippleColor = 2130903982;
        /* added by DevToolsApp */
        public static final int rotationCenterId = 2130903983;
        /* added by DevToolsApp */
        public static final int round = 2130903984;
        /* added by DevToolsApp */
        public static final int roundPercent = 2130903985;
        /* added by DevToolsApp */
        public static final int saturation = 2130903986;
        /* added by DevToolsApp */
        public static final int scaleFromTextSize = 2130903987;
        /* added by DevToolsApp */
        public static final int scopeUris = 2130903988;
        /* added by DevToolsApp */
        public static final int scrimAnimationDuration = 2130903989;
        /* added by DevToolsApp */
        public static final int scrimBackground = 2130903990;
        /* added by DevToolsApp */
        public static final int scrimVisibleHeightTrigger = 2130903991;
        /* added by DevToolsApp */
        public static final int searchHintIcon = 2130903992;
        /* added by DevToolsApp */
        public static final int searchIcon = 2130903993;
        /* added by DevToolsApp */
        public static final int searchPrefixText = 2130903994;
        /* added by DevToolsApp */
        public static final int searchViewStyle = 2130903995;
        /* added by DevToolsApp */
        public static final int seekBarStyle = 2130903996;
        /* added by DevToolsApp */
        public static final int selectableItemBackground = 2130903997;
        /* added by DevToolsApp */
        public static final int selectableItemBackgroundBorderless = 2130903998;
        /* added by DevToolsApp */
        public static final int selectionRequired = 2130903999;
        /* added by DevToolsApp */
        public static final int selectorSize = 2130904000;
        /* added by DevToolsApp */
        public static final int setsTag = 2130904001;
        /* added by DevToolsApp */
        public static final int shapeAppearance = 2130904002;
        /* added by DevToolsApp */
        public static final int shapeAppearanceCornerExtraLarge = 2130904003;
        /* added by DevToolsApp */
        public static final int shapeAppearanceCornerExtraSmall = 2130904004;
        /* added by DevToolsApp */
        public static final int shapeAppearanceCornerLarge = 2130904005;
        /* added by DevToolsApp */
        public static final int shapeAppearanceCornerMedium = 2130904006;
        /* added by DevToolsApp */
        public static final int shapeAppearanceCornerSmall = 2130904007;
        /* added by DevToolsApp */
        public static final int shapeAppearanceLargeComponent = 2130904008;
        /* added by DevToolsApp */
        public static final int shapeAppearanceMediumComponent = 2130904009;
        /* added by DevToolsApp */
        public static final int shapeAppearanceOverlay = 2130904010;
        /* added by DevToolsApp */
        public static final int shapeAppearanceSmallComponent = 2130904011;
        /* added by DevToolsApp */
        public static final int shapeCornerFamily = 2130904012;
        /* added by DevToolsApp */
        public static final int shortcutMatchRequired = 2130904013;
        /* added by DevToolsApp */
        public static final int shouldRemoveExpandedCorners = 2130904014;
        /* added by DevToolsApp */
        public static final int showAnimationBehavior = 2130904015;
        /* added by DevToolsApp */
        public static final int showAsAction = 2130904016;
        /* added by DevToolsApp */
        public static final int showDelay = 2130904017;
        /* added by DevToolsApp */
        public static final int showDividers = 2130904018;
        /* added by DevToolsApp */
        public static final int showMarker = 2130904019;
        /* added by DevToolsApp */
        public static final int showMotionSpec = 2130904020;
        /* added by DevToolsApp */
        public static final int showPaths = 2130904021;
        /* added by DevToolsApp */
        public static final int showText = 2130904022;
        /* added by DevToolsApp */
        public static final int showTitle = 2130904023;
        /* added by DevToolsApp */
        public static final int shrinkMotionSpec = 2130904024;
        /* added by DevToolsApp */
        public static final int sideSheetDialogTheme = 2130904025;
        /* added by DevToolsApp */
        public static final int sideSheetModalStyle = 2130904026;
        /* added by DevToolsApp */
        public static final int simpleItemLayout = 2130904027;
        /* added by DevToolsApp */
        public static final int simpleItemSelectedColor = 2130904028;
        /* added by DevToolsApp */
        public static final int simpleItemSelectedRippleColor = 2130904029;
        /* added by DevToolsApp */
        public static final int simpleItems = 2130904030;
        /* added by DevToolsApp */
        public static final int singleChoiceItemLayout = 2130904031;
        /* added by DevToolsApp */
        public static final int singleLine = 2130904032;
        /* added by DevToolsApp */
        public static final int singleSelection = 2130904033;
        /* added by DevToolsApp */
        public static final int sizePercent = 2130904034;
        /* added by DevToolsApp */
        public static final int sliderStyle = 2130904035;
        /* added by DevToolsApp */
        public static final int snackbarButtonStyle = 2130904036;
        /* added by DevToolsApp */
        public static final int snackbarStyle = 2130904037;
        /* added by DevToolsApp */
        public static final int snackbarTextViewStyle = 2130904038;
        /* added by DevToolsApp */
        public static final int spanCount = 2130904039;
        /* added by DevToolsApp */
        public static final int spinBars = 2130904040;
        /* added by DevToolsApp */
        public static final int spinnerDropDownItemStyle = 2130904041;
        /* added by DevToolsApp */
        public static final int spinnerStyle = 2130904042;
        /* added by DevToolsApp */
        public static final int splitTrack = 2130904043;
        /* added by DevToolsApp */
        public static final int springBoundary = 2130904044;
        /* added by DevToolsApp */
        public static final int springDamping = 2130904045;
        /* added by DevToolsApp */
        public static final int springMass = 2130904046;
        /* added by DevToolsApp */
        public static final int springStiffness = 2130904047;
        /* added by DevToolsApp */
        public static final int springStopThreshold = 2130904048;
        /* added by DevToolsApp */
        public static final int srcCompat = 2130904049;
        /* added by DevToolsApp */
        public static final int stackFromEnd = 2130904050;
        /* added by DevToolsApp */
        public static final int staggered = 2130904051;
        /* added by DevToolsApp */
        public static final int startIconCheckable = 2130904052;
        /* added by DevToolsApp */
        public static final int startIconContentDescription = 2130904053;
        /* added by DevToolsApp */
        public static final int startIconDrawable = 2130904054;
        /* added by DevToolsApp */
        public static final int startIconMinSize = 2130904055;
        /* added by DevToolsApp */
        public static final int startIconScaleType = 2130904056;
        /* added by DevToolsApp */
        public static final int startIconTint = 2130904057;
        /* added by DevToolsApp */
        public static final int startIconTintMode = 2130904058;
        /* added by DevToolsApp */
        public static final int stateLabels = 2130904059;
        /* added by DevToolsApp */
        public static final int state_above_anchor = 2130904060;
        /* added by DevToolsApp */
        public static final int state_collapsed = 2130904061;
        /* added by DevToolsApp */
        public static final int state_collapsible = 2130904062;
        /* added by DevToolsApp */
        public static final int state_dragged = 2130904063;
        /* added by DevToolsApp */
        public static final int state_error = 2130904064;
        /* added by DevToolsApp */
        public static final int state_indeterminate = 2130904065;
        /* added by DevToolsApp */
        public static final int state_liftable = 2130904066;
        /* added by DevToolsApp */
        public static final int state_lifted = 2130904067;
        /* added by DevToolsApp */
        public static final int state_with_icon = 2130904068;
        /* added by DevToolsApp */
        public static final int statusBarBackground = 2130904069;
        /* added by DevToolsApp */
        public static final int statusBarForeground = 2130904070;
        /* added by DevToolsApp */
        public static final int statusBarScrim = 2130904071;
        /* added by DevToolsApp */
        public static final int strokeColor = 2130904072;
        /* added by DevToolsApp */
        public static final int strokeWidth = 2130904073;
        /* added by DevToolsApp */
        public static final int subMenuArrow = 2130904074;
        /* added by DevToolsApp */
        public static final int subheaderColor = 2130904075;
        /* added by DevToolsApp */
        public static final int subheaderInsetEnd = 2130904076;
        /* added by DevToolsApp */
        public static final int subheaderInsetStart = 2130904077;
        /* added by DevToolsApp */
        public static final int subheaderTextAppearance = 2130904078;
        /* added by DevToolsApp */
        public static final int submitBackground = 2130904079;
        /* added by DevToolsApp */
        public static final int subtitle = 2130904080;
        /* added by DevToolsApp */
        public static final int subtitleCentered = 2130904081;
        /* added by DevToolsApp */
        public static final int subtitleTextAppearance = 2130904082;
        /* added by DevToolsApp */
        public static final int subtitleTextColor = 2130904083;
        /* added by DevToolsApp */
        public static final int subtitleTextStyle = 2130904084;
        /* added by DevToolsApp */
        public static final int suffixText = 2130904085;
        /* added by DevToolsApp */
        public static final int suffixTextAppearance = 2130904086;
        /* added by DevToolsApp */
        public static final int suffixTextColor = 2130904087;
        /* added by DevToolsApp */
        public static final int suggestionRowLayout = 2130904088;
        /* added by DevToolsApp */
        public static final int switchMinWidth = 2130904089;
        /* added by DevToolsApp */
        public static final int switchPadding = 2130904090;
        /* added by DevToolsApp */
        public static final int switchStyle = 2130904091;
        /* added by DevToolsApp */
        public static final int switchTextAppearance = 2130904092;
        /* added by DevToolsApp */
        public static final int tabBackground = 2130904093;
        /* added by DevToolsApp */
        public static final int tabContentStart = 2130904094;
        /* added by DevToolsApp */
        public static final int tabGravity = 2130904095;
        /* added by DevToolsApp */
        public static final int tabIconTint = 2130904096;
        /* added by DevToolsApp */
        public static final int tabIconTintMode = 2130904097;
        /* added by DevToolsApp */
        public static final int tabIndicator = 2130904098;
        /* added by DevToolsApp */
        public static final int tabIndicatorAnimationDuration = 2130904099;
        /* added by DevToolsApp */
        public static final int tabIndicatorAnimationMode = 2130904100;
        /* added by DevToolsApp */
        public static final int tabIndicatorColor = 2130904101;
        /* added by DevToolsApp */
        public static final int tabIndicatorFullWidth = 2130904102;
        /* added by DevToolsApp */
        public static final int tabIndicatorGravity = 2130904103;
        /* added by DevToolsApp */
        public static final int tabIndicatorHeight = 2130904104;
        /* added by DevToolsApp */
        public static final int tabInlineLabel = 2130904105;
        /* added by DevToolsApp */
        public static final int tabMaxWidth = 2130904106;
        /* added by DevToolsApp */
        public static final int tabMinWidth = 2130904107;
        /* added by DevToolsApp */
        public static final int tabMode = 2130904108;
        /* added by DevToolsApp */
        public static final int tabPadding = 2130904109;
        /* added by DevToolsApp */
        public static final int tabPaddingBottom = 2130904110;
        /* added by DevToolsApp */
        public static final int tabPaddingEnd = 2130904111;
        /* added by DevToolsApp */
        public static final int tabPaddingStart = 2130904112;
        /* added by DevToolsApp */
        public static final int tabPaddingTop = 2130904113;
        /* added by DevToolsApp */
        public static final int tabRippleColor = 2130904114;
        /* added by DevToolsApp */
        public static final int tabSecondaryStyle = 2130904115;
        /* added by DevToolsApp */
        public static final int tabSelectedTextAppearance = 2130904116;
        /* added by DevToolsApp */
        public static final int tabSelectedTextColor = 2130904117;
        /* added by DevToolsApp */
        public static final int tabStyle = 2130904118;
        /* added by DevToolsApp */
        public static final int tabTextAppearance = 2130904119;
        /* added by DevToolsApp */
        public static final int tabTextColor = 2130904120;
        /* added by DevToolsApp */
        public static final int tabUnboundedRipple = 2130904121;
        /* added by DevToolsApp */
        public static final int targetId = 2130904122;
        /* added by DevToolsApp */
        public static final int telltales_tailColor = 2130904123;
        /* added by DevToolsApp */
        public static final int telltales_tailScale = 2130904124;
        /* added by DevToolsApp */
        public static final int telltales_velocityMode = 2130904125;
        /* added by DevToolsApp */
        public static final int textAllCaps = 2130904126;
        /* added by DevToolsApp */
        public static final int textAppearanceBody1 = 2130904127;
        /* added by DevToolsApp */
        public static final int textAppearanceBody2 = 2130904128;
        /* added by DevToolsApp */
        public static final int textAppearanceBodyLarge = 2130904129;
        /* added by DevToolsApp */
        public static final int textAppearanceBodyMedium = 2130904130;
        /* added by DevToolsApp */
        public static final int textAppearanceBodySmall = 2130904131;
        /* added by DevToolsApp */
        public static final int textAppearanceButton = 2130904132;
        /* added by DevToolsApp */
        public static final int textAppearanceCaption = 2130904133;
        /* added by DevToolsApp */
        public static final int textAppearanceDisplayLarge = 2130904134;
        /* added by DevToolsApp */
        public static final int textAppearanceDisplayMedium = 2130904135;
        /* added by DevToolsApp */
        public static final int textAppearanceDisplaySmall = 2130904136;
        /* added by DevToolsApp */
        public static final int textAppearanceHeadline1 = 2130904137;
        /* added by DevToolsApp */
        public static final int textAppearanceHeadline2 = 2130904138;
        /* added by DevToolsApp */
        public static final int textAppearanceHeadline3 = 2130904139;
        /* added by DevToolsApp */
        public static final int textAppearanceHeadline4 = 2130904140;
        /* added by DevToolsApp */
        public static final int textAppearanceHeadline5 = 2130904141;
        /* added by DevToolsApp */
        public static final int textAppearanceHeadline6 = 2130904142;
        /* added by DevToolsApp */
        public static final int textAppearanceHeadlineLarge = 2130904143;
        /* added by DevToolsApp */
        public static final int textAppearanceHeadlineMedium = 2130904144;
        /* added by DevToolsApp */
        public static final int textAppearanceHeadlineSmall = 2130904145;
        /* added by DevToolsApp */
        public static final int textAppearanceLabelLarge = 2130904146;
        /* added by DevToolsApp */
        public static final int textAppearanceLabelMedium = 2130904147;
        /* added by DevToolsApp */
        public static final int textAppearanceLabelSmall = 2130904148;
        /* added by DevToolsApp */
        public static final int textAppearanceLargePopupMenu = 2130904149;
        /* added by DevToolsApp */
        public static final int textAppearanceLineHeightEnabled = 2130904150;
        /* added by DevToolsApp */
        public static final int textAppearanceListItem = 2130904151;
        /* added by DevToolsApp */
        public static final int textAppearanceListItemSecondary = 2130904152;
        /* added by DevToolsApp */
        public static final int textAppearanceListItemSmall = 2130904153;
        /* added by DevToolsApp */
        public static final int textAppearanceOverline = 2130904154;
        /* added by DevToolsApp */
        public static final int textAppearancePopupMenuHeader = 2130904155;
        /* added by DevToolsApp */
        public static final int textAppearanceSearchResultSubtitle = 2130904156;
        /* added by DevToolsApp */
        public static final int textAppearanceSearchResultTitle = 2130904157;
        /* added by DevToolsApp */
        public static final int textAppearanceSmallPopupMenu = 2130904158;
        /* added by DevToolsApp */
        public static final int textAppearanceSubtitle1 = 2130904159;
        /* added by DevToolsApp */
        public static final int textAppearanceSubtitle2 = 2130904160;
        /* added by DevToolsApp */
        public static final int textAppearanceTitleLarge = 2130904161;
        /* added by DevToolsApp */
        public static final int textAppearanceTitleMedium = 2130904162;
        /* added by DevToolsApp */
        public static final int textAppearanceTitleSmall = 2130904163;
        /* added by DevToolsApp */
        public static final int textBackground = 2130904164;
        /* added by DevToolsApp */
        public static final int textBackgroundPanX = 2130904165;
        /* added by DevToolsApp */
        public static final int textBackgroundPanY = 2130904166;
        /* added by DevToolsApp */
        public static final int textBackgroundRotate = 2130904167;
        /* added by DevToolsApp */
        public static final int textBackgroundZoom = 2130904168;
        /* added by DevToolsApp */
        public static final int textColorAlertDialogListItem = 2130904169;
        /* added by DevToolsApp */
        public static final int textColorSearchUrl = 2130904170;
        /* added by DevToolsApp */
        public static final int textEndPadding = 2130904171;
        /* added by DevToolsApp */
        public static final int textFillColor = 2130904172;
        /* added by DevToolsApp */
        public static final int textInputFilledDenseStyle = 2130904173;
        /* added by DevToolsApp */
        public static final int textInputFilledExposedDropdownMenuStyle = 2130904174;
        /* added by DevToolsApp */
        public static final int textInputFilledStyle = 2130904175;
        /* added by DevToolsApp */
        public static final int textInputLayoutFocusedRectEnabled = 2130904176;
        /* added by DevToolsApp */
        public static final int textInputOutlinedDenseStyle = 2130904177;
        /* added by DevToolsApp */
        public static final int textInputOutlinedExposedDropdownMenuStyle = 2130904178;
        /* added by DevToolsApp */
        public static final int textInputOutlinedStyle = 2130904179;
        /* added by DevToolsApp */
        public static final int textInputStyle = 2130904180;
        /* added by DevToolsApp */
        public static final int textLocale = 2130904181;
        /* added by DevToolsApp */
        public static final int textOutlineColor = 2130904182;
        /* added by DevToolsApp */
        public static final int textOutlineThickness = 2130904183;
        /* added by DevToolsApp */
        public static final int textPanX = 2130904184;
        /* added by DevToolsApp */
        public static final int textPanY = 2130904185;
        /* added by DevToolsApp */
        public static final int textStartPadding = 2130904186;
        /* added by DevToolsApp */
        public static final int textureBlurFactor = 2130904187;
        /* added by DevToolsApp */
        public static final int textureEffect = 2130904188;
        /* added by DevToolsApp */
        public static final int textureHeight = 2130904189;
        /* added by DevToolsApp */
        public static final int textureWidth = 2130904190;
        /* added by DevToolsApp */
        public static final int theme = 2130904191;
        /* added by DevToolsApp */
        public static final int thickness = 2130904192;
        /* added by DevToolsApp */
        public static final int thumbColor = 2130904193;
        /* added by DevToolsApp */
        public static final int thumbElevation = 2130904194;
        /* added by DevToolsApp */
        public static final int thumbHeight = 2130904195;
        /* added by DevToolsApp */
        public static final int thumbIcon = 2130904196;
        /* added by DevToolsApp */
        public static final int thumbIconSize = 2130904197;
        /* added by DevToolsApp */
        public static final int thumbIconTint = 2130904198;
        /* added by DevToolsApp */
        public static final int thumbIconTintMode = 2130904199;
        /* added by DevToolsApp */
        public static final int thumbRadius = 2130904200;
        /* added by DevToolsApp */
        public static final int thumbStrokeColor = 2130904201;
        /* added by DevToolsApp */
        public static final int thumbStrokeWidth = 2130904202;
        /* added by DevToolsApp */
        public static final int thumbTextPadding = 2130904203;
        /* added by DevToolsApp */
        public static final int thumbTint = 2130904204;
        /* added by DevToolsApp */
        public static final int thumbTintMode = 2130904205;
        /* added by DevToolsApp */
        public static final int thumbTrackGapSize = 2130904206;
        /* added by DevToolsApp */
        public static final int thumbWidth = 2130904207;
        /* added by DevToolsApp */
        public static final int tickColor = 2130904208;
        /* added by DevToolsApp */
        public static final int tickColorActive = 2130904209;
        /* added by DevToolsApp */
        public static final int tickColorInactive = 2130904210;
        /* added by DevToolsApp */
        public static final int tickMark = 2130904211;
        /* added by DevToolsApp */
        public static final int tickMarkTint = 2130904212;
        /* added by DevToolsApp */
        public static final int tickMarkTintMode = 2130904213;
        /* added by DevToolsApp */
        public static final int tickRadiusActive = 2130904214;
        /* added by DevToolsApp */
        public static final int tickRadiusInactive = 2130904215;
        /* added by DevToolsApp */
        public static final int tickVisible = 2130904216;
        /* added by DevToolsApp */
        public static final int tint = 2130904217;
        /* added by DevToolsApp */
        public static final int tintMode = 2130904218;
        /* added by DevToolsApp */
        public static final int tintNavigationIcon = 2130904219;
        /* added by DevToolsApp */
        public static final int title = 2130904220;
        /* added by DevToolsApp */
        public static final int titleCentered = 2130904221;
        /* added by DevToolsApp */
        public static final int titleCollapseMode = 2130904222;
        /* added by DevToolsApp */
        public static final int titleEnabled = 2130904223;
        /* added by DevToolsApp */
        public static final int titleMargin = 2130904224;
        /* added by DevToolsApp */
        public static final int titleMarginBottom = 2130904225;
        /* added by DevToolsApp */
        public static final int titleMarginEnd = 2130904226;
        /* added by DevToolsApp */
        public static final int titleMarginStart = 2130904227;
        /* added by DevToolsApp */
        public static final int titleMarginTop = 2130904228;
        /* added by DevToolsApp */
        public static final int titleMargins = 2130904229;
        /* added by DevToolsApp */
        public static final int titlePositionInterpolator = 2130904230;
        /* added by DevToolsApp */
        public static final int titleTextAppearance = 2130904231;
        /* added by DevToolsApp */
        public static final int titleTextColor = 2130904232;
        /* added by DevToolsApp */
        public static final int titleTextEllipsize = 2130904233;
        /* added by DevToolsApp */
        public static final int titleTextStyle = 2130904234;
        /* added by DevToolsApp */
        public static final int toggleCheckedStateOnClick = 2130904235;
        /* added by DevToolsApp */
        public static final int toolbarId = 2130904236;
        /* added by DevToolsApp */
        public static final int toolbarNavigationButtonStyle = 2130904237;
        /* added by DevToolsApp */
        public static final int toolbarStyle = 2130904238;
        /* added by DevToolsApp */
        public static final int toolbarSurfaceStyle = 2130904239;
        /* added by DevToolsApp */
        public static final int tooltipForegroundColor = 2130904240;
        /* added by DevToolsApp */
        public static final int tooltipFrameBackground = 2130904241;
        /* added by DevToolsApp */
        public static final int tooltipStyle = 2130904242;
        /* added by DevToolsApp */
        public static final int tooltipText = 2130904243;
        /* added by DevToolsApp */
        public static final int topInsetScrimEnabled = 2130904244;
        /* added by DevToolsApp */
        public static final int touchAnchorId = 2130904245;
        /* added by DevToolsApp */
        public static final int touchAnchorSide = 2130904246;
        /* added by DevToolsApp */
        public static final int touchRegionId = 2130904247;
        /* added by DevToolsApp */
        public static final int track = 2130904248;
        /* added by DevToolsApp */
        public static final int trackColor = 2130904249;
        /* added by DevToolsApp */
        public static final int trackColorActive = 2130904250;
        /* added by DevToolsApp */
        public static final int trackColorInactive = 2130904251;
        /* added by DevToolsApp */
        public static final int trackCornerRadius = 2130904252;
        /* added by DevToolsApp */
        public static final int trackDecoration = 2130904253;
        /* added by DevToolsApp */
        public static final int trackDecorationTint = 2130904254;
        /* added by DevToolsApp */
        public static final int trackDecorationTintMode = 2130904255;
        /* added by DevToolsApp */
        public static final int trackHeight = 2130904256;
        /* added by DevToolsApp */
        public static final int trackInsideCornerSize = 2130904257;
        /* added by DevToolsApp */
        public static final int trackStopIndicatorSize = 2130904258;
        /* added by DevToolsApp */
        public static final int trackThickness = 2130904259;
        /* added by DevToolsApp */
        public static final int trackTint = 2130904260;
        /* added by DevToolsApp */
        public static final int trackTintMode = 2130904261;
        /* added by DevToolsApp */
        public static final int transformPivotTarget = 2130904262;
        /* added by DevToolsApp */
        public static final int transitionDisable = 2130904263;
        /* added by DevToolsApp */
        public static final int transitionEasing = 2130904264;
        /* added by DevToolsApp */
        public static final int transitionFlags = 2130904265;
        /* added by DevToolsApp */
        public static final int transitionPathRotate = 2130904266;
        /* added by DevToolsApp */
        public static final int transitionShapeAppearance = 2130904267;
        /* added by DevToolsApp */
        public static final int triggerId = 2130904268;
        /* added by DevToolsApp */
        public static final int triggerReceiver = 2130904269;
        /* added by DevToolsApp */
        public static final int triggerSlack = 2130904270;
        /* added by DevToolsApp */
        public static final int ttcIndex = 2130904271;
        /* added by DevToolsApp */
        public static final int upDuration = 2130904272;
        /* added by DevToolsApp */
        public static final int useCompatPadding = 2130904273;
        /* added by DevToolsApp */
        public static final int useDrawerArrowDrawable = 2130904274;
        /* added by DevToolsApp */
        public static final int useMaterialThemeColors = 2130904275;
        /* added by DevToolsApp */
        public static final int values = 2130904276;
        /* added by DevToolsApp */
        public static final int verticalOffset = 2130904277;
        /* added by DevToolsApp */
        public static final int verticalOffsetWithText = 2130904278;
        /* added by DevToolsApp */
        public static final int viewInflaterClass = 2130904279;
        /* added by DevToolsApp */
        public static final int viewTransitionMode = 2130904280;
        /* added by DevToolsApp */
        public static final int viewTransitionOnCross = 2130904281;
        /* added by DevToolsApp */
        public static final int viewTransitionOnNegativeCross = 2130904282;
        /* added by DevToolsApp */
        public static final int viewTransitionOnPositiveCross = 2130904283;
        /* added by DevToolsApp */
        public static final int visibilityMode = 2130904284;
        /* added by DevToolsApp */
        public static final int voiceIcon = 2130904285;
        /* added by DevToolsApp */
        public static final int warmth = 2130904286;
        /* added by DevToolsApp */
        public static final int waveDecay = 2130904287;
        /* added by DevToolsApp */
        public static final int waveOffset = 2130904288;
        /* added by DevToolsApp */
        public static final int wavePeriod = 2130904289;
        /* added by DevToolsApp */
        public static final int wavePhase = 2130904290;
        /* added by DevToolsApp */
        public static final int waveShape = 2130904291;
        /* added by DevToolsApp */
        public static final int waveVariesBy = 2130904292;
        /* added by DevToolsApp */
        public static final int windowActionBar = 2130904293;
        /* added by DevToolsApp */
        public static final int windowActionBarOverlay = 2130904294;
        /* added by DevToolsApp */
        public static final int windowActionModeOverlay = 2130904295;
        /* added by DevToolsApp */
        public static final int windowFixedHeightMajor = 2130904296;
        /* added by DevToolsApp */
        public static final int windowFixedHeightMinor = 2130904297;
        /* added by DevToolsApp */
        public static final int windowFixedWidthMajor = 2130904298;
        /* added by DevToolsApp */
        public static final int windowFixedWidthMinor = 2130904299;
        /* added by DevToolsApp */
        public static final int windowMinWidthMajor = 2130904300;
        /* added by DevToolsApp */
        public static final int windowMinWidthMinor = 2130904301;
        /* added by DevToolsApp */
        public static final int windowNoTitle = 2130904302;
        /* added by DevToolsApp */
        public static final int yearSelectedStyle = 2130904303;
        /* added by DevToolsApp */
        public static final int yearStyle = 2130904304;
        /* added by DevToolsApp */
        public static final int yearTodayStyle = 2130904305;
    }

    /* added by DevToolsApp */
    public static final class bool {
        /* added by DevToolsApp */
        public static final int abc_action_bar_embed_tabs = 2130968576;
        /* added by DevToolsApp */
        public static final int abc_config_actionMenuItemAllCaps = 2130968577;
        /* added by DevToolsApp */
        public static final int enable_system_alarm_service_default = 2130968578;
        /* added by DevToolsApp */
        public static final int enable_system_foreground_service_default = 2130968579;
        /* added by DevToolsApp */
        public static final int enable_system_job_service_default = 2130968580;
        /* added by DevToolsApp */
        public static final int mtrl_btn_textappearance_all_caps = 2130968581;
        /* added by DevToolsApp */
        public static final int workmanager_test_configuration = 2130968582;
    }

    /* added by DevToolsApp */
    public static final class dimen {
        /* added by DevToolsApp */
        public static final int abc_action_bar_content_inset_material = 2131099648;
        /* added by DevToolsApp */
        public static final int abc_action_bar_content_inset_with_nav = 2131099649;
        /* added by DevToolsApp */
        public static final int abc_action_bar_default_height_material = 2131099650;
        /* added by DevToolsApp */
        public static final int abc_action_bar_default_padding_end_material = 2131099651;
        /* added by DevToolsApp */
        public static final int abc_action_bar_default_padding_start_material = 2131099652;
        /* added by DevToolsApp */
        public static final int abc_action_bar_elevation_material = 2131099653;
        /* added by DevToolsApp */
        public static final int abc_action_bar_icon_vertical_padding_material = 2131099654;
        /* added by DevToolsApp */
        public static final int abc_action_bar_overflow_padding_end_material = 2131099655;
        /* added by DevToolsApp */
        public static final int abc_action_bar_overflow_padding_start_material = 2131099656;
        /* added by DevToolsApp */
        public static final int abc_action_bar_stacked_max_height = 2131099657;
        /* added by DevToolsApp */
        public static final int abc_action_bar_stacked_tab_max_width = 2131099658;
        /* added by DevToolsApp */
        public static final int abc_action_bar_subtitle_bottom_margin_material = 2131099659;
        /* added by DevToolsApp */
        public static final int abc_action_bar_subtitle_top_margin_material = 2131099660;
        /* added by DevToolsApp */
        public static final int abc_action_button_min_height_material = 2131099661;
        /* added by DevToolsApp */
        public static final int abc_action_button_min_width_material = 2131099662;
        /* added by DevToolsApp */
        public static final int abc_action_button_min_width_overflow_material = 2131099663;
        /* added by DevToolsApp */
        public static final int abc_alert_dialog_button_bar_height = 2131099664;
        /* added by DevToolsApp */
        public static final int abc_alert_dialog_button_dimen = 2131099665;
        /* added by DevToolsApp */
        public static final int abc_button_inset_horizontal_material = 2131099666;
        /* added by DevToolsApp */
        public static final int abc_button_inset_vertical_material = 2131099667;
        /* added by DevToolsApp */
        public static final int abc_button_padding_horizontal_material = 2131099668;
        /* added by DevToolsApp */
        public static final int abc_button_padding_vertical_material = 2131099669;
        /* added by DevToolsApp */
        public static final int abc_cascading_menus_min_smallest_width = 2131099670;
        /* added by DevToolsApp */
        public static final int abc_config_prefDialogWidth = 2131099671;
        /* added by DevToolsApp */
        public static final int abc_control_corner_material = 2131099672;
        /* added by DevToolsApp */
        public static final int abc_control_inset_material = 2131099673;
        /* added by DevToolsApp */
        public static final int abc_control_padding_material = 2131099674;
        /* added by DevToolsApp */
        public static final int abc_dialog_corner_radius_material = 2131099675;
        /* added by DevToolsApp */
        public static final int abc_dialog_fixed_height_major = 2131099676;
        /* added by DevToolsApp */
        public static final int abc_dialog_fixed_height_minor = 2131099677;
        /* added by DevToolsApp */
        public static final int abc_dialog_fixed_width_major = 2131099678;
        /* added by DevToolsApp */
        public static final int abc_dialog_fixed_width_minor = 2131099679;
        /* added by DevToolsApp */
        public static final int abc_dialog_list_padding_bottom_no_buttons = 2131099680;
        /* added by DevToolsApp */
        public static final int abc_dialog_list_padding_top_no_title = 2131099681;
        /* added by DevToolsApp */
        public static final int abc_dialog_min_width_major = 2131099682;
        /* added by DevToolsApp */
        public static final int abc_dialog_min_width_minor = 2131099683;
        /* added by DevToolsApp */
        public static final int abc_dialog_padding_material = 2131099684;
        /* added by DevToolsApp */
        public static final int abc_dialog_padding_top_material = 2131099685;
        /* added by DevToolsApp */
        public static final int abc_dialog_title_divider_material = 2131099686;
        /* added by DevToolsApp */
        public static final int abc_disabled_alpha_material_dark = 2131099687;
        /* added by DevToolsApp */
        public static final int abc_disabled_alpha_material_light = 2131099688;
        /* added by DevToolsApp */
        public static final int abc_dropdownitem_icon_width = 2131099689;
        /* added by DevToolsApp */
        public static final int abc_dropdownitem_text_padding_left = 2131099690;
        /* added by DevToolsApp */
        public static final int abc_dropdownitem_text_padding_right = 2131099691;
        /* added by DevToolsApp */
        public static final int abc_edit_text_inset_bottom_material = 2131099692;
        /* added by DevToolsApp */
        public static final int abc_edit_text_inset_horizontal_material = 2131099693;
        /* added by DevToolsApp */
        public static final int abc_edit_text_inset_top_material = 2131099694;
        /* added by DevToolsApp */
        public static final int abc_floating_window_z = 2131099695;
        /* added by DevToolsApp */
        public static final int abc_list_item_height_large_material = 2131099696;
        /* added by DevToolsApp */
        public static final int abc_list_item_height_material = 2131099697;
        /* added by DevToolsApp */
        public static final int abc_list_item_height_small_material = 2131099698;
        /* added by DevToolsApp */
        public static final int abc_list_item_padding_horizontal_material = 2131099699;
        /* added by DevToolsApp */
        public static final int abc_panel_menu_list_width = 2131099700;
        /* added by DevToolsApp */
        public static final int abc_progress_bar_height_material = 2131099701;
        /* added by DevToolsApp */
        public static final int abc_search_view_preferred_height = 2131099702;
        /* added by DevToolsApp */
        public static final int abc_search_view_preferred_width = 2131099703;
        /* added by DevToolsApp */
        public static final int abc_seekbar_track_background_height_material = 2131099704;
        /* added by DevToolsApp */
        public static final int abc_seekbar_track_progress_height_material = 2131099705;
        /* added by DevToolsApp */
        public static final int abc_select_dialog_padding_start_material = 2131099706;
        /* added by DevToolsApp */
        public static final int abc_star_big = 2131099707;
        /* added by DevToolsApp */
        public static final int abc_star_medium = 2131099708;
        /* added by DevToolsApp */
        public static final int abc_star_small = 2131099709;
        /* added by DevToolsApp */
        public static final int abc_switch_padding = 2131099710;
        /* added by DevToolsApp */
        public static final int abc_text_size_body_1_material = 2131099711;
        /* added by DevToolsApp */
        public static final int abc_text_size_body_2_material = 2131099712;
        /* added by DevToolsApp */
        public static final int abc_text_size_button_material = 2131099713;
        /* added by DevToolsApp */
        public static final int abc_text_size_caption_material = 2131099714;
        /* added by DevToolsApp */
        public static final int abc_text_size_display_1_material = 2131099715;
        /* added by DevToolsApp */
        public static final int abc_text_size_display_2_material = 2131099716;
        /* added by DevToolsApp */
        public static final int abc_text_size_display_3_material = 2131099717;
        /* added by DevToolsApp */
        public static final int abc_text_size_display_4_material = 2131099718;
        /* added by DevToolsApp */
        public static final int abc_text_size_headline_material = 2131099719;
        /* added by DevToolsApp */
        public static final int abc_text_size_large_material = 2131099720;
        /* added by DevToolsApp */
        public static final int abc_text_size_medium_material = 2131099721;
        /* added by DevToolsApp */
        public static final int abc_text_size_menu_header_material = 2131099722;
        /* added by DevToolsApp */
        public static final int abc_text_size_menu_material = 2131099723;
        /* added by DevToolsApp */
        public static final int abc_text_size_small_material = 2131099724;
        /* added by DevToolsApp */
        public static final int abc_text_size_subhead_material = 2131099725;
        /* added by DevToolsApp */
        public static final int abc_text_size_subtitle_material_toolbar = 2131099726;
        /* added by DevToolsApp */
        public static final int abc_text_size_title_material = 2131099727;
        /* added by DevToolsApp */
        public static final int abc_text_size_title_material_toolbar = 2131099728;
        /* added by DevToolsApp */
        public static final int appcompat_dialog_background_inset = 2131099729;
        /* added by DevToolsApp */
        public static final int cardview_compat_inset_shadow = 2131099730;
        /* added by DevToolsApp */
        public static final int cardview_default_elevation = 2131099731;
        /* added by DevToolsApp */
        public static final int cardview_default_radius = 2131099732;
        /* added by DevToolsApp */
        public static final int clock_face_margin_start = 2131099733;
        /* added by DevToolsApp */
        public static final int compat_button_inset_horizontal_material = 2131099734;
        /* added by DevToolsApp */
        public static final int compat_button_inset_vertical_material = 2131099735;
        /* added by DevToolsApp */
        public static final int compat_button_padding_horizontal_material = 2131099736;
        /* added by DevToolsApp */
        public static final int compat_button_padding_vertical_material = 2131099737;
        /* added by DevToolsApp */
        public static final int compat_control_corner_material = 2131099738;
        /* added by DevToolsApp */
        public static final int compat_notification_large_icon_max_height = 2131099739;
        /* added by DevToolsApp */
        public static final int compat_notification_large_icon_max_width = 2131099740;
        /* added by DevToolsApp */
        public static final int def_drawer_elevation = 2131099741;
        /* added by DevToolsApp */
        public static final int design_appbar_elevation = 2131099742;
        /* added by DevToolsApp */
        public static final int design_bottom_navigation_active_item_max_width = 2131099743;
        /* added by DevToolsApp */
        public static final int design_bottom_navigation_active_item_min_width = 2131099744;
        /* added by DevToolsApp */
        public static final int design_bottom_navigation_active_text_size = 2131099745;
        /* added by DevToolsApp */
        public static final int design_bottom_navigation_elevation = 2131099746;
        /* added by DevToolsApp */
        public static final int design_bottom_navigation_height = 2131099747;
        /* added by DevToolsApp */
        public static final int design_bottom_navigation_icon_size = 2131099748;
        /* added by DevToolsApp */
        public static final int design_bottom_navigation_item_max_width = 2131099749;
        /* added by DevToolsApp */
        public static final int design_bottom_navigation_item_min_width = 2131099750;
        /* added by DevToolsApp */
        public static final int design_bottom_navigation_label_padding = 2131099751;
        /* added by DevToolsApp */
        public static final int design_bottom_navigation_margin = 2131099752;
        /* added by DevToolsApp */
        public static final int design_bottom_navigation_shadow_height = 2131099753;
        /* added by DevToolsApp */
        public static final int design_bottom_navigation_text_size = 2131099754;
        /* added by DevToolsApp */
        public static final int design_bottom_sheet_elevation = 2131099755;
        /* added by DevToolsApp */
        public static final int design_bottom_sheet_modal_elevation = 2131099756;
        /* added by DevToolsApp */
        public static final int design_bottom_sheet_peek_height_min = 2131099757;
        /* added by DevToolsApp */
        public static final int design_fab_border_width = 2131099758;
        /* added by DevToolsApp */
        public static final int design_fab_elevation = 2131099759;
        /* added by DevToolsApp */
        public static final int design_fab_image_size = 2131099760;
        /* added by DevToolsApp */
        public static final int design_fab_size_mini = 2131099761;
        /* added by DevToolsApp */
        public static final int design_fab_size_normal = 2131099762;
        /* added by DevToolsApp */
        public static final int design_fab_translation_z_hovered_focused = 2131099763;
        /* added by DevToolsApp */
        public static final int design_fab_translation_z_pressed = 2131099764;
        /* added by DevToolsApp */
        public static final int design_navigation_elevation = 2131099765;
        /* added by DevToolsApp */
        public static final int design_navigation_icon_padding = 2131099766;
        /* added by DevToolsApp */
        public static final int design_navigation_icon_size = 2131099767;
        /* added by DevToolsApp */
        public static final int design_navigation_item_horizontal_padding = 2131099768;
        /* added by DevToolsApp */
        public static final int design_navigation_item_icon_padding = 2131099769;
        /* added by DevToolsApp */
        public static final int design_navigation_item_vertical_padding = 2131099770;
        /* added by DevToolsApp */
        public static final int design_navigation_max_width = 2131099771;
        /* added by DevToolsApp */
        public static final int design_navigation_padding_bottom = 2131099772;
        /* added by DevToolsApp */
        public static final int design_navigation_separator_vertical_padding = 2131099773;
        /* added by DevToolsApp */
        public static final int design_snackbar_action_inline_max_width = 2131099774;
        /* added by DevToolsApp */
        public static final int design_snackbar_action_text_color_alpha = 2131099775;
        /* added by DevToolsApp */
        public static final int design_snackbar_background_corner_radius = 2131099776;
        /* added by DevToolsApp */
        public static final int design_snackbar_elevation = 2131099777;
        /* added by DevToolsApp */
        public static final int design_snackbar_extra_spacing_horizontal = 2131099778;
        /* added by DevToolsApp */
        public static final int design_snackbar_max_width = 2131099779;
        /* added by DevToolsApp */
        public static final int design_snackbar_min_width = 2131099780;
        /* added by DevToolsApp */
        public static final int design_snackbar_padding_horizontal = 2131099781;
        /* added by DevToolsApp */
        public static final int design_snackbar_padding_vertical = 2131099782;
        /* added by DevToolsApp */
        public static final int design_snackbar_padding_vertical_2lines = 2131099783;
        /* added by DevToolsApp */
        public static final int design_snackbar_text_size = 2131099784;
        /* added by DevToolsApp */
        public static final int design_tab_max_width = 2131099785;
        /* added by DevToolsApp */
        public static final int design_tab_scrollable_min_width = 2131099786;
        /* added by DevToolsApp */
        public static final int design_tab_text_size = 2131099787;
        /* added by DevToolsApp */
        public static final int design_tab_text_size_2line = 2131099788;
        /* added by DevToolsApp */
        public static final int design_textinput_caption_translate_y = 2131099789;
        /* added by DevToolsApp */
        public static final int disabled_alpha_material_dark = 2131099790;
        /* added by DevToolsApp */
        public static final int disabled_alpha_material_light = 2131099791;
        /* added by DevToolsApp */
        public static final int fastscroll_default_thickness = 2131099792;
        /* added by DevToolsApp */
        public static final int fastscroll_margin = 2131099793;
        /* added by DevToolsApp */
        public static final int fastscroll_minimum_range = 2131099794;
        /* added by DevToolsApp */
        public static final int highlight_alpha_material_colored = 2131099795;
        /* added by DevToolsApp */
        public static final int highlight_alpha_material_dark = 2131099796;
        /* added by DevToolsApp */
        public static final int highlight_alpha_material_light = 2131099797;
        /* added by DevToolsApp */
        public static final int hint_alpha_material_dark = 2131099798;
        /* added by DevToolsApp */
        public static final int hint_alpha_material_light = 2131099799;
        /* added by DevToolsApp */
        public static final int hint_pressed_alpha_material_dark = 2131099800;
        /* added by DevToolsApp */
        public static final int hint_pressed_alpha_material_light = 2131099801;
        /* added by DevToolsApp */
        public static final int item_touch_helper_max_drag_scroll_per_frame = 2131099802;
        /* added by DevToolsApp */
        public static final int item_touch_helper_swipe_escape_max_velocity = 2131099803;
        /* added by DevToolsApp */
        public static final int item_touch_helper_swipe_escape_velocity = 2131099804;
        /* added by DevToolsApp */
        public static final int m3_alert_dialog_action_bottom_padding = 2131099805;
        /* added by DevToolsApp */
        public static final int m3_alert_dialog_action_top_padding = 2131099806;
        /* added by DevToolsApp */
        public static final int m3_alert_dialog_corner_size = 2131099807;
        /* added by DevToolsApp */
        public static final int m3_alert_dialog_elevation = 2131099808;
        /* added by DevToolsApp */
        public static final int m3_alert_dialog_icon_margin = 2131099809;
        /* added by DevToolsApp */
        public static final int m3_alert_dialog_icon_size = 2131099810;
        /* added by DevToolsApp */
        public static final int m3_alert_dialog_title_bottom_margin = 2131099811;
        /* added by DevToolsApp */
        public static final int m3_appbar_expanded_title_margin_bottom = 2131099812;
        /* added by DevToolsApp */
        public static final int m3_appbar_expanded_title_margin_horizontal = 2131099813;
        /* added by DevToolsApp */
        public static final int m3_appbar_scrim_height_trigger = 2131099814;
        /* added by DevToolsApp */
        public static final int m3_appbar_scrim_height_trigger_large = 2131099815;
        /* added by DevToolsApp */
        public static final int m3_appbar_scrim_height_trigger_medium = 2131099816;
        /* added by DevToolsApp */
        public static final int m3_appbar_size_compact = 2131099817;
        /* added by DevToolsApp */
        public static final int m3_appbar_size_large = 2131099818;
        /* added by DevToolsApp */
        public static final int m3_appbar_size_medium = 2131099819;
        /* added by DevToolsApp */
        public static final int m3_back_progress_bottom_container_max_scale_x_distance = 2131099820;
        /* added by DevToolsApp */
        public static final int m3_back_progress_bottom_container_max_scale_y_distance = 2131099821;
        /* added by DevToolsApp */
        public static final int m3_back_progress_main_container_max_translation_y = 2131099822;
        /* added by DevToolsApp */
        public static final int m3_back_progress_main_container_min_edge_gap = 2131099823;
        /* added by DevToolsApp */
        public static final int m3_back_progress_side_container_max_scale_x_distance_grow = 2131099824;
        /* added by DevToolsApp */
        public static final int m3_back_progress_side_container_max_scale_x_distance_shrink = 2131099825;
        /* added by DevToolsApp */
        public static final int m3_back_progress_side_container_max_scale_y_distance = 2131099826;
        /* added by DevToolsApp */
        public static final int m3_badge_horizontal_offset = 2131099827;
        /* added by DevToolsApp */
        public static final int m3_badge_offset = 2131099828;
        /* added by DevToolsApp */
        public static final int m3_badge_size = 2131099829;
        /* added by DevToolsApp */
        public static final int m3_badge_vertical_offset = 2131099830;
        /* added by DevToolsApp */
        public static final int m3_badge_with_text_horizontal_offset = 2131099831;
        /* added by DevToolsApp */
        public static final int m3_badge_with_text_offset = 2131099832;
        /* added by DevToolsApp */
        public static final int m3_badge_with_text_size = 2131099833;
        /* added by DevToolsApp */
        public static final int m3_badge_with_text_vertical_offset = 2131099834;
        /* added by DevToolsApp */
        public static final int m3_badge_with_text_vertical_padding = 2131099835;
        /* added by DevToolsApp */
        public static final int m3_bottom_nav_item_active_indicator_height = 2131099836;
        /* added by DevToolsApp */
        public static final int m3_bottom_nav_item_active_indicator_margin_horizontal = 2131099837;
        /* added by DevToolsApp */
        public static final int m3_bottom_nav_item_active_indicator_width = 2131099838;
        /* added by DevToolsApp */
        public static final int m3_bottom_nav_item_padding_bottom = 2131099839;
        /* added by DevToolsApp */
        public static final int m3_bottom_nav_item_padding_top = 2131099840;
        /* added by DevToolsApp */
        public static final int m3_bottom_nav_min_height = 2131099841;
        /* added by DevToolsApp */
        public static final int m3_bottom_sheet_drag_handle_bottom_padding = 2131099842;
        /* added by DevToolsApp */
        public static final int m3_bottom_sheet_elevation = 2131099843;
        /* added by DevToolsApp */
        public static final int m3_bottom_sheet_modal_elevation = 2131099844;
        /* added by DevToolsApp */
        public static final int m3_bottomappbar_fab_cradle_margin = 2131099845;
        /* added by DevToolsApp */
        public static final int m3_bottomappbar_fab_cradle_rounded_corner_radius = 2131099846;
        /* added by DevToolsApp */
        public static final int m3_bottomappbar_fab_cradle_vertical_offset = 2131099847;
        /* added by DevToolsApp */
        public static final int m3_bottomappbar_fab_end_margin = 2131099848;
        /* added by DevToolsApp */
        public static final int m3_bottomappbar_height = 2131099849;
        /* added by DevToolsApp */
        public static final int m3_bottomappbar_horizontal_padding = 2131099850;
        /* added by DevToolsApp */
        public static final int m3_btn_dialog_btn_min_width = 2131099851;
        /* added by DevToolsApp */
        public static final int m3_btn_dialog_btn_spacing = 2131099852;
        /* added by DevToolsApp */
        public static final int m3_btn_disabled_elevation = 2131099853;
        /* added by DevToolsApp */
        public static final int m3_btn_disabled_translation_z = 2131099854;
        /* added by DevToolsApp */
        public static final int m3_btn_elevated_btn_elevation = 2131099855;
        /* added by DevToolsApp */
        public static final int m3_btn_elevation = 2131099856;
        /* added by DevToolsApp */
        public static final int m3_btn_icon_btn_padding_left = 2131099857;
        /* added by DevToolsApp */
        public static final int m3_btn_icon_btn_padding_right = 2131099858;
        /* added by DevToolsApp */
        public static final int m3_btn_icon_only_default_padding = 2131099859;
        /* added by DevToolsApp */
        public static final int m3_btn_icon_only_default_size = 2131099860;
        /* added by DevToolsApp */
        public static final int m3_btn_icon_only_icon_padding = 2131099861;
        /* added by DevToolsApp */
        public static final int m3_btn_icon_only_min_width = 2131099862;
        /* added by DevToolsApp */
        public static final int m3_btn_inset = 2131099863;
        /* added by DevToolsApp */
        public static final int m3_btn_max_width = 2131099864;
        /* added by DevToolsApp */
        public static final int m3_btn_padding_bottom = 2131099865;
        /* added by DevToolsApp */
        public static final int m3_btn_padding_left = 2131099866;
        /* added by DevToolsApp */
        public static final int m3_btn_padding_right = 2131099867;
        /* added by DevToolsApp */
        public static final int m3_btn_padding_top = 2131099868;
        /* added by DevToolsApp */
        public static final int m3_btn_stroke_size = 2131099869;
        /* added by DevToolsApp */
        public static final int m3_btn_text_btn_icon_padding_left = 2131099870;
        /* added by DevToolsApp */
        public static final int m3_btn_text_btn_icon_padding_right = 2131099871;
        /* added by DevToolsApp */
        public static final int m3_btn_text_btn_padding_left = 2131099872;
        /* added by DevToolsApp */
        public static final int m3_btn_text_btn_padding_right = 2131099873;
        /* added by DevToolsApp */
        public static final int m3_btn_translation_z_base = 2131099874;
        /* added by DevToolsApp */
        public static final int m3_btn_translation_z_hovered = 2131099875;
        /* added by DevToolsApp */
        public static final int m3_card_disabled_z = 2131099876;
        /* added by DevToolsApp */
        public static final int m3_card_dragged_z = 2131099877;
        /* added by DevToolsApp */
        public static final int m3_card_elevated_disabled_z = 2131099878;
        /* added by DevToolsApp */
        public static final int m3_card_elevated_dragged_z = 2131099879;
        /* added by DevToolsApp */
        public static final int m3_card_elevated_elevation = 2131099880;
        /* added by DevToolsApp */
        public static final int m3_card_elevated_hovered_z = 2131099881;
        /* added by DevToolsApp */
        public static final int m3_card_elevation = 2131099882;
        /* added by DevToolsApp */
        public static final int m3_card_hovered_z = 2131099883;
        /* added by DevToolsApp */
        public static final int m3_card_stroke_width = 2131099884;
        /* added by DevToolsApp */
        public static final int m3_carousel_debug_keyline_width = 2131099885;
        /* added by DevToolsApp */
        public static final int m3_carousel_extra_small_item_size = 2131099886;
        /* added by DevToolsApp */
        public static final int m3_carousel_gone_size = 2131099887;
        /* added by DevToolsApp */
        public static final int m3_carousel_small_item_default_corner_size = 2131099888;
        /* added by DevToolsApp */
        public static final int m3_carousel_small_item_size_max = 2131099889;
        /* added by DevToolsApp */
        public static final int m3_carousel_small_item_size_min = 2131099890;
        /* added by DevToolsApp */
        public static final int m3_chip_checked_hovered_translation_z = 2131099891;
        /* added by DevToolsApp */
        public static final int m3_chip_corner_size = 2131099892;
        /* added by DevToolsApp */
        public static final int m3_chip_disabled_translation_z = 2131099893;
        /* added by DevToolsApp */
        public static final int m3_chip_dragged_translation_z = 2131099894;
        /* added by DevToolsApp */
        public static final int m3_chip_elevated_elevation = 2131099895;
        /* added by DevToolsApp */
        public static final int m3_chip_hovered_translation_z = 2131099896;
        /* added by DevToolsApp */
        public static final int m3_chip_icon_size = 2131099897;
        /* added by DevToolsApp */
        public static final int m3_comp_assist_chip_container_height = 2131099898;
        /* added by DevToolsApp */
        public static final int m3_comp_assist_chip_elevated_container_elevation = 2131099899;
        /* added by DevToolsApp */
        public static final int m3_comp_assist_chip_flat_container_elevation = 2131099900;
        /* added by DevToolsApp */
        public static final int m3_comp_assist_chip_flat_outline_width = 2131099901;
        /* added by DevToolsApp */
        public static final int m3_comp_assist_chip_with_icon_icon_size = 2131099902;
        /* added by DevToolsApp */
        public static final int m3_comp_badge_large_size = 2131099903;
        /* added by DevToolsApp */
        public static final int m3_comp_badge_size = 2131099904;
        /* added by DevToolsApp */
        public static final int m3_comp_bottom_app_bar_container_elevation = 2131099905;
        /* added by DevToolsApp */
        public static final int m3_comp_bottom_app_bar_container_height = 2131099906;
        /* added by DevToolsApp */
        public static final int m3_comp_checkbox_selected_disabled_container_opacity = 2131099907;
        /* added by DevToolsApp */
        public static final int m3_comp_date_picker_modal_date_today_container_outline_width = 2131099908;
        /* added by DevToolsApp */
        public static final int m3_comp_date_picker_modal_header_container_height = 2131099909;
        /* added by DevToolsApp */
        public static final int m3_comp_date_picker_modal_range_selection_header_container_height = 2131099910;
        /* added by DevToolsApp */
        public static final int m3_comp_divider_thickness = 2131099911;
        /* added by DevToolsApp */
        public static final int m3_comp_elevated_button_container_elevation = 2131099912;
        /* added by DevToolsApp */
        public static final int m3_comp_elevated_button_disabled_container_elevation = 2131099913;
        /* added by DevToolsApp */
        public static final int m3_comp_elevated_card_container_elevation = 2131099914;
        /* added by DevToolsApp */
        public static final int m3_comp_elevated_card_icon_size = 2131099915;
        /* added by DevToolsApp */
        public static final int m3_comp_extended_fab_primary_container_elevation = 2131099916;
        /* added by DevToolsApp */
        public static final int m3_comp_extended_fab_primary_container_height = 2131099917;
        /* added by DevToolsApp */
        public static final int m3_comp_extended_fab_primary_focus_container_elevation = 2131099918;
        /* added by DevToolsApp */
        public static final int m3_comp_extended_fab_primary_focus_state_layer_opacity = 2131099919;
        /* added by DevToolsApp */
        public static final int m3_comp_extended_fab_primary_hover_container_elevation = 2131099920;
        /* added by DevToolsApp */
        public static final int m3_comp_extended_fab_primary_hover_state_layer_opacity = 2131099921;
        /* added by DevToolsApp */
        public static final int m3_comp_extended_fab_primary_icon_size = 2131099922;
        /* added by DevToolsApp */
        public static final int m3_comp_extended_fab_primary_pressed_container_elevation = 2131099923;
        /* added by DevToolsApp */
        public static final int m3_comp_extended_fab_primary_pressed_state_layer_opacity = 2131099924;
        /* added by DevToolsApp */
        public static final int m3_comp_fab_primary_container_elevation = 2131099925;
        /* added by DevToolsApp */
        public static final int m3_comp_fab_primary_container_height = 2131099926;
        /* added by DevToolsApp */
        public static final int m3_comp_fab_primary_focus_state_layer_opacity = 2131099927;
        /* added by DevToolsApp */
        public static final int m3_comp_fab_primary_hover_container_elevation = 2131099928;
        /* added by DevToolsApp */
        public static final int m3_comp_fab_primary_hover_state_layer_opacity = 2131099929;
        /* added by DevToolsApp */
        public static final int m3_comp_fab_primary_icon_size = 2131099930;
        /* added by DevToolsApp */
        public static final int m3_comp_fab_primary_large_container_height = 2131099931;
        /* added by DevToolsApp */
        public static final int m3_comp_fab_primary_large_icon_size = 2131099932;
        /* added by DevToolsApp */
        public static final int m3_comp_fab_primary_pressed_container_elevation = 2131099933;
        /* added by DevToolsApp */
        public static final int m3_comp_fab_primary_pressed_state_layer_opacity = 2131099934;
        /* added by DevToolsApp */
        public static final int m3_comp_fab_primary_small_container_height = 2131099935;
        /* added by DevToolsApp */
        public static final int m3_comp_fab_primary_small_icon_size = 2131099936;
        /* added by DevToolsApp */
        public static final int m3_comp_filled_autocomplete_menu_container_elevation = 2131099937;
        /* added by DevToolsApp */
        public static final int m3_comp_filled_button_container_elevation = 2131099938;
        /* added by DevToolsApp */
        public static final int m3_comp_filled_button_with_icon_icon_size = 2131099939;
        /* added by DevToolsApp */
        public static final int m3_comp_filled_card_container_elevation = 2131099940;
        /* added by DevToolsApp */
        public static final int m3_comp_filled_card_dragged_state_layer_opacity = 2131099941;
        /* added by DevToolsApp */
        public static final int m3_comp_filled_card_focus_state_layer_opacity = 2131099942;
        /* added by DevToolsApp */
        public static final int m3_comp_filled_card_hover_state_layer_opacity = 2131099943;
        /* added by DevToolsApp */
        public static final int m3_comp_filled_card_icon_size = 2131099944;
        /* added by DevToolsApp */
        public static final int m3_comp_filled_card_pressed_state_layer_opacity = 2131099945;
        /* added by DevToolsApp */
        public static final int m3_comp_filled_text_field_disabled_active_indicator_opacity = 2131099946;
        /* added by DevToolsApp */
        public static final int m3_comp_filter_chip_container_height = 2131099947;
        /* added by DevToolsApp */
        public static final int m3_comp_filter_chip_elevated_container_elevation = 2131099948;
        /* added by DevToolsApp */
        public static final int m3_comp_filter_chip_flat_container_elevation = 2131099949;
        /* added by DevToolsApp */
        public static final int m3_comp_filter_chip_flat_unselected_outline_width = 2131099950;
        /* added by DevToolsApp */
        public static final int m3_comp_filter_chip_with_icon_icon_size = 2131099951;
        /* added by DevToolsApp */
        public static final int m3_comp_input_chip_container_elevation = 2131099952;
        /* added by DevToolsApp */
        public static final int m3_comp_input_chip_container_height = 2131099953;
        /* added by DevToolsApp */
        public static final int m3_comp_input_chip_unselected_outline_width = 2131099954;
        /* added by DevToolsApp */
        public static final int m3_comp_input_chip_with_avatar_avatar_size = 2131099955;
        /* added by DevToolsApp */
        public static final int m3_comp_input_chip_with_leading_icon_leading_icon_size = 2131099956;
        /* added by DevToolsApp */
        public static final int m3_comp_menu_container_elevation = 2131099957;
        /* added by DevToolsApp */
        public static final int m3_comp_navigation_bar_active_indicator_height = 2131099958;
        /* added by DevToolsApp */
        public static final int m3_comp_navigation_bar_active_indicator_width = 2131099959;
        /* added by DevToolsApp */
        public static final int m3_comp_navigation_bar_container_elevation = 2131099960;
        /* added by DevToolsApp */
        public static final int m3_comp_navigation_bar_container_height = 2131099961;
        /* added by DevToolsApp */
        public static final int m3_comp_navigation_bar_focus_state_layer_opacity = 2131099962;
        /* added by DevToolsApp */
        public static final int m3_comp_navigation_bar_hover_state_layer_opacity = 2131099963;
        /* added by DevToolsApp */
        public static final int m3_comp_navigation_bar_icon_size = 2131099964;
        /* added by DevToolsApp */
        public static final int m3_comp_navigation_bar_pressed_state_layer_opacity = 2131099965;
        /* added by DevToolsApp */
        public static final int m3_comp_navigation_drawer_container_width = 2131099966;
        /* added by DevToolsApp */
        public static final int m3_comp_navigation_drawer_focus_state_layer_opacity = 2131099967;
        /* added by DevToolsApp */
        public static final int m3_comp_navigation_drawer_hover_state_layer_opacity = 2131099968;
        /* added by DevToolsApp */
        public static final int m3_comp_navigation_drawer_icon_size = 2131099969;
        /* added by DevToolsApp */
        public static final int m3_comp_navigation_drawer_modal_container_elevation = 2131099970;
        /* added by DevToolsApp */
        public static final int m3_comp_navigation_drawer_pressed_state_layer_opacity = 2131099971;
        /* added by DevToolsApp */
        public static final int m3_comp_navigation_drawer_standard_container_elevation = 2131099972;
        /* added by DevToolsApp */
        public static final int m3_comp_navigation_rail_active_indicator_height = 2131099973;
        /* added by DevToolsApp */
        public static final int m3_comp_navigation_rail_active_indicator_width = 2131099974;
        /* added by DevToolsApp */
        public static final int m3_comp_navigation_rail_container_elevation = 2131099975;
        /* added by DevToolsApp */
        public static final int m3_comp_navigation_rail_container_width = 2131099976;
        /* added by DevToolsApp */
        public static final int m3_comp_navigation_rail_focus_state_layer_opacity = 2131099977;
        /* added by DevToolsApp */
        public static final int m3_comp_navigation_rail_hover_state_layer_opacity = 2131099978;
        /* added by DevToolsApp */
        public static final int m3_comp_navigation_rail_icon_size = 2131099979;
        /* added by DevToolsApp */
        public static final int m3_comp_navigation_rail_pressed_state_layer_opacity = 2131099980;
        /* added by DevToolsApp */
        public static final int m3_comp_outlined_autocomplete_menu_container_elevation = 2131099981;
        /* added by DevToolsApp */
        public static final int m3_comp_outlined_button_disabled_outline_opacity = 2131099982;
        /* added by DevToolsApp */
        public static final int m3_comp_outlined_button_outline_width = 2131099983;
        /* added by DevToolsApp */
        public static final int m3_comp_outlined_card_container_elevation = 2131099984;
        /* added by DevToolsApp */
        public static final int m3_comp_outlined_card_disabled_outline_opacity = 2131099985;
        /* added by DevToolsApp */
        public static final int m3_comp_outlined_card_icon_size = 2131099986;
        /* added by DevToolsApp */
        public static final int m3_comp_outlined_card_outline_width = 2131099987;
        /* added by DevToolsApp */
        public static final int m3_comp_outlined_icon_button_unselected_outline_width = 2131099988;
        /* added by DevToolsApp */
        public static final int m3_comp_outlined_text_field_disabled_input_text_opacity = 2131099989;
        /* added by DevToolsApp */
        public static final int m3_comp_outlined_text_field_disabled_label_text_opacity = 2131099990;
        /* added by DevToolsApp */
        public static final int m3_comp_outlined_text_field_disabled_supporting_text_opacity = 2131099991;
        /* added by DevToolsApp */
        public static final int m3_comp_outlined_text_field_focus_outline_width = 2131099992;
        /* added by DevToolsApp */
        public static final int m3_comp_outlined_text_field_outline_width = 2131099993;
        /* added by DevToolsApp */
        public static final int m3_comp_primary_navigation_tab_active_focus_state_layer_opacity = 2131099994;
        /* added by DevToolsApp */
        public static final int m3_comp_primary_navigation_tab_active_hover_state_layer_opacity = 2131099995;
        /* added by DevToolsApp */
        public static final int m3_comp_primary_navigation_tab_active_indicator_height = 2131099996;
        /* added by DevToolsApp */
        public static final int m3_comp_primary_navigation_tab_active_pressed_state_layer_opacity = 2131099997;
        /* added by DevToolsApp */
        public static final int m3_comp_primary_navigation_tab_inactive_focus_state_layer_opacity = 2131099998;
        /* added by DevToolsApp */
        public static final int m3_comp_primary_navigation_tab_inactive_hover_state_layer_opacity = 2131099999;
        /* added by DevToolsApp */
        public static final int m3_comp_primary_navigation_tab_inactive_pressed_state_layer_opacity = 2131100000;
        /* added by DevToolsApp */
        public static final int m3_comp_primary_navigation_tab_with_icon_icon_size = 2131100001;
        /* added by DevToolsApp */
        public static final int m3_comp_progress_indicator_active_indicator_track_space = 2131100002;
        /* added by DevToolsApp */
        public static final int m3_comp_progress_indicator_stop_indicator_size = 2131100003;
        /* added by DevToolsApp */
        public static final int m3_comp_progress_indicator_track_thickness = 2131100004;
        /* added by DevToolsApp */
        public static final int m3_comp_radio_button_disabled_selected_icon_opacity = 2131100005;
        /* added by DevToolsApp */
        public static final int m3_comp_radio_button_disabled_unselected_icon_opacity = 2131100006;
        /* added by DevToolsApp */
        public static final int m3_comp_radio_button_selected_focus_state_layer_opacity = 2131100007;
        /* added by DevToolsApp */
        public static final int m3_comp_radio_button_selected_hover_state_layer_opacity = 2131100008;
        /* added by DevToolsApp */
        public static final int m3_comp_radio_button_selected_pressed_state_layer_opacity = 2131100009;
        /* added by DevToolsApp */
        public static final int m3_comp_radio_button_unselected_focus_state_layer_opacity = 2131100010;
        /* added by DevToolsApp */
        public static final int m3_comp_radio_button_unselected_hover_state_layer_opacity = 2131100011;
        /* added by DevToolsApp */
        public static final int m3_comp_radio_button_unselected_pressed_state_layer_opacity = 2131100012;
        /* added by DevToolsApp */
        public static final int m3_comp_scrim_container_opacity = 2131100013;
        /* added by DevToolsApp */
        public static final int m3_comp_search_bar_avatar_size = 2131100014;
        /* added by DevToolsApp */
        public static final int m3_comp_search_bar_container_elevation = 2131100015;
        /* added by DevToolsApp */
        public static final int m3_comp_search_bar_container_height = 2131100016;
        /* added by DevToolsApp */
        public static final int m3_comp_search_bar_hover_state_layer_opacity = 2131100017;
        /* added by DevToolsApp */
        public static final int m3_comp_search_bar_pressed_state_layer_opacity = 2131100018;
        /* added by DevToolsApp */
        public static final int m3_comp_search_view_container_elevation = 2131100019;
        /* added by DevToolsApp */
        public static final int m3_comp_search_view_docked_header_container_height = 2131100020;
        /* added by DevToolsApp */
        public static final int m3_comp_search_view_full_screen_header_container_height = 2131100021;
        /* added by DevToolsApp */
        public static final int m3_comp_secondary_navigation_tab_active_indicator_height = 2131100022;
        /* added by DevToolsApp */
        public static final int m3_comp_secondary_navigation_tab_focus_state_layer_opacity = 2131100023;
        /* added by DevToolsApp */
        public static final int m3_comp_secondary_navigation_tab_hover_state_layer_opacity = 2131100024;
        /* added by DevToolsApp */
        public static final int m3_comp_secondary_navigation_tab_pressed_state_layer_opacity = 2131100025;
        /* added by DevToolsApp */
        public static final int m3_comp_sheet_bottom_docked_drag_handle_height = 2131100026;
        /* added by DevToolsApp */
        public static final int m3_comp_sheet_bottom_docked_drag_handle_width = 2131100027;
        /* added by DevToolsApp */
        public static final int m3_comp_sheet_bottom_docked_modal_container_elevation = 2131100028;
        /* added by DevToolsApp */
        public static final int m3_comp_sheet_bottom_docked_standard_container_elevation = 2131100029;
        /* added by DevToolsApp */
        public static final int m3_comp_sheet_side_docked_container_width = 2131100030;
        /* added by DevToolsApp */
        public static final int m3_comp_sheet_side_docked_modal_container_elevation = 2131100031;
        /* added by DevToolsApp */
        public static final int m3_comp_sheet_side_docked_standard_container_elevation = 2131100032;
        /* added by DevToolsApp */
        public static final int m3_comp_slider_active_handle_height = 2131100033;
        /* added by DevToolsApp */
        public static final int m3_comp_slider_active_handle_leading_space = 2131100034;
        /* added by DevToolsApp */
        public static final int m3_comp_slider_active_handle_width = 2131100035;
        /* added by DevToolsApp */
        public static final int m3_comp_slider_disabled_active_track_opacity = 2131100036;
        /* added by DevToolsApp */
        public static final int m3_comp_slider_disabled_handle_opacity = 2131100037;
        /* added by DevToolsApp */
        public static final int m3_comp_slider_disabled_inactive_track_opacity = 2131100038;
        /* added by DevToolsApp */
        public static final int m3_comp_slider_inactive_track_height = 2131100039;
        /* added by DevToolsApp */
        public static final int m3_comp_slider_stop_indicator_size = 2131100040;
        /* added by DevToolsApp */
        public static final int m3_comp_snackbar_container_elevation = 2131100041;
        /* added by DevToolsApp */
        public static final int m3_comp_suggestion_chip_container_height = 2131100042;
        /* added by DevToolsApp */
        public static final int m3_comp_suggestion_chip_elevated_container_elevation = 2131100043;
        /* added by DevToolsApp */
        public static final int m3_comp_suggestion_chip_flat_container_elevation = 2131100044;
        /* added by DevToolsApp */
        public static final int m3_comp_suggestion_chip_flat_outline_width = 2131100045;
        /* added by DevToolsApp */
        public static final int m3_comp_suggestion_chip_with_leading_icon_leading_icon_size = 2131100046;
        /* added by DevToolsApp */
        public static final int m3_comp_switch_disabled_selected_handle_opacity = 2131100047;
        /* added by DevToolsApp */
        public static final int m3_comp_switch_disabled_selected_icon_opacity = 2131100048;
        /* added by DevToolsApp */
        public static final int m3_comp_switch_disabled_track_opacity = 2131100049;
        /* added by DevToolsApp */
        public static final int m3_comp_switch_disabled_unselected_handle_opacity = 2131100050;
        /* added by DevToolsApp */
        public static final int m3_comp_switch_disabled_unselected_icon_opacity = 2131100051;
        /* added by DevToolsApp */
        public static final int m3_comp_switch_selected_focus_state_layer_opacity = 2131100052;
        /* added by DevToolsApp */
        public static final int m3_comp_switch_selected_hover_state_layer_opacity = 2131100053;
        /* added by DevToolsApp */
        public static final int m3_comp_switch_selected_pressed_state_layer_opacity = 2131100054;
        /* added by DevToolsApp */
        public static final int m3_comp_switch_track_height = 2131100055;
        /* added by DevToolsApp */
        public static final int m3_comp_switch_track_width = 2131100056;
        /* added by DevToolsApp */
        public static final int m3_comp_switch_unselected_focus_state_layer_opacity = 2131100057;
        /* added by DevToolsApp */
        public static final int m3_comp_switch_unselected_hover_state_layer_opacity = 2131100058;
        /* added by DevToolsApp */
        public static final int m3_comp_switch_unselected_pressed_state_layer_opacity = 2131100059;
        /* added by DevToolsApp */
        public static final int m3_comp_text_button_focus_state_layer_opacity = 2131100060;
        /* added by DevToolsApp */
        public static final int m3_comp_text_button_hover_state_layer_opacity = 2131100061;
        /* added by DevToolsApp */
        public static final int m3_comp_text_button_pressed_state_layer_opacity = 2131100062;
        /* added by DevToolsApp */
        public static final int m3_comp_time_input_time_input_field_focus_outline_width = 2131100063;
        /* added by DevToolsApp */
        public static final int m3_comp_time_picker_container_elevation = 2131100064;
        /* added by DevToolsApp */
        public static final int m3_comp_time_picker_period_selector_focus_state_layer_opacity = 2131100065;
        /* added by DevToolsApp */
        public static final int m3_comp_time_picker_period_selector_hover_state_layer_opacity = 2131100066;
        /* added by DevToolsApp */
        public static final int m3_comp_time_picker_period_selector_outline_width = 2131100067;
        /* added by DevToolsApp */
        public static final int m3_comp_time_picker_period_selector_pressed_state_layer_opacity = 2131100068;
        /* added by DevToolsApp */
        public static final int m3_comp_time_picker_time_selector_focus_state_layer_opacity = 2131100069;
        /* added by DevToolsApp */
        public static final int m3_comp_time_picker_time_selector_hover_state_layer_opacity = 2131100070;
        /* added by DevToolsApp */
        public static final int m3_comp_time_picker_time_selector_pressed_state_layer_opacity = 2131100071;
        /* added by DevToolsApp */
        public static final int m3_comp_top_app_bar_large_container_height = 2131100072;
        /* added by DevToolsApp */
        public static final int m3_comp_top_app_bar_medium_container_height = 2131100073;
        /* added by DevToolsApp */
        public static final int m3_comp_top_app_bar_small_container_elevation = 2131100074;
        /* added by DevToolsApp */
        public static final int m3_comp_top_app_bar_small_container_height = 2131100075;
        /* added by DevToolsApp */
        public static final int m3_comp_top_app_bar_small_on_scroll_container_elevation = 2131100076;
        /* added by DevToolsApp */
        public static final int m3_datepicker_elevation = 2131100077;
        /* added by DevToolsApp */
        public static final int m3_divider_heavy_thickness = 2131100078;
        /* added by DevToolsApp */
        public static final int m3_extended_fab_bottom_padding = 2131100079;
        /* added by DevToolsApp */
        public static final int m3_extended_fab_end_padding = 2131100080;
        /* added by DevToolsApp */
        public static final int m3_extended_fab_icon_padding = 2131100081;
        /* added by DevToolsApp */
        public static final int m3_extended_fab_min_height = 2131100082;
        /* added by DevToolsApp */
        public static final int m3_extended_fab_start_padding = 2131100083;
        /* added by DevToolsApp */
        public static final int m3_extended_fab_top_padding = 2131100084;
        /* added by DevToolsApp */
        public static final int m3_fab_border_width = 2131100085;
        /* added by DevToolsApp */
        public static final int m3_fab_corner_size = 2131100086;
        /* added by DevToolsApp */
        public static final int m3_fab_translation_z_hovered_focused = 2131100087;
        /* added by DevToolsApp */
        public static final int m3_fab_translation_z_pressed = 2131100088;
        /* added by DevToolsApp */
        public static final int m3_large_fab_max_image_size = 2131100089;
        /* added by DevToolsApp */
        public static final int m3_large_fab_size = 2131100090;
        /* added by DevToolsApp */
        public static final int m3_large_text_vertical_offset_adjustment = 2131100091;
        /* added by DevToolsApp */
        public static final int m3_menu_elevation = 2131100092;
        /* added by DevToolsApp */
        public static final int m3_nav_badge_with_text_vertical_offset = 2131100093;
        /* added by DevToolsApp */
        public static final int m3_navigation_drawer_layout_corner_size = 2131100094;
        /* added by DevToolsApp */
        public static final int m3_navigation_item_active_indicator_label_padding = 2131100095;
        /* added by DevToolsApp */
        public static final int m3_navigation_item_horizontal_padding = 2131100096;
        /* added by DevToolsApp */
        public static final int m3_navigation_item_icon_padding = 2131100097;
        /* added by DevToolsApp */
        public static final int m3_navigation_item_shape_inset_bottom = 2131100098;
        /* added by DevToolsApp */
        public static final int m3_navigation_item_shape_inset_end = 2131100099;
        /* added by DevToolsApp */
        public static final int m3_navigation_item_shape_inset_start = 2131100100;
        /* added by DevToolsApp */
        public static final int m3_navigation_item_shape_inset_top = 2131100101;
        /* added by DevToolsApp */
        public static final int m3_navigation_item_vertical_padding = 2131100102;
        /* added by DevToolsApp */
        public static final int m3_navigation_menu_divider_horizontal_padding = 2131100103;
        /* added by DevToolsApp */
        public static final int m3_navigation_menu_headline_horizontal_padding = 2131100104;
        /* added by DevToolsApp */
        public static final int m3_navigation_rail_default_width = 2131100105;
        /* added by DevToolsApp */
        public static final int m3_navigation_rail_elevation = 2131100106;
        /* added by DevToolsApp */
        public static final int m3_navigation_rail_icon_size = 2131100107;
        /* added by DevToolsApp */
        public static final int m3_navigation_rail_item_active_indicator_height = 2131100108;
        /* added by DevToolsApp */
        public static final int m3_navigation_rail_item_active_indicator_margin_horizontal = 2131100109;
        /* added by DevToolsApp */
        public static final int m3_navigation_rail_item_active_indicator_width = 2131100110;
        /* added by DevToolsApp */
        public static final int m3_navigation_rail_item_min_height = 2131100111;
        /* added by DevToolsApp */
        public static final int m3_navigation_rail_item_padding_bottom = 2131100112;
        /* added by DevToolsApp */
        public static final int m3_navigation_rail_item_padding_bottom_with_large_font = 2131100113;
        /* added by DevToolsApp */
        public static final int m3_navigation_rail_item_padding_top = 2131100114;
        /* added by DevToolsApp */
        public static final int m3_navigation_rail_item_padding_top_with_large_font = 2131100115;
        /* added by DevToolsApp */
        public static final int m3_navigation_rail_label_padding_horizontal = 2131100116;
        /* added by DevToolsApp */
        public static final int m3_ripple_default_alpha = 2131100117;
        /* added by DevToolsApp */
        public static final int m3_ripple_focused_alpha = 2131100118;
        /* added by DevToolsApp */
        public static final int m3_ripple_hovered_alpha = 2131100119;
        /* added by DevToolsApp */
        public static final int m3_ripple_pressed_alpha = 2131100120;
        /* added by DevToolsApp */
        public static final int m3_ripple_selectable_pressed_alpha = 2131100121;
        /* added by DevToolsApp */
        public static final int m3_searchbar_elevation = 2131100122;
        /* added by DevToolsApp */
        public static final int m3_searchbar_height = 2131100123;
        /* added by DevToolsApp */
        public static final int m3_searchbar_margin_horizontal = 2131100124;
        /* added by DevToolsApp */
        public static final int m3_searchbar_margin_vertical = 2131100125;
        /* added by DevToolsApp */
        public static final int m3_searchbar_outlined_stroke_width = 2131100126;
        /* added by DevToolsApp */
        public static final int m3_searchbar_padding_start = 2131100127;
        /* added by DevToolsApp */
        public static final int m3_searchbar_text_margin_start_no_navigation_icon = 2131100128;
        /* added by DevToolsApp */
        public static final int m3_searchbar_text_size = 2131100129;
        /* added by DevToolsApp */
        public static final int m3_searchview_divider_size = 2131100130;
        /* added by DevToolsApp */
        public static final int m3_searchview_elevation = 2131100131;
        /* added by DevToolsApp */
        public static final int m3_searchview_height = 2131100132;
        /* added by DevToolsApp */
        public static final int m3_side_sheet_margin_detached = 2131100133;
        /* added by DevToolsApp */
        public static final int m3_side_sheet_modal_elevation = 2131100134;
        /* added by DevToolsApp */
        public static final int m3_side_sheet_standard_elevation = 2131100135;
        /* added by DevToolsApp */
        public static final int m3_side_sheet_width = 2131100136;
        /* added by DevToolsApp */
        public static final int m3_simple_item_color_hovered_alpha = 2131100137;
        /* added by DevToolsApp */
        public static final int m3_simple_item_color_selected_alpha = 2131100138;
        /* added by DevToolsApp */
        public static final int m3_slider_thumb_elevation = 2131100139;
        /* added by DevToolsApp */
        public static final int m3_small_fab_max_image_size = 2131100140;
        /* added by DevToolsApp */
        public static final int m3_small_fab_size = 2131100141;
        /* added by DevToolsApp */
        public static final int m3_snackbar_action_text_color_alpha = 2131100142;
        /* added by DevToolsApp */
        public static final int m3_snackbar_margin = 2131100143;
        /* added by DevToolsApp */
        public static final int m3_sys_elevation_level0 = 2131100144;
        /* added by DevToolsApp */
        public static final int m3_sys_elevation_level1 = 2131100145;
        /* added by DevToolsApp */
        public static final int m3_sys_elevation_level2 = 2131100146;
        /* added by DevToolsApp */
        public static final int m3_sys_elevation_level3 = 2131100147;
        /* added by DevToolsApp */
        public static final int m3_sys_elevation_level4 = 2131100148;
        /* added by DevToolsApp */
        public static final int m3_sys_elevation_level5 = 2131100149;
        /* added by DevToolsApp */
        public static final int m3_sys_motion_easing_emphasized_accelerate_control_x1 = 2131100150;
        /* added by DevToolsApp */
        public static final int m3_sys_motion_easing_emphasized_accelerate_control_x2 = 2131100151;
        /* added by DevToolsApp */
        public static final int m3_sys_motion_easing_emphasized_accelerate_control_y1 = 2131100152;
        /* added by DevToolsApp */
        public static final int m3_sys_motion_easing_emphasized_accelerate_control_y2 = 2131100153;
        /* added by DevToolsApp */
        public static final int m3_sys_motion_easing_emphasized_decelerate_control_x1 = 2131100154;
        /* added by DevToolsApp */
        public static final int m3_sys_motion_easing_emphasized_decelerate_control_x2 = 2131100155;
        /* added by DevToolsApp */
        public static final int m3_sys_motion_easing_emphasized_decelerate_control_y1 = 2131100156;
        /* added by DevToolsApp */
        public static final int m3_sys_motion_easing_emphasized_decelerate_control_y2 = 2131100157;
        /* added by DevToolsApp */
        public static final int m3_sys_motion_easing_legacy_accelerate_control_x1 = 2131100158;
        /* added by DevToolsApp */
        public static final int m3_sys_motion_easing_legacy_accelerate_control_x2 = 2131100159;
        /* added by DevToolsApp */
        public static final int m3_sys_motion_easing_legacy_accelerate_control_y1 = 2131100160;
        /* added by DevToolsApp */
        public static final int m3_sys_motion_easing_legacy_accelerate_control_y2 = 2131100161;
        /* added by DevToolsApp */
        public static final int m3_sys_motion_easing_legacy_control_x1 = 2131100162;
        /* added by DevToolsApp */
        public static final int m3_sys_motion_easing_legacy_control_x2 = 2131100163;
        /* added by DevToolsApp */
        public static final int m3_sys_motion_easing_legacy_control_y1 = 2131100164;
        /* added by DevToolsApp */
        public static final int m3_sys_motion_easing_legacy_control_y2 = 2131100165;
        /* added by DevToolsApp */
        public static final int m3_sys_motion_easing_legacy_decelerate_control_x1 = 2131100166;
        /* added by DevToolsApp */
        public static final int m3_sys_motion_easing_legacy_decelerate_control_x2 = 2131100167;
        /* added by DevToolsApp */
        public static final int m3_sys_motion_easing_legacy_decelerate_control_y1 = 2131100168;
        /* added by DevToolsApp */
        public static final int m3_sys_motion_easing_legacy_decelerate_control_y2 = 2131100169;
        /* added by DevToolsApp */
        public static final int m3_sys_motion_easing_linear_control_x1 = 2131100170;
        /* added by DevToolsApp */
        public static final int m3_sys_motion_easing_linear_control_x2 = 2131100171;
        /* added by DevToolsApp */
        public static final int m3_sys_motion_easing_linear_control_y1 = 2131100172;
        /* added by DevToolsApp */
        public static final int m3_sys_motion_easing_linear_control_y2 = 2131100173;
        /* added by DevToolsApp */
        public static final int m3_sys_motion_easing_standard_accelerate_control_x1 = 2131100174;
        /* added by DevToolsApp */
        public static final int m3_sys_motion_easing_standard_accelerate_control_x2 = 2131100175;
        /* added by DevToolsApp */
        public static final int m3_sys_motion_easing_standard_accelerate_control_y1 = 2131100176;
        /* added by DevToolsApp */
        public static final int m3_sys_motion_easing_standard_accelerate_control_y2 = 2131100177;
        /* added by DevToolsApp */
        public static final int m3_sys_motion_easing_standard_control_x1 = 2131100178;
        /* added by DevToolsApp */
        public static final int m3_sys_motion_easing_standard_control_x2 = 2131100179;
        /* added by DevToolsApp */
        public static final int m3_sys_motion_easing_standard_control_y1 = 2131100180;
        /* added by DevToolsApp */
        public static final int m3_sys_motion_easing_standard_control_y2 = 2131100181;
        /* added by DevToolsApp */
        public static final int m3_sys_motion_easing_standard_decelerate_control_x1 = 2131100182;
        /* added by DevToolsApp */
        public static final int m3_sys_motion_easing_standard_decelerate_control_x2 = 2131100183;
        /* added by DevToolsApp */
        public static final int m3_sys_motion_easing_standard_decelerate_control_y1 = 2131100184;
        /* added by DevToolsApp */
        public static final int m3_sys_motion_easing_standard_decelerate_control_y2 = 2131100185;
        /* added by DevToolsApp */
        public static final int m3_sys_state_dragged_state_layer_opacity = 2131100186;
        /* added by DevToolsApp */
        public static final int m3_sys_state_focus_state_layer_opacity = 2131100187;
        /* added by DevToolsApp */
        public static final int m3_sys_state_hover_state_layer_opacity = 2131100188;
        /* added by DevToolsApp */
        public static final int m3_sys_state_pressed_state_layer_opacity = 2131100189;
        /* added by DevToolsApp */
        public static final int m3_timepicker_display_stroke_width = 2131100190;
        /* added by DevToolsApp */
        public static final int m3_timepicker_window_elevation = 2131100191;
        /* added by DevToolsApp */
        public static final int m3_toolbar_text_size_title = 2131100192;
        /* added by DevToolsApp */
        public static final int material_bottom_sheet_max_width = 2131100193;
        /* added by DevToolsApp */
        public static final int material_clock_display_height = 2131100194;
        /* added by DevToolsApp */
        public static final int material_clock_display_padding = 2131100195;
        /* added by DevToolsApp */
        public static final int material_clock_display_width = 2131100196;
        /* added by DevToolsApp */
        public static final int material_clock_face_margin_bottom = 2131100197;
        /* added by DevToolsApp */
        public static final int material_clock_face_margin_top = 2131100198;
        /* added by DevToolsApp */
        public static final int material_clock_hand_center_dot_radius = 2131100199;
        /* added by DevToolsApp */
        public static final int material_clock_hand_padding = 2131100200;
        /* added by DevToolsApp */
        public static final int material_clock_hand_stroke_width = 2131100201;
        /* added by DevToolsApp */
        public static final int material_clock_number_text_size = 2131100202;
        /* added by DevToolsApp */
        public static final int material_clock_period_toggle_height = 2131100203;
        /* added by DevToolsApp */
        public static final int material_clock_period_toggle_horizontal_gap = 2131100204;
        /* added by DevToolsApp */
        public static final int material_clock_period_toggle_vertical_gap = 2131100205;
        /* added by DevToolsApp */
        public static final int material_clock_period_toggle_width = 2131100206;
        /* added by DevToolsApp */
        public static final int material_clock_size = 2131100207;
        /* added by DevToolsApp */
        public static final int material_cursor_inset = 2131100208;
        /* added by DevToolsApp */
        public static final int material_cursor_width = 2131100209;
        /* added by DevToolsApp */
        public static final int material_divider_thickness = 2131100210;
        /* added by DevToolsApp */
        public static final int material_emphasis_disabled = 2131100211;
        /* added by DevToolsApp */
        public static final int material_emphasis_disabled_background = 2131100212;
        /* added by DevToolsApp */
        public static final int material_emphasis_high_type = 2131100213;
        /* added by DevToolsApp */
        public static final int material_emphasis_medium = 2131100214;
        /* added by DevToolsApp */
        public static final int material_filled_edittext_font_1_3_padding_bottom = 2131100215;
        /* added by DevToolsApp */
        public static final int material_filled_edittext_font_1_3_padding_top = 2131100216;
        /* added by DevToolsApp */
        public static final int material_filled_edittext_font_2_0_padding_bottom = 2131100217;
        /* added by DevToolsApp */
        public static final int material_filled_edittext_font_2_0_padding_top = 2131100218;
        /* added by DevToolsApp */
        public static final int material_font_1_3_box_collapsed_padding_top = 2131100219;
        /* added by DevToolsApp */
        public static final int material_font_2_0_box_collapsed_padding_top = 2131100220;
        /* added by DevToolsApp */
        public static final int material_helper_text_default_padding_top = 2131100221;
        /* added by DevToolsApp */
        public static final int material_helper_text_font_1_3_padding_horizontal = 2131100222;
        /* added by DevToolsApp */
        public static final int material_helper_text_font_1_3_padding_top = 2131100223;
        /* added by DevToolsApp */
        public static final int material_input_text_to_prefix_suffix_padding = 2131100224;
        /* added by DevToolsApp */
        public static final int material_textinput_default_width = 2131100225;
        /* added by DevToolsApp */
        public static final int material_textinput_max_width = 2131100226;
        /* added by DevToolsApp */
        public static final int material_textinput_min_width = 2131100227;
        /* added by DevToolsApp */
        public static final int material_time_picker_minimum_screen_height = 2131100228;
        /* added by DevToolsApp */
        public static final int material_time_picker_minimum_screen_width = 2131100229;
        /* added by DevToolsApp */
        public static final int mtrl_alert_dialog_background_inset_bottom = 2131100230;
        /* added by DevToolsApp */
        public static final int mtrl_alert_dialog_background_inset_end = 2131100231;
        /* added by DevToolsApp */
        public static final int mtrl_alert_dialog_background_inset_start = 2131100232;
        /* added by DevToolsApp */
        public static final int mtrl_alert_dialog_background_inset_top = 2131100233;
        /* added by DevToolsApp */
        public static final int mtrl_alert_dialog_picker_background_inset = 2131100234;
        /* added by DevToolsApp */
        public static final int mtrl_badge_horizontal_edge_offset = 2131100235;
        /* added by DevToolsApp */
        public static final int mtrl_badge_long_text_horizontal_padding = 2131100236;
        /* added by DevToolsApp */
        public static final int mtrl_badge_size = 2131100237;
        /* added by DevToolsApp */
        public static final int mtrl_badge_text_horizontal_edge_offset = 2131100238;
        /* added by DevToolsApp */
        public static final int mtrl_badge_text_size = 2131100239;
        /* added by DevToolsApp */
        public static final int mtrl_badge_toolbar_action_menu_item_horizontal_offset = 2131100240;
        /* added by DevToolsApp */
        public static final int mtrl_badge_toolbar_action_menu_item_vertical_offset = 2131100241;
        /* added by DevToolsApp */
        public static final int mtrl_badge_with_text_size = 2131100242;
        /* added by DevToolsApp */
        public static final int mtrl_bottomappbar_fabOffsetEndMode = 2131100243;
        /* added by DevToolsApp */
        public static final int mtrl_bottomappbar_fab_bottom_margin = 2131100244;
        /* added by DevToolsApp */
        public static final int mtrl_bottomappbar_fab_cradle_margin = 2131100245;
        /* added by DevToolsApp */
        public static final int mtrl_bottomappbar_fab_cradle_rounded_corner_radius = 2131100246;
        /* added by DevToolsApp */
        public static final int mtrl_bottomappbar_fab_cradle_vertical_offset = 2131100247;
        /* added by DevToolsApp */
        public static final int mtrl_bottomappbar_height = 2131100248;
        /* added by DevToolsApp */
        public static final int mtrl_btn_corner_radius = 2131100249;
        /* added by DevToolsApp */
        public static final int mtrl_btn_dialog_btn_min_width = 2131100250;
        /* added by DevToolsApp */
        public static final int mtrl_btn_disabled_elevation = 2131100251;
        /* added by DevToolsApp */
        public static final int mtrl_btn_disabled_z = 2131100252;
        /* added by DevToolsApp */
        public static final int mtrl_btn_elevation = 2131100253;
        /* added by DevToolsApp */
        public static final int mtrl_btn_focused_z = 2131100254;
        /* added by DevToolsApp */
        public static final int mtrl_btn_hovered_z = 2131100255;
        /* added by DevToolsApp */
        public static final int mtrl_btn_icon_btn_padding_left = 2131100256;
        /* added by DevToolsApp */
        public static final int mtrl_btn_icon_padding = 2131100257;
        /* added by DevToolsApp */
        public static final int mtrl_btn_inset = 2131100258;
        /* added by DevToolsApp */
        public static final int mtrl_btn_letter_spacing = 2131100259;
        /* added by DevToolsApp */
        public static final int mtrl_btn_max_width = 2131100260;
        /* added by DevToolsApp */
        public static final int mtrl_btn_padding_bottom = 2131100261;
        /* added by DevToolsApp */
        public static final int mtrl_btn_padding_left = 2131100262;
        /* added by DevToolsApp */
        public static final int mtrl_btn_padding_right = 2131100263;
        /* added by DevToolsApp */
        public static final int mtrl_btn_padding_top = 2131100264;
        /* added by DevToolsApp */
        public static final int mtrl_btn_pressed_z = 2131100265;
        /* added by DevToolsApp */
        public static final int mtrl_btn_snackbar_margin_horizontal = 2131100266;
        /* added by DevToolsApp */
        public static final int mtrl_btn_stroke_size = 2131100267;
        /* added by DevToolsApp */
        public static final int mtrl_btn_text_btn_icon_padding = 2131100268;
        /* added by DevToolsApp */
        public static final int mtrl_btn_text_btn_padding_left = 2131100269;
        /* added by DevToolsApp */
        public static final int mtrl_btn_text_btn_padding_right = 2131100270;
        /* added by DevToolsApp */
        public static final int mtrl_btn_text_size = 2131100271;
        /* added by DevToolsApp */
        public static final int mtrl_btn_z = 2131100272;
        /* added by DevToolsApp */
        public static final int mtrl_calendar_action_confirm_button_min_width = 2131100273;
        /* added by DevToolsApp */
        public static final int mtrl_calendar_action_height = 2131100274;
        /* added by DevToolsApp */
        public static final int mtrl_calendar_action_padding = 2131100275;
        /* added by DevToolsApp */
        public static final int mtrl_calendar_bottom_padding = 2131100276;
        /* added by DevToolsApp */
        public static final int mtrl_calendar_content_padding = 2131100277;
        /* added by DevToolsApp */
        public static final int mtrl_calendar_day_corner = 2131100278;
        /* added by DevToolsApp */
        public static final int mtrl_calendar_day_height = 2131100279;
        /* added by DevToolsApp */
        public static final int mtrl_calendar_day_horizontal_padding = 2131100280;
        /* added by DevToolsApp */
        public static final int mtrl_calendar_day_today_stroke = 2131100281;
        /* added by DevToolsApp */
        public static final int mtrl_calendar_day_vertical_padding = 2131100282;
        /* added by DevToolsApp */
        public static final int mtrl_calendar_day_width = 2131100283;
        /* added by DevToolsApp */
        public static final int mtrl_calendar_days_of_week_height = 2131100284;
        /* added by DevToolsApp */
        public static final int mtrl_calendar_dialog_background_inset = 2131100285;
        /* added by DevToolsApp */
        public static final int mtrl_calendar_header_content_padding = 2131100286;
        /* added by DevToolsApp */
        public static final int mtrl_calendar_header_content_padding_fullscreen = 2131100287;
        /* added by DevToolsApp */
        public static final int mtrl_calendar_header_divider_thickness = 2131100288;
        /* added by DevToolsApp */
        public static final int mtrl_calendar_header_height = 2131100289;
        /* added by DevToolsApp */
        public static final int mtrl_calendar_header_height_fullscreen = 2131100290;
        /* added by DevToolsApp */
        public static final int mtrl_calendar_header_selection_line_height = 2131100291;
        /* added by DevToolsApp */
        public static final int mtrl_calendar_header_text_padding = 2131100292;
        /* added by DevToolsApp */
        public static final int mtrl_calendar_header_toggle_margin_bottom = 2131100293;
        /* added by DevToolsApp */
        public static final int mtrl_calendar_header_toggle_margin_top = 2131100294;
        /* added by DevToolsApp */
        public static final int mtrl_calendar_landscape_header_width = 2131100295;
        /* added by DevToolsApp */
        public static final int mtrl_calendar_maximum_default_fullscreen_minor_axis = 2131100296;
        /* added by DevToolsApp */
        public static final int mtrl_calendar_month_horizontal_padding = 2131100297;
        /* added by DevToolsApp */
        public static final int mtrl_calendar_month_vertical_padding = 2131100298;
        /* added by DevToolsApp */
        public static final int mtrl_calendar_navigation_bottom_padding = 2131100299;
        /* added by DevToolsApp */
        public static final int mtrl_calendar_navigation_height = 2131100300;
        /* added by DevToolsApp */
        public static final int mtrl_calendar_navigation_top_padding = 2131100301;
        /* added by DevToolsApp */
        public static final int mtrl_calendar_pre_l_text_clip_padding = 2131100302;
        /* added by DevToolsApp */
        public static final int mtrl_calendar_selection_baseline_to_top_fullscreen = 2131100303;
        /* added by DevToolsApp */
        public static final int mtrl_calendar_selection_text_baseline_to_bottom = 2131100304;
        /* added by DevToolsApp */
        public static final int mtrl_calendar_selection_text_baseline_to_bottom_fullscreen = 2131100305;
        /* added by DevToolsApp */
        public static final int mtrl_calendar_selection_text_baseline_to_top = 2131100306;
        /* added by DevToolsApp */
        public static final int mtrl_calendar_text_input_padding_top = 2131100307;
        /* added by DevToolsApp */
        public static final int mtrl_calendar_title_baseline_to_top = 2131100308;
        /* added by DevToolsApp */
        public static final int mtrl_calendar_title_baseline_to_top_fullscreen = 2131100309;
        /* added by DevToolsApp */
        public static final int mtrl_calendar_year_corner = 2131100310;
        /* added by DevToolsApp */
        public static final int mtrl_calendar_year_height = 2131100311;
        /* added by DevToolsApp */
        public static final int mtrl_calendar_year_horizontal_padding = 2131100312;
        /* added by DevToolsApp */
        public static final int mtrl_calendar_year_vertical_padding = 2131100313;
        /* added by DevToolsApp */
        public static final int mtrl_calendar_year_width = 2131100314;
        /* added by DevToolsApp */
        public static final int mtrl_card_checked_icon_margin = 2131100315;
        /* added by DevToolsApp */
        public static final int mtrl_card_checked_icon_size = 2131100316;
        /* added by DevToolsApp */
        public static final int mtrl_card_corner_radius = 2131100317;
        /* added by DevToolsApp */
        public static final int mtrl_card_dragged_z = 2131100318;
        /* added by DevToolsApp */
        public static final int mtrl_card_elevation = 2131100319;
        /* added by DevToolsApp */
        public static final int mtrl_card_spacing = 2131100320;
        /* added by DevToolsApp */
        public static final int mtrl_chip_pressed_translation_z = 2131100321;
        /* added by DevToolsApp */
        public static final int mtrl_chip_text_size = 2131100322;
        /* added by DevToolsApp */
        public static final int mtrl_exposed_dropdown_menu_popup_elevation = 2131100323;
        /* added by DevToolsApp */
        public static final int mtrl_exposed_dropdown_menu_popup_vertical_offset = 2131100324;
        /* added by DevToolsApp */
        public static final int mtrl_exposed_dropdown_menu_popup_vertical_padding = 2131100325;
        /* added by DevToolsApp */
        public static final int mtrl_extended_fab_bottom_padding = 2131100326;
        /* added by DevToolsApp */
        public static final int mtrl_extended_fab_disabled_elevation = 2131100327;
        /* added by DevToolsApp */
        public static final int mtrl_extended_fab_disabled_translation_z = 2131100328;
        /* added by DevToolsApp */
        public static final int mtrl_extended_fab_elevation = 2131100329;
        /* added by DevToolsApp */
        public static final int mtrl_extended_fab_end_padding = 2131100330;
        /* added by DevToolsApp */
        public static final int mtrl_extended_fab_end_padding_icon = 2131100331;
        /* added by DevToolsApp */
        public static final int mtrl_extended_fab_icon_size = 2131100332;
        /* added by DevToolsApp */
        public static final int mtrl_extended_fab_icon_text_spacing = 2131100333;
        /* added by DevToolsApp */
        public static final int mtrl_extended_fab_min_height = 2131100334;
        /* added by DevToolsApp */
        public static final int mtrl_extended_fab_min_width = 2131100335;
        /* added by DevToolsApp */
        public static final int mtrl_extended_fab_start_padding = 2131100336;
        /* added by DevToolsApp */
        public static final int mtrl_extended_fab_start_padding_icon = 2131100337;
        /* added by DevToolsApp */
        public static final int mtrl_extended_fab_top_padding = 2131100338;
        /* added by DevToolsApp */
        public static final int mtrl_extended_fab_translation_z_base = 2131100339;
        /* added by DevToolsApp */
        public static final int mtrl_extended_fab_translation_z_hovered_focused = 2131100340;
        /* added by DevToolsApp */
        public static final int mtrl_extended_fab_translation_z_pressed = 2131100341;
        /* added by DevToolsApp */
        public static final int mtrl_fab_elevation = 2131100342;
        /* added by DevToolsApp */
        public static final int mtrl_fab_min_touch_target = 2131100343;
        /* added by DevToolsApp */
        public static final int mtrl_fab_translation_z_hovered_focused = 2131100344;
        /* added by DevToolsApp */
        public static final int mtrl_fab_translation_z_pressed = 2131100345;
        /* added by DevToolsApp */
        public static final int mtrl_high_ripple_default_alpha = 2131100346;
        /* added by DevToolsApp */
        public static final int mtrl_high_ripple_focused_alpha = 2131100347;
        /* added by DevToolsApp */
        public static final int mtrl_high_ripple_hovered_alpha = 2131100348;
        /* added by DevToolsApp */
        public static final int mtrl_high_ripple_pressed_alpha = 2131100349;
        /* added by DevToolsApp */
        public static final int mtrl_low_ripple_default_alpha = 2131100350;
        /* added by DevToolsApp */
        public static final int mtrl_low_ripple_focused_alpha = 2131100351;
        /* added by DevToolsApp */
        public static final int mtrl_low_ripple_hovered_alpha = 2131100352;
        /* added by DevToolsApp */
        public static final int mtrl_low_ripple_pressed_alpha = 2131100353;
        /* added by DevToolsApp */
        public static final int mtrl_min_touch_target_size = 2131100354;
        /* added by DevToolsApp */
        public static final int mtrl_navigation_bar_item_default_icon_size = 2131100355;
        /* added by DevToolsApp */
        public static final int mtrl_navigation_bar_item_default_margin = 2131100356;
        /* added by DevToolsApp */
        public static final int mtrl_navigation_elevation = 2131100357;
        /* added by DevToolsApp */
        public static final int mtrl_navigation_item_horizontal_padding = 2131100358;
        /* added by DevToolsApp */
        public static final int mtrl_navigation_item_icon_padding = 2131100359;
        /* added by DevToolsApp */
        public static final int mtrl_navigation_item_icon_size = 2131100360;
        /* added by DevToolsApp */
        public static final int mtrl_navigation_item_shape_horizontal_margin = 2131100361;
        /* added by DevToolsApp */
        public static final int mtrl_navigation_item_shape_vertical_margin = 2131100362;
        /* added by DevToolsApp */
        public static final int mtrl_navigation_rail_active_text_size = 2131100363;
        /* added by DevToolsApp */
        public static final int mtrl_navigation_rail_compact_width = 2131100364;
        /* added by DevToolsApp */
        public static final int mtrl_navigation_rail_default_width = 2131100365;
        /* added by DevToolsApp */
        public static final int mtrl_navigation_rail_elevation = 2131100366;
        /* added by DevToolsApp */
        public static final int mtrl_navigation_rail_icon_margin = 2131100367;
        /* added by DevToolsApp */
        public static final int mtrl_navigation_rail_icon_size = 2131100368;
        /* added by DevToolsApp */
        public static final int mtrl_navigation_rail_margin = 2131100369;
        /* added by DevToolsApp */
        public static final int mtrl_navigation_rail_text_bottom_margin = 2131100370;
        /* added by DevToolsApp */
        public static final int mtrl_navigation_rail_text_size = 2131100371;
        /* added by DevToolsApp */
        public static final int mtrl_progress_circular_inset = 2131100372;
        /* added by DevToolsApp */
        public static final int mtrl_progress_circular_inset_extra_small = 2131100373;
        /* added by DevToolsApp */
        public static final int mtrl_progress_circular_inset_medium = 2131100374;
        /* added by DevToolsApp */
        public static final int mtrl_progress_circular_inset_small = 2131100375;
        /* added by DevToolsApp */
        public static final int mtrl_progress_circular_radius = 2131100376;
        /* added by DevToolsApp */
        public static final int mtrl_progress_circular_size = 2131100377;
        /* added by DevToolsApp */
        public static final int mtrl_progress_circular_size_extra_small = 2131100378;
        /* added by DevToolsApp */
        public static final int mtrl_progress_circular_size_medium = 2131100379;
        /* added by DevToolsApp */
        public static final int mtrl_progress_circular_size_small = 2131100380;
        /* added by DevToolsApp */
        public static final int mtrl_progress_circular_track_thickness_extra_small = 2131100381;
        /* added by DevToolsApp */
        public static final int mtrl_progress_circular_track_thickness_medium = 2131100382;
        /* added by DevToolsApp */
        public static final int mtrl_progress_circular_track_thickness_small = 2131100383;
        /* added by DevToolsApp */
        public static final int mtrl_progress_indicator_full_rounded_corner_radius = 2131100384;
        /* added by DevToolsApp */
        public static final int mtrl_progress_track_thickness = 2131100385;
        /* added by DevToolsApp */
        public static final int mtrl_shape_corner_size_large_component = 2131100386;
        /* added by DevToolsApp */
        public static final int mtrl_shape_corner_size_medium_component = 2131100387;
        /* added by DevToolsApp */
        public static final int mtrl_shape_corner_size_small_component = 2131100388;
        /* added by DevToolsApp */
        public static final int mtrl_slider_halo_radius = 2131100389;
        /* added by DevToolsApp */
        public static final int mtrl_slider_label_padding = 2131100390;
        /* added by DevToolsApp */
        public static final int mtrl_slider_label_radius = 2131100391;
        /* added by DevToolsApp */
        public static final int mtrl_slider_label_square_side = 2131100392;
        /* added by DevToolsApp */
        public static final int mtrl_slider_thumb_elevation = 2131100393;
        /* added by DevToolsApp */
        public static final int mtrl_slider_thumb_radius = 2131100394;
        /* added by DevToolsApp */
        public static final int mtrl_slider_tick_min_spacing = 2131100395;
        /* added by DevToolsApp */
        public static final int mtrl_slider_tick_radius = 2131100396;
        /* added by DevToolsApp */
        public static final int mtrl_slider_track_height = 2131100397;
        /* added by DevToolsApp */
        public static final int mtrl_slider_track_side_padding = 2131100398;
        /* added by DevToolsApp */
        public static final int mtrl_slider_widget_height = 2131100399;
        /* added by DevToolsApp */
        public static final int mtrl_snackbar_action_text_color_alpha = 2131100400;
        /* added by DevToolsApp */
        public static final int mtrl_snackbar_background_corner_radius = 2131100401;
        /* added by DevToolsApp */
        public static final int mtrl_snackbar_background_overlay_color_alpha = 2131100402;
        /* added by DevToolsApp */
        public static final int mtrl_snackbar_margin = 2131100403;
        /* added by DevToolsApp */
        public static final int mtrl_snackbar_message_margin_horizontal = 2131100404;
        /* added by DevToolsApp */
        public static final int mtrl_snackbar_padding_horizontal = 2131100405;
        /* added by DevToolsApp */
        public static final int mtrl_switch_text_padding = 2131100406;
        /* added by DevToolsApp */
        public static final int mtrl_switch_thumb_elevation = 2131100407;
        /* added by DevToolsApp */
        public static final int mtrl_switch_thumb_icon_size = 2131100408;
        /* added by DevToolsApp */
        public static final int mtrl_switch_thumb_size = 2131100409;
        /* added by DevToolsApp */
        public static final int mtrl_switch_track_height = 2131100410;
        /* added by DevToolsApp */
        public static final int mtrl_switch_track_width = 2131100411;
        /* added by DevToolsApp */
        public static final int mtrl_textinput_box_corner_radius_medium = 2131100412;
        /* added by DevToolsApp */
        public static final int mtrl_textinput_box_corner_radius_small = 2131100413;
        /* added by DevToolsApp */
        public static final int mtrl_textinput_box_label_cutout_padding = 2131100414;
        /* added by DevToolsApp */
        public static final int mtrl_textinput_box_stroke_width_default = 2131100415;
        /* added by DevToolsApp */
        public static final int mtrl_textinput_box_stroke_width_focused = 2131100416;
        /* added by DevToolsApp */
        public static final int mtrl_textinput_counter_margin_start = 2131100417;
        /* added by DevToolsApp */
        public static final int mtrl_textinput_end_icon_margin_start = 2131100418;
        /* added by DevToolsApp */
        public static final int mtrl_textinput_outline_box_expanded_padding = 2131100419;
        /* added by DevToolsApp */
        public static final int mtrl_textinput_start_icon_margin_end = 2131100420;
        /* added by DevToolsApp */
        public static final int mtrl_toolbar_default_height = 2131100421;
        /* added by DevToolsApp */
        public static final int mtrl_tooltip_arrowSize = 2131100422;
        /* added by DevToolsApp */
        public static final int mtrl_tooltip_cornerSize = 2131100423;
        /* added by DevToolsApp */
        public static final int mtrl_tooltip_minHeight = 2131100424;
        /* added by DevToolsApp */
        public static final int mtrl_tooltip_minWidth = 2131100425;
        /* added by DevToolsApp */
        public static final int mtrl_tooltip_padding = 2131100426;
        /* added by DevToolsApp */
        public static final int mtrl_transition_shared_axis_slide_distance = 2131100427;
        /* added by DevToolsApp */
        public static final int notification_action_icon_size = 2131100428;
        /* added by DevToolsApp */
        public static final int notification_action_text_size = 2131100429;
        /* added by DevToolsApp */
        public static final int notification_big_circle_margin = 2131100430;
        /* added by DevToolsApp */
        public static final int notification_content_margin_start = 2131100431;
        /* added by DevToolsApp */
        public static final int notification_large_icon_height = 2131100432;
        /* added by DevToolsApp */
        public static final int notification_large_icon_width = 2131100433;
        /* added by DevToolsApp */
        public static final int notification_main_column_padding_top = 2131100434;
        /* added by DevToolsApp */
        public static final int notification_media_narrow_margin = 2131100435;
        /* added by DevToolsApp */
        public static final int notification_right_icon_size = 2131100436;
        /* added by DevToolsApp */
        public static final int notification_right_side_padding_top = 2131100437;
        /* added by DevToolsApp */
        public static final int notification_small_icon_background_padding = 2131100438;
        /* added by DevToolsApp */
        public static final int notification_small_icon_size_as_large = 2131100439;
        /* added by DevToolsApp */
        public static final int notification_subtext_size = 2131100440;
        /* added by DevToolsApp */
        public static final int notification_top_pad = 2131100441;
        /* added by DevToolsApp */
        public static final int notification_top_pad_large_text = 2131100442;
        /* added by DevToolsApp */
        public static final int tooltip_corner_radius = 2131100443;
        /* added by DevToolsApp */
        public static final int tooltip_horizontal_padding = 2131100444;
        /* added by DevToolsApp */
        public static final int tooltip_margin = 2131100445;
        /* added by DevToolsApp */
        public static final int tooltip_precise_anchor_extra_offset = 2131100446;
        /* added by DevToolsApp */
        public static final int tooltip_precise_anchor_threshold = 2131100447;
        /* added by DevToolsApp */
        public static final int tooltip_vertical_padding = 2131100448;
        /* added by DevToolsApp */
        public static final int tooltip_y_offset_non_touch = 2131100449;
        /* added by DevToolsApp */
        public static final int tooltip_y_offset_touch = 2131100450;
    }

    /* added by DevToolsApp */
    public static final class integer {
        /* added by DevToolsApp */
        public static final int abc_config_activityDefaultDur = 2131361792;
        /* added by DevToolsApp */
        public static final int abc_config_activityShortDur = 2131361793;
        /* added by DevToolsApp */
        public static final int app_bar_elevation_anim_duration = 2131361794;
        /* added by DevToolsApp */
        public static final int bottom_sheet_slide_duration = 2131361795;
        /* added by DevToolsApp */
        public static final int cancel_button_image_alpha = 2131361796;
        /* added by DevToolsApp */
        public static final int config_tooltipAnimTime = 2131361797;
        /* added by DevToolsApp */
        public static final int design_snackbar_text_max_lines = 2131361798;
        /* added by DevToolsApp */
        public static final int design_tab_indicator_anim_duration_ms = 2131361799;
        /* added by DevToolsApp */
        public static final int google_play_services_version = 2131361800;
        /* added by DevToolsApp */
        public static final int hide_password_duration = 2131361801;
        /* added by DevToolsApp */
        public static final int m3_badge_max_number = 2131361802;
        /* added by DevToolsApp */
        public static final int m3_btn_anim_delay_ms = 2131361803;
        /* added by DevToolsApp */
        public static final int m3_btn_anim_duration_ms = 2131361804;
        /* added by DevToolsApp */
        public static final int m3_card_anim_delay_ms = 2131361805;
        /* added by DevToolsApp */
        public static final int m3_card_anim_duration_ms = 2131361806;
        /* added by DevToolsApp */
        public static final int m3_chip_anim_duration = 2131361807;
        /* added by DevToolsApp */
        public static final int m3_sys_motion_duration_extra_long1 = 2131361808;
        /* added by DevToolsApp */
        public static final int m3_sys_motion_duration_extra_long2 = 2131361809;
        /* added by DevToolsApp */
        public static final int m3_sys_motion_duration_extra_long3 = 2131361810;
        /* added by DevToolsApp */
        public static final int m3_sys_motion_duration_extra_long4 = 2131361811;
        /* added by DevToolsApp */
        public static final int m3_sys_motion_duration_long1 = 2131361812;
        /* added by DevToolsApp */
        public static final int m3_sys_motion_duration_long2 = 2131361813;
        /* added by DevToolsApp */
        public static final int m3_sys_motion_duration_long3 = 2131361814;
        /* added by DevToolsApp */
        public static final int m3_sys_motion_duration_long4 = 2131361815;
        /* added by DevToolsApp */
        public static final int m3_sys_motion_duration_medium1 = 2131361816;
        /* added by DevToolsApp */
        public static final int m3_sys_motion_duration_medium2 = 2131361817;
        /* added by DevToolsApp */
        public static final int m3_sys_motion_duration_medium3 = 2131361818;
        /* added by DevToolsApp */
        public static final int m3_sys_motion_duration_medium4 = 2131361819;
        /* added by DevToolsApp */
        public static final int m3_sys_motion_duration_short1 = 2131361820;
        /* added by DevToolsApp */
        public static final int m3_sys_motion_duration_short2 = 2131361821;
        /* added by DevToolsApp */
        public static final int m3_sys_motion_duration_short3 = 2131361822;
        /* added by DevToolsApp */
        public static final int m3_sys_motion_duration_short4 = 2131361823;
        /* added by DevToolsApp */
        public static final int m3_sys_motion_path = 2131361824;
        /* added by DevToolsApp */
        public static final int m3_sys_shape_corner_extra_large_corner_family = 2131361825;
        /* added by DevToolsApp */
        public static final int m3_sys_shape_corner_extra_small_corner_family = 2131361826;
        /* added by DevToolsApp */
        public static final int m3_sys_shape_corner_full_corner_family = 2131361827;
        /* added by DevToolsApp */
        public static final int m3_sys_shape_corner_large_corner_family = 2131361828;
        /* added by DevToolsApp */
        public static final int m3_sys_shape_corner_medium_corner_family = 2131361829;
        /* added by DevToolsApp */
        public static final int m3_sys_shape_corner_small_corner_family = 2131361830;
        /* added by DevToolsApp */
        public static final int material_motion_duration_long_1 = 2131361831;
        /* added by DevToolsApp */
        public static final int material_motion_duration_long_2 = 2131361832;
        /* added by DevToolsApp */
        public static final int material_motion_duration_medium_1 = 2131361833;
        /* added by DevToolsApp */
        public static final int material_motion_duration_medium_2 = 2131361834;
        /* added by DevToolsApp */
        public static final int material_motion_duration_short_1 = 2131361835;
        /* added by DevToolsApp */
        public static final int material_motion_duration_short_2 = 2131361836;
        /* added by DevToolsApp */
        public static final int material_motion_path = 2131361837;
        /* added by DevToolsApp */
        public static final int mtrl_badge_max_character_count = 2131361838;
        /* added by DevToolsApp */
        public static final int mtrl_btn_anim_delay_ms = 2131361839;
        /* added by DevToolsApp */
        public static final int mtrl_btn_anim_duration_ms = 2131361840;
        /* added by DevToolsApp */
        public static final int mtrl_calendar_header_orientation = 2131361841;
        /* added by DevToolsApp */
        public static final int mtrl_calendar_selection_text_lines = 2131361842;
        /* added by DevToolsApp */
        public static final int mtrl_calendar_year_selector_span = 2131361843;
        /* added by DevToolsApp */
        public static final int mtrl_card_anim_delay_ms = 2131361844;
        /* added by DevToolsApp */
        public static final int mtrl_card_anim_duration_ms = 2131361845;
        /* added by DevToolsApp */
        public static final int mtrl_chip_anim_duration = 2131361846;
        /* added by DevToolsApp */
        public static final int mtrl_switch_thumb_motion_duration = 2131361847;
        /* added by DevToolsApp */
        public static final int mtrl_switch_thumb_post_morphing_duration = 2131361848;
        /* added by DevToolsApp */
        public static final int mtrl_switch_thumb_pre_morphing_duration = 2131361849;
        /* added by DevToolsApp */
        public static final int mtrl_switch_thumb_pressed_duration = 2131361850;
        /* added by DevToolsApp */
        public static final int mtrl_switch_thumb_viewport_center_coordinate = 2131361851;
        /* added by DevToolsApp */
        public static final int mtrl_switch_thumb_viewport_size = 2131361852;
        /* added by DevToolsApp */
        public static final int mtrl_switch_track_viewport_height = 2131361853;
        /* added by DevToolsApp */
        public static final int mtrl_switch_track_viewport_width = 2131361854;
        /* added by DevToolsApp */
        public static final int mtrl_tab_indicator_anim_duration_ms = 2131361855;
        /* added by DevToolsApp */
        public static final int mtrl_view_gone = 2131361856;
        /* added by DevToolsApp */
        public static final int mtrl_view_invisible = 2131361857;
        /* added by DevToolsApp */
        public static final int mtrl_view_visible = 2131361858;
        /* added by DevToolsApp */
        public static final int show_password_duration = 2131361859;
        /* added by DevToolsApp */
        public static final int status_bar_notification_info_maxnum = 2131361860;
    }

    /* added by DevToolsApp */
    public static final class interpolator {
        /* added by DevToolsApp */
        public static final int btn_checkbox_checked_mtrl_animation_interpolator_0 = 2131427328;
        /* added by DevToolsApp */
        public static final int btn_checkbox_checked_mtrl_animation_interpolator_1 = 2131427329;
        /* added by DevToolsApp */
        public static final int btn_checkbox_unchecked_mtrl_animation_interpolator_0 = 2131427330;
        /* added by DevToolsApp */
        public static final int btn_checkbox_unchecked_mtrl_animation_interpolator_1 = 2131427331;
        /* added by DevToolsApp */
        public static final int btn_radio_to_off_mtrl_animation_interpolator_0 = 2131427332;
        /* added by DevToolsApp */
        public static final int btn_radio_to_on_mtrl_animation_interpolator_0 = 2131427333;
        /* added by DevToolsApp */
        public static final int fast_out_slow_in = 2131427334;
        /* added by DevToolsApp */
        public static final int m3_sys_motion_easing_emphasized = 2131427335;
        /* added by DevToolsApp */
        public static final int m3_sys_motion_easing_emphasized_accelerate = 2131427336;
        /* added by DevToolsApp */
        public static final int m3_sys_motion_easing_emphasized_decelerate = 2131427337;
        /* added by DevToolsApp */
        public static final int m3_sys_motion_easing_linear = 2131427338;
        /* added by DevToolsApp */
        public static final int m3_sys_motion_easing_standard = 2131427339;
        /* added by DevToolsApp */
        public static final int m3_sys_motion_easing_standard_accelerate = 2131427340;
        /* added by DevToolsApp */
        public static final int m3_sys_motion_easing_standard_decelerate = 2131427341;
        /* added by DevToolsApp */
        public static final int mtrl_fast_out_linear_in = 2131427342;
        /* added by DevToolsApp */
        public static final int mtrl_fast_out_slow_in = 2131427343;
        /* added by DevToolsApp */
        public static final int mtrl_linear = 2131427344;
        /* added by DevToolsApp */
        public static final int mtrl_linear_out_slow_in = 2131427345;
    }

    /* added by DevToolsApp */
    public static final class plurals {
        /* added by DevToolsApp */
        public static final int mtrl_badge_content_description = 2131689472;
    }

    /* added by DevToolsApp */
    public static final class raw {
        /* added by DevToolsApp */
        public static final int firebase_common_keep = 2131755008;
        /* added by DevToolsApp */
        public static final int keep_cronet_api = 2131755009;
    }

    private R() {
    }
}
