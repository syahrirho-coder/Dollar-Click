package com.nishant.superadspro;

/* compiled from: D8$$SyntheticClass */
public final /* synthetic */ class Task$$ExternalSyntheticLambda0 implements Runnable {
    public final /* synthetic */ Task f$0;

    public /* synthetic */ Task$$ExternalSyntheticLambda0(Task task) {
        this.f$0 = task;
    }

    public final void run() {
        this.f$0.m1lambda$openUrlAndReward$0$com-nishant-superadspro-Task();
    }
}
