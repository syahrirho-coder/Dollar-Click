package com.nishant.superadspro;

import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;

/* compiled from: D8$$SyntheticClass */
public final /* synthetic */ class Task$$ExternalSyntheticLambda1 implements OnClickListener {
    public final void onClick(DialogInterface dialogInterface, int i) {
        dialogInterface.dismiss();
    }
}
