package com.nishant.superadspro;

import android.app.AlertDialog.Builder;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Handler;
import java.util.List;

public class Task {
    private final Context context;
    private final Handler handler = new Handler();
    private boolean isTimerRunning = false;
    private OnTimerCompletedListener timerCompletedListener;
    private int timerDurationMs;

    public interface OnTimerCompletedListener {
        void onTimerCompleted();
    }

    public Task(Context context) {
        this.context = context;
    }

    public void openUrlAndReward(String str, int i) {
        if (!this.isTimerRunning) {
            Intent intent = new Intent("android.intent.action.VIEW", Uri.parse(str));
            intent.putExtra("android.intent.extra.REFERRER", Uri.parse("android-app://com.android.chrome"));
            intent.setFlags(268435456);
            this.context.startActivity(intent);
            this.timerDurationMs = i * 60000;
            this.isTimerRunning = true;
            this.handler.postDelayed(new Task$$ExternalSyntheticLambda0(this), (long) this.timerDurationMs);
        }
    }

    /* renamed from: lambda$openUrlAndReward$0$com-nishant-superadspro-Task */
    /* synthetic */ void m1lambda$openUrlAndReward$0$com-nishant-superadspro-Task() {
        showReward();
        OnTimerCompletedListener onTimerCompletedListener = this.timerCompletedListener;
        if (onTimerCompletedListener != null) {
            onTimerCompletedListener.onTimerCompleted();
        }
        this.isTimerRunning = false;
    }

    private void showReward() {
        new Builder(this.context).setTitle("Reward").setMessage("Congratulations! Timer is complete!").setPositiveButton("OK", new Task$$ExternalSyntheticLambda1()).setCancelable(false).create().show();
    }

    public int sumAll(List<String> list) {
        int i = 0;
        for (String str : list) {
            String str2;
            try {
                str2 = Integer.parseInt(str2);
                i += str2;
            } catch (NumberFormatException unused) {
                throw new RuntimeException("Invalid number: " + str2);
            }
        }
        return i;
    }

    public void setTimerRunning(boolean z) {
        this.isTimerRunning = z;
    }

    public boolean isTimerRunning() {
        return this.isTimerRunning;
    }

    public void setOnTimerCompletedListener(OnTimerCompletedListener onTimerCompletedListener) {
        this.timerCompletedListener = onTimerCompletedListener;
    }
}
