package com.nishant.superadspro;

/* compiled from: D8$$SyntheticClass */
public final /* synthetic */ class TimePro$$ExternalSyntheticLambda0 implements Runnable {
    public final /* synthetic */ TimePro f$0;

    public /* synthetic */ TimePro$$ExternalSyntheticLambda0(TimePro timePro) {
        this.f$0 = timePro;
    }

    public final void run() {
        this.f$0.m2lambda$pauseTimer$1$com-nishant-superadspro-TimePro();
    }
}
