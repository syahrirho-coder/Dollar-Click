package com.nishant.superadspro;

/* compiled from: D8$$SyntheticClass */
public final /* synthetic */ class TimePro$$ExternalSyntheticLambda1 implements Runnable {
    public final /* synthetic */ TimePro f$0;

    public /* synthetic */ TimePro$$ExternalSyntheticLambda1(TimePro timePro) {
        this.f$0 = timePro;
    }

    public final void run() {
        this.f$0.m4lambda$resumeTimer$2$com-nishant-superadspro-TimePro();
    }
}
