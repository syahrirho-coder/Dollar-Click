package com.nishant.superadspro;

/* compiled from: D8$$SyntheticClass */
public final /* synthetic */ class TimePro$$ExternalSyntheticLambda3 implements Runnable {
    public final /* synthetic */ TimePro f$0;

    public /* synthetic */ TimePro$$ExternalSyntheticLambda3(TimePro timePro) {
        this.f$0 = timePro;
    }

    public final void run() {
        this.f$0.m5lambda$startTimer$0$com-nishant-superadspro-TimePro();
    }
}
