package com.nishant.superadspro;

import com.nishant.superadspro.TimePro.AnonymousClass1;

/* compiled from: D8$$SyntheticClass */
public final /* synthetic */ class TimePro$1$$ExternalSyntheticLambda0 implements Runnable {
    public final /* synthetic */ AnonymousClass1 f$0;

    public /* synthetic */ TimePro$1$$ExternalSyntheticLambda0(AnonymousClass1 anonymousClass1) {
        this.f$0 = anonymousClass1;
    }

    public final void run() {
        this.f$0.m6lambda$run$0$com-nishant-superadspro-TimePro$1();
    }
}
