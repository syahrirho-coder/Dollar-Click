package com.nishant.superadspro;

import com.nishant.superadspro.TimePro.AnonymousClass1;

/* compiled from: D8$$SyntheticClass */
public final /* synthetic */ class TimePro$1$$ExternalSyntheticLambda2 implements Runnable {
    public final /* synthetic */ AnonymousClass1 f$0;
    public final /* synthetic */ String f$1;

    public /* synthetic */ TimePro$1$$ExternalSyntheticLambda2(AnonymousClass1 anonymousClass1, String str) {
        this.f$0 = anonymousClass1;
        this.f$1 = str;
    }

    public final void run() {
        this.f$0.m8lambda$run$2$com-nishant-superadspro-TimePro$1(this.f$1);
    }
}
