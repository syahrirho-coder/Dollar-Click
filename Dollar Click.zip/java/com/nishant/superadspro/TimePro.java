package com.nishant.superadspro;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;

public class TimePro {
    private final Context context;
    private final Handler handler;
    private boolean isPaused = false;
    private boolean isTimerRunning = false;
    private TimerListener listener;
    private long pausedTimeMillis;
    private final SharedPreferences preferences;
    private long remainingTimeMillis;
    private TimerTask task;
    private Timer timer;

    public interface TimerListener {
        void onTimerClose();

        void onTimerPaused();

        void onTimerResumed();

        void onTimerStart();

        void onTimerUpdate(String str);
    }

    public TimePro(Context context, TimerListener timerListener) {
        context = context.getApplicationContext();
        this.context = context;
        this.listener = timerListener;
        this.handler = new Handler(Looper.getMainLooper());
        SharedPreferences sharedPreferences = context.getSharedPreferences("TimePrefs", 0);
        this.preferences = sharedPreferences;
        this.remainingTimeMillis = sharedPreferences.getLong("remainingTime", 0);
        boolean z = sharedPreferences.getBoolean("timerRunning", false);
        this.isTimerRunning = z;
        if (z) {
            long j = this.remainingTimeMillis;
            if (j > 0) {
                startTimer(j);
            }
        }
    }

    public String getCurrentTime() {
        return new SimpleDateFormat("HH:mm:ss").format(new Date());
    }

    public void startTimer(int i, int i2, int i3) {
        startTimer((((((long) i) * 3600) + (((long) i2) * 60)) + ((long) i3)) * 1000);
    }

    private void startTimer(long j) {
        stopTimer();
        this.remainingTimeMillis = j;
        this.isTimerRunning = true;
        this.isPaused = false;
        saveState();
        if (this.listener != null) {
            this.handler.post(new TimePro$$ExternalSyntheticLambda3(this));
        }
        this.timer = new Timer();
        TimerTask anonymousClass1 = new TimerTask() {
            public void run() {
                if (TimePro.this.remainingTimeMillis <= 0) {
                    TimePro.this.stopTimer();
                    if (TimePro.this.listener != null) {
                        TimePro.this.handler.post(new TimePro$1$$ExternalSyntheticLambda0(this));
                        TimePro.this.handler.post(new TimePro$1$$ExternalSyntheticLambda1(this));
                    }
                    return;
                }
                TimePro timePro = TimePro.this;
                timePro.remainingTimeMillis = timePro.remainingTimeMillis - 1000;
                TimePro.this.saveState();
                timePro = TimePro.this;
                String -$$Nest$mformatMillis = timePro.formatMillis(timePro.remainingTimeMillis);
                if (TimePro.this.listener != null) {
                    TimePro.this.handler.post(new TimePro$1$$ExternalSyntheticLambda2(this, -$$Nest$mformatMillis));
                }
            }

            /* renamed from: lambda$run$0$com-nishant-superadspro-TimePro$1 */
            /* synthetic */ void m6lambda$run$0$com-nishant-superadspro-TimePro$1() {
                TimePro.this.listener.onTimerUpdate("00:00:00");
            }

            /* renamed from: lambda$run$1$com-nishant-superadspro-TimePro$1 */
            /* synthetic */ void m7lambda$run$1$com-nishant-superadspro-TimePro$1() {
                TimePro.this.listener.onTimerClose();
            }

            /* renamed from: lambda$run$2$com-nishant-superadspro-TimePro$1 */
            /* synthetic */ void m8lambda$run$2$com-nishant-superadspro-TimePro$1(String str) {
                TimePro.this.listener.onTimerUpdate(str);
            }
        };
        this.task = anonymousClass1;
        this.timer.scheduleAtFixedRate(anonymousClass1, 0, 1000);
    }

    /* renamed from: lambda$startTimer$0$com-nishant-superadspro-TimePro */
    /* synthetic */ void m5lambda$startTimer$0$com-nishant-superadspro-TimePro() {
        this.listener.onTimerStart();
    }

    public void pauseTimer() {
        if (this.isTimerRunning && !this.isPaused) {
            this.isPaused = true;
            this.pausedTimeMillis = this.remainingTimeMillis;
            stopTimer();
            if (this.listener != null) {
                this.handler.post(new TimePro$$ExternalSyntheticLambda0(this));
            }
        }
    }

    /* renamed from: lambda$pauseTimer$1$com-nishant-superadspro-TimePro */
    /* synthetic */ void m2lambda$pauseTimer$1$com-nishant-superadspro-TimePro() {
        this.listener.onTimerPaused();
    }

    public void resumeTimer() {
        if (this.isTimerRunning && this.isPaused) {
            long j = this.pausedTimeMillis;
            this.remainingTimeMillis = j;
            this.isPaused = false;
            startTimer(j);
            if (this.listener != null) {
                this.handler.post(new TimePro$$ExternalSyntheticLambda1(this));
            }
        }
    }

    /* renamed from: lambda$resumeTimer$2$com-nishant-superadspro-TimePro */
    /* synthetic */ void m4lambda$resumeTimer$2$com-nishant-superadspro-TimePro() {
        this.listener.onTimerResumed();
    }

    public void resetTimer() {
        stopTimer();
        this.remainingTimeMillis = 0;
        saveState();
        if (this.listener != null) {
            this.handler.post(new TimePro$$ExternalSyntheticLambda2(this));
        }
    }

    /* renamed from: lambda$resetTimer$3$com-nishant-superadspro-TimePro */
    /* synthetic */ void m3lambda$resetTimer$3$com-nishant-superadspro-TimePro() {
        this.listener.onTimerUpdate("00:00:00");
    }

    public void stopTimer() {
        Timer timer = this.timer;
        if (timer != null) {
            timer.cancel();
            this.timer = null;
        }
        TimerTask timerTask = this.task;
        if (timerTask != null) {
            timerTask.cancel();
            this.task = null;
        }
        this.isTimerRunning = false;
        saveState();
    }

    private void saveState() {
        this.preferences.edit().putLong("remainingTime", this.remainingTimeMillis).putBoolean("timerRunning", this.isTimerRunning).apply();
    }

    private String formatMillis(long j) {
        int i = (int) (j / 1000);
        return String.format("%02d:%02d:%02d", new Object[]{Integer.valueOf(i / 3600), Integer.valueOf((i % 3600) / 60), Integer.valueOf(i % 60)});
    }
}
