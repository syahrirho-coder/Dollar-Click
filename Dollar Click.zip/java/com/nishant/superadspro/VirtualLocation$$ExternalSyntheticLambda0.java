package com.nishant.superadspro;

/* compiled from: D8$$SyntheticClass */
public final /* synthetic */ class VirtualLocation$$ExternalSyntheticLambda0 implements Runnable {
    public final /* synthetic */ VirtualLocation f$0;
    public final /* synthetic */ String f$1;

    public /* synthetic */ VirtualLocation$$ExternalSyntheticLambda0(VirtualLocation virtualLocation, String str) {
        this.f$0 = virtualLocation;
        this.f$1 = str;
    }

    public final void run() {
        this.f$0.m11lambda$showToast$0$com-nishant-superadspro-VirtualLocation(this.f$1);
    }
}
