package com.nishant.superadspro;

import android.content.Context;
import android.os.Handler;
import android.widget.Toast;
import com.unity3d.services.UnityAdsConstants.RequestPolicy;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;
import kotlin.time.DurationKt;

public class VirtualLocation {
    private boolean adClickSimulated = false;
    private boolean appDownloadSimulated = false;
    private final String[] cities;
    private final Context context;
    private final String[] countries;
    private final String fakeUserId;
    private final String[] highRevenueCountries;
    private final String[] ips;
    private final Random random = new Random();
    private Timer timer;
    private int updateCount = 0;

    public VirtualLocation(Context context) {
        r2 = new String[5];
        r2[0] = "USA";
        r2[1] = "India";
        r2[2] = "Germany";
        r2[3] = "UK";
        r2[4] = "France";
        this.countries = r2;
        this.cities = new String[]{"New York", "Mumbai", "Berlin", "London", "Paris"};
        this.ips = new String[]{"192.168.1.1", "192.168.2.1", "192.168.3.1", "192.168.4.1", "192.168.5.1"};
        this.highRevenueCountries = new String[]{"USA", "Germany", "UK"};
        this.context = context.getApplicationContext();
        this.fakeUserId = generateFakeUserId();
    }

    private String generateFakeUserId() {
        return "user" + this.random.nextInt(DurationKt.NANOS_IN_MILLIS);
    }

    public void startLocationProcess() {
        Timer timer = this.timer;
        if (timer != null) {
            timer.cancel();
        }
        Timer timer2 = new Timer();
        this.timer = timer2;
        timer2.scheduleAtFixedRate(new TimerTask() {
            public void run() {
                VirtualLocation.this.simulateClicks();
                int nextInt = VirtualLocation.this.random.nextInt(VirtualLocation.this.countries.length);
                VirtualLocation.this.informationUpdated(VirtualLocation.this.countries[nextInt], VirtualLocation.this.cities[nextInt], VirtualLocation.this.ips[nextInt]);
            }
        }, 0, 60000);
        showToast("Location simulation started");
    }

    public void simulateAdClick() {
        this.adClickSimulated = true;
        System.out.println("Ad click simulated.");
    }

    public void simulateAppDownload() {
        this.appDownloadSimulated = true;
        System.out.println("App download simulated.");
    }

    private void simulateClicks() {
        for (int i = 0; i < 5; i++) {
            int nextInt = this.random.nextInt(RequestPolicy.RETRY_WAIT_BASE);
            System.out.println("Simulating click at: (" + nextInt + ", " + this.random.nextInt(800) + ")");
        }
    }

    public void informationUpdated(String str, String str2, String str3) {
        for (String equalsIgnoreCase : this.highRevenueCountries) {
            String equalsIgnoreCase2;
            if (equalsIgnoreCase2.equalsIgnoreCase(str)) {
                String str4 = ", City: ";
                equalsIgnoreCase2 = ", IP: ";
                System.out.println("Sending high-revenue location info: Country: " + str + str4 + str2 + equalsIgnoreCase2 + str3);
                String str5 = ", Country: ";
                if (this.adClickSimulated) {
                    System.out.println("Ad clicked by Fake User! Tracking info sent to ad network: Fake UserID: " + this.fakeUserId + str5 + str + str4 + str2 + equalsIgnoreCase2 + str3);
                }
                if (this.appDownloadSimulated) {
                    System.out.println("App downloaded by Fake User! Tracking info sent to ad network: Fake UserID: " + this.fakeUserId + str5 + str + str4 + str2 + equalsIgnoreCase2 + str3);
                }
                return;
            }
        }
        System.out.println("Low-revenue country detected: " + str);
    }

    private void showToast(String str) {
        new Handler(this.context.getMainLooper()).post(new VirtualLocation$$ExternalSyntheticLambda0(this, str));
    }

    /* renamed from: lambda$showToast$0$com-nishant-superadspro-VirtualLocation */
    /* synthetic */ void m11lambda$showToast$0$com-nishant-superadspro-VirtualLocation(String str) {
        Toast.makeText(this.context, str, 0).show();
    }

    public void stopLocationProcess() {
        Timer timer = this.timer;
        if (timer != null) {
            timer.cancel();
            this.timer = null;
            showToast("Location simulation stopped");
        }
    }

    public int getUpdateCount() {
        int i = this.updateCount;
        this.updateCount = i + 1;
        return i;
    }
}
