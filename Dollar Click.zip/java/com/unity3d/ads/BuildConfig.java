package com.unity3d.ads;

public final class BuildConfig {
    public static final String BUILD_TYPE = "release";
    public static final boolean DEBUG = false;
    public static final String LIBRARY_PACKAGE_NAME = "com.unity3d.ads";
    public static final int VERSION_CODE = 41500;
    public static final String VERSION_NAME = "4.15.0";
    public static final String WEBVIEW_BRANCH = "4.15.0";
}
