package com.unity3d.ads;

import com.unity3d.ads.UnityAds.UnityAdsInitializationError;

public interface IUnityAdsInitializationListener {
    void onInitializationComplete();

    void onInitializationFailed(UnityAdsInitializationError unityAdsInitializationError, String str);
}
