package com.unity3d.ads;

import com.unity3d.ads.UnityAds.UnityAdsLoadError;

public interface IUnityAdsLoadListener {
    void onUnityAdsAdLoaded(String str);

    void onUnityAdsFailedToLoad(String str, UnityAdsLoadError unityAdsLoadError, String str2);
}
