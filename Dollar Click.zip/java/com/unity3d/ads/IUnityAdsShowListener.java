package com.unity3d.ads;

import com.unity3d.ads.UnityAds.UnityAdsShowCompletionState;
import com.unity3d.ads.UnityAds.UnityAdsShowError;

public interface IUnityAdsShowListener {
    void onUnityAdsShowClick(String str);

    void onUnityAdsShowComplete(String str, UnityAdsShowCompletionState unityAdsShowCompletionState);

    void onUnityAdsShowFailure(String str, UnityAdsShowError unityAdsShowError, String str2);

    void onUnityAdsShowStart(String str);
}
