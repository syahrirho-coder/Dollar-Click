package com.unity3d.ads;

public interface IUnityAdsTokenListener {
    void onUnityAdsTokenReady(String str);
}
