package com.unity3d.ads;

public class UnityAdsShowOptions extends UnityAdsBaseOptions {
}
