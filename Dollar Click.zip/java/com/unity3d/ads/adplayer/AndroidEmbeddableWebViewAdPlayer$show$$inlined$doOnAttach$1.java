package com.unity3d.ads.adplayer;

import android.view.View;
import android.view.View.OnAttachStateChangeListener;
import androidx.core.view.ViewCompat;
import com.unity3d.services.banners.BannerView;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import kotlinx.coroutines.flow.SharedFlow;

@Metadata(d1 = {"\u0000\u0019\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002*\u0001\u0000\b\n\u0018\u00002\u00020\u0001J\u0010\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u0005H\u0016J\u0010\u0010\u0006\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u0005H\u0016¨\u0006\u0007¸\u0006\u0000"}, d2 = {"androidx/core/view/ViewKt$doOnAttach$1", "Landroid/view/View$OnAttachStateChangeListener;", "onViewAttachedToWindow", "", "view", "Landroid/view/View;", "onViewDetachedFromWindow", "core-ktx_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
/* compiled from: View.kt */
public final class AndroidEmbeddableWebViewAdPlayer$show$$inlined$doOnAttach$1 implements OnAttachStateChangeListener {
    final /* synthetic */ BannerView $bannerView$inlined;
    final /* synthetic */ SharedFlow $scarEvents$inlined;
    final /* synthetic */ ShowOptions $showOptions$inlined;
    final /* synthetic */ View $this_doOnAttach;
    final /* synthetic */ AndroidEmbeddableWebViewAdPlayer this$0;

    public void onViewDetachedFromWindow(View view) {
        Intrinsics.checkNotNullParameter(view, "view");
    }

    public AndroidEmbeddableWebViewAdPlayer$show$$inlined$doOnAttach$1(View view, AndroidEmbeddableWebViewAdPlayer androidEmbeddableWebViewAdPlayer, BannerView bannerView, SharedFlow sharedFlow, ShowOptions showOptions) {
        this.$this_doOnAttach = view;
        this.this$0 = androidEmbeddableWebViewAdPlayer;
        this.$bannerView$inlined = bannerView;
        this.$scarEvents$inlined = sharedFlow;
        this.$showOptions$inlined = showOptions;
    }

    public void onViewAttachedToWindow(View view) {
        Intrinsics.checkNotNullParameter(view, "view");
        this.$this_doOnAttach.removeOnAttachStateChangeListener(this);
        BuildersKt__Builders_commonKt.launch$default(this.this$0.getScope(), null, null, new AndroidEmbeddableWebViewAdPlayer$show$1$1(this.this$0, this.$scarEvents$inlined, this.$showOptions$inlined, null), 3, null);
        view = this.$bannerView$inlined;
        if (ViewCompat.isAttachedToWindow(view)) {
            view.addOnAttachStateChangeListener(new AndroidEmbeddableWebViewAdPlayer$show$lambda$2$$inlined$doOnDetach$1(view, this.this$0));
        } else {
            BuildersKt__Builders_commonKt.launch$default(this.this$0.webViewAdPlayer.getScope(), null, null, new AndroidEmbeddableWebViewAdPlayer$show$1$2$1(this.this$0, null), 3, null);
        }
    }
}
