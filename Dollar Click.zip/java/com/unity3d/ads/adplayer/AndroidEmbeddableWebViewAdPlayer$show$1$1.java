package com.unity3d.ads.adplayer;

import com.unity3d.ads.core.data.model.ScarEvent;
import com.unity3d.ads.core.data.model.ScarEvent.Show;
import com.unity3d.ads.core.domain.scar.GmaEventData;
import com.unity3d.services.banners.bridge.BannerBridge.BannerEvent;
import java.util.Map;
import kotlin.Function;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.jvm.internal.Boxing;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.FunctionAdapter;
import kotlin.jvm.internal.FunctionReferenceImpl;
import kotlin.jvm.internal.Intrinsics;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.flow.Flow;
import kotlinx.coroutines.flow.FlowCollector;
import kotlinx.coroutines.flow.FlowKt;
import kotlinx.coroutines.flow.SharedFlow;

@Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H@"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {1, 8, 0}, xi = 48)
@DebugMetadata(c = "com.unity3d.ads.adplayer.AndroidEmbeddableWebViewAdPlayer$show$1$1", f = "AndroidEmbeddableWebViewAdPlayer.kt", i = {}, l = {75, 79}, m = "invokeSuspend", n = {}, s = {})
/* compiled from: AndroidEmbeddableWebViewAdPlayer.kt */
final class AndroidEmbeddableWebViewAdPlayer$show$1$1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
    final /* synthetic */ SharedFlow<GmaEventData> $scarEvents;
    final /* synthetic */ ShowOptions $showOptions;
    int label;
    final /* synthetic */ AndroidEmbeddableWebViewAdPlayer this$0;

    AndroidEmbeddableWebViewAdPlayer$show$1$1(AndroidEmbeddableWebViewAdPlayer androidEmbeddableWebViewAdPlayer, SharedFlow<GmaEventData> sharedFlow, ShowOptions showOptions, Continuation<? super AndroidEmbeddableWebViewAdPlayer$show$1$1> continuation) {
        this.this$0 = androidEmbeddableWebViewAdPlayer;
        this.$scarEvents = sharedFlow;
        this.$showOptions = showOptions;
        super(2, continuation);
    }

    public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
        return new AndroidEmbeddableWebViewAdPlayer$show$1$1(this.this$0, this.$scarEvents, this.$showOptions, continuation);
    }

    public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
        return ((AndroidEmbeddableWebViewAdPlayer$show$1$1) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
    }

    public final Object invokeSuspend(Object obj) {
        Object coroutine_suspended = IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED();
        int i = this.label;
        if (i == 0) {
            ResultKt.throwOnFailure(obj);
            Flow onScarEvent = this.this$0.getOnScarEvent();
            final AndroidEmbeddableWebViewAdPlayer androidEmbeddableWebViewAdPlayer = this.this$0;
            final ShowOptions showOptions = this.$showOptions;
            onScarEvent = FlowKt.onStart(onScarEvent, new Function2<FlowCollector<? super ScarEvent>, Continuation<? super Unit>, Object>(null) {
                int label;

                public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                    return /* anonymous class already generated */;
                }

                public final Object invoke(FlowCollector<? super ScarEvent> flowCollector, Continuation<? super Unit> continuation) {
                    return ((AnonymousClass1) create(flowCollector, continuation)).invokeSuspend(Unit.INSTANCE);
                }

                public final Object invokeSuspend(Object obj) {
                    Object coroutine_suspended = IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED();
                    int i = this.label;
                    if (i == 0) {
                        ResultKt.throwOnFailure(obj);
                        WebViewAdPlayer access$getWebViewAdPlayer$p = androidEmbeddableWebViewAdPlayer.webViewAdPlayer;
                        Map unityAdsShowOptions = ((AndroidShowOptions) showOptions).getUnityAdsShowOptions();
                        Continuation continuation = this;
                        this.label = 1;
                        if (access$getWebViewAdPlayer$p.requestShow(unityAdsShowOptions, continuation) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                    } else if (i == 1) {
                        ResultKt.throwOnFailure(obj);
                    } else {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    return Unit.INSTANCE;
                }
            });
            Function2 anonymousClass2 = new Function2<ScarEvent, Continuation<? super Boolean>, Object>(null) {
                /* synthetic */ Object L$0;
                int label;

                public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                    AnonymousClass2 anonymousClass2 = /* anonymous class already generated */;
                    anonymousClass2.L$0 = obj;
                    return anonymousClass2;
                }

                public final Object invoke(ScarEvent scarEvent, Continuation<? super Boolean> continuation) {
                    return ((AnonymousClass2) create(scarEvent, continuation)).invokeSuspend(Unit.INSTANCE);
                }

                public final Object invokeSuspend(Object obj) {
                    IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED();
                    if (this.label == 0) {
                        ResultKt.throwOnFailure(obj);
                        return Boxing.boxBoolean(Intrinsics.areEqual((ScarEvent) this.L$0, Show.INSTANCE));
                    }
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
            };
            Continuation continuation = this;
            this.label = 1;
            if (FlowKt.first(onScarEvent, anonymousClass2, continuation) == coroutine_suspended) {
                return coroutine_suspended;
            }
        } else if (i == 1) {
            ResultKt.throwOnFailure(obj);
        } else if (i == 2) {
            ResultKt.throwOnFailure(obj);
            return Unit.INSTANCE;
        } else {
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }
        Flow androidEmbeddableWebViewAdPlayer$show$1$1$invokeSuspend$$inlined$mapNotNull$1 = new AndroidEmbeddableWebViewAdPlayer$show$1$1$invokeSuspend$$inlined$mapNotNull$1(this.$scarEvents);
        final WebViewAdPlayer access$getWebViewAdPlayer$p = this.this$0.webViewAdPlayer;
        FlowCollector anonymousClass4 = new Object() {
            public final boolean equals(Object obj) {
                return ((obj instanceof FlowCollector) && (obj instanceof FunctionAdapter)) ? Intrinsics.areEqual(getFunctionDelegate(), ((FunctionAdapter) obj).getFunctionDelegate()) : false;
            }

            public final Function<?> getFunctionDelegate() {
                return new FunctionReferenceImpl(2, access$getWebViewAdPlayer$p, WebViewAdPlayer.class, "sendScarBannerEvent", "sendScarBannerEvent(Lcom/unity3d/services/banners/bridge/BannerBridge$BannerEvent;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", 0);
            }

            public final int hashCode() {
                return getFunctionDelegate().hashCode();
            }

            public final Object emit(BannerEvent bannerEvent, Continuation<? super Unit> continuation) {
                Object sendScarBannerEvent = access$getWebViewAdPlayer$p.sendScarBannerEvent(bannerEvent, continuation);
                return sendScarBannerEvent == IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED() ? sendScarBannerEvent : Unit.INSTANCE;
            }
        };
        Continuation continuation2 = this;
        this.label = 2;
        if (androidEmbeddableWebViewAdPlayer$show$1$1$invokeSuspend$$inlined$mapNotNull$1.collect(anonymousClass4, continuation2) == coroutine_suspended) {
            return coroutine_suspended;
        }
        return Unit.INSTANCE;
    }
}
