package com.unity3d.ads.adplayer;

import android.app.Activity;
import android.content.Context;
import android.view.View;
import androidx.core.view.ViewCompat;
import com.unity3d.ads.adplayer.model.LoadEvent;
import com.unity3d.ads.core.data.datasource.LifecycleDataSource;
import com.unity3d.ads.core.data.manager.ScarManager;
import com.unity3d.ads.core.data.model.OfferwallShowEvent;
import com.unity3d.ads.core.data.model.ScarEvent;
import com.unity3d.ads.core.data.model.ShowEvent;
import com.unity3d.ads.core.data.repository.OpenMeasurementRepository;
import com.unity3d.scar.adapter.common.GMAEvent;
import com.unity3d.scar.adapter.common.scarads.ScarAdMetadata;
import com.unity3d.services.ads.offerwall.OfferwallEvent;
import com.unity3d.services.banners.BannerView;
import com.unity3d.services.banners.BannerViewCache;
import com.unity3d.services.banners.UnityBannerSize;
import com.unity3d.services.banners.bridge.BannerBridge.BannerEvent;
import java.util.Map;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.jvm.internal.Intrinsics;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.CoroutineScopeKt;
import kotlinx.coroutines.flow.Flow;
import kotlinx.coroutines.flow.FlowKt;
import kotlinx.coroutines.flow.SharedFlow;
import kotlinx.coroutines.flow.SharingStarted;

@Metadata(d1 = {"\u0000ª\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u0002\n\u0002\b\u0004\n\u0002\u0010\u0012\n\u0002\b\u0006\n\u0002\u0010$\n\u0002\u0010\u0000\n\u0002\b\u0004\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0010\u0006\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\b\u0000\u0018\u00002\u00020\u00012\u00020\u0002B5\u0012\u0006\u0010\u0003\u001a\u00020\u0004\u0012\u0006\u0010\u0005\u001a\u00020\u0006\u0012\u0006\u0010\u0007\u001a\u00020\b\u0012\u0006\u0010\t\u001a\u00020\n\u0012\u0006\u0010\u000b\u001a\u00020\f\u0012\u0006\u0010\r\u001a\u00020\u000e¢\u0006\u0002\u0010\u000fJ\u0011\u0010$\u001a\u00020%H@ø\u0001\u0000¢\u0006\u0002\u0010&J\t\u0010'\u001a\u00020%H\u0001J\u0019\u0010(\u001a\u00020%2\u0006\u0010)\u001a\u00020*HAø\u0001\u0000¢\u0006\u0002\u0010+J\u0019\u0010,\u001a\u00020%2\u0006\u0010-\u001a\u00020\u0006HAø\u0001\u0000¢\u0006\u0002\u0010.J)\u0010/\u001a\u00020%2\u0016\u00100\u001a\u0012\u0012\u0004\u0012\u00020\u0006\u0012\u0006\u0012\u0004\u0018\u000102\u0018\u000101HAø\u0001\u0000¢\u0006\u0002\u00103J\u0011\u00104\u001a\u00020%HAø\u0001\u0000¢\u0006\u0002\u0010&J\u0019\u00105\u001a\u00020%2\u0006\u00106\u001a\u000207HAø\u0001\u0000¢\u0006\u0002\u00108J\u0019\u00109\u001a\u00020%2\u0006\u0010-\u001a\u00020:HAø\u0001\u0000¢\u0006\u0002\u0010;J\u0019\u0010<\u001a\u00020%2\u0006\u0010=\u001a\u000207HAø\u0001\u0000¢\u0006\u0002\u00108J\u0019\u0010>\u001a\u00020%2\u0006\u0010-\u001a\u00020?HAø\u0001\u0000¢\u0006\u0002\u0010@J\u0019\u0010A\u001a\u00020%2\u0006\u0010)\u001a\u00020*HAø\u0001\u0000¢\u0006\u0002\u0010+J\u0019\u0010B\u001a\u00020%2\u0006\u0010-\u001a\u00020CHAø\u0001\u0000¢\u0006\u0002\u0010DJ\u0019\u0010E\u001a\u00020%2\u0006\u0010)\u001a\u00020*HAø\u0001\u0000¢\u0006\u0002\u0010+J\u0019\u0010F\u001a\u00020%2\u0006\u0010G\u001a\u000207HAø\u0001\u0000¢\u0006\u0002\u00108J\u0019\u0010H\u001a\u00020%2\u0006\u0010I\u001a\u00020JHAø\u0001\u0000¢\u0006\u0002\u0010KJ\u0010\u0010L\u001a\u00020%2\u0006\u0010M\u001a\u00020NH\u0016R\u000e\u0010\r\u001a\u00020\u000eX\u0004¢\u0006\u0002\n\u0000R\u0018\u0010\u0010\u001a\b\u0012\u0004\u0012\u00020\u00120\u0011X\u0005¢\u0006\u0006\u001a\u0004\b\u0013\u0010\u0014R\u0018\u0010\u0015\u001a\b\u0012\u0004\u0012\u00020\u00160\u0011X\u0005¢\u0006\u0006\u001a\u0004\b\u0017\u0010\u0014R\u0018\u0010\u0018\u001a\b\u0012\u0004\u0012\u00020\u00190\u0011X\u0005¢\u0006\u0006\u001a\u0004\b\u001a\u0010\u0014R\u0018\u0010\u001b\u001a\b\u0012\u0004\u0012\u00020\u001c0\u0011X\u0005¢\u0006\u0006\u001a\u0004\b\u001d\u0010\u0014R\u000e\u0010\t\u001a\u00020\nX\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0006X\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\fX\u0004¢\u0006\u0002\n\u0000R\u0012\u0010\u001e\u001a\u00020\u001fX\u0005¢\u0006\u0006\u001a\u0004\b \u0010!R\u000e\u0010\u0003\u001a\u00020\u0004X\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\u0007\u001a\u00020\bX\u0004¢\u0006\b\n\u0000\u001a\u0004\b\"\u0010#\u0002\u0004\n\u0002\b\u0019¨\u0006O"}, d2 = {"Lcom/unity3d/ads/adplayer/AndroidEmbeddableWebViewAdPlayer;", "Lcom/unity3d/ads/adplayer/AdPlayer;", "Lcom/unity3d/ads/adplayer/EmbeddableAdPlayer;", "webViewAdPlayer", "Lcom/unity3d/ads/adplayer/WebViewAdPlayer;", "opportunityId", "", "webViewContainer", "Lcom/unity3d/ads/adplayer/AndroidWebViewContainer;", "openMeasurementRepository", "Lcom/unity3d/ads/core/data/repository/OpenMeasurementRepository;", "scarManager", "Lcom/unity3d/ads/core/data/manager/ScarManager;", "lifecycleDataSource", "Lcom/unity3d/ads/core/data/datasource/LifecycleDataSource;", "(Lcom/unity3d/ads/adplayer/WebViewAdPlayer;Ljava/lang/String;Lcom/unity3d/ads/adplayer/AndroidWebViewContainer;Lcom/unity3d/ads/core/data/repository/OpenMeasurementRepository;Lcom/unity3d/ads/core/data/manager/ScarManager;Lcom/unity3d/ads/core/data/datasource/LifecycleDataSource;)V", "onLoadEvent", "Lkotlinx/coroutines/flow/Flow;", "Lcom/unity3d/ads/adplayer/model/LoadEvent;", "getOnLoadEvent", "()Lkotlinx/coroutines/flow/Flow;", "onOfferwallEvent", "Lcom/unity3d/ads/core/data/model/OfferwallShowEvent;", "getOnOfferwallEvent", "onScarEvent", "Lcom/unity3d/ads/core/data/model/ScarEvent;", "getOnScarEvent", "onShowEvent", "Lcom/unity3d/ads/core/data/model/ShowEvent;", "getOnShowEvent", "scope", "Lkotlinx/coroutines/CoroutineScope;", "getScope", "()Lkotlinx/coroutines/CoroutineScope;", "getWebViewContainer", "()Lcom/unity3d/ads/adplayer/AndroidWebViewContainer;", "destroy", "", "(Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "dispatchShowCompleted", "onAllowedPiiChange", "value", "", "([BLkotlin/coroutines/Continuation;)Ljava/lang/Object;", "onBroadcastEvent", "event", "(Ljava/lang/String;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "requestShow", "unityAdsShowOptions", "", "", "(Ljava/util/Map;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "sendActivityDestroyed", "sendFocusChange", "isFocused", "", "(ZLkotlin/coroutines/Continuation;)Ljava/lang/Object;", "sendGmaEvent", "Lcom/unity3d/scar/adapter/common/GMAEvent;", "(Lcom/unity3d/scar/adapter/common/GMAEvent;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "sendMuteChange", "isMuted", "sendOfferwallEvent", "Lcom/unity3d/services/ads/offerwall/OfferwallEvent;", "(Lcom/unity3d/services/ads/offerwall/OfferwallEvent;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "sendPrivacyFsmChange", "sendScarBannerEvent", "Lcom/unity3d/services/banners/bridge/BannerBridge$BannerEvent;", "(Lcom/unity3d/services/banners/bridge/BannerBridge$BannerEvent;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "sendUserConsentChange", "sendVisibilityChange", "isVisible", "sendVolumeChange", "volume", "", "(DLkotlin/coroutines/Continuation;)Ljava/lang/Object;", "show", "showOptions", "Lcom/unity3d/ads/adplayer/ShowOptions;", "unity-ads_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
/* compiled from: AndroidEmbeddableWebViewAdPlayer.kt */
public final class AndroidEmbeddableWebViewAdPlayer implements AdPlayer, EmbeddableAdPlayer {
    private final LifecycleDataSource lifecycleDataSource;
    private final OpenMeasurementRepository openMeasurementRepository;
    private final String opportunityId;
    private final ScarManager scarManager;
    private final WebViewAdPlayer webViewAdPlayer;
    private final AndroidWebViewContainer webViewContainer;

    public void dispatchShowCompleted() {
        this.webViewAdPlayer.dispatchShowCompleted();
    }

    public Flow<LoadEvent> getOnLoadEvent() {
        return this.webViewAdPlayer.getOnLoadEvent();
    }

    public Flow<OfferwallShowEvent> getOnOfferwallEvent() {
        return this.webViewAdPlayer.getOnOfferwallEvent();
    }

    public Flow<ScarEvent> getOnScarEvent() {
        return this.webViewAdPlayer.getOnScarEvent();
    }

    public Flow<ShowEvent> getOnShowEvent() {
        return this.webViewAdPlayer.getOnShowEvent();
    }

    public CoroutineScope getScope() {
        return this.webViewAdPlayer.getScope();
    }

    public Object onAllowedPiiChange(byte[] bArr, Continuation<? super Unit> continuation) {
        return this.webViewAdPlayer.onAllowedPiiChange(bArr, continuation);
    }

    public Object onBroadcastEvent(String str, Continuation<? super Unit> continuation) {
        return this.webViewAdPlayer.onBroadcastEvent(str, continuation);
    }

    public Object requestShow(Map<String, ? extends Object> map, Continuation<? super Unit> continuation) {
        return this.webViewAdPlayer.requestShow(map, continuation);
    }

    public Object sendActivityDestroyed(Continuation<? super Unit> continuation) {
        return this.webViewAdPlayer.sendActivityDestroyed(continuation);
    }

    public Object sendFocusChange(boolean z, Continuation<? super Unit> continuation) {
        return this.webViewAdPlayer.sendFocusChange(z, continuation);
    }

    public Object sendGmaEvent(GMAEvent gMAEvent, Continuation<? super Unit> continuation) {
        return this.webViewAdPlayer.sendGmaEvent(gMAEvent, continuation);
    }

    public Object sendMuteChange(boolean z, Continuation<? super Unit> continuation) {
        return this.webViewAdPlayer.sendMuteChange(z, continuation);
    }

    public Object sendOfferwallEvent(OfferwallEvent offerwallEvent, Continuation<? super Unit> continuation) {
        return this.webViewAdPlayer.sendOfferwallEvent(offerwallEvent, continuation);
    }

    public Object sendPrivacyFsmChange(byte[] bArr, Continuation<? super Unit> continuation) {
        return this.webViewAdPlayer.sendPrivacyFsmChange(bArr, continuation);
    }

    public Object sendScarBannerEvent(BannerEvent bannerEvent, Continuation<? super Unit> continuation) {
        return this.webViewAdPlayer.sendScarBannerEvent(bannerEvent, continuation);
    }

    public Object sendUserConsentChange(byte[] bArr, Continuation<? super Unit> continuation) {
        return this.webViewAdPlayer.sendUserConsentChange(bArr, continuation);
    }

    public Object sendVisibilityChange(boolean z, Continuation<? super Unit> continuation) {
        return this.webViewAdPlayer.sendVisibilityChange(z, continuation);
    }

    public Object sendVolumeChange(double d, Continuation<? super Unit> continuation) {
        return this.webViewAdPlayer.sendVolumeChange(d, continuation);
    }

    public AndroidEmbeddableWebViewAdPlayer(WebViewAdPlayer webViewAdPlayer, String str, AndroidWebViewContainer androidWebViewContainer, OpenMeasurementRepository openMeasurementRepository, ScarManager scarManager, LifecycleDataSource lifecycleDataSource) {
        Intrinsics.checkNotNullParameter(webViewAdPlayer, "webViewAdPlayer");
        Intrinsics.checkNotNullParameter(str, "opportunityId");
        Intrinsics.checkNotNullParameter(androidWebViewContainer, "webViewContainer");
        Intrinsics.checkNotNullParameter(openMeasurementRepository, "openMeasurementRepository");
        Intrinsics.checkNotNullParameter(scarManager, "scarManager");
        Intrinsics.checkNotNullParameter(lifecycleDataSource, "lifecycleDataSource");
        this.webViewAdPlayer = webViewAdPlayer;
        this.opportunityId = str;
        this.webViewContainer = androidWebViewContainer;
        this.openMeasurementRepository = openMeasurementRepository;
        this.scarManager = scarManager;
        this.lifecycleDataSource = lifecycleDataSource;
    }

    public AndroidWebViewContainer getWebViewContainer() {
        return this.webViewContainer;
    }

    public void show(ShowOptions showOptions) {
        ShowOptions showOptions2 = showOptions;
        Intrinsics.checkNotNullParameter(showOptions2, "showOptions");
        if (showOptions2 instanceof AndroidShowOptions) {
            AndroidShowOptions androidShowOptions = (AndroidShowOptions) showOptions2;
            Activity activity = (Activity) androidShowOptions.getActivity().get();
            if (activity != null) {
                BannerViewCache instance = BannerViewCache.getInstance();
                BannerView bannerView = instance.getBannerView(this.opportunityId);
                if (bannerView == null) {
                    Object obj;
                    if (instance.isBannerViewDeleted(this.opportunityId)) {
                        obj = "BannerView has been deleted";
                    } else {
                        obj = "BannerView not found";
                    }
                    throw new IllegalStateException(obj.toString());
                } else if (androidShowOptions.isScarAd()) {
                    String placementId = androidShowOptions.getPlacementId();
                    String str = "";
                    String str2 = placementId == null ? str : placementId;
                    placementId = androidShowOptions.getScarQueryId();
                    String str3 = placementId == null ? str : placementId;
                    placementId = androidShowOptions.getScarAdUnitId();
                    String str4 = placementId == null ? str : placementId;
                    String scarAdString = androidShowOptions.getScarAdString();
                    if (scarAdString == null) {
                        scarAdString = str;
                    }
                    ScarAdMetadata scarAdMetadata = new ScarAdMetadata(str2, str3, str4, scarAdString, Integer.valueOf(0));
                    ScarManager scarManager = this.scarManager;
                    Context context = activity;
                    UnityBannerSize size = bannerView.getSize();
                    Intrinsics.checkNotNullExpressionValue(size, "bannerView.size");
                    SharedFlow shareIn = FlowKt.shareIn(scarManager.loadBannerAd(context, bannerView, scarAdMetadata, size, this.opportunityId), getScope(), SharingStarted.Companion.getEagerly(), 10);
                    View view = bannerView;
                    if (ViewCompat.isAttachedToWindow(view)) {
                        BuildersKt__Builders_commonKt.launch$default(getScope(), null, null, new AndroidEmbeddableWebViewAdPlayer$show$1$1(this, shareIn, showOptions2, null), 3, null);
                        if (ViewCompat.isAttachedToWindow(view)) {
                            view.addOnAttachStateChangeListener(new AndroidEmbeddableWebViewAdPlayer$show$lambda$2$$inlined$doOnDetach$1(view, this));
                            return;
                        } else {
                            BuildersKt__Builders_commonKt.launch$default(this.webViewAdPlayer.getScope(), null, null, new AndroidEmbeddableWebViewAdPlayer$show$1$2$1(this, null), 3, null);
                            return;
                        }
                    }
                    view.addOnAttachStateChangeListener(new AndroidEmbeddableWebViewAdPlayer$show$$inlined$doOnAttach$1(view, this, bannerView, shareIn, showOptions));
                    return;
                } else {
                    BuildersKt__Builders_commonKt.launch$default(CoroutineScopeKt.MainScope(), null, null, new AndroidEmbeddableWebViewAdPlayer$show$2(this, activity, bannerView, null), 3, null);
                    View webView = getWebViewContainer().getWebView();
                    if (ViewCompat.isAttachedToWindow(webView)) {
                        BuildersKt__Builders_commonKt.launch$default(this.webViewAdPlayer.getScope(), null, null, new AndroidEmbeddableWebViewAdPlayer$show$3$1(this, showOptions2, null), 3, null);
                        if (ViewCompat.isAttachedToWindow(webView)) {
                            webView.addOnAttachStateChangeListener(new AndroidEmbeddableWebViewAdPlayer$show$lambda$4$$inlined$doOnDetach$1(webView, this));
                        } else {
                            BuildersKt__Builders_commonKt.launch$default(this.webViewAdPlayer.getScope(), null, null, new AndroidEmbeddableWebViewAdPlayer$show$3$2$1(this, null), 3, null);
                        }
                    } else {
                        webView.addOnAttachStateChangeListener(new AndroidEmbeddableWebViewAdPlayer$show$$inlined$doOnAttach$2(webView, this, showOptions2));
                    }
                    BuildersKt__Builders_commonKt.launch$default(CoroutineScopeKt.MainScope(), null, null, new AndroidEmbeddableWebViewAdPlayer$show$4(bannerView, this, null), 3, null);
                    return;
                }
            }
            throw new IllegalArgumentException("Required value was null.".toString());
        }
        throw new IllegalArgumentException("Failed requirement.".toString());
    }

    /* DevToolsApp WARNING: Removed duplicated region for block: B:27:0x0086 A:{RETURN} */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:16:0x0048  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:8:0x0026  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:24:0x007a A:{RETURN} */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:27:0x0086 A:{RETURN} */
    public java.lang.Object destroy(kotlin.coroutines.Continuation<? super kotlin.Unit> r8) {
        /*
        r7 = this;
        r0 = r8 instanceof com.unity3d.ads.adplayer.AndroidEmbeddableWebViewAdPlayer$destroy$1;
        if (r0 == 0) goto L_0x0014;
    L_0x0004:
        r0 = r8;
        r0 = (com.unity3d.ads.adplayer.AndroidEmbeddableWebViewAdPlayer$destroy$1) r0;
        r1 = r0.label;
        r2 = -2147483648; // 0xffffffff80000000 float:-0.0 double:NaN;
        r1 = r1 & r2;
        if (r1 == 0) goto L_0x0014;
    L_0x000e:
        r8 = r0.label;
        r8 = r8 - r2;
        r0.label = r8;
        goto L_0x0019;
    L_0x0014:
        r0 = new com.unity3d.ads.adplayer.AndroidEmbeddableWebViewAdPlayer$destroy$1;
        r0.<init>(r7, r8);
    L_0x0019:
        r8 = r0.result;
        r1 = kotlin.coroutines.intrinsics.IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED();
        r2 = r0.label;
        r3 = 3;
        r4 = 2;
        r5 = 1;
        if (r2 == 0) goto L_0x0048;
    L_0x0026:
        if (r2 == r5) goto L_0x0040;
    L_0x0028:
        if (r2 == r4) goto L_0x0038;
    L_0x002a:
        if (r2 != r3) goto L_0x0030;
    L_0x002c:
        kotlin.ResultKt.throwOnFailure(r8);
        goto L_0x0087;
    L_0x0030:
        r8 = new java.lang.IllegalStateException;
        r0 = "call to 'resume' before 'invoke' with coroutine";
        r8.<init>(r0);
        throw r8;
    L_0x0038:
        r2 = r0.L$0;
        r2 = (com.unity3d.ads.adplayer.AndroidEmbeddableWebViewAdPlayer) r2;
        kotlin.ResultKt.throwOnFailure(r8);
        goto L_0x007b;
    L_0x0040:
        r2 = r0.L$0;
        r2 = (com.unity3d.ads.adplayer.AndroidEmbeddableWebViewAdPlayer) r2;
        kotlin.ResultKt.throwOnFailure(r8);
        goto L_0x006c;
    L_0x0048:
        kotlin.ResultKt.throwOnFailure(r8);
        r8 = r7.webViewAdPlayer;
        r8.dispatchShowCompleted();
        r8 = r7.openMeasurementRepository;
        r2 = r7.opportunityId;
        r2 = com.google.protobuf.kotlin.ByteStringsKt.toByteStringUtf8(r2);
        r8 = r8.hasSessionFinished(r2);
        if (r8 == 0) goto L_0x006b;
    L_0x005e:
        r0.L$0 = r7;
        r0.label = r5;
        r5 = 1000; // 0x3e8 float:1.401E-42 double:4.94E-321;
        r8 = kotlinx.coroutines.DelayKt.delay(r5, r0);
        if (r8 != r1) goto L_0x006b;
    L_0x006a:
        return r1;
    L_0x006b:
        r2 = r7;
    L_0x006c:
        r8 = r2.getWebViewContainer();
        r0.L$0 = r2;
        r0.label = r4;
        r8 = r8.destroy(r0);
        if (r8 != r1) goto L_0x007b;
    L_0x007a:
        return r1;
    L_0x007b:
        r8 = 0;
        r0.L$0 = r8;
        r0.label = r3;
        r8 = com.unity3d.ads.adplayer.AdPlayer.DefaultImpls.destroy(r2, r0);
        if (r8 != r1) goto L_0x0087;
    L_0x0086:
        return r1;
    L_0x0087:
        r8 = kotlin.Unit.INSTANCE;
        return r8;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.unity3d.ads.adplayer.AndroidEmbeddableWebViewAdPlayer.destroy(kotlin.coroutines.Continuation):java.lang.Object");
    }
}
