package com.unity3d.ads.adplayer;

import com.unity3d.ads.core.data.model.AdObject;
import com.unity3d.ads.core.data.repository.AdRepository;
import com.unity3d.ads.core.extensions.ProtobufExtensionsKt;
import java.util.UUID;
import kotlin.Metadata;
import kotlin.Result;
import kotlin.Result.Companion;
import kotlin.ResultKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Lambda;

@Metadata(d1 = {"\u0000\b\n\u0000\n\u0002\u0018\u0002\n\u0000\u0010\u0000\u001a\u0004\u0018\u00010\u0001H\n¢\u0006\u0002\b\u0002"}, d2 = {"<anonymous>", "Lcom/unity3d/ads/core/data/model/AdObject;", "invoke"}, k = 3, mv = {1, 8, 0}, xi = 48)
/* compiled from: AndroidFullscreenWebViewAdPlayer.kt */
final class AndroidFullscreenWebViewAdPlayer$adObject$2 extends Lambda implements Function0<AdObject> {
    final /* synthetic */ AndroidFullscreenWebViewAdPlayer this$0;

    AndroidFullscreenWebViewAdPlayer$adObject$2(AndroidFullscreenWebViewAdPlayer androidFullscreenWebViewAdPlayer) {
        this.this$0 = androidFullscreenWebViewAdPlayer;
        super(0);
    }

    public final AdObject invoke() {
        Object constructor-impl;
        AndroidFullscreenWebViewAdPlayer androidFullscreenWebViewAdPlayer = this.this$0;
        Companion companion;
        try {
            companion = Result.Companion;
            AdRepository access$getAdRepository$p = androidFullscreenWebViewAdPlayer.adRepository;
            UUID fromString = UUID.fromString(androidFullscreenWebViewAdPlayer.opportunityId);
            Intrinsics.checkNotNullExpressionValue(fromString, "fromString(opportunityId)");
            constructor-impl = Result.m17constructor-impl(access$getAdRepository$p.getAd(ProtobufExtensionsKt.toByteString(fromString)));
        } catch (Throwable th) {
            companion = Result.Companion;
            constructor-impl = Result.m17constructor-impl(ResultKt.createFailure(th));
        }
        if (Result.m23isFailure-impl(constructor-impl)) {
            constructor-impl = null;
        }
        return (AdObject) constructor-impl;
    }
}
