package com.unity3d.ads.adplayer;

import com.unity3d.ads.adplayer.DisplayMessage.DisplayDestroyed;
import com.unity3d.ads.adplayer.DisplayMessage.DisplayError;
import com.unity3d.ads.adplayer.DisplayMessage.DisplayReady;
import com.unity3d.ads.adplayer.DisplayMessage.FocusChanged;
import com.unity3d.ads.adplayer.DisplayMessage.VisibilityChanged;
import com.unity3d.ads.adplayer.DisplayMessage.WebViewInstanceRequest;
import com.unity3d.ads.adplayer.DisplayMessage.WebViewInstanceResponse;
import com.unity3d.ads.core.domain.SendDiagnosticEvent.DefaultImpls;
import java.util.Map;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.TuplesKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Reflection;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.flow.MutableSharedFlow;

@Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H@"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {1, 8, 0}, xi = 48)
@DebugMetadata(c = "com.unity3d.ads.adplayer.AndroidFullscreenWebViewAdPlayer$displayEventsRouter$1", f = "AndroidFullscreenWebViewAdPlayer.kt", i = {}, l = {190, 191, 192, 193, 194, 196}, m = "invokeSuspend", n = {}, s = {})
/* compiled from: AndroidFullscreenWebViewAdPlayer.kt */
final class AndroidFullscreenWebViewAdPlayer$displayEventsRouter$1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
    final /* synthetic */ DisplayMessage $displayMessage;
    int label;
    final /* synthetic */ AndroidFullscreenWebViewAdPlayer this$0;

    AndroidFullscreenWebViewAdPlayer$displayEventsRouter$1(AndroidFullscreenWebViewAdPlayer androidFullscreenWebViewAdPlayer, DisplayMessage displayMessage, Continuation<? super AndroidFullscreenWebViewAdPlayer$displayEventsRouter$1> continuation) {
        this.this$0 = androidFullscreenWebViewAdPlayer;
        this.$displayMessage = displayMessage;
        super(2, continuation);
    }

    public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
        return new AndroidFullscreenWebViewAdPlayer$displayEventsRouter$1(this.this$0, this.$displayMessage, continuation);
    }

    public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
        return ((AndroidFullscreenWebViewAdPlayer$displayEventsRouter$1) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
    }

    public final Object invokeSuspend(Object obj) {
        Object coroutine_suspended = IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED();
        switch (this.label) {
            case 0:
                ResultKt.throwOnFailure(obj);
                String str = "native_show_ad_viewer_fullscreen_activity_event";
                DefaultImpls.invoke$default(this.this$0.sendDiagnosticEvent, str, null, MapsKt__MapsJVMKt.mapOf(TuplesKt.to("eventType", String.valueOf(Reflection.getOrCreateKotlinClass(this.$displayMessage.getClass()).getSimpleName()))), null, this.this$0.getAdObject(), null, 42, null);
                DisplayMessage displayMessage = this.$displayMessage;
                WebViewAdPlayer access$getWebViewAdPlayer$p;
                Continuation continuation;
                boolean isVisible;
                Continuation continuation2;
                if (displayMessage instanceof DisplayReady) {
                    access$getWebViewAdPlayer$p = this.this$0.webViewAdPlayer;
                    Map showOptions = ((DisplayReady) this.$displayMessage).getShowOptions();
                    continuation = this;
                    this.label = 1;
                    if (access$getWebViewAdPlayer$p.requestShow(showOptions, continuation) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                } else if (displayMessage instanceof WebViewInstanceRequest) {
                    MutableSharedFlow displayMessages = AndroidFullscreenWebViewAdPlayer.Companion.getDisplayMessages();
                    WebViewInstanceResponse webViewInstanceResponse = new WebViewInstanceResponse(this.$displayMessage.getOpportunityId(), this.this$0.getWebViewContainer().getWebView());
                    continuation = this;
                    this.label = 2;
                    if (displayMessages.emit(webViewInstanceResponse, continuation) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                } else if (displayMessage instanceof VisibilityChanged) {
                    access$getWebViewAdPlayer$p = this.this$0.webViewAdPlayer;
                    isVisible = ((VisibilityChanged) this.$displayMessage).isVisible();
                    continuation = this;
                    this.label = 3;
                    if (access$getWebViewAdPlayer$p.sendVisibilityChange(isVisible, continuation) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                } else if (displayMessage instanceof FocusChanged) {
                    access$getWebViewAdPlayer$p = this.this$0.webViewAdPlayer;
                    isVisible = ((FocusChanged) this.$displayMessage).isFocused();
                    continuation = this;
                    this.label = 4;
                    if (access$getWebViewAdPlayer$p.sendFocusChange(isVisible, continuation) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                } else if (displayMessage instanceof DisplayDestroyed) {
                    access$getWebViewAdPlayer$p = this.this$0.webViewAdPlayer;
                    continuation2 = this;
                    this.label = 5;
                    if (access$getWebViewAdPlayer$p.sendActivityDestroyed(continuation2) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                } else if (displayMessage instanceof DisplayError) {
                    AndroidFullscreenWebViewAdPlayer androidFullscreenWebViewAdPlayer = this.this$0;
                    continuation2 = this;
                    this.label = 6;
                    if (androidFullscreenWebViewAdPlayer.destroy(continuation2) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                }
                break;
            case 1:
            case 2:
            case 3:
            case 4:
            case 5:
            case 6:
                ResultKt.throwOnFailure(obj);
                break;
            default:
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }
        return Unit.INSTANCE;
    }
}
