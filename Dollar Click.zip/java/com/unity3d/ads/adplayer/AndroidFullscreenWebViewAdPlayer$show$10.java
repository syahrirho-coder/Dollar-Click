package com.unity3d.ads.adplayer;

import com.unity3d.ads.adplayer.DisplayMessage.DisplayReady;
import com.unity3d.ads.core.data.manager.OfferwallManager;
import com.unity3d.ads.core.data.model.OfferwallShowEvent;
import com.unity3d.ads.core.data.model.OfferwallShowEvent.Show;
import com.unity3d.services.ads.offerwall.OfferwallEvent;
import kotlin.Function;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.jvm.internal.Boxing;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.FunctionAdapter;
import kotlin.jvm.internal.FunctionReferenceImpl;
import kotlin.jvm.internal.Intrinsics;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.flow.Flow;
import kotlinx.coroutines.flow.FlowCollector;
import kotlinx.coroutines.flow.FlowKt;
import kotlinx.coroutines.flow.MutableSharedFlow;
import kotlinx.coroutines.flow.SharingStarted;

@Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H@"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {1, 8, 0}, xi = 48)
@DebugMetadata(c = "com.unity3d.ads.adplayer.AndroidFullscreenWebViewAdPlayer$show$10", f = "AndroidFullscreenWebViewAdPlayer.kt", i = {}, l = {144, 149}, m = "invokeSuspend", n = {}, s = {})
/* compiled from: AndroidFullscreenWebViewAdPlayer.kt */
final class AndroidFullscreenWebViewAdPlayer$show$10 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
    final /* synthetic */ ShowOptions $showOptions;
    int label;
    final /* synthetic */ AndroidFullscreenWebViewAdPlayer this$0;

    AndroidFullscreenWebViewAdPlayer$show$10(AndroidFullscreenWebViewAdPlayer androidFullscreenWebViewAdPlayer, ShowOptions showOptions, Continuation<? super AndroidFullscreenWebViewAdPlayer$show$10> continuation) {
        this.this$0 = androidFullscreenWebViewAdPlayer;
        this.$showOptions = showOptions;
        super(2, continuation);
    }

    public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
        return new AndroidFullscreenWebViewAdPlayer$show$10(this.this$0, this.$showOptions, continuation);
    }

    public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
        return ((AndroidFullscreenWebViewAdPlayer$show$10) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
    }

    public final Object invokeSuspend(Object obj) {
        Object coroutine_suspended = IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED();
        int i = this.label;
        if (i == 0) {
            ResultKt.throwOnFailure(obj);
            Flow onOfferwallEvent = this.this$0.getOnOfferwallEvent();
            final AndroidFullscreenWebViewAdPlayer androidFullscreenWebViewAdPlayer = this.this$0;
            final ShowOptions showOptions = this.$showOptions;
            onOfferwallEvent = FlowKt.onStart(onOfferwallEvent, new Function2<FlowCollector<? super OfferwallShowEvent>, Continuation<? super Unit>, Object>(null) {
                int label;

                public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                    return /* anonymous class already generated */;
                }

                public final Object invoke(FlowCollector<? super OfferwallShowEvent> flowCollector, Continuation<? super Unit> continuation) {
                    return ((AnonymousClass1) create(flowCollector, continuation)).invokeSuspend(Unit.INSTANCE);
                }

                public final Object invokeSuspend(Object obj) {
                    Object coroutine_suspended = IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED();
                    int i = this.label;
                    if (i == 0) {
                        ResultKt.throwOnFailure(obj);
                        MutableSharedFlow displayMessages = AndroidFullscreenWebViewAdPlayer.Companion.getDisplayMessages();
                        DisplayReady displayReady = new DisplayReady(androidFullscreenWebViewAdPlayer.opportunityId, ((AndroidShowOptions) showOptions).getUnityAdsShowOptions());
                        Continuation continuation = this;
                        this.label = 1;
                        if (displayMessages.emit(displayReady, continuation) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                    } else if (i == 1) {
                        ResultKt.throwOnFailure(obj);
                    } else {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    return Unit.INSTANCE;
                }
            });
            Function2 anonymousClass2 = new Function2<OfferwallShowEvent, Continuation<? super Boolean>, Object>(null) {
                /* synthetic */ Object L$0;
                int label;

                public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                    AnonymousClass2 anonymousClass2 = /* anonymous class already generated */;
                    anonymousClass2.L$0 = obj;
                    return anonymousClass2;
                }

                public final Object invoke(OfferwallShowEvent offerwallShowEvent, Continuation<? super Boolean> continuation) {
                    return ((AnonymousClass2) create(offerwallShowEvent, continuation)).invokeSuspend(Unit.INSTANCE);
                }

                public final Object invokeSuspend(Object obj) {
                    IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED();
                    if (this.label == 0) {
                        ResultKt.throwOnFailure(obj);
                        return Boxing.boxBoolean(Intrinsics.areEqual((OfferwallShowEvent) this.L$0, Show.INSTANCE));
                    }
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
            };
            Continuation continuation = this;
            this.label = 1;
            if (FlowKt.first(onOfferwallEvent, anonymousClass2, continuation) == coroutine_suspended) {
                return coroutine_suspended;
            }
        } else if (i == 1) {
            ResultKt.throwOnFailure(obj);
        } else if (i == 2) {
            ResultKt.throwOnFailure(obj);
            return Unit.INSTANCE;
        } else {
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }
        OfferwallManager access$getOfferwallManager$p = this.this$0.offerwallManager;
        String offerwallPlacementName = ((AndroidShowOptions) this.$showOptions).getOfferwallPlacementName();
        if (offerwallPlacementName == null) {
            offerwallPlacementName = "";
        }
        Flow androidFullscreenWebViewAdPlayer$show$10$invokeSuspend$$inlined$mapNotNull$1 = new AndroidFullscreenWebViewAdPlayer$show$10$invokeSuspend$$inlined$mapNotNull$1(FlowKt.shareIn(access$getOfferwallManager$p.showAd(offerwallPlacementName), this.this$0.getScope(), SharingStarted.Companion.getEagerly(), 5));
        final WebViewAdPlayer access$getWebViewAdPlayer$p = this.this$0.webViewAdPlayer;
        FlowCollector anonymousClass4 = new Object() {
            public final boolean equals(Object obj) {
                return ((obj instanceof FlowCollector) && (obj instanceof FunctionAdapter)) ? Intrinsics.areEqual(getFunctionDelegate(), ((FunctionAdapter) obj).getFunctionDelegate()) : false;
            }

            public final Function<?> getFunctionDelegate() {
                return new FunctionReferenceImpl(2, access$getWebViewAdPlayer$p, WebViewAdPlayer.class, "sendOfferwallEvent", "sendOfferwallEvent(Lcom/unity3d/services/ads/offerwall/OfferwallEvent;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", 0);
            }

            public final int hashCode() {
                return getFunctionDelegate().hashCode();
            }

            public final Object emit(OfferwallEvent offerwallEvent, Continuation<? super Unit> continuation) {
                Object sendOfferwallEvent = access$getWebViewAdPlayer$p.sendOfferwallEvent(offerwallEvent, continuation);
                return sendOfferwallEvent == IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED() ? sendOfferwallEvent : Unit.INSTANCE;
            }
        };
        Continuation continuation2 = this;
        this.label = 2;
        if (androidFullscreenWebViewAdPlayer$show$10$invokeSuspend$$inlined$mapNotNull$1.collect(anonymousClass4, continuation2) == coroutine_suspended) {
            return coroutine_suspended;
        }
        return Unit.INSTANCE;
    }
}
