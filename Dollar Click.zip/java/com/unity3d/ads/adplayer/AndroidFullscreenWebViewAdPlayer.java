package com.unity3d.ads.adplayer;

import android.app.Activity;
import android.content.Intent;
import com.unity3d.ads.adplayer.model.LoadEvent;
import com.unity3d.ads.core.data.datasource.VolumeSettingsChange;
import com.unity3d.ads.core.data.datasource.VolumeSettingsChange.MuteChange;
import com.unity3d.ads.core.data.datasource.VolumeSettingsChange.VolumeChange;
import com.unity3d.ads.core.data.manager.OfferwallManager;
import com.unity3d.ads.core.data.manager.ScarManager;
import com.unity3d.ads.core.data.model.AdObject;
import com.unity3d.ads.core.data.model.OfferwallShowEvent;
import com.unity3d.ads.core.data.model.ScarEvent;
import com.unity3d.ads.core.data.model.SessionChange;
import com.unity3d.ads.core.data.model.SessionChange.PrivacyFsmChange;
import com.unity3d.ads.core.data.model.SessionChange.UserConsentChange;
import com.unity3d.ads.core.data.model.ShowEvent;
import com.unity3d.ads.core.data.repository.AdRepository;
import com.unity3d.ads.core.data.repository.DeviceInfoRepository;
import com.unity3d.ads.core.data.repository.OpenMeasurementRepository;
import com.unity3d.ads.core.data.repository.SessionRepository;
import com.unity3d.ads.core.domain.SendDiagnosticEvent;
import com.unity3d.ads.core.domain.SendDiagnosticEvent.DefaultImpls;
import com.unity3d.scar.adapter.common.GMAEvent;
import com.unity3d.services.ads.adunit.AdUnitActivity;
import com.unity3d.services.ads.offerwall.OfferwallEvent;
import com.unity3d.services.banners.bridge.BannerBridge.BannerEvent;
import java.util.Map;
import kotlin.Lazy;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlinx.coroutines.CompletableDeferred;
import kotlinx.coroutines.CompletableDeferredKt;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.Job;
import kotlinx.coroutines.flow.Flow;
import kotlinx.coroutines.flow.FlowKt;
import kotlinx.coroutines.flow.MutableSharedFlow;
import kotlinx.coroutines.flow.SharedFlowKt;
import kotlinx.coroutines.flow.SharingStarted;
import org.json.JSONObject;

@Metadata(d1 = {"\u0000ê\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0012\n\u0002\b\u0006\n\u0002\u0010$\n\u0002\u0010\u0000\n\u0002\b\u0004\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0010\u0006\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\b\u0000\u0018\u0000 h2\u00020\u00012\u00020\u0002:\u0001hBU\u0012\u0006\u0010\u0003\u001a\u00020\u0004\u0012\u0006\u0010\u0005\u001a\u00020\u0006\u0012\u0006\u0010\u0007\u001a\u00020\b\u0012\u0006\u0010\t\u001a\u00020\n\u0012\u0006\u0010\u000b\u001a\u00020\f\u0012\u0006\u0010\r\u001a\u00020\u000e\u0012\u0006\u0010\u000f\u001a\u00020\u0010\u0012\u0006\u0010\u0011\u001a\u00020\u0012\u0012\u0006\u0010\u0013\u001a\u00020\u0014\u0012\u0006\u0010\u0015\u001a\u00020\u0016¢\u0006\u0002\u0010\u0017J\u0011\u00102\u001a\u000203H@ø\u0001\u0000¢\u0006\u0002\u00104J\t\u00105\u001a\u000203H\u0001J\u0010\u00106\u001a\u0002072\u0006\u00108\u001a\u000209H\u0002J\u0019\u0010:\u001a\u0002032\u0006\u0010;\u001a\u00020<H@ø\u0001\u0000¢\u0006\u0002\u0010=J\u0019\u0010>\u001a\u0002032\u0006\u0010;\u001a\u00020?H@ø\u0001\u0000¢\u0006\u0002\u0010@J\u0019\u0010A\u001a\u0002032\u0006\u0010B\u001a\u00020CHAø\u0001\u0000¢\u0006\u0002\u0010DJ\u0019\u0010E\u001a\u0002032\u0006\u0010F\u001a\u00020\u0006HAø\u0001\u0000¢\u0006\u0002\u0010GJ)\u0010H\u001a\u0002032\u0016\u0010I\u001a\u0012\u0012\u0004\u0012\u00020\u0006\u0012\u0006\u0012\u0004\u0018\u00010K\u0018\u00010JHAø\u0001\u0000¢\u0006\u0002\u0010LJ\u0011\u0010M\u001a\u000203HAø\u0001\u0000¢\u0006\u0002\u00104J\u0019\u0010N\u001a\u0002032\u0006\u0010O\u001a\u00020PHAø\u0001\u0000¢\u0006\u0002\u0010QJ\u0019\u0010R\u001a\u0002032\u0006\u0010F\u001a\u00020SHAø\u0001\u0000¢\u0006\u0002\u0010TJ\u0019\u0010U\u001a\u0002032\u0006\u0010V\u001a\u00020PHAø\u0001\u0000¢\u0006\u0002\u0010QJ\u0019\u0010W\u001a\u0002032\u0006\u0010F\u001a\u00020XHAø\u0001\u0000¢\u0006\u0002\u0010YJ\u0019\u0010Z\u001a\u0002032\u0006\u0010B\u001a\u00020CHAø\u0001\u0000¢\u0006\u0002\u0010DJ\u0019\u0010[\u001a\u0002032\u0006\u0010F\u001a\u00020\\HAø\u0001\u0000¢\u0006\u0002\u0010]J\u0019\u0010^\u001a\u0002032\u0006\u0010B\u001a\u00020CHAø\u0001\u0000¢\u0006\u0002\u0010DJ\u0019\u0010_\u001a\u0002032\u0006\u0010`\u001a\u00020PHAø\u0001\u0000¢\u0006\u0002\u0010QJ\u0019\u0010a\u001a\u0002032\u0006\u0010b\u001a\u00020cHAø\u0001\u0000¢\u0006\u0002\u0010dJ\u0010\u0010e\u001a\u0002032\u0006\u0010f\u001a\u00020gH\u0016R\u001d\u0010\u0018\u001a\u0004\u0018\u00010\u00198BX\u0002¢\u0006\f\n\u0004\b\u001c\u0010\u001d\u001a\u0004\b\u001a\u0010\u001bR\u000e\u0010\u0015\u001a\u00020\u0016X\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\nX\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0011\u001a\u00020\u0012X\u0004¢\u0006\u0002\n\u0000R\u0018\u0010\u001e\u001a\b\u0012\u0004\u0012\u00020 0\u001fX\u0005¢\u0006\u0006\u001a\u0004\b!\u0010\"R\u0018\u0010#\u001a\b\u0012\u0004\u0012\u00020$0\u001fX\u0005¢\u0006\u0006\u001a\u0004\b%\u0010\"R\u0018\u0010&\u001a\b\u0012\u0004\u0012\u00020'0\u001fX\u0005¢\u0006\u0006\u001a\u0004\b(\u0010\"R\u0018\u0010)\u001a\b\u0012\u0004\u0012\u00020*0\u001fX\u0005¢\u0006\u0006\u001a\u0004\b+\u0010\"R\u000e\u0010\r\u001a\u00020\u000eX\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0006X\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u000f\u001a\u00020\u0010X\u0004¢\u0006\u0002\n\u0000R\u0012\u0010,\u001a\u00020-X\u0005¢\u0006\u0006\u001a\u0004\b.\u0010/R\u000e\u0010\u0013\u001a\u00020\u0014X\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\fX\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0003\u001a\u00020\u0004X\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\u0007\u001a\u00020\bX\u0004¢\u0006\b\n\u0000\u001a\u0004\b0\u00101\u0002\u0004\n\u0002\b\u0019¨\u0006i"}, d2 = {"Lcom/unity3d/ads/adplayer/AndroidFullscreenWebViewAdPlayer;", "Lcom/unity3d/ads/adplayer/AdPlayer;", "Lcom/unity3d/ads/adplayer/FullscreenAdPlayer;", "webViewAdPlayer", "Lcom/unity3d/ads/adplayer/WebViewAdPlayer;", "opportunityId", "", "webViewContainer", "Lcom/unity3d/ads/adplayer/AndroidWebViewContainer;", "deviceInfoRepository", "Lcom/unity3d/ads/core/data/repository/DeviceInfoRepository;", "sessionRepository", "Lcom/unity3d/ads/core/data/repository/SessionRepository;", "openMeasurementRepository", "Lcom/unity3d/ads/core/data/repository/OpenMeasurementRepository;", "scarManager", "Lcom/unity3d/ads/core/data/manager/ScarManager;", "offerwallManager", "Lcom/unity3d/ads/core/data/manager/OfferwallManager;", "sendDiagnosticEvent", "Lcom/unity3d/ads/core/domain/SendDiagnosticEvent;", "adRepository", "Lcom/unity3d/ads/core/data/repository/AdRepository;", "(Lcom/unity3d/ads/adplayer/WebViewAdPlayer;Ljava/lang/String;Lcom/unity3d/ads/adplayer/AndroidWebViewContainer;Lcom/unity3d/ads/core/data/repository/DeviceInfoRepository;Lcom/unity3d/ads/core/data/repository/SessionRepository;Lcom/unity3d/ads/core/data/repository/OpenMeasurementRepository;Lcom/unity3d/ads/core/data/manager/ScarManager;Lcom/unity3d/ads/core/data/manager/OfferwallManager;Lcom/unity3d/ads/core/domain/SendDiagnosticEvent;Lcom/unity3d/ads/core/data/repository/AdRepository;)V", "adObject", "Lcom/unity3d/ads/core/data/model/AdObject;", "getAdObject", "()Lcom/unity3d/ads/core/data/model/AdObject;", "adObject$delegate", "Lkotlin/Lazy;", "onLoadEvent", "Lkotlinx/coroutines/flow/Flow;", "Lcom/unity3d/ads/adplayer/model/LoadEvent;", "getOnLoadEvent", "()Lkotlinx/coroutines/flow/Flow;", "onOfferwallEvent", "Lcom/unity3d/ads/core/data/model/OfferwallShowEvent;", "getOnOfferwallEvent", "onScarEvent", "Lcom/unity3d/ads/core/data/model/ScarEvent;", "getOnScarEvent", "onShowEvent", "Lcom/unity3d/ads/core/data/model/ShowEvent;", "getOnShowEvent", "scope", "Lkotlinx/coroutines/CoroutineScope;", "getScope", "()Lkotlinx/coroutines/CoroutineScope;", "getWebViewContainer", "()Lcom/unity3d/ads/adplayer/AndroidWebViewContainer;", "destroy", "", "(Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "dispatchShowCompleted", "displayEventsRouter", "Lkotlinx/coroutines/Job;", "displayMessage", "Lcom/unity3d/ads/adplayer/DisplayMessage;", "handleSessionChange", "change", "Lcom/unity3d/ads/core/data/model/SessionChange;", "(Lcom/unity3d/ads/core/data/model/SessionChange;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "handleVolumeSettingsChange", "Lcom/unity3d/ads/core/data/datasource/VolumeSettingsChange;", "(Lcom/unity3d/ads/core/data/datasource/VolumeSettingsChange;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "onAllowedPiiChange", "value", "", "([BLkotlin/coroutines/Continuation;)Ljava/lang/Object;", "onBroadcastEvent", "event", "(Ljava/lang/String;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "requestShow", "unityAdsShowOptions", "", "", "(Ljava/util/Map;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "sendActivityDestroyed", "sendFocusChange", "isFocused", "", "(ZLkotlin/coroutines/Continuation;)Ljava/lang/Object;", "sendGmaEvent", "Lcom/unity3d/scar/adapter/common/GMAEvent;", "(Lcom/unity3d/scar/adapter/common/GMAEvent;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "sendMuteChange", "isMuted", "sendOfferwallEvent", "Lcom/unity3d/services/ads/offerwall/OfferwallEvent;", "(Lcom/unity3d/services/ads/offerwall/OfferwallEvent;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "sendPrivacyFsmChange", "sendScarBannerEvent", "Lcom/unity3d/services/banners/bridge/BannerBridge$BannerEvent;", "(Lcom/unity3d/services/banners/bridge/BannerBridge$BannerEvent;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "sendUserConsentChange", "sendVisibilityChange", "isVisible", "sendVolumeChange", "volume", "", "(DLkotlin/coroutines/Continuation;)Ljava/lang/Object;", "show", "showOptions", "Lcom/unity3d/ads/adplayer/ShowOptions;", "Companion", "unity-ads_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
/* compiled from: AndroidFullscreenWebViewAdPlayer.kt */
public final class AndroidFullscreenWebViewAdPlayer implements AdPlayer, FullscreenAdPlayer {
    public static final Companion Companion = new Companion();
    private static final MutableSharedFlow<DisplayMessage> displayMessages = SharedFlowKt.MutableSharedFlow$default(0, 0, null, 7, null);
    private final Lazy adObject$delegate = LazyKt__LazyJVMKt.lazy(new AndroidFullscreenWebViewAdPlayer$adObject$2(this));
    private final AdRepository adRepository;
    private final DeviceInfoRepository deviceInfoRepository;
    private final OfferwallManager offerwallManager;
    private final OpenMeasurementRepository openMeasurementRepository;
    private final String opportunityId;
    private final ScarManager scarManager;
    private final SendDiagnosticEvent sendDiagnosticEvent;
    private final SessionRepository sessionRepository;
    private final WebViewAdPlayer webViewAdPlayer;
    private final AndroidWebViewContainer webViewContainer;

    @Metadata(d1 = {"\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002R\u0017\u0010\u0003\u001a\b\u0012\u0004\u0012\u00020\u00050\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0006\u0010\u0007¨\u0006\b"}, d2 = {"Lcom/unity3d/ads/adplayer/AndroidFullscreenWebViewAdPlayer$Companion;", "", "()V", "displayMessages", "Lkotlinx/coroutines/flow/MutableSharedFlow;", "Lcom/unity3d/ads/adplayer/DisplayMessage;", "getDisplayMessages", "()Lkotlinx/coroutines/flow/MutableSharedFlow;", "unity-ads_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
    /* compiled from: AndroidFullscreenWebViewAdPlayer.kt */
    public static final class Companion {
        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        private Companion() {
        }

        public final MutableSharedFlow<DisplayMessage> getDisplayMessages() {
            return AndroidFullscreenWebViewAdPlayer.displayMessages;
        }
    }

    public void dispatchShowCompleted() {
        this.webViewAdPlayer.dispatchShowCompleted();
    }

    public Flow<LoadEvent> getOnLoadEvent() {
        return this.webViewAdPlayer.getOnLoadEvent();
    }

    public Flow<OfferwallShowEvent> getOnOfferwallEvent() {
        return this.webViewAdPlayer.getOnOfferwallEvent();
    }

    public Flow<ScarEvent> getOnScarEvent() {
        return this.webViewAdPlayer.getOnScarEvent();
    }

    public Flow<ShowEvent> getOnShowEvent() {
        return this.webViewAdPlayer.getOnShowEvent();
    }

    public CoroutineScope getScope() {
        return this.webViewAdPlayer.getScope();
    }

    public Object onAllowedPiiChange(byte[] bArr, Continuation<? super Unit> continuation) {
        return this.webViewAdPlayer.onAllowedPiiChange(bArr, continuation);
    }

    public Object onBroadcastEvent(String str, Continuation<? super Unit> continuation) {
        return this.webViewAdPlayer.onBroadcastEvent(str, continuation);
    }

    public Object requestShow(Map<String, ? extends Object> map, Continuation<? super Unit> continuation) {
        return this.webViewAdPlayer.requestShow(map, continuation);
    }

    public Object sendActivityDestroyed(Continuation<? super Unit> continuation) {
        return this.webViewAdPlayer.sendActivityDestroyed(continuation);
    }

    public Object sendFocusChange(boolean z, Continuation<? super Unit> continuation) {
        return this.webViewAdPlayer.sendFocusChange(z, continuation);
    }

    public Object sendGmaEvent(GMAEvent gMAEvent, Continuation<? super Unit> continuation) {
        return this.webViewAdPlayer.sendGmaEvent(gMAEvent, continuation);
    }

    public Object sendMuteChange(boolean z, Continuation<? super Unit> continuation) {
        return this.webViewAdPlayer.sendMuteChange(z, continuation);
    }

    public Object sendOfferwallEvent(OfferwallEvent offerwallEvent, Continuation<? super Unit> continuation) {
        return this.webViewAdPlayer.sendOfferwallEvent(offerwallEvent, continuation);
    }

    public Object sendPrivacyFsmChange(byte[] bArr, Continuation<? super Unit> continuation) {
        return this.webViewAdPlayer.sendPrivacyFsmChange(bArr, continuation);
    }

    public Object sendScarBannerEvent(BannerEvent bannerEvent, Continuation<? super Unit> continuation) {
        return this.webViewAdPlayer.sendScarBannerEvent(bannerEvent, continuation);
    }

    public Object sendUserConsentChange(byte[] bArr, Continuation<? super Unit> continuation) {
        return this.webViewAdPlayer.sendUserConsentChange(bArr, continuation);
    }

    public Object sendVisibilityChange(boolean z, Continuation<? super Unit> continuation) {
        return this.webViewAdPlayer.sendVisibilityChange(z, continuation);
    }

    public Object sendVolumeChange(double d, Continuation<? super Unit> continuation) {
        return this.webViewAdPlayer.sendVolumeChange(d, continuation);
    }

    public AndroidFullscreenWebViewAdPlayer(WebViewAdPlayer webViewAdPlayer, String str, AndroidWebViewContainer androidWebViewContainer, DeviceInfoRepository deviceInfoRepository, SessionRepository sessionRepository, OpenMeasurementRepository openMeasurementRepository, ScarManager scarManager, OfferwallManager offerwallManager, SendDiagnosticEvent sendDiagnosticEvent, AdRepository adRepository) {
        Intrinsics.checkNotNullParameter(webViewAdPlayer, "webViewAdPlayer");
        Intrinsics.checkNotNullParameter(str, "opportunityId");
        Intrinsics.checkNotNullParameter(androidWebViewContainer, "webViewContainer");
        Intrinsics.checkNotNullParameter(deviceInfoRepository, "deviceInfoRepository");
        Intrinsics.checkNotNullParameter(sessionRepository, "sessionRepository");
        Intrinsics.checkNotNullParameter(openMeasurementRepository, "openMeasurementRepository");
        Intrinsics.checkNotNullParameter(scarManager, "scarManager");
        Intrinsics.checkNotNullParameter(offerwallManager, "offerwallManager");
        Intrinsics.checkNotNullParameter(sendDiagnosticEvent, "sendDiagnosticEvent");
        Intrinsics.checkNotNullParameter(adRepository, "adRepository");
        this.webViewAdPlayer = webViewAdPlayer;
        this.opportunityId = str;
        this.webViewContainer = androidWebViewContainer;
        this.deviceInfoRepository = deviceInfoRepository;
        this.sessionRepository = sessionRepository;
        this.openMeasurementRepository = openMeasurementRepository;
        this.scarManager = scarManager;
        this.offerwallManager = offerwallManager;
        this.sendDiagnosticEvent = sendDiagnosticEvent;
        this.adRepository = adRepository;
    }

    public AndroidWebViewContainer getWebViewContainer() {
        return this.webViewContainer;
    }

    private final AdObject getAdObject() {
        return (AdObject) this.adObject$delegate.getValue();
    }

    public void show(ShowOptions showOptions) {
        ShowOptions showOptions2 = showOptions;
        String str = "showOptions";
        Intrinsics.checkNotNullParameter(showOptions2, str);
        if (showOptions2 instanceof AndroidShowOptions) {
            AndroidShowOptions androidShowOptions = (AndroidShowOptions) showOptions2;
            Activity activity = (Activity) androidShowOptions.getActivity().get();
            if (activity != null) {
                boolean isScarAd = androidShowOptions.isScarAd();
                boolean isOfferwallAd = androidShowOptions.isOfferwallAd();
                CompletableDeferred CompletableDeferred$default = CompletableDeferredKt.CompletableDeferred$default(null, 1, null);
                FlowKt.launchIn(FlowKt.onEach(new AndroidFullscreenWebViewAdPlayer$show$$inlined$filter$1(FlowKt.onSubscription(displayMessages, new AndroidFullscreenWebViewAdPlayer$show$1(CompletableDeferred$default, null)), this), new AndroidFullscreenWebViewAdPlayer$show$3(this)), getScope());
                FlowKt.launchIn(FlowKt.onEach(this.deviceInfoRepository.getVolumeSettingsChange(), new AndroidFullscreenWebViewAdPlayer$show$4(this)), getScope());
                FlowKt.launchIn(FlowKt.onEach(new AndroidFullscreenWebViewAdPlayer$show$$inlined$filter$2(this.webViewAdPlayer.getOnShowEvent()), new AndroidFullscreenWebViewAdPlayer$show$6(this, null)), getScope());
                FlowKt.launchIn(FlowKt.onEach(this.sessionRepository.getOnChange(), new AndroidFullscreenWebViewAdPlayer$show$7(this)), getScope());
                if (!isScarAd && !isOfferwallAd) {
                    DefaultImpls.invoke$default(this.sendDiagnosticEvent, "native_show_ad_viewer_fullscreen", null, null, null, getAdObject(), null, 46, null);
                    Intent intent = new Intent(activity, FullScreenWebViewDisplay.class);
                    intent.putExtra("opportunityId", this.opportunityId);
                    Map unityAdsShowOptions = androidShowOptions.getUnityAdsShowOptions();
                    if (unityAdsShowOptions != null) {
                        intent.putExtra(str, new JSONObject(unityAdsShowOptions).toString());
                    }
                    intent.addFlags(268500992);
                    intent.putExtra(AdUnitActivity.EXTRA_ORIENTATION, activity.getRequestedOrientation());
                    BuildersKt__Builders_commonKt.launch$default(getScope(), null, null, new AndroidFullscreenWebViewAdPlayer$show$8(CompletableDeferred$default, activity, intent, this, null), 3, null);
                    return;
                } else if (isScarAd) {
                    ScarManager scarManager = this.scarManager;
                    String placementId = androidShowOptions.getPlacementId();
                    String str2 = "";
                    if (placementId == null) {
                        placementId = str2;
                    }
                    String scarQueryId = androidShowOptions.getScarQueryId();
                    if (scarQueryId != null) {
                        str2 = scarQueryId;
                    }
                    BuildersKt__Builders_commonKt.launch$default(getScope(), null, null, new AndroidFullscreenWebViewAdPlayer$show$9(this, FlowKt.shareIn(scarManager.show(placementId, str2), getScope(), SharingStarted.Companion.getEagerly(), 10), showOptions2, null), 3, null);
                    return;
                } else {
                    BuildersKt__Builders_commonKt.launch$default(getScope(), null, null, new AndroidFullscreenWebViewAdPlayer$show$10(this, showOptions2, null), 3, null);
                    return;
                }
            }
            throw new IllegalArgumentException("Required value was null.".toString());
        }
        throw new IllegalArgumentException("Failed requirement.".toString());
    }

    private final Object handleVolumeSettingsChange(VolumeSettingsChange volumeSettingsChange, Continuation<? super Unit> continuation) {
        Object sendMuteChange;
        if (volumeSettingsChange instanceof MuteChange) {
            sendMuteChange = this.webViewAdPlayer.sendMuteChange(((MuteChange) volumeSettingsChange).isMuted(), continuation);
            return sendMuteChange == IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED() ? sendMuteChange : Unit.INSTANCE;
        } else if (!(volumeSettingsChange instanceof VolumeChange)) {
            return Unit.INSTANCE;
        } else {
            sendMuteChange = this.webViewAdPlayer.sendVolumeChange(((VolumeChange) volumeSettingsChange).getVolume(), continuation);
            return sendMuteChange == IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED() ? sendMuteChange : Unit.INSTANCE;
        }
    }

    private final Object handleSessionChange(SessionChange sessionChange, Continuation<? super Unit> continuation) {
        String str = "change.value.toByteArray()";
        WebViewAdPlayer webViewAdPlayer;
        Object toByteArray;
        if (sessionChange instanceof UserConsentChange) {
            webViewAdPlayer = this.webViewAdPlayer;
            toByteArray = ((UserConsentChange) sessionChange).getValue().toByteArray();
            Intrinsics.checkNotNullExpressionValue(toByteArray, str);
            toByteArray = webViewAdPlayer.sendUserConsentChange(toByteArray, continuation);
            return toByteArray == IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED() ? toByteArray : Unit.INSTANCE;
        } else if (!(sessionChange instanceof PrivacyFsmChange)) {
            return Unit.INSTANCE;
        } else {
            webViewAdPlayer = this.webViewAdPlayer;
            toByteArray = ((PrivacyFsmChange) sessionChange).getValue().toByteArray();
            Intrinsics.checkNotNullExpressionValue(toByteArray, str);
            toByteArray = webViewAdPlayer.sendPrivacyFsmChange(toByteArray, continuation);
            return toByteArray == IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED() ? toByteArray : Unit.INSTANCE;
        }
    }

    /* DevToolsApp WARNING: Removed duplicated region for block: B:32:0x00a0 A:{RETURN} */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:29:0x0094 A:{RETURN} */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:32:0x00a0 A:{RETURN} */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:18:0x0053  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:8:0x0027  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:24:0x0079  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:29:0x0094 A:{RETURN} */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:32:0x00a0 A:{RETURN} */
    public java.lang.Object destroy(kotlin.coroutines.Continuation<? super kotlin.Unit> r9) {
        /*
        r8 = this;
        r0 = r9 instanceof com.unity3d.ads.adplayer.AndroidFullscreenWebViewAdPlayer$destroy$1;
        if (r0 == 0) goto L_0x0014;
    L_0x0004:
        r0 = r9;
        r0 = (com.unity3d.ads.adplayer.AndroidFullscreenWebViewAdPlayer$destroy$1) r0;
        r1 = r0.label;
        r2 = -2147483648; // 0xffffffff80000000 float:-0.0 double:NaN;
        r1 = r1 & r2;
        if (r1 == 0) goto L_0x0014;
    L_0x000e:
        r9 = r0.label;
        r9 = r9 - r2;
        r0.label = r9;
        goto L_0x0019;
    L_0x0014:
        r0 = new com.unity3d.ads.adplayer.AndroidFullscreenWebViewAdPlayer$destroy$1;
        r0.<init>(r8, r9);
    L_0x0019:
        r9 = r0.result;
        r1 = kotlin.coroutines.intrinsics.IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED();
        r2 = r0.label;
        r3 = 4;
        r4 = 3;
        r5 = 2;
        r6 = 1;
        if (r2 == 0) goto L_0x0053;
    L_0x0027:
        if (r2 == r6) goto L_0x004b;
    L_0x0029:
        if (r2 == r5) goto L_0x0043;
    L_0x002b:
        if (r2 == r4) goto L_0x003b;
    L_0x002d:
        if (r2 != r3) goto L_0x0033;
    L_0x002f:
        kotlin.ResultKt.throwOnFailure(r9);
        goto L_0x00a1;
    L_0x0033:
        r9 = new java.lang.IllegalStateException;
        r0 = "call to 'resume' before 'invoke' with coroutine";
        r9.<init>(r0);
        throw r9;
    L_0x003b:
        r2 = r0.L$0;
        r2 = (com.unity3d.ads.adplayer.AndroidFullscreenWebViewAdPlayer) r2;
        kotlin.ResultKt.throwOnFailure(r9);
        goto L_0x0095;
    L_0x0043:
        r2 = r0.L$0;
        r2 = (com.unity3d.ads.adplayer.AndroidFullscreenWebViewAdPlayer) r2;
        kotlin.ResultKt.throwOnFailure(r9);
        goto L_0x0086;
    L_0x004b:
        r2 = r0.L$0;
        r2 = (com.unity3d.ads.adplayer.AndroidFullscreenWebViewAdPlayer) r2;
        kotlin.ResultKt.throwOnFailure(r9);
        goto L_0x006b;
    L_0x0053:
        kotlin.ResultKt.throwOnFailure(r9);
        r9 = displayMessages;
        r2 = new com.unity3d.ads.adplayer.DisplayMessage$DisplayFinishRequest;
        r7 = r8.opportunityId;
        r2.<init>(r7);
        r0.L$0 = r8;
        r0.label = r6;
        r9 = r9.emit(r2, r0);
        if (r9 != r1) goto L_0x006a;
    L_0x0069:
        return r1;
    L_0x006a:
        r2 = r8;
    L_0x006b:
        r9 = r2.openMeasurementRepository;
        r6 = r2.opportunityId;
        r6 = com.google.protobuf.kotlin.ByteStringsKt.toByteStringUtf8(r6);
        r9 = r9.hasSessionFinished(r6);
        if (r9 == 0) goto L_0x0086;
    L_0x0079:
        r0.L$0 = r2;
        r0.label = r5;
        r5 = 1000; // 0x3e8 float:1.401E-42 double:4.94E-321;
        r9 = kotlinx.coroutines.DelayKt.delay(r5, r0);
        if (r9 != r1) goto L_0x0086;
    L_0x0085:
        return r1;
    L_0x0086:
        r9 = r2.getWebViewContainer();
        r0.L$0 = r2;
        r0.label = r4;
        r9 = r9.destroy(r0);
        if (r9 != r1) goto L_0x0095;
    L_0x0094:
        return r1;
    L_0x0095:
        r9 = 0;
        r0.L$0 = r9;
        r0.label = r3;
        r9 = com.unity3d.ads.adplayer.AdPlayer.DefaultImpls.destroy(r2, r0);
        if (r9 != r1) goto L_0x00a1;
    L_0x00a0:
        return r1;
    L_0x00a1:
        r9 = kotlin.Unit.INSTANCE;
        return r9;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.unity3d.ads.adplayer.AndroidFullscreenWebViewAdPlayer.destroy(kotlin.coroutines.Continuation):java.lang.Object");
    }

    private final Job displayEventsRouter(DisplayMessage displayMessage) {
        return BuildersKt__Builders_commonKt.launch$default(getScope(), null, null, new AndroidFullscreenWebViewAdPlayer$displayEventsRouter$1(this, displayMessage, null), 3, null);
    }
}
