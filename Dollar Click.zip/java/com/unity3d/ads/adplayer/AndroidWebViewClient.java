package com.unity3d.ads.adplayer;

import android.webkit.RenderProcessGoneDetail;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;
import androidx.webkit.WebResourceErrorCompat;
import androidx.webkit.WebViewClientCompat;
import androidx.webkit.WebViewFeature;
import com.unity3d.ads.adplayer.model.ErrorReason;
import com.unity3d.ads.adplayer.model.WebViewClientError;
import com.unity3d.ads.core.domain.GetCachedAsset;
import com.unity3d.ads.core.domain.SendDiagnosticEvent;
import com.unity3d.ads.core.extensions.IntExtensionKt;
import com.unity3d.ads.core.extensions.ViewExtensionsKt;
import java.util.Collection;
import java.util.List;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlinx.coroutines.CompletableDeferred;
import kotlinx.coroutines.CompletableDeferredKt;
import kotlinx.coroutines.Deferred;
import kotlinx.coroutines.flow.FlowKt;
import kotlinx.coroutines.flow.MutableStateFlow;
import kotlinx.coroutines.flow.StateFlow;
import kotlinx.coroutines.flow.StateFlowKt;

@Metadata(d1 = {"\u0000r\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\u0018\u0000 )2\u00020\u0001:\u0001)B\u0015\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005¢\u0006\u0002\u0010\u0006J\u0018\u0010\u0018\u001a\u00020\u00192\u0006\u0010\u001a\u001a\u00020\u001b2\u0006\u0010\u001c\u001a\u00020\u0017H\u0016J \u0010\u001d\u001a\u00020\u00192\u0006\u0010\u001a\u001a\u00020\u001b2\u0006\u0010\u001e\u001a\u00020\u001f2\u0006\u0010 \u001a\u00020!H\u0017J \u0010\"\u001a\u00020\u00192\u0006\u0010\u001a\u001a\u00020\u001b2\u0006\u0010\u001e\u001a\u00020\u001f2\u0006\u0010#\u001a\u00020$H\u0016J\u0018\u0010%\u001a\u00020\t2\u0006\u0010\u001a\u001a\u00020\u001b2\u0006\u0010&\u001a\u00020'H\u0016J\u001a\u0010(\u001a\u0004\u0018\u00010$2\u0006\u0010\u001a\u001a\u00020\u001b2\u0006\u0010\u001e\u001a\u00020\u001fH\u0016R\u0014\u0010\u0007\u001a\b\u0012\u0004\u0012\u00020\t0\bX\u0004¢\u0006\u0002\n\u0000R\u001a\u0010\n\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\r0\f0\u000bX\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0002\u001a\u00020\u0003X\u0004¢\u0006\u0002\n\u0000R\u0017\u0010\u000e\u001a\b\u0012\u0004\u0012\u00020\t0\u000f¢\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\u0010R\u001a\u0010\u0011\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\r0\f0\bX\u0004¢\u0006\u0002\n\u0000R\u001d\u0010\u0012\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\r0\f0\u0013¢\u0006\b\n\u0000\u001a\u0004\b\u0014\u0010\u0015R\u000e\u0010\u0004\u001a\u00020\u0005X\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\u0016\u001a\b\u0012\u0004\u0012\u00020\u00170\bX\u0004¢\u0006\u0002\n\u0000¨\u0006*"}, d2 = {"Lcom/unity3d/ads/adplayer/AndroidWebViewClient;", "Landroidx/webkit/WebViewClientCompat;", "getCachedAsset", "Lcom/unity3d/ads/core/domain/GetCachedAsset;", "sendDiagnosticEvent", "Lcom/unity3d/ads/core/domain/SendDiagnosticEvent;", "(Lcom/unity3d/ads/core/domain/GetCachedAsset;Lcom/unity3d/ads/core/domain/SendDiagnosticEvent;)V", "_isRenderProcessGone", "Lkotlinx/coroutines/flow/MutableStateFlow;", "", "_onLoadFinished", "Lkotlinx/coroutines/CompletableDeferred;", "", "Lcom/unity3d/ads/adplayer/model/WebViewClientError;", "isRenderProcessGone", "Lkotlinx/coroutines/flow/StateFlow;", "()Lkotlinx/coroutines/flow/StateFlow;", "loadErrors", "onLoadFinished", "Lkotlinx/coroutines/Deferred;", "getOnLoadFinished", "()Lkotlinx/coroutines/Deferred;", "webviewType", "", "onPageFinished", "", "view", "Landroid/webkit/WebView;", "url", "onReceivedError", "request", "Landroid/webkit/WebResourceRequest;", "error", "Landroidx/webkit/WebResourceErrorCompat;", "onReceivedHttpError", "errorResponse", "Landroid/webkit/WebResourceResponse;", "onRenderProcessGone", "detail", "Landroid/webkit/RenderProcessGoneDetail;", "shouldInterceptRequest", "Companion", "unity-ads_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
/* compiled from: AndroidWebViewClient.kt */
public final class AndroidWebViewClient extends WebViewClientCompat {
    public static final String BLANK_PAGE = "about:blank";
    public static final Companion Companion = new Companion();
    private final MutableStateFlow<Boolean> _isRenderProcessGone;
    private final CompletableDeferred<List<WebViewClientError>> _onLoadFinished;
    private final GetCachedAsset getCachedAsset;
    private final StateFlow<Boolean> isRenderProcessGone;
    private final MutableStateFlow<List<WebViewClientError>> loadErrors = StateFlowKt.MutableStateFlow(CollectionsKt__CollectionsKt.emptyList());
    private final Deferred<List<WebViewClientError>> onLoadFinished;
    private final SendDiagnosticEvent sendDiagnosticEvent;
    private final MutableStateFlow<String> webviewType;

    @Metadata(d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\b\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002R\u000e\u0010\u0003\u001a\u00020\u0004XT¢\u0006\u0002\n\u0000¨\u0006\u0005"}, d2 = {"Lcom/unity3d/ads/adplayer/AndroidWebViewClient$Companion;", "", "()V", "BLANK_PAGE", "", "unity-ads_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
    /* compiled from: AndroidWebViewClient.kt */
    public static final class Companion {
        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        private Companion() {
        }
    }

    public AndroidWebViewClient(GetCachedAsset getCachedAsset, SendDiagnosticEvent sendDiagnosticEvent) {
        Intrinsics.checkNotNullParameter(getCachedAsset, "getCachedAsset");
        Intrinsics.checkNotNullParameter(sendDiagnosticEvent, "sendDiagnosticEvent");
        this.getCachedAsset = getCachedAsset;
        this.sendDiagnosticEvent = sendDiagnosticEvent;
        CompletableDeferred CompletableDeferred$default = CompletableDeferredKt.CompletableDeferred$default(null, 1, null);
        this._onLoadFinished = CompletableDeferred$default;
        this.onLoadFinished = CompletableDeferred$default;
        MutableStateFlow MutableStateFlow = StateFlowKt.MutableStateFlow(Boolean.valueOf(false));
        this._isRenderProcessGone = MutableStateFlow;
        this.isRenderProcessGone = FlowKt.asStateFlow(MutableStateFlow);
        this.webviewType = StateFlowKt.MutableStateFlow("");
    }

    public final Deferred<List<WebViewClientError>> getOnLoadFinished() {
        return this.onLoadFinished;
    }

    public final StateFlow<Boolean> isRenderProcessGone() {
        return this.isRenderProcessGone;
    }

    public void onPageFinished(WebView webView, String str) {
        Intrinsics.checkNotNullParameter(webView, "view");
        Intrinsics.checkNotNullParameter(str, "url");
        if (Intrinsics.areEqual((Object) str, BLANK_PAGE)) {
            MutableStateFlow mutableStateFlow = this.loadErrors;
            Object value;
            do {
                value = mutableStateFlow.getValue();
            } while (!mutableStateFlow.compareAndSet(value, CollectionsKt___CollectionsKt.plus((Collection) (List) value, (Object) new WebViewClientError(str, ErrorReason.REASON_WEB_BLANK, null, 4, null))));
        }
        super.onPageFinished(webView, str);
        this._onLoadFinished.complete(this.loadErrors.getValue());
    }

    public void onReceivedError(WebView webView, WebResourceRequest webResourceRequest, WebResourceErrorCompat webResourceErrorCompat) {
        ErrorReason webResourceToErrorReason;
        Intrinsics.checkNotNullParameter(webView, "view");
        Intrinsics.checkNotNullParameter(webResourceRequest, "request");
        Intrinsics.checkNotNullParameter(webResourceErrorCompat, "error");
        super.onReceivedError(webView, webResourceRequest, webResourceErrorCompat);
        if (WebViewFeature.isFeatureSupported("WEB_RESOURCE_ERROR_GET_CODE")) {
            webResourceToErrorReason = IntExtensionKt.webResourceToErrorReason(webResourceErrorCompat.getErrorCode());
        } else {
            webResourceToErrorReason = ErrorReason.REASON_UNKNOWN;
        }
        MutableStateFlow mutableStateFlow = this.loadErrors;
        Object value;
        do {
            value = mutableStateFlow.getValue();
        } while (!mutableStateFlow.compareAndSet(value, CollectionsKt___CollectionsKt.plus((Collection) (List) value, (Object) new WebViewClientError(webResourceRequest.getUrl().toString(), webResourceToErrorReason, null, 4, null))));
    }

    public void onReceivedHttpError(WebView webView, WebResourceRequest webResourceRequest, WebResourceResponse webResourceResponse) {
        Intrinsics.checkNotNullParameter(webView, "view");
        Intrinsics.checkNotNullParameter(webResourceRequest, "request");
        Intrinsics.checkNotNullParameter(webResourceResponse, "errorResponse");
        super.onReceivedHttpError(webView, webResourceRequest, webResourceResponse);
        WebViewClientError webViewClientError = new WebViewClientError(webResourceRequest.getUrl().toString(), ErrorReason.REASON_WEB_ERROR_RECEIVED_HTTP, Integer.valueOf(webResourceResponse.getStatusCode()));
        MutableStateFlow mutableStateFlow = this.loadErrors;
        Object value;
        do {
            value = mutableStateFlow.getValue();
        } while (!mutableStateFlow.compareAndSet(value, CollectionsKt___CollectionsKt.plus((Collection) (List) value, (Object) webViewClientError)));
    }

    /* DevToolsApp WARNING: Missing block: B:27:0x0088, code:
            if (r0 == null) goto L_0x008a;
     */
    public android.webkit.WebResourceResponse shouldInterceptRequest(android.webkit.WebView r11, android.webkit.WebResourceRequest r12) {
        /*
        r10 = this;
        r0 = "view";
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r11, r0);
        r0 = "request";
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r12, r0);
        r0 = r12.getUrl();
        if (r0 != 0) goto L_0x0015;
    L_0x0010:
        r11 = super.shouldInterceptRequest(r11, r12);
        return r11;
    L_0x0015:
        r1 = kotlin.Result.Companion;	 Catch:{ all -> 0x0025 }
        r1 = r10;
        r1 = (com.unity3d.ads.adplayer.AndroidWebViewClient) r1;	 Catch:{ all -> 0x0025 }
        r1 = "webviewType";
        r1 = r0.getQueryParameter(r1);	 Catch:{ all -> 0x0025 }
        r1 = kotlin.Result.m17constructor-impl(r1);	 Catch:{ all -> 0x0025 }
        goto L_0x0030;
    L_0x0025:
        r1 = move-exception;
        r2 = kotlin.Result.Companion;	 Catch:{ all -> 0x0077 }
        r1 = kotlin.ResultKt.createFailure(r1);	 Catch:{ all -> 0x0077 }
        r1 = kotlin.Result.m17constructor-impl(r1);	 Catch:{ all -> 0x0077 }
    L_0x0030:
        r2 = kotlin.Result.m23isFailure-impl(r1);	 Catch:{ all -> 0x0077 }
        r3 = 0;
        if (r2 == 0) goto L_0x0038;
    L_0x0037:
        r1 = r3;
    L_0x0038:
        r1 = (java.lang.String) r1;	 Catch:{ all -> 0x0077 }
        r2 = r1;
        r2 = (java.lang.CharSequence) r2;	 Catch:{ all -> 0x0077 }
        if (r2 == 0) goto L_0x004b;
    L_0x003f:
        r2 = kotlin.text.StringsKt__StringsJVMKt.isBlank(r2);	 Catch:{ all -> 0x0077 }
        if (r2 == 0) goto L_0x0046;
    L_0x0045:
        goto L_0x004b;
    L_0x0046:
        r2 = r10.webviewType;	 Catch:{ all -> 0x0077 }
        r2.setValue(r1);	 Catch:{ all -> 0x0077 }
    L_0x004b:
        r0 = r0.getLastPathSegment();	 Catch:{ all -> 0x0077 }
        r1 = "favicon.ico";
        r0 = kotlin.jvm.internal.Intrinsics.areEqual(r0, r1);	 Catch:{ all -> 0x0077 }
        if (r0 == 0) goto L_0x005f;
    L_0x0057:
        r0 = new android.webkit.WebResourceResponse;	 Catch:{ all -> 0x0077 }
        r1 = "image/png";
        r0.<init>(r1, r3, r3);	 Catch:{ all -> 0x0077 }
        return r0;
    L_0x005f:
        r0 = r10.getCachedAsset;	 Catch:{ all -> 0x0077 }
        r1 = r12.getUrl();	 Catch:{ all -> 0x0077 }
        r2 = "request.url";
        kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r1, r2);	 Catch:{ all -> 0x0077 }
        r2 = r10.webviewType;	 Catch:{ all -> 0x0077 }
        r2 = r2.getValue();	 Catch:{ all -> 0x0077 }
        r2 = (java.lang.String) r2;	 Catch:{ all -> 0x0077 }
        r11 = r0.invoke(r1, r2);	 Catch:{ all -> 0x0077 }
        return r11;
    L_0x0077:
        r0 = move-exception;
        r0 = r0.getMessage();
        if (r0 == 0) goto L_0x008a;
    L_0x007e:
        r1 = "reason";
        r0 = kotlin.TuplesKt.to(r1, r0);
        r0 = kotlin.collections.MapsKt__MapsJVMKt.mapOf(r0);
        if (r0 != 0) goto L_0x008e;
    L_0x008a:
        r0 = kotlin.collections.MapsKt__MapsKt.emptyMap();
    L_0x008e:
        r4 = r0;
        r1 = r10.sendDiagnosticEvent;
        r8 = 58;
        r9 = 0;
        r2 = "webview_could_not_handle_intercepted_url";
        r3 = 0;
        r5 = 0;
        r6 = 0;
        r7 = 0;
        com.unity3d.ads.core.domain.SendDiagnosticEvent.DefaultImpls.invoke$default(r1, r2, r3, r4, r5, r6, r7, r8, r9);
        r11 = super.shouldInterceptRequest(r11, r12);
        return r11;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.unity3d.ads.adplayer.AndroidWebViewClient.shouldInterceptRequest(android.webkit.WebView, android.webkit.WebResourceRequest):android.webkit.WebResourceResponse");
    }

    public boolean onRenderProcessGone(WebView webView, RenderProcessGoneDetail renderProcessGoneDetail) {
        Intrinsics.checkNotNullParameter(webView, "view");
        Intrinsics.checkNotNullParameter(renderProcessGoneDetail, "detail");
        ViewExtensionsKt.removeViewFromParent(webView);
        webView.destroy();
        if (this._onLoadFinished.isCompleted()) {
            this._isRenderProcessGone.setValue(Boolean.valueOf(true));
        } else {
            MutableStateFlow mutableStateFlow = this.loadErrors;
            Object value;
            do {
                value = mutableStateFlow.getValue();
            } while (!mutableStateFlow.compareAndSet(value, CollectionsKt___CollectionsKt.plus((Collection) (List) value, (Object) new WebViewClientError(String.valueOf(webView.getUrl()), ErrorReason.REASON_WEBVIEW_RENDER_PROCESS_GONE, null, 4, null))));
            this._onLoadFinished.complete(this.loadErrors.getValue());
        }
        return true;
    }
}
