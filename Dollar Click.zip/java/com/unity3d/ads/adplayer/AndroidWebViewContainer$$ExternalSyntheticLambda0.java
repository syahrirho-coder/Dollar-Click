package com.unity3d.ads.adplayer;

import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;

/* compiled from: D8$$SyntheticClass */
public final /* synthetic */ class AndroidWebViewContainer$$ExternalSyntheticLambda0 implements OnTouchListener {
    public final /* synthetic */ AndroidWebViewContainer f$0;

    public /* synthetic */ AndroidWebViewContainer$$ExternalSyntheticLambda0(AndroidWebViewContainer androidWebViewContainer) {
        this.f$0 = androidWebViewContainer;
    }

    public final boolean onTouch(View view, MotionEvent motionEvent) {
        return AndroidWebViewContainer._init_$lambda$1(this.f$0, view, motionEvent);
    }
}
