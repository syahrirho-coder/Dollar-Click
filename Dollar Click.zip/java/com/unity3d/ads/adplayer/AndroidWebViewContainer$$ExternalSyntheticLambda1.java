package com.unity3d.ads.adplayer;

import android.view.View;
import androidx.core.view.OnApplyWindowInsetsListener;
import androidx.core.view.WindowInsetsCompat;

/* compiled from: D8$$SyntheticClass */
public final /* synthetic */ class AndroidWebViewContainer$$ExternalSyntheticLambda1 implements OnApplyWindowInsetsListener {
    public final /* synthetic */ AndroidWebViewContainer f$0;

    public /* synthetic */ AndroidWebViewContainer$$ExternalSyntheticLambda1(AndroidWebViewContainer androidWebViewContainer) {
        this.f$0 = androidWebViewContainer;
    }

    public final WindowInsetsCompat onApplyWindowInsets(View view, WindowInsetsCompat windowInsetsCompat) {
        return AndroidWebViewContainer.applySafeAreaInsets$lambda$3(this.f$0, view, windowInsetsCompat);
    }
}
