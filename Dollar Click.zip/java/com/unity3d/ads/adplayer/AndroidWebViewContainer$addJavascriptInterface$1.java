package com.unity3d.ads.adplayer;

import kotlin.Metadata;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.jvm.internal.ContinuationImpl;
import kotlin.coroutines.jvm.internal.DebugMetadata;

@Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
@DebugMetadata(c = "com.unity3d.ads.adplayer.AndroidWebViewContainer", f = "AndroidWebViewContainer.kt", i = {}, l = {98}, m = "addJavascriptInterface", n = {}, s = {})
/* compiled from: AndroidWebViewContainer.kt */
final class AndroidWebViewContainer$addJavascriptInterface$1 extends ContinuationImpl {
    int label;
    /* synthetic */ Object result;
    final /* synthetic */ AndroidWebViewContainer this$0;

    AndroidWebViewContainer$addJavascriptInterface$1(AndroidWebViewContainer androidWebViewContainer, Continuation<? super AndroidWebViewContainer$addJavascriptInterface$1> continuation) {
        this.this$0 = androidWebViewContainer;
        super(continuation);
    }

    public final Object invokeSuspend(Object obj) {
        this.result = obj;
        this.label |= Integer.MIN_VALUE;
        return this.this$0.addJavascriptInterface(null, null, this);
    }
}
