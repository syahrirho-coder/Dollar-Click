package com.unity3d.ads.adplayer;

import kotlin.Metadata;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.jvm.internal.ContinuationImpl;
import kotlin.coroutines.jvm.internal.DebugMetadata;

@Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
@DebugMetadata(c = "com.unity3d.ads.adplayer.AndroidWebViewContainer", f = "AndroidWebViewContainer.kt", i = {0}, l = {62}, m = "onRenderProcessGone", n = {"this"}, s = {"L$0"})
/* compiled from: AndroidWebViewContainer.kt */
final class AndroidWebViewContainer$onRenderProcessGone$1 extends ContinuationImpl {
    Object L$0;
    int label;
    /* synthetic */ Object result;
    final /* synthetic */ AndroidWebViewContainer this$0;

    AndroidWebViewContainer$onRenderProcessGone$1(AndroidWebViewContainer androidWebViewContainer, Continuation<? super AndroidWebViewContainer$onRenderProcessGone$1> continuation) {
        this.this$0 = androidWebViewContainer;
        super(continuation);
    }

    public final Object invokeSuspend(Object obj) {
        this.result = obj;
        this.label |= Integer.MIN_VALUE;
        return this.this$0.onRenderProcessGone(this);
    }
}
