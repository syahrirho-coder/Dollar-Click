package com.unity3d.ads.adplayer;

import android.content.Context;
import android.view.InputEvent;
import android.view.MotionEvent;
import android.view.View;
import android.webkit.WebView;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsCompat.Type;
import com.unity3d.ads.core.domain.SendWebViewClientErrorDiagnostics;
import kotlin.Metadata;
import kotlin.Result;
import kotlin.Result.Companion;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;
import kotlinx.coroutines.CoroutineDispatcher;
import kotlinx.coroutines.CoroutineName;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.CoroutineScopeKt;
import kotlinx.coroutines.flow.FlowKt;
import kotlinx.coroutines.flow.MutableStateFlow;
import kotlinx.coroutines.flow.StateFlow;
import kotlinx.coroutines.flow.StateFlowKt;

@Metadata(d1 = {"\u0000Z\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u000b\b\u0007\u0018\u00002\u00020\u0001B=\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\u0006\u0010\b\u001a\u00020\t\u0012\u0006\u0010\n\u001a\u00020\t\u0012\u0006\u0010\u000b\u001a\u00020\f\u0012\u0006\u0010\r\u001a\u00020\u000e¢\u0006\u0002\u0010\u000fJ!\u0010\u001e\u001a\u00020\u001f2\u0006\u0010 \u001a\u00020!2\u0006\u0010\"\u001a\u00020#H@ø\u0001\u0000¢\u0006\u0002\u0010$J\b\u0010%\u001a\u00020\u001fH\u0002J\u0011\u0010&\u001a\u00020\u001fH@ø\u0001\u0000¢\u0006\u0002\u0010'J\u0019\u0010(\u001a\u00020\u001f2\u0006\u0010)\u001a\u00020#H@ø\u0001\u0000¢\u0006\u0002\u0010*J\u0019\u0010+\u001a\u00020\u001f2\u0006\u0010,\u001a\u00020#H@ø\u0001\u0000¢\u0006\u0002\u0010*J\u0011\u0010-\u001a\u00020\u001fH@ø\u0001\u0000¢\u0006\u0002\u0010'R\u0019\u0010\u0010\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\u00120\u0011¢\u0006\b\n\u0000\u001a\u0004\b\u0013\u0010\u0014R\u000e\u0010\r\u001a\u00020\u000eX\u0004¢\u0006\u0002\n\u0000R\u001c\u0010\u0015\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\u00120\u0016X\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0017\u0010\u0018R\u0011\u0010\u0019\u001a\u00020\f¢\u0006\b\n\u0000\u001a\u0004\b\u001a\u0010\u001bR\u000e\u0010\u0006\u001a\u00020\u0007X\u0004¢\u0006\u0002\n\u0000R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u001c\u0010\u001dR\u000e\u0010\u0004\u001a\u00020\u0005X\u0004¢\u0006\u0002\n\u0000\u0002\u0004\n\u0002\b\u0019¨\u0006."}, d2 = {"Lcom/unity3d/ads/adplayer/AndroidWebViewContainer;", "Lcom/unity3d/ads/adplayer/WebViewContainer;", "webView", "Landroid/webkit/WebView;", "webViewClient", "Lcom/unity3d/ads/adplayer/AndroidWebViewClient;", "sendWebViewClientErrorDiagnostics", "Lcom/unity3d/ads/core/domain/SendWebViewClientErrorDiagnostics;", "mainDispatcher", "Lkotlinx/coroutines/CoroutineDispatcher;", "defaultDispatcher", "adPlayerScope", "Lkotlinx/coroutines/CoroutineScope;", "context", "Landroid/content/Context;", "(Landroid/webkit/WebView;Lcom/unity3d/ads/adplayer/AndroidWebViewClient;Lcom/unity3d/ads/core/domain/SendWebViewClientErrorDiagnostics;Lkotlinx/coroutines/CoroutineDispatcher;Lkotlinx/coroutines/CoroutineDispatcher;Lkotlinx/coroutines/CoroutineScope;Landroid/content/Context;)V", "_lastInputEvent", "Lkotlinx/coroutines/flow/MutableStateFlow;", "Landroid/view/InputEvent;", "get_lastInputEvent", "()Lkotlinx/coroutines/flow/MutableStateFlow;", "lastInputEvent", "Lkotlinx/coroutines/flow/StateFlow;", "getLastInputEvent", "()Lkotlinx/coroutines/flow/StateFlow;", "scope", "getScope", "()Lkotlinx/coroutines/CoroutineScope;", "getWebView", "()Landroid/webkit/WebView;", "addJavascriptInterface", "", "webViewBridgeInterface", "Lcom/unity3d/ads/adplayer/WebViewBridge;", "name", "", "(Lcom/unity3d/ads/adplayer/WebViewBridge;Ljava/lang/String;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "applySafeAreaInsets", "destroy", "(Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "evaluateJavascript", "script", "(Ljava/lang/String;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "loadUrl", "url", "onRenderProcessGone", "unity-ads_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
/* compiled from: AndroidWebViewContainer.kt */
public final class AndroidWebViewContainer implements WebViewContainer {
    private final MutableStateFlow<InputEvent> _lastInputEvent;
    private final Context context;
    private final StateFlow<InputEvent> lastInputEvent;
    private final CoroutineScope scope;
    private final SendWebViewClientErrorDiagnostics sendWebViewClientErrorDiagnostics;
    private final WebView webView;
    private final AndroidWebViewClient webViewClient;

    private static final int applySafeAreaInsets$lambda$3$toPx(int i, float f) {
        return (int) (((float) i) / f);
    }

    public AndroidWebViewContainer(WebView webView, AndroidWebViewClient androidWebViewClient, SendWebViewClientErrorDiagnostics sendWebViewClientErrorDiagnostics, CoroutineDispatcher coroutineDispatcher, CoroutineDispatcher coroutineDispatcher2, CoroutineScope coroutineScope, Context context) {
        Intrinsics.checkNotNullParameter(webView, "webView");
        Intrinsics.checkNotNullParameter(androidWebViewClient, "webViewClient");
        Intrinsics.checkNotNullParameter(sendWebViewClientErrorDiagnostics, "sendWebViewClientErrorDiagnostics");
        Intrinsics.checkNotNullParameter(coroutineDispatcher, "mainDispatcher");
        Intrinsics.checkNotNullParameter(coroutineDispatcher2, "defaultDispatcher");
        Intrinsics.checkNotNullParameter(coroutineScope, "adPlayerScope");
        Intrinsics.checkNotNullParameter(context, "context");
        this.webView = webView;
        this.webViewClient = androidWebViewClient;
        this.sendWebViewClientErrorDiagnostics = sendWebViewClientErrorDiagnostics;
        this.context = context;
        CoroutineScope plus = CoroutineScopeKt.plus(CoroutineScopeKt.plus(coroutineScope, coroutineDispatcher), new CoroutineName("AndroidWebViewContainer"));
        this.scope = plus;
        MutableStateFlow MutableStateFlow = StateFlowKt.MutableStateFlow(null);
        this._lastInputEvent = MutableStateFlow;
        this.lastInputEvent = FlowKt.asStateFlow(MutableStateFlow);
        FlowKt.launchIn(FlowKt.onEach(new AndroidWebViewContainer$special$$inlined$filter$1(androidWebViewClient.isRenderProcessGone()), new Function2<Boolean, Continuation<? super Unit>, Object>(this, null) {
            int label;
            final /* synthetic */ AndroidWebViewContainer this$0;

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return /* anonymous class already generated */;
            }

            public final Object invoke(boolean z, Continuation<? super Unit> continuation) {
                return ((AnonymousClass2) create(Boolean.valueOf(z), continuation)).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object obj) {
                Object coroutine_suspended = IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED();
                int i = this.label;
                if (i == 0) {
                    ResultKt.throwOnFailure(obj);
                    AndroidWebViewContainer androidWebViewContainer = this.this$0;
                    Continuation continuation = this;
                    this.label = 1;
                    if (androidWebViewContainer.onRenderProcessGone(continuation) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                } else if (i == 1) {
                    ResultKt.throwOnFailure(obj);
                } else {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }), CoroutineScopeKt.plus(plus, coroutineDispatcher2));
        webView.setOnTouchListener(new AndroidWebViewContainer$$ExternalSyntheticLambda0(this));
        applySafeAreaInsets();
    }

    public final WebView getWebView() {
        return this.webView;
    }

    public final CoroutineScope getScope() {
        return this.scope;
    }

    public final MutableStateFlow<InputEvent> get_lastInputEvent() {
        return this._lastInputEvent;
    }

    public StateFlow<InputEvent> getLastInputEvent() {
        return this.lastInputEvent;
    }

    private static final boolean _init_$lambda$1(AndroidWebViewContainer androidWebViewContainer, View view, MotionEvent motionEvent) {
        Intrinsics.checkNotNullParameter(androidWebViewContainer, "this$0");
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 0 || actionMasked == 1 || actionMasked == 5 || actionMasked == 6) {
            androidWebViewContainer._lastInputEvent.setValue(motionEvent);
        }
        return false;
    }

    /* DevToolsApp WARNING: Removed duplicated region for block: B:12:0x0036  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:8:0x0024  */
    private final java.lang.Object onRenderProcessGone(kotlin.coroutines.Continuation<? super kotlin.Unit> r8) {
        /*
        r7 = this;
        r0 = r8 instanceof com.unity3d.ads.adplayer.AndroidWebViewContainer$onRenderProcessGone$1;
        if (r0 == 0) goto L_0x0014;
    L_0x0004:
        r0 = r8;
        r0 = (com.unity3d.ads.adplayer.AndroidWebViewContainer$onRenderProcessGone$1) r0;
        r1 = r0.label;
        r2 = -2147483648; // 0xffffffff80000000 float:-0.0 double:NaN;
        r1 = r1 & r2;
        if (r1 == 0) goto L_0x0014;
    L_0x000e:
        r8 = r0.label;
        r8 = r8 - r2;
        r0.label = r8;
        goto L_0x0019;
    L_0x0014:
        r0 = new com.unity3d.ads.adplayer.AndroidWebViewContainer$onRenderProcessGone$1;
        r0.<init>(r7, r8);
    L_0x0019:
        r8 = r0.result;
        r1 = kotlin.coroutines.intrinsics.IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED();
        r2 = r0.label;
        r3 = 1;
        if (r2 == 0) goto L_0x0036;
    L_0x0024:
        if (r2 != r3) goto L_0x002e;
    L_0x0026:
        r0 = r0.L$0;
        r0 = (com.unity3d.ads.adplayer.AndroidWebViewContainer) r0;
        kotlin.ResultKt.throwOnFailure(r8);
        goto L_0x0045;
    L_0x002e:
        r8 = new java.lang.IllegalStateException;
        r0 = "call to 'resume' before 'invoke' with coroutine";
        r8.<init>(r0);
        throw r8;
    L_0x0036:
        kotlin.ResultKt.throwOnFailure(r8);
        r0.L$0 = r7;
        r0.label = r3;
        r8 = r7.destroy(r0);
        if (r8 != r1) goto L_0x0044;
    L_0x0043:
        return r1;
    L_0x0044:
        r0 = r7;
    L_0x0045:
        r8 = r0.sendWebViewClientErrorDiagnostics;
        r6 = new com.unity3d.ads.adplayer.model.WebViewClientError;
        r2 = com.unity3d.ads.adplayer.model.ErrorReason.REASON_WEBVIEW_RENDER_PROCESS_GONE;
        r4 = 4;
        r5 = 0;
        r1 = "Render process gone";
        r3 = 0;
        r0 = r6;
        r0.<init>(r1, r2, r3, r4, r5);
        r0 = kotlin.collections.CollectionsKt__CollectionsJVMKt.listOf(r6);
        r8.invoke(r0);
        r8 = kotlin.Unit.INSTANCE;
        return r8;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.unity3d.ads.adplayer.AndroidWebViewContainer.onRenderProcessGone(kotlin.coroutines.Continuation):java.lang.Object");
    }

    /* DevToolsApp WARNING: Removed duplicated region for block: B:31:0x00a3  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:25:0x0089  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:16:0x0050  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:8:0x0026  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:22:0x007d A:{RETURN} */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:25:0x0089  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:31:0x00a3  */
    public java.lang.Object loadUrl(java.lang.String r8, kotlin.coroutines.Continuation<? super kotlin.Unit> r9) {
        /*
        r7 = this;
        r0 = r9 instanceof com.unity3d.ads.adplayer.AndroidWebViewContainer$loadUrl$1;
        if (r0 == 0) goto L_0x0014;
    L_0x0004:
        r0 = r9;
        r0 = (com.unity3d.ads.adplayer.AndroidWebViewContainer$loadUrl$1) r0;
        r1 = r0.label;
        r2 = -2147483648; // 0xffffffff80000000 float:-0.0 double:NaN;
        r1 = r1 & r2;
        if (r1 == 0) goto L_0x0014;
    L_0x000e:
        r9 = r0.label;
        r9 = r9 - r2;
        r0.label = r9;
        goto L_0x0019;
    L_0x0014:
        r0 = new com.unity3d.ads.adplayer.AndroidWebViewContainer$loadUrl$1;
        r0.<init>(r7, r9);
    L_0x0019:
        r9 = r0.result;
        r1 = kotlin.coroutines.intrinsics.IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED();
        r2 = r0.label;
        r3 = 3;
        r4 = 2;
        r5 = 1;
        if (r2 == 0) goto L_0x0050;
    L_0x0026:
        if (r2 == r5) goto L_0x0048;
    L_0x0028:
        if (r2 == r4) goto L_0x0040;
    L_0x002a:
        if (r2 == r3) goto L_0x0034;
    L_0x002c:
        r8 = new java.lang.IllegalStateException;
        r9 = "call to 'resume' before 'invoke' with coroutine";
        r8.<init>(r9);
        throw r8;
    L_0x0034:
        r8 = r0.L$1;
        r8 = (java.util.List) r8;
        r0 = r0.L$0;
        r0 = (com.unity3d.ads.adplayer.AndroidWebViewContainer) r0;
        kotlin.ResultKt.throwOnFailure(r9);
        goto L_0x0098;
    L_0x0040:
        r8 = r0.L$0;
        r8 = (com.unity3d.ads.adplayer.AndroidWebViewContainer) r8;
        kotlin.ResultKt.throwOnFailure(r9);
        goto L_0x007e;
    L_0x0048:
        r8 = r0.L$0;
        r8 = (com.unity3d.ads.adplayer.AndroidWebViewContainer) r8;
        kotlin.ResultKt.throwOnFailure(r9);
        goto L_0x006d;
    L_0x0050:
        kotlin.ResultKt.throwOnFailure(r9);
        r9 = r7.scope;
        r9 = r9.getCoroutineContext();
        r2 = new com.unity3d.ads.adplayer.AndroidWebViewContainer$loadUrl$2;
        r6 = 0;
        r2.<init>(r7, r8, r6);
        r2 = (kotlin.jvm.functions.Function2) r2;
        r0.L$0 = r7;
        r0.label = r5;
        r8 = kotlinx.coroutines.BuildersKt.withContext(r9, r2, r0);
        if (r8 != r1) goto L_0x006c;
    L_0x006b:
        return r1;
    L_0x006c:
        r8 = r7;
    L_0x006d:
        r9 = r8.webViewClient;
        r9 = r9.getOnLoadFinished();
        r0.L$0 = r8;
        r0.label = r4;
        r9 = r9.await(r0);
        if (r9 != r1) goto L_0x007e;
    L_0x007d:
        return r1;
    L_0x007e:
        r9 = (java.util.List) r9;
        r2 = r9;
        r2 = (java.util.Collection) r2;
        r2 = r2.isEmpty();
        if (r2 != 0) goto L_0x00a3;
    L_0x0089:
        r0.L$0 = r8;
        r0.L$1 = r9;
        r0.label = r3;
        r0 = r8.destroy(r0);
        if (r0 != r1) goto L_0x0096;
    L_0x0095:
        return r1;
    L_0x0096:
        r0 = r8;
        r8 = r9;
    L_0x0098:
        r9 = r0.sendWebViewClientErrorDiagnostics;
        r9.invoke(r8);
        r9 = new com.unity3d.ads.adplayer.LoadWebViewError;
        r9.<init>(r8);
        throw r9;
    L_0x00a3:
        r8 = kotlin.Unit.INSTANCE;
        return r8;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.unity3d.ads.adplayer.AndroidWebViewContainer.loadUrl(java.lang.String, kotlin.coroutines.Continuation):java.lang.Object");
    }

    /* DevToolsApp WARNING: Removed duplicated region for block: B:13:0x0032  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:8:0x0024  */
    public java.lang.Object evaluateJavascript(java.lang.String r6, kotlin.coroutines.Continuation<? super kotlin.Unit> r7) {
        /*
        r5 = this;
        r0 = r7 instanceof com.unity3d.ads.adplayer.AndroidWebViewContainer$evaluateJavascript$1;
        if (r0 == 0) goto L_0x0014;
    L_0x0004:
        r0 = r7;
        r0 = (com.unity3d.ads.adplayer.AndroidWebViewContainer$evaluateJavascript$1) r0;
        r1 = r0.label;
        r2 = -2147483648; // 0xffffffff80000000 float:-0.0 double:NaN;
        r1 = r1 & r2;
        if (r1 == 0) goto L_0x0014;
    L_0x000e:
        r7 = r0.label;
        r7 = r7 - r2;
        r0.label = r7;
        goto L_0x0019;
    L_0x0014:
        r0 = new com.unity3d.ads.adplayer.AndroidWebViewContainer$evaluateJavascript$1;
        r0.<init>(r5, r7);
    L_0x0019:
        r7 = r0.result;
        r1 = kotlin.coroutines.intrinsics.IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED();
        r2 = r0.label;
        r3 = 1;
        if (r2 == 0) goto L_0x0032;
    L_0x0024:
        if (r2 != r3) goto L_0x002a;
    L_0x0026:
        kotlin.ResultKt.throwOnFailure(r7);	 Catch:{ CancellationException -> 0x004c }
        goto L_0x004c;
    L_0x002a:
        r6 = new java.lang.IllegalStateException;
        r7 = "call to 'resume' before 'invoke' with coroutine";
        r6.<init>(r7);
        throw r6;
    L_0x0032:
        kotlin.ResultKt.throwOnFailure(r7);
        r7 = r5.scope;	 Catch:{ CancellationException -> 0x004c }
        r7 = r7.getCoroutineContext();	 Catch:{ CancellationException -> 0x004c }
        r2 = new com.unity3d.ads.adplayer.AndroidWebViewContainer$evaluateJavascript$2;	 Catch:{ CancellationException -> 0x004c }
        r4 = 0;
        r2.<init>(r5, r6, r4);	 Catch:{ CancellationException -> 0x004c }
        r2 = (kotlin.jvm.functions.Function2) r2;	 Catch:{ CancellationException -> 0x004c }
        r0.label = r3;	 Catch:{ CancellationException -> 0x004c }
        r6 = kotlinx.coroutines.BuildersKt.withContext(r7, r2, r0);	 Catch:{ CancellationException -> 0x004c }
        if (r6 != r1) goto L_0x004c;
    L_0x004b:
        return r1;
    L_0x004c:
        r6 = kotlin.Unit.INSTANCE;
        return r6;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.unity3d.ads.adplayer.AndroidWebViewContainer.evaluateJavascript(java.lang.String, kotlin.coroutines.Continuation):java.lang.Object");
    }

    /* DevToolsApp WARNING: Removed duplicated region for block: B:13:0x0032  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:8:0x0024  */
    public java.lang.Object addJavascriptInterface(com.unity3d.ads.adplayer.WebViewBridge r6, java.lang.String r7, kotlin.coroutines.Continuation<? super kotlin.Unit> r8) {
        /*
        r5 = this;
        r0 = r8 instanceof com.unity3d.ads.adplayer.AndroidWebViewContainer$addJavascriptInterface$1;
        if (r0 == 0) goto L_0x0014;
    L_0x0004:
        r0 = r8;
        r0 = (com.unity3d.ads.adplayer.AndroidWebViewContainer$addJavascriptInterface$1) r0;
        r1 = r0.label;
        r2 = -2147483648; // 0xffffffff80000000 float:-0.0 double:NaN;
        r1 = r1 & r2;
        if (r1 == 0) goto L_0x0014;
    L_0x000e:
        r8 = r0.label;
        r8 = r8 - r2;
        r0.label = r8;
        goto L_0x0019;
    L_0x0014:
        r0 = new com.unity3d.ads.adplayer.AndroidWebViewContainer$addJavascriptInterface$1;
        r0.<init>(r5, r8);
    L_0x0019:
        r8 = r0.result;
        r1 = kotlin.coroutines.intrinsics.IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED();
        r2 = r0.label;
        r3 = 1;
        if (r2 == 0) goto L_0x0032;
    L_0x0024:
        if (r2 != r3) goto L_0x002a;
    L_0x0026:
        kotlin.ResultKt.throwOnFailure(r8);	 Catch:{ CancellationException -> 0x004c }
        goto L_0x004c;
    L_0x002a:
        r6 = new java.lang.IllegalStateException;
        r7 = "call to 'resume' before 'invoke' with coroutine";
        r6.<init>(r7);
        throw r6;
    L_0x0032:
        kotlin.ResultKt.throwOnFailure(r8);
        r8 = r5.scope;	 Catch:{ CancellationException -> 0x004c }
        r8 = r8.getCoroutineContext();	 Catch:{ CancellationException -> 0x004c }
        r2 = new com.unity3d.ads.adplayer.AndroidWebViewContainer$addJavascriptInterface$2;	 Catch:{ CancellationException -> 0x004c }
        r4 = 0;
        r2.<init>(r5, r7, r6, r4);	 Catch:{ CancellationException -> 0x004c }
        r2 = (kotlin.jvm.functions.Function2) r2;	 Catch:{ CancellationException -> 0x004c }
        r0.label = r3;	 Catch:{ CancellationException -> 0x004c }
        r6 = kotlinx.coroutines.BuildersKt.withContext(r8, r2, r0);	 Catch:{ CancellationException -> 0x004c }
        if (r6 != r1) goto L_0x004c;
    L_0x004b:
        return r1;
    L_0x004c:
        r6 = kotlin.Unit.INSTANCE;
        return r6;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.unity3d.ads.adplayer.AndroidWebViewContainer.addJavascriptInterface(com.unity3d.ads.adplayer.WebViewBridge, java.lang.String, kotlin.coroutines.Continuation):java.lang.Object");
    }

    /* DevToolsApp WARNING: Removed duplicated region for block: B:12:0x0037  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:8:0x0025  */
    public java.lang.Object destroy(kotlin.coroutines.Continuation<? super kotlin.Unit> r6) {
        /*
        r5 = this;
        r0 = r6 instanceof com.unity3d.ads.adplayer.AndroidWebViewContainer$destroy$1;
        if (r0 == 0) goto L_0x0014;
    L_0x0004:
        r0 = r6;
        r0 = (com.unity3d.ads.adplayer.AndroidWebViewContainer$destroy$1) r0;
        r1 = r0.label;
        r2 = -2147483648; // 0xffffffff80000000 float:-0.0 double:NaN;
        r1 = r1 & r2;
        if (r1 == 0) goto L_0x0014;
    L_0x000e:
        r6 = r0.label;
        r6 = r6 - r2;
        r0.label = r6;
        goto L_0x0019;
    L_0x0014:
        r0 = new com.unity3d.ads.adplayer.AndroidWebViewContainer$destroy$1;
        r0.<init>(r5, r6);
    L_0x0019:
        r6 = r0.result;
        r1 = kotlin.coroutines.intrinsics.IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED();
        r2 = r0.label;
        r3 = 0;
        r4 = 1;
        if (r2 == 0) goto L_0x0037;
    L_0x0025:
        if (r2 != r4) goto L_0x002f;
    L_0x0027:
        r0 = r0.L$0;
        r0 = (com.unity3d.ads.adplayer.AndroidWebViewContainer) r0;
        kotlin.ResultKt.throwOnFailure(r6);
        goto L_0x005b;
    L_0x002f:
        r6 = new java.lang.IllegalStateException;
        r0 = "call to 'resume' before 'invoke' with coroutine";
        r6.<init>(r0);
        throw r6;
    L_0x0037:
        kotlin.ResultKt.throwOnFailure(r6);
        r6 = r5.scope;
        r6 = r6.getCoroutineContext();
        r2 = kotlinx.coroutines.NonCancellable.INSTANCE;
        r2 = (kotlin.coroutines.CoroutineContext) r2;
        r6 = r6.plus(r2);
        r2 = new com.unity3d.ads.adplayer.AndroidWebViewContainer$destroy$2;
        r2.<init>(r5, r3);
        r2 = (kotlin.jvm.functions.Function2) r2;
        r0.L$0 = r5;
        r0.label = r4;
        r6 = kotlinx.coroutines.BuildersKt.withContext(r6, r2, r0);
        if (r6 != r1) goto L_0x005a;
    L_0x0059:
        return r1;
    L_0x005a:
        r0 = r5;
    L_0x005b:
        r6 = r0.scope;
        kotlinx.coroutines.CoroutineScopeKt.cancel$default(r6, r3, r4, r3);
        r6 = kotlin.Unit.INSTANCE;
        return r6;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.unity3d.ads.adplayer.AndroidWebViewContainer.destroy(kotlin.coroutines.Continuation):java.lang.Object");
    }

    private final void applySafeAreaInsets() {
        ViewCompat.setOnApplyWindowInsetsListener(this.webView, new AndroidWebViewContainer$$ExternalSyntheticLambda1(this));
    }

    private static final WindowInsetsCompat applySafeAreaInsets$lambda$3(AndroidWebViewContainer androidWebViewContainer, View view, WindowInsetsCompat windowInsetsCompat) {
        Object constructor-impl;
        Intrinsics.checkNotNullParameter(androidWebViewContainer, "this$0");
        Intrinsics.checkNotNullParameter(view, "v");
        Intrinsics.checkNotNullParameter(windowInsetsCompat, "insets");
        Insets insets = windowInsetsCompat.getInsets(Type.systemBars());
        Intrinsics.checkNotNullExpressionValue(insets, "insets.getInsets(WindowI…Compat.Type.systemBars())");
        Insets insets2 = windowInsetsCompat.getInsets(Type.displayCutout());
        Intrinsics.checkNotNullExpressionValue(insets2, "insets.getInsets(WindowI…pat.Type.displayCutout())");
        try {
            Companion companion = Result.Companion;
            constructor-impl = Result.m17constructor-impl(Float.valueOf(androidWebViewContainer.context.getResources().getDisplayMetrics().density));
        } catch (Throwable th) {
            Companion companion2 = Result.Companion;
            constructor-impl = Result.m17constructor-impl(ResultKt.createFailure(th));
        }
        Float valueOf = Float.valueOf(1.0f);
        if (Result.m23isFailure-impl(constructor-impl)) {
            constructor-impl = valueOf;
        }
        float floatValue = ((Number) constructor-impl).floatValue();
        int applySafeAreaInsets$lambda$3$toPx = applySafeAreaInsets$lambda$3$toPx(Math.max(insets.left, insets2.left), floatValue);
        int applySafeAreaInsets$lambda$3$toPx2 = applySafeAreaInsets$lambda$3$toPx(Math.max(insets.top, insets2.top), floatValue);
        int applySafeAreaInsets$lambda$3$toPx3 = applySafeAreaInsets$lambda$3$toPx(Math.max(insets.right, insets2.right), floatValue);
        BuildersKt__Builders_commonKt.launch$default(androidWebViewContainer.scope, null, null, new AndroidWebViewContainer$applySafeAreaInsets$1$1(androidWebViewContainer, StringsKt__IndentKt.trimIndent("\n                (function() {\n                    const root = document.documentElement;\n                    root.style.setProperty('--safe-area-inset-left', '" + applySafeAreaInsets$lambda$3$toPx + "px');\n                    root.style.setProperty('--safe-area-inset-right', '" + applySafeAreaInsets$lambda$3$toPx3 + "px');\n                    root.style.setProperty('--safe-area-inset-top', '" + applySafeAreaInsets$lambda$3$toPx2 + "px');\n                    root.style.setProperty('--safe-area-inset-bottom', '" + applySafeAreaInsets$lambda$3$toPx(Math.max(insets.bottom, insets2.bottom), floatValue) + "px');\n                })();\n            "), null), 3, null);
        return windowInsetsCompat;
    }
}
