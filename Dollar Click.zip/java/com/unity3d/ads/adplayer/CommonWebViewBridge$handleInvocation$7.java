package com.unity3d.ads.adplayer;

import kotlin.Metadata;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function2;
import kotlinx.coroutines.CoroutineScope;
import org.json.JSONArray;

@Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H@"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {1, 8, 0}, xi = 48)
@DebugMetadata(c = "com.unity3d.ads.adplayer.CommonWebViewBridge$handleInvocation$7", f = "CommonWebViewBridge.kt", i = {0, 1}, l = {127, 129, 130, 131, 132, 139}, m = "invokeSuspend", n = {"invocation", "invocation"}, s = {"L$0", "L$0"})
/* compiled from: CommonWebViewBridge.kt */
final class CommonWebViewBridge$handleInvocation$7 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
    final /* synthetic */ String $callback;
    final /* synthetic */ String $location;
    final /* synthetic */ JSONArray $parameters;
    Object L$0;
    int label;
    final /* synthetic */ CommonWebViewBridge this$0;

    CommonWebViewBridge$handleInvocation$7(String str, JSONArray jSONArray, CommonWebViewBridge commonWebViewBridge, String str2, Continuation<? super CommonWebViewBridge$handleInvocation$7> continuation) {
        this.$location = str;
        this.$parameters = jSONArray;
        this.this$0 = commonWebViewBridge;
        this.$callback = str2;
        super(2, continuation);
    }

    public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
        return new CommonWebViewBridge$handleInvocation$7(this.$location, this.$parameters, this.this$0, this.$callback, continuation);
    }

    public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
        return ((CommonWebViewBridge$handleInvocation$7) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
    }

    /* DevToolsApp WARNING: Missing block: B:18:?, code:
            r8 = new com.unity3d.ads.adplayer.CommonWebViewBridge$handleInvocation$7.AnonymousClass1(null);
            r3 = r7;
            r7.L$0 = r1;
            r7.label = 2;
     */
    /* DevToolsApp WARNING: Missing block: B:19:0x006e, code:
            if (kotlinx.coroutines.TimeoutKt.withTimeout(com.unity3d.services.core.di.ServiceProvider.SCAR_VERSION_FETCH_TIMEOUT, r8, r3) != r0) goto L_0x0071;
     */
    /* DevToolsApp WARNING: Missing block: B:20:0x0070, code:
            return r0;
     */
    /* DevToolsApp WARNING: Missing block: B:21:0x0071, code:
            r8 = r7;
            r7.L$0 = null;
            r7.label = 3;
            r8 = r1.getResult(r8);
     */
    /* DevToolsApp WARNING: Missing block: B:22:0x007d, code:
            if (r8 != r0) goto L_0x0080;
     */
    /* DevToolsApp WARNING: Missing block: B:23:0x007f, code:
            return r0;
     */
    /* DevToolsApp WARNING: Missing block: B:25:0x0082, code:
            if ((r8 instanceof com.unity3d.ads.adplayer.model.WebViewEvent) == false) goto L_0x0095;
     */
    /* DevToolsApp WARNING: Missing block: B:26:0x0084, code:
            r1 = r7.this$0;
            r8 = (com.unity3d.ads.adplayer.model.WebViewEvent) r8;
            r3 = r7;
            r7.label = 4;
     */
    /* DevToolsApp WARNING: Missing block: B:27:0x0092, code:
            if (r1.sendEvent(r8, r3) != r0) goto L_0x00f6;
     */
    /* DevToolsApp WARNING: Missing block: B:28:0x0094, code:
            return r0;
     */
    /* DevToolsApp WARNING: Missing block: B:29:0x0095, code:
            r8 = new java.lang.Object[]{r8};
            r5 = r7;
            r7.label = 5;
     */
    /* DevToolsApp WARNING: Missing block: B:30:0x00a9, code:
            if (com.unity3d.ads.adplayer.CommonWebViewBridge.access$respond(r7.this$0, r7.$callback, "OK", r8, r5) != r0) goto L_0x00f6;
     */
    /* DevToolsApp WARNING: Missing block: B:31:0x00ab, code:
            return r0;
     */
    /* DevToolsApp WARNING: Missing block: B:43:0x00f8, code:
            return kotlin.Unit.INSTANCE;
     */
    public final java.lang.Object invokeSuspend(java.lang.Object r8) {
        /*
        r7 = this;
        r0 = kotlin.coroutines.intrinsics.IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED();
        r1 = r7.label;
        r2 = 0;
        switch(r1) {
            case 0: goto L_0x0033;
            case 1: goto L_0x002b;
            case 2: goto L_0x0023;
            case 3: goto L_0x001c;
            case 4: goto L_0x0017;
            case 5: goto L_0x0017;
            case 6: goto L_0x0012;
            default: goto L_0x000a;
        };
    L_0x000a:
        r8 = new java.lang.IllegalStateException;
        r0 = "call to 'resume' before 'invoke' with coroutine";
        r8.<init>(r0);
        throw r8;
    L_0x0012:
        kotlin.ResultKt.throwOnFailure(r8);
        goto L_0x00f6;
    L_0x0017:
        kotlin.ResultKt.throwOnFailure(r8);	 Catch:{ Exception -> 0x0020 }
        goto L_0x00f6;
    L_0x001c:
        kotlin.ResultKt.throwOnFailure(r8);	 Catch:{ Exception -> 0x0020 }
        goto L_0x0080;
    L_0x0020:
        r8 = move-exception;
        goto L_0x00ac;
    L_0x0023:
        r1 = r7.L$0;
        r1 = (com.unity3d.ads.adplayer.Invocation) r1;
        kotlin.ResultKt.throwOnFailure(r8);	 Catch:{ Exception -> 0x0020 }
        goto L_0x0071;
    L_0x002b:
        r1 = r7.L$0;
        r1 = (com.unity3d.ads.adplayer.Invocation) r1;
        kotlin.ResultKt.throwOnFailure(r8);
        goto L_0x0059;
    L_0x0033:
        kotlin.ResultKt.throwOnFailure(r8);
        r8 = new com.unity3d.ads.adplayer.Invocation;
        r1 = r7.$location;
        r3 = r7.$parameters;
        r3 = com.unity3d.ads.core.extensions.JSONArrayExtensionsKt.toTypedArray(r3);
        r8.<init>(r1, r3);
        r1 = r7.this$0;
        r1 = r1._onInvocation;
        r3 = r7;
        r3 = (kotlin.coroutines.Continuation) r3;
        r7.L$0 = r8;
        r4 = 1;
        r7.label = r4;
        r1 = r1.emit(r8, r3);
        if (r1 != r0) goto L_0x0058;
    L_0x0057:
        return r0;
    L_0x0058:
        r1 = r8;
    L_0x0059:
        r8 = new com.unity3d.ads.adplayer.CommonWebViewBridge$handleInvocation$7$1;	 Catch:{ Exception -> 0x0020 }
        r8.<init>(r1, r2);	 Catch:{ Exception -> 0x0020 }
        r8 = (kotlin.jvm.functions.Function2) r8;	 Catch:{ Exception -> 0x0020 }
        r3 = r7;
        r3 = (kotlin.coroutines.Continuation) r3;	 Catch:{ Exception -> 0x0020 }
        r7.L$0 = r1;	 Catch:{ Exception -> 0x0020 }
        r4 = 2;
        r7.label = r4;	 Catch:{ Exception -> 0x0020 }
        r4 = 5000; // 0x1388 float:7.006E-42 double:2.4703E-320;
        r8 = kotlinx.coroutines.TimeoutKt.withTimeout(r4, r8, r3);	 Catch:{ Exception -> 0x0020 }
        if (r8 != r0) goto L_0x0071;
    L_0x0070:
        return r0;
    L_0x0071:
        r8 = r7;
        r8 = (kotlin.coroutines.Continuation) r8;	 Catch:{ Exception -> 0x0020 }
        r7.L$0 = r2;	 Catch:{ Exception -> 0x0020 }
        r3 = 3;
        r7.label = r3;	 Catch:{ Exception -> 0x0020 }
        r8 = r1.getResult(r8);	 Catch:{ Exception -> 0x0020 }
        if (r8 != r0) goto L_0x0080;
    L_0x007f:
        return r0;
    L_0x0080:
        r1 = r8 instanceof com.unity3d.ads.adplayer.model.WebViewEvent;	 Catch:{ Exception -> 0x0020 }
        if (r1 == 0) goto L_0x0095;
    L_0x0084:
        r1 = r7.this$0;	 Catch:{ Exception -> 0x0020 }
        r8 = (com.unity3d.ads.adplayer.model.WebViewEvent) r8;	 Catch:{ Exception -> 0x0020 }
        r3 = r7;
        r3 = (kotlin.coroutines.Continuation) r3;	 Catch:{ Exception -> 0x0020 }
        r4 = 4;
        r7.label = r4;	 Catch:{ Exception -> 0x0020 }
        r8 = r1.sendEvent(r8, r3);	 Catch:{ Exception -> 0x0020 }
        if (r8 != r0) goto L_0x00f6;
    L_0x0094:
        return r0;
    L_0x0095:
        r1 = r7.this$0;	 Catch:{ Exception -> 0x0020 }
        r3 = r7.$callback;	 Catch:{ Exception -> 0x0020 }
        r4 = "OK";
        r8 = new java.lang.Object[]{r8};	 Catch:{ Exception -> 0x0020 }
        r5 = r7;
        r5 = (kotlin.coroutines.Continuation) r5;	 Catch:{ Exception -> 0x0020 }
        r6 = 5;
        r7.label = r6;	 Catch:{ Exception -> 0x0020 }
        r8 = r1.respond(r3, r4, r8, r5);	 Catch:{ Exception -> 0x0020 }
        if (r8 != r0) goto L_0x00f6;
    L_0x00ab:
        return r0;
    L_0x00ac:
        r1 = r8 instanceof kotlinx.coroutines.TimeoutCancellationException;
        if (r1 == 0) goto L_0x00c8;
    L_0x00b0:
        r8 = new java.lang.StringBuilder;
        r1 = "Invocation(";
        r8.<init>(r1);
        r1 = r7.$location;
        r8 = r8.append(r1);
        r1 = ") is not handled";
        r8 = r8.append(r1);
        r8 = r8.toString();
        goto L_0x00d8;
    L_0x00c8:
        r1 = r8.getMessage();
        if (r1 != 0) goto L_0x00d7;
    L_0x00ce:
        r8 = r8.getClass();
        r8 = r8.getSimpleName();
        goto L_0x00d8;
    L_0x00d7:
        r8 = r1;
    L_0x00d8:
        r1 = r7.this$0;
        r3 = r7.$callback;
        r4 = "reason";
        kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r8, r4);
        r8 = new java.lang.Object[]{r8};
        r4 = r7;
        r4 = (kotlin.coroutines.Continuation) r4;
        r7.L$0 = r2;
        r2 = 6;
        r7.label = r2;
        r2 = "ERROR";
        r8 = r1.respond(r3, r2, r8, r4);
        if (r8 != r0) goto L_0x00f6;
    L_0x00f5:
        return r0;
    L_0x00f6:
        r8 = kotlin.Unit.INSTANCE;
        return r8;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.unity3d.ads.adplayer.CommonWebViewBridge$handleInvocation$7.invokeSuspend(java.lang.Object):java.lang.Object");
    }
}
