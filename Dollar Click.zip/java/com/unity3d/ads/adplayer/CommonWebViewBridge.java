package com.unity3d.ads.adplayer;

import com.unity3d.ads.adplayer.model.WebViewEvent;
import com.unity3d.ads.core.domain.SendDiagnosticEvent;
import com.unity3d.ads.core.domain.SendDiagnosticEvent.DefaultImpls;
import com.unity3d.services.core.log.DeviceLog;
import java.util.Set;
import kotlin.Metadata;
import kotlin.Pair;
import kotlin.ResultKt;
import kotlin.TuplesKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;
import kotlinx.coroutines.CompletableDeferred;
import kotlinx.coroutines.CoroutineDispatcher;
import kotlinx.coroutines.CoroutineName;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.CoroutineScopeKt;
import kotlinx.coroutines.flow.FlowKt;
import kotlinx.coroutines.flow.MutableSharedFlow;
import kotlinx.coroutines.flow.MutableStateFlow;
import kotlinx.coroutines.flow.SharedFlow;
import kotlinx.coroutines.flow.SharedFlowKt;
import kotlinx.coroutines.flow.StateFlowKt;
import org.json.JSONArray;
import org.json.JSONException;

@Metadata(d1 = {"\u0000j\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\"\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0002\u0018\u0002\n\u0002\u0010\u0011\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0011\n\u0002\u0018\u0002\n\u0002\b\u0002\u0018\u00002\u00020\u0001B%\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\u0006\u0010\b\u001a\u00020\t¢\u0006\u0002\u0010\nJ!\u0010\u001d\u001a\u00020\u001e2\u0006\u0010\u001f\u001a\u00020 2\u0006\u0010!\u001a\u00020\u0012H@ø\u0001\u0000¢\u0006\u0002\u0010\"J \u0010#\u001a\u00020\u001e2\u0006\u0010$\u001a\u00020\u00122\u0006\u0010%\u001a\u00020\u00122\u0006\u0010&\u001a\u00020\u0012H\u0016J\u0010\u0010'\u001a\u00020\u001e2\u0006\u0010(\u001a\u00020\u0012H\u0016J;\u0010)\u001a\b\u0012\u0004\u0012\u00020\u00150\u00142\u0006\u0010*\u001a\u00020\u00122\u0006\u0010+\u001a\u00020\u00122\u0012\u0010,\u001a\n\u0012\u0006\b\u0001\u0012\u00020\u00150\u0014\"\u00020\u0015H@ø\u0001\u0000¢\u0006\u0002\u0010-J5\u0010.\u001a\u00020\u001e2\u0006\u0010$\u001a\u00020\u00122\u0006\u0010/\u001a\u00020\u00122\u0012\u0010,\u001a\n\u0012\u0006\b\u0001\u0012\u00020\u00150\u0014\"\u00020\u0015H@ø\u0001\u0000¢\u0006\u0002\u0010-J\u0019\u00100\u001a\u00020\u001e2\u0006\u00101\u001a\u000202H@ø\u0001\u0000¢\u0006\u0002\u00103R\u0014\u0010\u000b\u001a\b\u0012\u0004\u0012\u00020\r0\fX\u0004¢\u0006\u0002\n\u0000R2\u0010\u000e\u001a&\u0012\"\u0012 \u0012\u001c\u0012\u001a\u0012\u0004\u0012\u00020\u0012\u0012\u0010\u0012\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00150\u00140\u00130\u00110\u00100\u000fX\u0004¢\u0006\u0002\n\u0000R\u001a\u0010\u0016\u001a\b\u0012\u0004\u0012\u00020\r0\u0017X\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0018\u0010\u0019R\u0011\u0010\u001a\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u001b\u0010\u001cR\u000e\u0010\b\u001a\u00020\tX\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0004\u001a\u00020\u0005X\u0004¢\u0006\u0002\n\u0000\u0002\u0004\n\u0002\b\u0019¨\u00064"}, d2 = {"Lcom/unity3d/ads/adplayer/CommonWebViewBridge;", "Lcom/unity3d/ads/adplayer/WebViewBridge;", "dispatcher", "Lkotlinx/coroutines/CoroutineDispatcher;", "webViewContainer", "Lcom/unity3d/ads/adplayer/WebViewContainer;", "adPlayerScope", "Lkotlinx/coroutines/CoroutineScope;", "sendDiagnosticEvent", "Lcom/unity3d/ads/core/domain/SendDiagnosticEvent;", "(Lkotlinx/coroutines/CoroutineDispatcher;Lcom/unity3d/ads/adplayer/WebViewContainer;Lkotlinx/coroutines/CoroutineScope;Lcom/unity3d/ads/core/domain/SendDiagnosticEvent;)V", "_onInvocation", "Lkotlinx/coroutines/flow/MutableSharedFlow;", "Lcom/unity3d/ads/adplayer/Invocation;", "callbacks", "Lkotlinx/coroutines/flow/MutableStateFlow;", "", "Lkotlin/Pair;", "", "Lkotlinx/coroutines/CompletableDeferred;", "", "", "onInvocation", "Lkotlinx/coroutines/flow/SharedFlow;", "getOnInvocation", "()Lkotlinx/coroutines/flow/SharedFlow;", "scope", "getScope", "()Lkotlinx/coroutines/CoroutineScope;", "execute", "", "handlerType", "Lcom/unity3d/ads/adplayer/HandlerType;", "arguments", "(Lcom/unity3d/ads/adplayer/HandlerType;Ljava/lang/String;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "handleCallback", "callbackId", "callbackStatus", "rawParameters", "handleInvocation", "message", "request", "className", "method", "params", "(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "respond", "status", "sendEvent", "event", "Lcom/unity3d/ads/adplayer/model/WebViewEvent;", "(Lcom/unity3d/ads/adplayer/model/WebViewEvent;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "unity-ads_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
/* compiled from: CommonWebViewBridge.kt */
public final class CommonWebViewBridge implements WebViewBridge {
    private final MutableSharedFlow<Invocation> _onInvocation;
    private final MutableStateFlow<Set<Pair<String, CompletableDeferred<Object[]>>>> callbacks = StateFlowKt.MutableStateFlow(SetsKt__SetsKt.emptySet());
    private final SharedFlow<Invocation> onInvocation;
    private final CoroutineScope scope;
    private final SendDiagnosticEvent sendDiagnosticEvent;
    private final WebViewContainer webViewContainer;

    public CommonWebViewBridge(CoroutineDispatcher coroutineDispatcher, WebViewContainer webViewContainer, CoroutineScope coroutineScope, SendDiagnosticEvent sendDiagnosticEvent) {
        Intrinsics.checkNotNullParameter(coroutineDispatcher, "dispatcher");
        Intrinsics.checkNotNullParameter(webViewContainer, "webViewContainer");
        Intrinsics.checkNotNullParameter(coroutineScope, "adPlayerScope");
        Intrinsics.checkNotNullParameter(sendDiagnosticEvent, "sendDiagnosticEvent");
        this.webViewContainer = webViewContainer;
        this.sendDiagnosticEvent = sendDiagnosticEvent;
        CoroutineScope plus = CoroutineScopeKt.plus(CoroutineScopeKt.plus(coroutineScope, coroutineDispatcher), new CoroutineName("CommonWebViewBridge"));
        this.scope = plus;
        MutableSharedFlow MutableSharedFlow$default = SharedFlowKt.MutableSharedFlow$default(0, 64, null, 5, null);
        this._onInvocation = MutableSharedFlow$default;
        this.onInvocation = FlowKt.asSharedFlow(MutableSharedFlow$default);
        BuildersKt__Builders_commonKt.launch$default(plus, null, null, new Function2<CoroutineScope, Continuation<? super Unit>, Object>(this, null) {
            int label;
            final /* synthetic */ CommonWebViewBridge this$0;

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return /* anonymous class already generated */;
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return ((AnonymousClass1) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object obj) {
                Object coroutine_suspended = IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED();
                int i = this.label;
                if (i == 0) {
                    ResultKt.throwOnFailure(obj);
                    WebViewContainer access$getWebViewContainer$p = this.this$0.webViewContainer;
                    WebViewBridge webViewBridge = this.this$0;
                    Continuation continuation = this;
                    this.label = 1;
                    if (access$getWebViewContainer$p.addJavascriptInterface(webViewBridge, "webviewbridge", continuation) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                } else if (i == 1) {
                    ResultKt.throwOnFailure(obj);
                } else {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }, 3, null);
    }

    public final CoroutineScope getScope() {
        return this.scope;
    }

    public SharedFlow<Invocation> getOnInvocation() {
        return this.onInvocation;
    }

    private final Object execute(HandlerType handlerType, String str, Continuation<? super Unit> continuation) {
        Object evaluateJavascript = this.webViewContainer.evaluateJavascript("window.nativebridge." + handlerType.getJsPath() + '(' + str + ");", continuation);
        return evaluateJavascript == IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED() ? evaluateJavascript : Unit.INSTANCE;
    }

    public Object sendEvent(WebViewEvent webViewEvent, Continuation<? super Unit> continuation) {
        JSONArray jSONArray = new JSONArray();
        jSONArray.put(webViewEvent.getCategory());
        jSONArray.put(webViewEvent.getName());
        for (Object put : webViewEvent.getParameters()) {
            jSONArray.put(put);
        }
        HandlerType handlerType = HandlerType.EVENT;
        String jSONArray2 = jSONArray.toString();
        Intrinsics.checkNotNullExpressionValue(jSONArray2, "arguments.toString()");
        Object execute = execute(handlerType, jSONArray2, continuation);
        return execute == IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED() ? execute : Unit.INSTANCE;
    }

    /* DevToolsApp WARNING: Removed duplicated region for block: B:14:0x003e  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:8:0x0026  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:27:0x00a0 A:{RETURN, PHI: r14 } */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:26:0x009f A:{RETURN} */
    public java.lang.Object request(java.lang.String r11, java.lang.String r12, java.lang.Object[] r13, kotlin.coroutines.Continuation<? super java.lang.Object[]> r14) {
        /*
        r10 = this;
        r0 = r14 instanceof com.unity3d.ads.adplayer.CommonWebViewBridge$request$1;
        if (r0 == 0) goto L_0x0014;
    L_0x0004:
        r0 = r14;
        r0 = (com.unity3d.ads.adplayer.CommonWebViewBridge$request$1) r0;
        r1 = r0.label;
        r2 = -2147483648; // 0xffffffff80000000 float:-0.0 double:NaN;
        r1 = r1 & r2;
        if (r1 == 0) goto L_0x0014;
    L_0x000e:
        r14 = r0.label;
        r14 = r14 - r2;
        r0.label = r14;
        goto L_0x0019;
    L_0x0014:
        r0 = new com.unity3d.ads.adplayer.CommonWebViewBridge$request$1;
        r0.<init>(r10, r14);
    L_0x0019:
        r14 = r0.result;
        r1 = kotlin.coroutines.intrinsics.IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED();
        r2 = r0.label;
        r3 = 2;
        r4 = 0;
        r5 = 1;
        if (r2 == 0) goto L_0x003e;
    L_0x0026:
        if (r2 == r5) goto L_0x0036;
    L_0x0028:
        if (r2 != r3) goto L_0x002e;
    L_0x002a:
        kotlin.ResultKt.throwOnFailure(r14);
        goto L_0x00a0;
    L_0x002e:
        r11 = new java.lang.IllegalStateException;
        r12 = "call to 'resume' before 'invoke' with coroutine";
        r11.<init>(r12);
        throw r11;
    L_0x0036:
        r11 = r0.L$0;
        r11 = (kotlinx.coroutines.CompletableDeferred) r11;
        kotlin.ResultKt.throwOnFailure(r14);
        goto L_0x0095;
    L_0x003e:
        kotlin.ResultKt.throwOnFailure(r14);
        r14 = kotlinx.coroutines.CompletableDeferredKt.CompletableDeferred$default(r4, r5, r4);
        r2 = r14.hashCode();
        r2 = java.lang.String.valueOf(r2);
        r6 = r10.callbacks;
    L_0x004f:
        r7 = r6.getValue();
        r8 = r7;
        r8 = (java.util.Set) r8;
        r9 = kotlin.TuplesKt.to(r2, r14);
        r8 = kotlin.collections.SetsKt___SetsKt.plus(r8, r9);
        r7 = r6.compareAndSet(r7, r8);
        if (r7 == 0) goto L_0x004f;
    L_0x0064:
        r6 = new org.json.JSONArray;
        r6.<init>();
        r6.put(r11);
        r6.put(r12);
        r6.put(r2);
        r11 = r13.length;
        r12 = 0;
    L_0x0074:
        if (r12 >= r11) goto L_0x007e;
    L_0x0076:
        r2 = r13[r12];
        r6.put(r2);
        r12 = r12 + 1;
        goto L_0x0074;
    L_0x007e:
        r11 = com.unity3d.ads.adplayer.HandlerType.INVOCATION;
        r12 = r6.toString();
        r13 = "arguments.toString()";
        kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r12, r13);
        r0.L$0 = r14;
        r0.label = r5;
        r11 = r10.execute(r11, r12, r0);
        if (r11 != r1) goto L_0x0094;
    L_0x0093:
        return r1;
    L_0x0094:
        r11 = r14;
    L_0x0095:
        r0.L$0 = r4;
        r0.label = r3;
        r14 = r11.await(r0);
        if (r14 != r1) goto L_0x00a0;
    L_0x009f:
        return r1;
    L_0x00a0:
        return r14;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.unity3d.ads.adplayer.CommonWebViewBridge.request(java.lang.String, java.lang.String, java.lang.Object[], kotlin.coroutines.Continuation):java.lang.Object");
    }

    /* DevToolsApp WARNING: Missing block: B:26:0x00bc, code:
            if (r2.equals("OK") == false) goto L_0x00c9;
     */
    /* DevToolsApp WARNING: Missing block: B:28:0x00c3, code:
            if (r2.equals(r7) == false) goto L_0x00c9;
     */
    public void handleCallback(java.lang.String r20, java.lang.String r21, java.lang.String r22) {
        /*
        r19 = this;
        r0 = r19;
        r1 = r20;
        r2 = r21;
        r3 = r22;
        r4 = "callbackId";
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r1, r4);
        r4 = "callbackStatus";
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r4);
        r4 = "rawParameters";
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r3, r4);
        r4 = new org.json.JSONArray;
        r4.<init>(r3);
        r3 = com.unity3d.ads.core.extensions.JSONArrayExtensionsKt.toTypedArray(r4);
        r4 = r0.callbacks;
        r4 = r4.getValue();
        r4 = (java.lang.Iterable) r4;
        r4 = r4.iterator();
    L_0x002c:
        r5 = r4.hasNext();
        if (r5 == 0) goto L_0x0046;
    L_0x0032:
        r5 = r4.next();
        r6 = r5;
        r6 = (kotlin.Pair) r6;
        r6 = r6.component1();
        r6 = (java.lang.String) r6;
        r6 = kotlin.jvm.internal.Intrinsics.areEqual(r6, r1);
        if (r6 == 0) goto L_0x002c;
    L_0x0045:
        goto L_0x0047;
    L_0x0046:
        r5 = 0;
    L_0x0047:
        r5 = (kotlin.Pair) r5;
        if (r5 != 0) goto L_0x004c;
    L_0x004b:
        return;
    L_0x004c:
        r1 = r5.component2();
        r1 = (kotlinx.coroutines.CompletableDeferred) r1;
        r4 = 2;
        r4 = new java.lang.String[r4];
        r6 = 0;
        r7 = "success";
        r4[r6] = r7;
        r8 = 1;
        r9 = "error";
        r4[r8] = r9;
        r4 = kotlin.collections.SetsKt__SetsKt.setOf(r4);
        r4 = r4.contains(r2);
        if (r4 == 0) goto L_0x007a;
    L_0x0069:
        r10 = r0.sendDiagnosticEvent;
        r17 = 62;
        r18 = 0;
        r11 = "old_callback_status";
        r12 = 0;
        r13 = 0;
        r14 = 0;
        r15 = 0;
        r16 = 0;
        com.unity3d.ads.core.domain.SendDiagnosticEvent.DefaultImpls.invoke$default(r10, r11, r12, r13, r14, r15, r16, r17, r18);
    L_0x007a:
        r4 = r21.hashCode();
        r8 = -1867169789; // 0xffffffff90b54003 float:-7.149054E-29 double:NaN;
        if (r4 == r8) goto L_0x00bf;
    L_0x0083:
        r7 = 2524; // 0x9dc float:3.537E-42 double:1.247E-320;
        if (r4 == r7) goto L_0x00b6;
    L_0x0087:
        r7 = 66247144; // 0x3f2d9e8 float:1.42735105E-36 double:3.2730438E-316;
        if (r4 == r7) goto L_0x0099;
    L_0x008c:
        r7 = 96784904; // 0x5c4d208 float:1.8508905E-35 double:4.7818096E-316;
        if (r4 == r7) goto L_0x0092;
    L_0x0091:
        goto L_0x00c9;
    L_0x0092:
        r2 = r2.equals(r9);
        if (r2 != 0) goto L_0x00a2;
    L_0x0098:
        goto L_0x00c9;
    L_0x0099:
        r4 = "ERROR";
        r2 = r2.equals(r4);
        if (r2 != 0) goto L_0x00a2;
    L_0x00a1:
        goto L_0x00c9;
    L_0x00a2:
        r2 = new java.lang.Exception;
        r3 = r3[r6];
        r4 = "null cannot be cast to non-null type kotlin.String";
        kotlin.jvm.internal.Intrinsics.checkNotNull(r3, r4);
        r3 = (java.lang.String) r3;
        r2.<init>(r3);
        r2 = (java.lang.Throwable) r2;
        r1.completeExceptionally(r2);
        goto L_0x00c9;
    L_0x00b6:
        r4 = "OK";
        r2 = r2.equals(r4);
        if (r2 != 0) goto L_0x00c6;
    L_0x00be:
        goto L_0x00c9;
    L_0x00bf:
        r2 = r2.equals(r7);
        if (r2 != 0) goto L_0x00c6;
    L_0x00c5:
        goto L_0x00c9;
    L_0x00c6:
        r1.complete(r3);
    L_0x00c9:
        r1 = r0.callbacks;
    L_0x00cb:
        r2 = r1.getValue();
        r3 = r2;
        r3 = (java.util.Set) r3;
        r3 = kotlin.collections.SetsKt___SetsKt.minus(r3, r5);
        r2 = r1.compareAndSet(r2, r3);
        if (r2 == 0) goto L_0x00cb;
    L_0x00dc:
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.unity3d.ads.adplayer.CommonWebViewBridge.handleCallback(java.lang.String, java.lang.String, java.lang.String):void");
    }

    public void handleInvocation(String str) {
        String str2 = str;
        String str3 = "Invalid JSON array passed to CommonWebViewBridge: ";
        Intrinsics.checkNotNullParameter(str2, "message");
        Object obj;
        try {
            JSONArray jSONArray = new JSONArray(str2);
            int length = jSONArray.length();
            int i = 0;
            while (i < length) {
                Object obj2 = jSONArray.get(i);
                JSONArray jSONArray2 = obj2 instanceof JSONArray ? (JSONArray) obj2 : null;
                if (jSONArray2 == null) {
                    throw new IllegalArgumentException(("Invalid invocation passed to CommonWebViewBridge: " + str2).toString());
                } else if (jSONArray2.length() == 4) {
                    obj = jSONArray2.get(0);
                    String str4 = obj instanceof String ? (String) obj : null;
                    if (str4 != null) {
                        Object obj3 = jSONArray2.get(1);
                        String str5 = obj3 instanceof String ? (String) obj3 : null;
                        if (str5 != null) {
                            Object obj4 = jSONArray2.get(2);
                            JSONArray jSONArray3 = obj4 instanceof JSONArray ? (JSONArray) obj4 : null;
                            if (jSONArray3 != null) {
                                obj2 = jSONArray2.get(3);
                                String str6 = obj2 instanceof String ? (String) obj2 : null;
                                if (str6 != null) {
                                    str4 = str4 + '.' + str5;
                                    DeviceLog.debug("Unity Ads WebView calling for: " + str4 + '(' + jSONArray3 + ')');
                                    BuildersKt__Builders_commonKt.launch$default(this.scope, null, null, new CommonWebViewBridge$handleInvocation$7(str4, jSONArray3, this, str6, null), 3, null);
                                    i++;
                                } else {
                                    throw new IllegalArgumentException(("Invalid callback id passed to CommonWebViewBridge: " + str2).toString());
                                }
                            }
                            throw new IllegalArgumentException(("Invalid parameters passed to CommonWebViewBridge: " + str2).toString());
                        }
                        throw new IllegalArgumentException(("Invalid method name passed to CommonWebViewBridge: " + str2).toString());
                    }
                    throw new IllegalArgumentException(("Invalid class name passed to CommonWebViewBridge: " + str2).toString());
                } else {
                    throw new IllegalArgumentException(("Invocation must have 4 elements: " + jSONArray2).toString());
                }
            }
        } catch (JSONException e) {
            throw new IllegalArgumentException(str2, e);
        } catch (Exception e2) {
            DeviceLog.error("Error handling invocation from webview (" + str2 + ')');
            SendDiagnosticEvent sendDiagnosticEvent = this.sendDiagnosticEvent;
            Pair[] pairArr = new Pair[2];
            obj = e2.getMessage();
            if (obj == null) {
                obj = e2.getClass().getSimpleName();
            }
            pairArr[0] = TuplesKt.to("reason_debug", obj);
            pairArr[1] = TuplesKt.to("webview_invocation", str2);
            DefaultImpls.invoke$default(sendDiagnosticEvent, "native_webview_invocation_error", null, MapsKt__MapsKt.mapOf(pairArr), null, null, null, 58, null);
            throw new IllegalArgumentException("Invalid message passed to CommonWebViewBridge: " + str2, e2);
        }
    }

    private final Object respond(String str, String str2, Object[] objArr, Continuation<? super Unit> continuation) {
        JSONArray jSONArray = new JSONArray();
        jSONArray.put((Object) str);
        jSONArray.put((Object) str2);
        jSONArray.put(new JSONArray((Object) objArr));
        Object execute = execute(HandlerType.CALLBACK, "[" + jSONArray + ']', continuation);
        return execute == IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED() ? execute : Unit.INSTANCE;
    }
}
