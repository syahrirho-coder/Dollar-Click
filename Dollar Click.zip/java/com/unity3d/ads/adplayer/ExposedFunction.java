package com.unity3d.ads.adplayer;

import kotlin.Metadata;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.jvm.internal.SuspendFunction;
import kotlin.jvm.functions.Function2;

@Metadata(d1 = {"\u0000\u0016\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0011\n\u0002\u0010\u0000\n\u0002\u0018\u0002\n\u0000\bæ\u0001\u0018\u00002$\b\u0001\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00030\u0002\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00030\u0004\u0012\u0006\u0012\u0004\u0018\u00010\u00030\u0001¨\u0006\u0005"}, d2 = {"Lcom/unity3d/ads/adplayer/ExposedFunction;", "Lkotlin/Function2;", "", "", "Lkotlin/coroutines/Continuation;", "unity-ads_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
/* compiled from: ExposedFunctionLocation.kt */
public interface ExposedFunction extends Function2<Object[], Continuation<? super Object>, Object>, SuspendFunction {
}
