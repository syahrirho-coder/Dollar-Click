package com.unity3d.ads.adplayer;

import com.unity3d.ads.core.data.model.AdObject;
import com.unity3d.ads.core.data.repository.AdRepository;
import com.unity3d.ads.core.extensions.ProtobufExtensionsKt;
import java.util.UUID;
import kotlin.Lazy;
import kotlin.LazyThreadSafetyMode;
import kotlin.Metadata;
import kotlin.Result;
import kotlin.Result.Companion;
import kotlin.ResultKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Lambda;

@Metadata(d1 = {"\u0000\b\n\u0000\n\u0002\u0018\u0002\n\u0000\u0010\u0000\u001a\u0004\u0018\u00010\u0001H\n¢\u0006\u0002\b\u0002"}, d2 = {"<anonymous>", "Lcom/unity3d/ads/core/data/model/AdObject;", "invoke"}, k = 3, mv = {1, 8, 0}, xi = 48)
/* compiled from: FullScreenWebViewDisplay.kt */
final class FullScreenWebViewDisplay$adObject$2 extends Lambda implements Function0<AdObject> {
    final /* synthetic */ FullScreenWebViewDisplay this$0;

    FullScreenWebViewDisplay$adObject$2(FullScreenWebViewDisplay fullScreenWebViewDisplay) {
        this.this$0 = fullScreenWebViewDisplay;
        super(0);
    }

    private static final AdRepository invoke$lambda$0(Lazy<? extends AdRepository> lazy) {
        return (AdRepository) lazy.getValue();
    }

    public final AdObject invoke() {
        Object constructor-impl;
        Lazy lazy = LazyKt__LazyJVMKt.lazy(LazyThreadSafetyMode.NONE, (Function0) new FullScreenWebViewDisplay$adObject$2$invoke$$inlined$inject$default$1(this.this$0, ""));
        FullScreenWebViewDisplay fullScreenWebViewDisplay = this.this$0;
        try {
            Companion companion = Result.Companion;
            AdRepository invoke$lambda$0 = invoke$lambda$0(lazy);
            UUID fromString = UUID.fromString(fullScreenWebViewDisplay.opportunityId);
            Intrinsics.checkNotNullExpressionValue(fromString, "fromString(opportunityId)");
            constructor-impl = Result.m17constructor-impl(invoke$lambda$0.getAd(ProtobufExtensionsKt.toByteString(fromString)));
        } catch (Throwable th) {
            Companion companion2 = Result.Companion;
            constructor-impl = Result.m17constructor-impl(ResultKt.createFailure(th));
        }
        if (Result.m23isFailure-impl(constructor-impl)) {
            constructor-impl = null;
        }
        return (AdObject) constructor-impl;
    }
}
