package com.unity3d.ads.adplayer;

import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.webkit.WebView;
import com.unity3d.ads.adplayer.DisplayMessage.DisplayError;
import com.unity3d.ads.adplayer.DisplayMessage.DisplayReady;
import com.unity3d.ads.core.domain.SendDiagnosticEvent.DefaultImpls;
import java.util.concurrent.CancellationException;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.TuplesKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function2;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.CoroutineScopeKt;
import kotlinx.coroutines.flow.MutableSharedFlow;

@Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H@"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {1, 8, 0}, xi = 48)
@DebugMetadata(c = "com.unity3d.ads.adplayer.FullScreenWebViewDisplay$loadWebView$1", f = "FullScreenWebViewDisplay.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
/* compiled from: FullScreenWebViewDisplay.kt */
final class FullScreenWebViewDisplay$loadWebView$1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
    final /* synthetic */ WebView $webView;
    int label;
    final /* synthetic */ FullScreenWebViewDisplay this$0;

    FullScreenWebViewDisplay$loadWebView$1(WebView webView, FullScreenWebViewDisplay fullScreenWebViewDisplay, Continuation<? super FullScreenWebViewDisplay$loadWebView$1> continuation) {
        this.$webView = webView;
        this.this$0 = fullScreenWebViewDisplay;
        super(2, continuation);
    }

    public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
        return new FullScreenWebViewDisplay$loadWebView$1(this.$webView, this.this$0, continuation);
    }

    public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
        return ((FullScreenWebViewDisplay$loadWebView$1) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
    }

    public final Object invokeSuspend(Object obj) {
        IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED();
        if (this.label == 0) {
            ResultKt.throwOnFailure(obj);
            try {
                ViewParent parent = this.$webView.getParent();
                ViewGroup viewGroup = parent instanceof ViewGroup ? (ViewGroup) parent : null;
                if (viewGroup != null) {
                    viewGroup.removeView(this.$webView);
                }
                this.this$0.setContentView((View) this.$webView);
                CoroutineScope CoroutineScope = CoroutineScopeKt.CoroutineScope(this.this$0.getDispatchers().getDefault());
                final FullScreenWebViewDisplay fullScreenWebViewDisplay = this.this$0;
                BuildersKt__Builders_commonKt.launch$default(CoroutineScope, null, null, new Function2<CoroutineScope, Continuation<? super Unit>, Object>(null) {
                    int label;

                    public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                        return /* anonymous class already generated */;
                    }

                    public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                        return ((AnonymousClass1) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
                    }

                    public final Object invokeSuspend(Object obj) {
                        Object coroutine_suspended = IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED();
                        int i = this.label;
                        if (i == 0) {
                            ResultKt.throwOnFailure(obj);
                            MutableSharedFlow displayMessages = AndroidFullscreenWebViewAdPlayer.Companion.getDisplayMessages();
                            DisplayReady displayReady = new DisplayReady(fullScreenWebViewDisplay.opportunityId, fullScreenWebViewDisplay.showOptions);
                            Continuation continuation = this;
                            this.label = 1;
                            if (displayMessages.emit(displayReady, continuation) == coroutine_suspended) {
                                return coroutine_suspended;
                            }
                        } else if (i == 1) {
                            ResultKt.throwOnFailure(obj);
                        } else {
                            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                        }
                        return Unit.INSTANCE;
                    }
                }, 3, null);
            } catch (Throwable th) {
                if (th instanceof CancellationException) {
                    return Unit.INSTANCE;
                }
                CoroutineScope CoroutineScope2 = CoroutineScopeKt.CoroutineScope(this.this$0.getDispatchers().getDefault());
                final FullScreenWebViewDisplay fullScreenWebViewDisplay2 = this.this$0;
                BuildersKt__Builders_commonKt.launch$default(CoroutineScope2, null, null, new Function2<CoroutineScope, Continuation<? super Unit>, Object>(null) {
                    int label;

                    public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                        return /* anonymous class already generated */;
                    }

                    public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                        return ((AnonymousClass2) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
                    }

                    public final Object invokeSuspend(Object obj) {
                        Object coroutine_suspended = IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED();
                        int i = this.label;
                        if (i == 0) {
                            ResultKt.throwOnFailure(obj);
                            MutableSharedFlow displayMessages = AndroidFullscreenWebViewAdPlayer.Companion.getDisplayMessages();
                            DisplayError displayError = new DisplayError(fullScreenWebViewDisplay2.opportunityId, "WebView failed to attach to FullScreenWebViewDisplay.");
                            Continuation continuation = this;
                            this.label = 1;
                            if (displayMessages.emit(displayError, continuation) == coroutine_suspended) {
                                return coroutine_suspended;
                            }
                        } else if (i == 1) {
                            ResultKt.throwOnFailure(obj);
                        } else {
                            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                        }
                        return Unit.INSTANCE;
                    }
                }, 3, null);
                obj = th.getMessage();
                if (obj == null) {
                    obj = "Unknown";
                }
                DefaultImpls.invoke$default(this.this$0.getSendDiagnosticEvent(), "native_show_ad_viewer_fullscreen_intent_failed_to_attach_webview", null, MapsKt__MapsJVMKt.mapOf(TuplesKt.to("reason", obj)), null, this.this$0.getAdObject(), null, 42, null);
                this.this$0.setResult(0);
                this.this$0.finish();
            }
            return Unit.INSTANCE;
        }
        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
    }
}
