package com.unity3d.ads.adplayer;

import com.unity3d.ads.core.domain.SendDiagnosticEvent;
import com.unity3d.services.core.di.IServiceComponent;
import kotlin.Metadata;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Lambda;
import kotlin.jvm.internal.Reflection;

@Metadata(d1 = {"\u0000\f\n\u0002\b\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\u0010\u0000\u001a\u0002H\u0001\"\n\b\u0000\u0010\u0001\u0018\u0001*\u00020\u0002H\n¢\u0006\u0004\b\u0003\u0010\u0004¨\u0006\u0005"}, d2 = {"<anonymous>", "T", "", "invoke", "()Ljava/lang/Object;", "com/unity3d/services/core/di/IServiceComponentKt$inject$1"}, k = 3, mv = {1, 8, 0}, xi = 48)
/* compiled from: IServiceComponent.kt */
public final class FullScreenWebViewDisplay$special$$inlined$inject$default$1 extends Lambda implements Function0<SendDiagnosticEvent> {
    final /* synthetic */ String $named;
    final /* synthetic */ IServiceComponent $this_inject;

    public FullScreenWebViewDisplay$special$$inlined$inject$default$1(IServiceComponent iServiceComponent, String str) {
        this.$this_inject = iServiceComponent;
        this.$named = str;
        super(0);
    }

    public final SendDiagnosticEvent invoke() {
        IServiceComponent iServiceComponent = this.$this_inject;
        return iServiceComponent.getServiceProvider().getRegistry().getService(this.$named, Reflection.getOrCreateKotlinClass(SendDiagnosticEvent.class));
    }
}
