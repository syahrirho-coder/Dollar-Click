package com.unity3d.ads.adplayer;

import com.unity3d.ads.core.data.model.ShowEvent;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlinx.coroutines.flow.Flow;
import kotlinx.coroutines.flow.FlowCollector;

@Metadata(d1 = {"\u0000\u0019\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004*\u0001\u0000\b\n\u0018\u00002\b\u0012\u0004\u0012\u00028\u00000\u0001J\u001f\u0010\u0002\u001a\u00020\u00032\f\u0010\u0004\u001a\b\u0012\u0004\u0012\u00028\u00000\u0005H@ø\u0001\u0000¢\u0006\u0002\u0010\u0006\u0002\u0004\n\u0002\b\u0019¨\u0006\u0007¸\u0006\t"}, d2 = {"kotlinx/coroutines/flow/internal/SafeCollector_commonKt$unsafeFlow$1", "Lkotlinx/coroutines/flow/Flow;", "collect", "", "collector", "Lkotlinx/coroutines/flow/FlowCollector;", "(Lkotlinx/coroutines/flow/FlowCollector;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "kotlinx-coroutines-core", "kotlinx/coroutines/flow/FlowKt__EmittersKt$unsafeTransform$$inlined$unsafeFlow$1", "kotlinx/coroutines/flow/FlowKt__TransformKt$map$$inlined$unsafeTransform$1"}, k = 1, mv = {1, 8, 0}, xi = 48)
/* compiled from: SafeCollector.common.kt */
public final class WebViewAdPlayer$special$$inlined$map$3 implements Flow<ShowEvent> {
    final /* synthetic */ Flow $this_unsafeTransform$inlined;

    public WebViewAdPlayer$special$$inlined$map$3(Flow flow) {
        this.$this_unsafeTransform$inlined = flow;
    }

    public Object collect(final FlowCollector flowCollector, Continuation continuation) {
        Object collect = this.$this_unsafeTransform$inlined.collect(new FlowCollector() {
            /* DevToolsApp WARNING: Removed duplicated region for block: B:14:0x0044  */
            /* DevToolsApp WARNING: Removed duplicated region for block: B:8:0x0026  */
            /* DevToolsApp WARNING: Removed duplicated region for block: B:52:0x011c A:{RETURN} */
            /* DevToolsApp WARNING: Missing block: B:46:0x0102, code:
            r0.L$0 = r2;
            r0.L$1 = r14;
            r0.label = 1;
     */
            /* DevToolsApp WARNING: Missing block: B:47:0x010c, code:
            if (com.unity3d.ads.adplayer.Invocation.handle$default(r13, null, r0, 1, null) != r1) goto L_0x010f;
     */
            /* DevToolsApp WARNING: Missing block: B:48:0x010e, code:
            return r1;
     */
            /* DevToolsApp WARNING: Missing block: B:49:0x010f, code:
            r13 = r14;
     */
            /* DevToolsApp WARNING: Missing block: B:56:0x0138, code:
            throw new java.lang.IllegalStateException("Unexpected location: " + r13.getLocation());
     */
            public final java.lang.Object emit(java.lang.Object r13, kotlin.coroutines.Continuation r14) {
                /*
                r12 = this;
                r0 = r14 instanceof com.unity3d.ads.adplayer.WebViewAdPlayer$special$$inlined$map$3.2.AnonymousClass1;
                if (r0 == 0) goto L_0x0014;
            L_0x0004:
                r0 = r14;
                r0 = (com.unity3d.ads.adplayer.WebViewAdPlayer$special$$inlined$map$3.2.AnonymousClass1) r0;
                r1 = r0.label;
                r2 = -2147483648; // 0xffffffff80000000 float:-0.0 double:NaN;
                r1 = r1 & r2;
                if (r1 == 0) goto L_0x0014;
            L_0x000e:
                r14 = r0.label;
                r14 = r14 - r2;
                r0.label = r14;
                goto L_0x0019;
            L_0x0014:
                r0 = new com.unity3d.ads.adplayer.WebViewAdPlayer$special$$inlined$map$3$2$1;
                r0.<init>(r12, r14);
            L_0x0019:
                r14 = r0.result;
                r1 = kotlin.coroutines.intrinsics.IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED();
                r2 = r0.label;
                r3 = 2;
                r4 = 1;
                r5 = 0;
                if (r2 == 0) goto L_0x0044;
            L_0x0026:
                if (r2 == r4) goto L_0x0037;
            L_0x0028:
                if (r2 != r3) goto L_0x002f;
            L_0x002a:
                kotlin.ResultKt.throwOnFailure(r14);
                goto L_0x011d;
            L_0x002f:
                r13 = new java.lang.IllegalStateException;
                r14 = "call to 'resume' before 'invoke' with coroutine";
                r13.<init>(r14);
                throw r13;
            L_0x0037:
                r13 = r0.L$1;
                r13 = (com.unity3d.ads.core.data.model.ShowEvent) r13;
                r2 = r0.L$0;
                r2 = (kotlinx.coroutines.flow.FlowCollector) r2;
                kotlin.ResultKt.throwOnFailure(r14);
                goto L_0x0110;
            L_0x0044:
                kotlin.ResultKt.throwOnFailure(r14);
                r2 = r3;
                r14 = r0;
                r14 = (kotlin.coroutines.Continuation) r14;
                r13 = (com.unity3d.ads.adplayer.Invocation) r13;
                r14 = r13.getLocation();
                r6 = r14.hashCode();
                switch(r6) {
                    case -1250843874: goto L_0x00f6;
                    case -928612193: goto L_0x00b7;
                    case -707523043: goto L_0x00aa;
                    case -497639557: goto L_0x009d;
                    case 1039618005: goto L_0x008f;
                    case 1306610281: goto L_0x005b;
                    default: goto L_0x0059;
                };
            L_0x0059:
                goto L_0x0120;
            L_0x005b:
                r6 = "com.unity3d.services.ads.api.AdViewer.failed";
                r14 = r14.equals(r6);
                if (r14 == 0) goto L_0x0120;
            L_0x0063:
                r14 = r13.getParameters();
                r14 = kotlin.collections.ArraysKt___ArraysKt.first(r14);
                r6 = "null cannot be cast to non-null type org.json.JSONObject";
                kotlin.jvm.internal.Intrinsics.checkNotNull(r14, r6);
                r14 = (org.json.JSONObject) r14;
                r6 = "code";
                r6 = r14.optInt(r6);
                r7 = "message";
                r14 = r14.optString(r7);
                r7 = new com.unity3d.ads.core.data.model.ShowEvent$Error;
                r8 = "errorMessage";
                kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r14, r8);
                r8 = "adviewer";
                r7.<init>(r14, r6, r8);
                r7 = (com.unity3d.ads.core.data.model.ShowEvent) r7;
                r14 = r7;
                goto L_0x0102;
            L_0x008f:
                r6 = "com.unity3d.services.ads.api.AdViewer.started";
                r14 = r14.equals(r6);
                if (r14 == 0) goto L_0x0120;
            L_0x0097:
                r14 = com.unity3d.ads.core.data.model.ShowEvent.Started.INSTANCE;
                r14 = (com.unity3d.ads.core.data.model.ShowEvent) r14;
                goto L_0x0102;
            L_0x009d:
                r6 = "com.unity3d.services.ads.api.AdViewer.clicked";
                r14 = r14.equals(r6);
                if (r14 == 0) goto L_0x0120;
            L_0x00a5:
                r14 = com.unity3d.ads.core.data.model.ShowEvent.Clicked.INSTANCE;
                r14 = (com.unity3d.ads.core.data.model.ShowEvent) r14;
                goto L_0x0102;
            L_0x00aa:
                r6 = "com.unity3d.services.ads.api.AdViewer.leftApplication";
                r14 = r14.equals(r6);
                if (r14 == 0) goto L_0x0120;
            L_0x00b2:
                r14 = com.unity3d.ads.core.data.model.ShowEvent.LeftApplication.INSTANCE;
                r14 = (com.unity3d.ads.core.data.model.ShowEvent) r14;
                goto L_0x0102;
            L_0x00b7:
                r6 = "com.unity3d.services.ads.api.AdViewer.completed";
                r14 = r14.equals(r6);
                if (r14 == 0) goto L_0x0120;
            L_0x00bf:
                r14 = new com.unity3d.ads.core.data.model.ShowEvent$Completed;
                r6 = r13.getParameters();
                r6 = kotlin.collections.ArraysKt___ArraysKt.first(r6);
                r7 = r6 instanceof java.lang.String;
                if (r7 == 0) goto L_0x00d0;
            L_0x00cd:
                r6 = (java.lang.String) r6;
                goto L_0x00d1;
            L_0x00d0:
                r6 = r5;
            L_0x00d1:
                r7 = "COMPLETED";
                r7 = kotlin.jvm.internal.Intrinsics.areEqual(r6, r7);
                if (r7 == 0) goto L_0x00dd;
            L_0x00d9:
                r6 = com.unity3d.ads.adplayer.model.ShowStatus.COMPLETED;
            L_0x00db:
                r7 = r6;
                goto L_0x00eb;
            L_0x00dd:
                r7 = "SKIPPED";
                r6 = kotlin.jvm.internal.Intrinsics.areEqual(r6, r7);
                if (r6 == 0) goto L_0x00e8;
            L_0x00e5:
                r6 = com.unity3d.ads.adplayer.model.ShowStatus.SKIPPED;
                goto L_0x00db;
            L_0x00e8:
                r6 = com.unity3d.ads.adplayer.model.ShowStatus.ERROR;
                goto L_0x00db;
            L_0x00eb:
                r10 = 6;
                r11 = 0;
                r8 = 0;
                r9 = 0;
                r6 = r14;
                r6.<init>(r7, r8, r9, r10, r11);
                r14 = (com.unity3d.ads.core.data.model.ShowEvent) r14;
                goto L_0x0102;
            L_0x00f6:
                r6 = "com.unity3d.services.ads.api.AdViewer.cancelShowTimeout";
                r14 = r14.equals(r6);
                if (r14 == 0) goto L_0x0120;
            L_0x00fe:
                r14 = com.unity3d.ads.core.data.model.ShowEvent.CancelTimeout.INSTANCE;
                r14 = (com.unity3d.ads.core.data.model.ShowEvent) r14;
            L_0x0102:
                r0.L$0 = r2;
                r0.L$1 = r14;
                r0.label = r4;
                r13 = com.unity3d.ads.adplayer.Invocation.handle$default(r13, r5, r0, r4, r5);
                if (r13 != r1) goto L_0x010f;
            L_0x010e:
                return r1;
            L_0x010f:
                r13 = r14;
            L_0x0110:
                r0.L$0 = r5;
                r0.L$1 = r5;
                r0.label = r3;
                r13 = r2.emit(r13, r0);
                if (r13 != r1) goto L_0x011d;
            L_0x011c:
                return r1;
            L_0x011d:
                r13 = kotlin.Unit.INSTANCE;
                return r13;
            L_0x0120:
                r14 = new java.lang.IllegalStateException;
                r0 = new java.lang.StringBuilder;
                r1 = "Unexpected location: ";
                r0.<init>(r1);
                r13 = r13.getLocation();
                r13 = r0.append(r13);
                r13 = r13.toString();
                r14.<init>(r13);
                throw r14;
                */
                throw new UnsupportedOperationException("Method not decompiled: com.unity3d.ads.adplayer.WebViewAdPlayer$special$.inlined.map.3.2.emit(java.lang.Object, kotlin.coroutines.Continuation):java.lang.Object");
            }
        }, continuation);
        if (collect == IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED()) {
            return collect;
        }
        return Unit.INSTANCE;
    }
}
