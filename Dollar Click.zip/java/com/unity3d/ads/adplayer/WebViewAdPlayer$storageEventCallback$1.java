package com.unity3d.ads.adplayer;

import com.unity3d.ads.adplayer.model.OnStorageEvent;
import com.unity3d.ads.adplayer.model.WebViewEvent;
import com.unity3d.services.core.device.StorageEventInfo;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Lambda;
import kotlinx.coroutines.CoroutineScope;

@Metadata(d1 = {"\u0000\u000e\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u0003H\n¢\u0006\u0002\b\u0004"}, d2 = {"<anonymous>", "", "it", "Lcom/unity3d/services/core/device/StorageEventInfo;", "invoke"}, k = 3, mv = {1, 8, 0}, xi = 48)
/* compiled from: WebViewAdPlayer.kt */
final class WebViewAdPlayer$storageEventCallback$1 extends Lambda implements Function1<StorageEventInfo, Unit> {
    final /* synthetic */ WebViewAdPlayer this$0;

    WebViewAdPlayer$storageEventCallback$1(WebViewAdPlayer webViewAdPlayer) {
        this.this$0 = webViewAdPlayer;
        super(1);
    }

    public final void invoke(final StorageEventInfo storageEventInfo) {
        Intrinsics.checkNotNullParameter(storageEventInfo, "it");
        CoroutineScope scope = this.this$0.getScope();
        final WebViewAdPlayer webViewAdPlayer = this.this$0;
        BuildersKt__Builders_commonKt.launch$default(scope, null, null, new Function2<CoroutineScope, Continuation<? super Unit>, Object>(null) {
            int label;

            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return /* anonymous class already generated */;
            }

            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return ((AnonymousClass1) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
            }

            public final Object invokeSuspend(Object obj) {
                Object coroutine_suspended = IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED();
                int i = this.label;
                if (i == 0) {
                    ResultKt.throwOnFailure(obj);
                    WebViewBridge access$getBridge$p = webViewAdPlayer.bridge;
                    WebViewEvent onStorageEvent = new OnStorageEvent(storageEventInfo.getEventType(), storageEventInfo.getStorageType(), storageEventInfo.getValue());
                    Continuation continuation = this;
                    this.label = 1;
                    if (access$getBridge$p.sendEvent(onStorageEvent, continuation) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                } else if (i == 1) {
                    ResultKt.throwOnFailure(obj);
                } else {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }, 3, null);
    }
}
