package com.unity3d.ads.adplayer;

import com.unity3d.ads.adplayer.AdPlayer.DefaultImpls;
import com.unity3d.ads.adplayer.model.LoadEvent;
import com.unity3d.ads.core.data.model.OfferwallShowEvent.Show;
import com.unity3d.ads.core.data.model.ScarEvent;
import com.unity3d.ads.core.data.model.ShowEvent;
import com.unity3d.ads.core.data.repository.DeviceInfoRepository;
import com.unity3d.ads.core.data.repository.SessionRepository;
import com.unity3d.ads.core.domain.SendDiagnosticEvent;
import com.unity3d.scar.adapter.common.GMAEvent;
import com.unity3d.services.ads.offerwall.OfferwallEvent;
import com.unity3d.services.banners.bridge.BannerBridge.BannerEvent;
import com.unity3d.services.core.device.Storage;
import com.unity3d.services.core.device.StorageEventInfo;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.FunctionReferenceImpl;
import kotlin.jvm.internal.Intrinsics;
import kotlinx.coroutines.CoroutineDispatcher;
import kotlinx.coroutines.CoroutineExceptionHandler;
import kotlinx.coroutines.CoroutineName;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.CoroutineScopeKt;
import kotlinx.coroutines.flow.Flow;
import kotlinx.coroutines.flow.FlowKt;
import kotlinx.coroutines.flow.MutableSharedFlow;
import kotlinx.coroutines.flow.MutableStateFlow;
import kotlinx.coroutines.flow.SharingStarted;
import kotlinx.coroutines.flow.StateFlowKt;

@Metadata(d1 = {"\u0000À\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\u0005\n\u0002\u0010\u0012\n\u0002\b\u0006\n\u0002\u0010$\n\u0002\u0010\u0000\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0010\u0006\n\u0002\b\u0002\b\u0000\u0018\u00002\u00020\u0001B=\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\u0006\u0010\b\u001a\u00020\t\u0012\u0006\u0010\n\u001a\u00020\u000b\u0012\u0006\u0010\f\u001a\u00020\r\u0012\u0006\u0010\u000e\u001a\u00020\u000f¢\u0006\u0002\u0010\u0010J\b\u0010/\u001a\u00020,H\u0016J\u0019\u00100\u001a\u00020,2\u0006\u00101\u001a\u000202H@ø\u0001\u0000¢\u0006\u0002\u00103J\u0019\u00104\u001a\u00020,2\u0006\u00105\u001a\u00020\u0016H@ø\u0001\u0000¢\u0006\u0002\u00106J)\u00107\u001a\u00020,2\u0016\u00108\u001a\u0012\u0012\u0004\u0012\u00020\u0016\u0012\u0006\u0012\u0004\u0018\u00010:\u0018\u000109H@ø\u0001\u0000¢\u0006\u0002\u0010;J\u0011\u0010<\u001a\u00020,H@ø\u0001\u0000¢\u0006\u0002\u0010=J\u001f\u0010>\u001a\u00020,2\f\u0010?\u001a\b\u0012\u0004\u0012\u00020A0@H@ø\u0001\u0000¢\u0006\u0002\u0010BJ\u0019\u0010C\u001a\u00020,2\u0006\u0010D\u001a\u00020\u0013H@ø\u0001\u0000¢\u0006\u0002\u0010EJ\u0019\u0010F\u001a\u00020,2\u0006\u00105\u001a\u00020GH@ø\u0001\u0000¢\u0006\u0002\u0010HJ\u0019\u0010I\u001a\u00020,2\u0006\u0010J\u001a\u00020\u0013H@ø\u0001\u0000¢\u0006\u0002\u0010EJ\u0019\u0010K\u001a\u00020,2\u0006\u00105\u001a\u00020LH@ø\u0001\u0000¢\u0006\u0002\u0010MJ\u0019\u0010N\u001a\u00020,2\u0006\u00101\u001a\u000202H@ø\u0001\u0000¢\u0006\u0002\u00103J\u0019\u0010O\u001a\u00020,2\u0006\u00105\u001a\u00020PH@ø\u0001\u0000¢\u0006\u0002\u0010QJ\u0019\u0010R\u001a\u00020,2\u0006\u00101\u001a\u000202H@ø\u0001\u0000¢\u0006\u0002\u00103J\u0019\u0010S\u001a\u00020,2\u0006\u0010T\u001a\u00020\u0013H@ø\u0001\u0000¢\u0006\u0002\u0010EJ\u0019\u0010U\u001a\u00020,2\u0006\u0010V\u001a\u00020WH@ø\u0001\u0000¢\u0006\u0002\u0010XR\u000e\u0010\u0002\u001a\u00020\u0003X\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0004\u001a\u00020\u0005X\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\tX\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\u0011\u001a\b\u0012\u0004\u0012\u00020\u00130\u0012X\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\u0014\u001a\b\u0012\u0004\u0012\u00020\u00160\u0015X\u0004¢\u0006\u0002\n\u0000R\u001a\u0010\u0017\u001a\b\u0012\u0004\u0012\u00020\u00180\u0015X\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0019\u0010\u001aR\u001a\u0010\u001b\u001a\b\u0012\u0004\u0012\u00020\u001c0\u0015X\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u001d\u0010\u001aR\u001a\u0010\u001e\u001a\b\u0012\u0004\u0012\u00020\u001f0\u0015X\u0004¢\u0006\b\n\u0000\u001a\u0004\b \u0010\u001aR\u001a\u0010!\u001a\b\u0012\u0004\u0012\u00020\"0\u0015X\u0004¢\u0006\b\n\u0000\u001a\u0004\b#\u0010\u001aR\u0014\u0010$\u001a\u00020\u000fX\u0004¢\u0006\b\n\u0000\u001a\u0004\b%\u0010&R\u000e\u0010'\u001a\u00020(X\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u000bX\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0007X\u0004¢\u0006\u0002\n\u0000R\u001a\u0010)\u001a\u000e\u0012\u0004\u0012\u00020+\u0012\u0004\u0012\u00020,0*X\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\f\u001a\u00020\rX\u0004¢\u0006\b\n\u0000\u001a\u0004\b-\u0010.\u0002\u0004\n\u0002\b\u0019¨\u0006Y"}, d2 = {"Lcom/unity3d/ads/adplayer/WebViewAdPlayer;", "Lcom/unity3d/ads/adplayer/AdPlayer;", "bridge", "Lcom/unity3d/ads/adplayer/WebViewBridge;", "deviceInfoRepository", "Lcom/unity3d/ads/core/data/repository/DeviceInfoRepository;", "sessionRepository", "Lcom/unity3d/ads/core/data/repository/SessionRepository;", "dispatcher", "Lkotlinx/coroutines/CoroutineDispatcher;", "sendDiagnosticEvent", "Lcom/unity3d/ads/core/domain/SendDiagnosticEvent;", "webViewContainer", "Lcom/unity3d/ads/adplayer/WebViewContainer;", "adPlayerScope", "Lkotlinx/coroutines/CoroutineScope;", "(Lcom/unity3d/ads/adplayer/WebViewBridge;Lcom/unity3d/ads/core/data/repository/DeviceInfoRepository;Lcom/unity3d/ads/core/data/repository/SessionRepository;Lkotlinx/coroutines/CoroutineDispatcher;Lcom/unity3d/ads/core/domain/SendDiagnosticEvent;Lcom/unity3d/ads/adplayer/WebViewContainer;Lkotlinx/coroutines/CoroutineScope;)V", "isCompletedManually", "Lkotlinx/coroutines/flow/MutableStateFlow;", "", "onBroadcastEvents", "Lkotlinx/coroutines/flow/Flow;", "", "onLoadEvent", "Lcom/unity3d/ads/adplayer/model/LoadEvent;", "getOnLoadEvent", "()Lkotlinx/coroutines/flow/Flow;", "onOfferwallEvent", "Lcom/unity3d/ads/core/data/model/OfferwallShowEvent$Show;", "getOnOfferwallEvent", "onScarEvent", "Lcom/unity3d/ads/core/data/model/ScarEvent$Show;", "getOnScarEvent", "onShowEvent", "Lcom/unity3d/ads/core/data/model/ShowEvent;", "getOnShowEvent", "scope", "getScope", "()Lkotlinx/coroutines/CoroutineScope;", "scopeCancellationHandler", "Lkotlinx/coroutines/CoroutineExceptionHandler;", "storageEventCallback", "Lkotlin/Function1;", "Lcom/unity3d/services/core/device/StorageEventInfo;", "", "getWebViewContainer", "()Lcom/unity3d/ads/adplayer/WebViewContainer;", "dispatchShowCompleted", "onAllowedPiiChange", "value", "", "([BLkotlin/coroutines/Continuation;)Ljava/lang/Object;", "onBroadcastEvent", "event", "(Ljava/lang/String;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "requestShow", "unityAdsShowOptions", "", "", "(Ljava/util/Map;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "sendActivityDestroyed", "(Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "sendEvent", "getEvent", "Lkotlin/Function0;", "Lcom/unity3d/ads/adplayer/model/WebViewEvent;", "(Lkotlin/jvm/functions/Function0;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "sendFocusChange", "isFocused", "(ZLkotlin/coroutines/Continuation;)Ljava/lang/Object;", "sendGmaEvent", "Lcom/unity3d/scar/adapter/common/GMAEvent;", "(Lcom/unity3d/scar/adapter/common/GMAEvent;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "sendMuteChange", "isMuted", "sendOfferwallEvent", "Lcom/unity3d/services/ads/offerwall/OfferwallEvent;", "(Lcom/unity3d/services/ads/offerwall/OfferwallEvent;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "sendPrivacyFsmChange", "sendScarBannerEvent", "Lcom/unity3d/services/banners/bridge/BannerBridge$BannerEvent;", "(Lcom/unity3d/services/banners/bridge/BannerBridge$BannerEvent;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "sendUserConsentChange", "sendVisibilityChange", "isVisible", "sendVolumeChange", "volume", "", "(DLkotlin/coroutines/Continuation;)Ljava/lang/Object;", "unity-ads_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
/* compiled from: WebViewAdPlayer.kt */
public final class WebViewAdPlayer implements AdPlayer {
    private final WebViewBridge bridge;
    private final DeviceInfoRepository deviceInfoRepository;
    private final CoroutineDispatcher dispatcher;
    private final MutableStateFlow<Boolean> isCompletedManually;
    private final Flow<String> onBroadcastEvents;
    private final Flow<LoadEvent> onLoadEvent;
    private final Flow<Show> onOfferwallEvent;
    private final Flow<ScarEvent.Show> onScarEvent;
    private final Flow<ShowEvent> onShowEvent;
    private final CoroutineScope scope;
    private final CoroutineExceptionHandler scopeCancellationHandler;
    private final SendDiagnosticEvent sendDiagnosticEvent;
    private final SessionRepository sessionRepository;
    private final Function1<StorageEventInfo, Unit> storageEventCallback;
    private final WebViewContainer webViewContainer;

    public WebViewAdPlayer(WebViewBridge webViewBridge, DeviceInfoRepository deviceInfoRepository, SessionRepository sessionRepository, CoroutineDispatcher coroutineDispatcher, SendDiagnosticEvent sendDiagnosticEvent, WebViewContainer webViewContainer, CoroutineScope coroutineScope) {
        Intrinsics.checkNotNullParameter(webViewBridge, "bridge");
        Intrinsics.checkNotNullParameter(deviceInfoRepository, "deviceInfoRepository");
        Intrinsics.checkNotNullParameter(sessionRepository, "sessionRepository");
        Intrinsics.checkNotNullParameter(coroutineDispatcher, "dispatcher");
        Intrinsics.checkNotNullParameter(sendDiagnosticEvent, "sendDiagnosticEvent");
        Intrinsics.checkNotNullParameter(webViewContainer, "webViewContainer");
        Intrinsics.checkNotNullParameter(coroutineScope, "adPlayerScope");
        this.bridge = webViewBridge;
        this.deviceInfoRepository = deviceInfoRepository;
        this.sessionRepository = sessionRepository;
        this.dispatcher = coroutineDispatcher;
        this.sendDiagnosticEvent = sendDiagnosticEvent;
        this.webViewContainer = webViewContainer;
        MutableStateFlow MutableStateFlow = StateFlowKt.MutableStateFlow(Boolean.valueOf(false));
        this.isCompletedManually = MutableStateFlow;
        Function1 webViewAdPlayer$storageEventCallback$1 = new WebViewAdPlayer$storageEventCallback$1(this);
        this.storageEventCallback = webViewAdPlayer$storageEventCallback$1;
        CoroutineExceptionHandler webViewAdPlayer$special$$inlined$CoroutineExceptionHandler$1 = new WebViewAdPlayer$special$$inlined$CoroutineExceptionHandler$1(CoroutineExceptionHandler.Key, this);
        this.scopeCancellationHandler = webViewAdPlayer$special$$inlined$CoroutineExceptionHandler$1;
        this.scope = CoroutineScopeKt.plus(CoroutineScopeKt.plus(CoroutineScopeKt.plus(coroutineScope, coroutineDispatcher), new CoroutineName("WebViewAdPlayer")), webViewAdPlayer$special$$inlined$CoroutineExceptionHandler$1);
        this.onScarEvent = new WebViewAdPlayer$special$$inlined$map$1(new WebViewAdPlayer$special$$inlined$filter$1(webViewBridge.getOnInvocation()));
        this.onOfferwallEvent = new WebViewAdPlayer$special$$inlined$map$2(new WebViewAdPlayer$special$$inlined$filter$2(webViewBridge.getOnInvocation()));
        this.onShowEvent = FlowKt.flowCombine(new WebViewAdPlayer$special$$inlined$map$3(new WebViewAdPlayer$special$$inlined$filter$3(webViewBridge.getOnInvocation())), MutableStateFlow, new WebViewAdPlayer$onShowEvent$3(null));
        this.onLoadEvent = FlowKt.take(FlowKt.shareIn(new WebViewAdPlayer$special$$inlined$map$4(new WebViewAdPlayer$special$$inlined$filter$4(webViewBridge.getOnInvocation())), getScope(), SharingStarted.Companion.getEagerly(), 1), 1);
        Flow webViewAdPlayer$special$$inlined$map$5 = new WebViewAdPlayer$special$$inlined$map$5(new WebViewAdPlayer$special$$inlined$filter$5(webViewBridge.getOnInvocation()));
        this.onBroadcastEvents = webViewAdPlayer$special$$inlined$map$5;
        Storage.Companion.addStorageEventCallback(webViewAdPlayer$storageEventCallback$1);
        FlowKt.launchIn(FlowKt.onEach(webViewAdPlayer$special$$inlined$map$5, new FunctionReferenceImpl(AdPlayer.Companion.getBroadcastEventChannel()) {
            public final Object invoke(String str, Continuation<? super Unit> continuation) {
                return ((MutableSharedFlow) this.receiver).emit(str, continuation);
            }
        }), getScope());
        FlowKt.launchIn(FlowKt.onEach(AdPlayer.Companion.getBroadcastEventChannel(), new FunctionReferenceImpl(this) {
            public final Object invoke(String str, Continuation<? super Unit> continuation) {
                return ((WebViewAdPlayer) this.receiver).onBroadcastEvent(str, continuation);
            }
        }), getScope());
    }

    public Object destroy(Continuation<? super Unit> continuation) {
        return DefaultImpls.destroy(this, continuation);
    }

    public void show(ShowOptions showOptions) {
        DefaultImpls.show(this, showOptions);
    }

    public WebViewContainer getWebViewContainer() {
        return this.webViewContainer;
    }

    public CoroutineScope getScope() {
        return this.scope;
    }

    public Flow<ScarEvent.Show> getOnScarEvent() {
        return this.onScarEvent;
    }

    public Flow<Show> getOnOfferwallEvent() {
        return this.onOfferwallEvent;
    }

    public Flow<ShowEvent> getOnShowEvent() {
        return this.onShowEvent;
    }

    public Flow<LoadEvent> getOnLoadEvent() {
        return this.onLoadEvent;
    }

    /* DevToolsApp WARNING: Removed duplicated region for block: B:30:0x0127  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:41:0x0188 A:{RETURN} */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:16:0x0077  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:8:0x0028  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:27:0x00f7  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:26:0x00f6 A:{RETURN} */
    public java.lang.Object requestShow(java.util.Map<java.lang.String, ? extends java.lang.Object> r14, kotlin.coroutines.Continuation<? super kotlin.Unit> r15) {
        /*
        r13 = this;
        r0 = r15 instanceof com.unity3d.ads.adplayer.WebViewAdPlayer$requestShow$1;
        if (r0 == 0) goto L_0x0014;
    L_0x0004:
        r0 = r15;
        r0 = (com.unity3d.ads.adplayer.WebViewAdPlayer$requestShow$1) r0;
        r1 = r0.label;
        r2 = -2147483648; // 0xffffffff80000000 float:-0.0 double:NaN;
        r1 = r1 & r2;
        if (r1 == 0) goto L_0x0014;
    L_0x000e:
        r15 = r0.label;
        r15 = r15 - r2;
        r0.label = r15;
        goto L_0x0019;
    L_0x0014:
        r0 = new com.unity3d.ads.adplayer.WebViewAdPlayer$requestShow$1;
        r0.<init>(r13, r15);
    L_0x0019:
        r15 = r0.result;
        r1 = kotlin.coroutines.intrinsics.IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED();
        r2 = r0.label;
        r3 = 3;
        r4 = 2;
        r5 = 0;
        r6 = 1;
        r7 = 0;
        if (r2 == 0) goto L_0x0077;
    L_0x0028:
        if (r2 == r6) goto L_0x0058;
    L_0x002a:
        if (r2 == r4) goto L_0x003b;
    L_0x002c:
        if (r2 != r3) goto L_0x0033;
    L_0x002e:
        kotlin.ResultKt.throwOnFailure(r15);
        goto L_0x0189;
    L_0x0033:
        r14 = new java.lang.IllegalStateException;
        r15 = "call to 'resume' before 'invoke' with coroutine";
        r14.<init>(r15);
        throw r14;
    L_0x003b:
        r14 = r0.L$5;
        r14 = (org.json.JSONObject) r14;
        r2 = r0.L$4;
        r2 = (java.lang.String) r2;
        r4 = r0.L$3;
        r4 = (org.json.JSONObject) r4;
        r8 = r0.L$2;
        r8 = (org.json.JSONObject) r8;
        r9 = r0.L$1;
        r9 = (java.util.Map) r9;
        r10 = r0.L$0;
        r10 = (com.unity3d.ads.adplayer.WebViewAdPlayer) r10;
        kotlin.ResultKt.throwOnFailure(r15);
        goto L_0x00fe;
    L_0x0058:
        r14 = r0.L$5;
        r14 = (org.json.JSONObject) r14;
        r2 = r0.L$4;
        r2 = (java.lang.String) r2;
        r8 = r0.L$3;
        r8 = (org.json.JSONObject) r8;
        r9 = r0.L$2;
        r9 = (org.json.JSONObject) r9;
        r10 = r0.L$1;
        r10 = (java.util.Map) r10;
        r11 = r0.L$0;
        r11 = (com.unity3d.ads.adplayer.WebViewAdPlayer) r11;
        kotlin.ResultKt.throwOnFailure(r15);
        r12 = r8;
        r8 = r2;
        r2 = r12;
        goto L_0x00d5;
    L_0x0077:
        kotlin.ResultKt.throwOnFailure(r15);
        r15 = r13.deviceInfoRepository;
        r15 = r15.getDynamicDeviceInfo();
        r2 = new org.json.JSONObject;
        r2.<init>();
        r8 = r13.deviceInfoRepository;
        r8 = r8.getOrientation();
        r9 = "orientation";
        r2.put(r9, r8);
        r8 = r13.deviceInfoRepository;
        r8 = r8.getConnectionTypeStr();
        r9 = "connectionType";
        r2.put(r9, r8);
        r8 = r13.deviceInfoRepository;
        r8 = r8.getRingerMode();
        if (r8 == r4) goto L_0x00a5;
    L_0x00a3:
        r8 = r6;
        goto L_0x00a6;
    L_0x00a5:
        r8 = r5;
    L_0x00a6:
        r9 = "isMuted";
        r2.put(r9, r8);
        r15 = r15.getAndroid();
        r8 = r15.getVolume();
        r15 = "volume";
        r2.put(r15, r8);
        r15 = r13.sessionRepository;
        r0.L$0 = r13;
        r0.L$1 = r14;
        r0.L$2 = r2;
        r0.L$3 = r2;
        r8 = "privacy";
        r0.L$4 = r8;
        r0.L$5 = r2;
        r0.label = r6;
        r15 = r15.getPrivacy(r0);
        if (r15 != r1) goto L_0x00d1;
    L_0x00d0:
        return r1;
    L_0x00d1:
        r11 = r13;
        r10 = r14;
        r14 = r2;
        r9 = r14;
    L_0x00d5:
        r15 = (com.google.protobuf.ByteString) r15;
        r15 = com.unity3d.ads.core.extensions.ProtobufExtensionsKt.toBase64$default(r15, r5, r6, r7);
        r14.put(r8, r15);
        r14 = r11.sessionRepository;
        r0.L$0 = r11;
        r0.L$1 = r10;
        r0.L$2 = r9;
        r0.L$3 = r2;
        r15 = "privacyFsm";
        r0.L$4 = r15;
        r0.L$5 = r2;
        r0.label = r4;
        r14 = r14.getPrivacyFsm(r0);
        if (r14 != r1) goto L_0x00f7;
    L_0x00f6:
        return r1;
    L_0x00f7:
        r4 = r2;
        r8 = r9;
        r9 = r10;
        r10 = r11;
        r2 = r15;
        r15 = r14;
        r14 = r4;
    L_0x00fe:
        r15 = (com.google.protobuf.ByteString) r15;
        r15 = com.unity3d.ads.core.extensions.ProtobufExtensionsKt.toBase64$default(r15, r5, r6, r7);
        r14.put(r2, r15);
        r14 = r10.deviceInfoRepository;
        r14 = r14.getAllowedPii();
        r14 = r14.getValue();
        r14 = (gatewayprotocol.v1.AllowedPiiOuterClass.AllowedPii) r14;
        r14 = r14.toByteString();
        r15 = "deviceInfoRepository.all…dPii.value.toByteString()";
        kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r14, r15);
        r14 = com.unity3d.ads.core.extensions.ProtobufExtensionsKt.toBase64$default(r14, r5, r6, r7);
        r15 = "allowedPii";
        r4.put(r15, r14);
        if (r9 == 0) goto L_0x016a;
    L_0x0127:
        r14 = new java.util.LinkedHashMap;
        r14.<init>();
        r14 = (java.util.Map) r14;
        r15 = r9.entrySet();
        r15 = r15.iterator();
    L_0x0136:
        r2 = r15.hasNext();
        if (r2 == 0) goto L_0x015a;
    L_0x013c:
        r2 = r15.next();
        r2 = (java.util.Map.Entry) r2;
        r5 = r2.getKey();
        r6 = "objectId";
        r5 = kotlin.jvm.internal.Intrinsics.areEqual(r5, r6);
        if (r5 != 0) goto L_0x0136;
    L_0x014e:
        r5 = r2.getKey();
        r2 = r2.getValue();
        r14.put(r5, r2);
        goto L_0x0136;
    L_0x015a:
        r15 = r14.isEmpty();
        if (r15 != 0) goto L_0x016a;
    L_0x0160:
        r15 = new org.json.JSONObject;
        r15.<init>(r14);
        r14 = "showOptions";
        r4.put(r14, r15);
    L_0x016a:
        r14 = r10.bridge;
        r15 = new java.lang.Object[]{r8};
        r0.L$0 = r7;
        r0.L$1 = r7;
        r0.L$2 = r7;
        r0.L$3 = r7;
        r0.L$4 = r7;
        r0.L$5 = r7;
        r0.label = r3;
        r2 = "webview";
        r3 = "show";
        r14 = r14.request(r2, r3, r15, r0);
        if (r14 != r1) goto L_0x0189;
    L_0x0188:
        return r1;
    L_0x0189:
        r14 = kotlin.Unit.INSTANCE;
        return r14;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.unity3d.ads.adplayer.WebViewAdPlayer.requestShow(java.util.Map, kotlin.coroutines.Continuation):java.lang.Object");
    }

    public void dispatchShowCompleted() {
        this.isCompletedManually.setValue(Boolean.valueOf(true));
    }

    /* DevToolsApp WARNING: Removed duplicated region for block: B:14:0x0046  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:8:0x0029  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:22:0x00a5  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:20:0x0063  */
    private final java.lang.Object sendEvent(kotlin.jvm.functions.Function0<? extends com.unity3d.ads.adplayer.model.WebViewEvent> r19, kotlin.coroutines.Continuation<? super kotlin.Unit> r20) {
        /*
        r18 = this;
        r0 = r18;
        r1 = r20;
        r2 = r1 instanceof com.unity3d.ads.adplayer.WebViewAdPlayer$sendEvent$1;
        if (r2 == 0) goto L_0x0018;
    L_0x0008:
        r2 = r1;
        r2 = (com.unity3d.ads.adplayer.WebViewAdPlayer$sendEvent$1) r2;
        r3 = r2.label;
        r4 = -2147483648; // 0xffffffff80000000 float:-0.0 double:NaN;
        r3 = r3 & r4;
        if (r3 == 0) goto L_0x0018;
    L_0x0012:
        r1 = r2.label;
        r1 = r1 - r4;
        r2.label = r1;
        goto L_0x001d;
    L_0x0018:
        r2 = new com.unity3d.ads.adplayer.WebViewAdPlayer$sendEvent$1;
        r2.<init>(r0, r1);
    L_0x001d:
        r1 = r2.result;
        r3 = kotlin.coroutines.intrinsics.IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED();
        r4 = r2.label;
        r5 = 2;
        r6 = 1;
        if (r4 == 0) goto L_0x0046;
    L_0x0029:
        if (r4 == r6) goto L_0x003a;
    L_0x002b:
        if (r4 != r5) goto L_0x0032;
    L_0x002d:
        kotlin.ResultKt.throwOnFailure(r1);
        goto L_0x00bb;
    L_0x0032:
        r1 = new java.lang.IllegalStateException;
        r2 = "call to 'resume' before 'invoke' with coroutine";
        r1.<init>(r2);
        throw r1;
    L_0x003a:
        r4 = r2.L$1;
        r4 = (kotlin.jvm.functions.Function0) r4;
        r7 = r2.L$0;
        r7 = (com.unity3d.ads.adplayer.WebViewAdPlayer) r7;
        kotlin.ResultKt.throwOnFailure(r1);
        goto L_0x005d;
    L_0x0046:
        kotlin.ResultKt.throwOnFailure(r1);
        r1 = r18.getOnLoadEvent();
        r2.L$0 = r0;
        r4 = r19;
        r2.L$1 = r4;
        r2.label = r6;
        r1 = kotlinx.coroutines.flow.FlowKt.single(r1, r2);
        if (r1 != r3) goto L_0x005c;
    L_0x005b:
        return r3;
    L_0x005c:
        r7 = r0;
    L_0x005d:
        r1 = (com.unity3d.ads.adplayer.model.LoadEvent) r1;
        r8 = r1 instanceof com.unity3d.ads.adplayer.model.LoadEvent.Error;
        if (r8 == 0) goto L_0x00a5;
    L_0x0063:
        r9 = r7.sendDiagnosticEvent;
        r2 = 3;
        r2 = new kotlin.Pair[r2];
        r3 = "reason";
        r4 = "adviewer";
        r3 = kotlin.TuplesKt.to(r3, r4);
        r4 = 0;
        r2[r4] = r3;
        r1 = (com.unity3d.ads.adplayer.model.LoadEvent.Error) r1;
        r3 = r1.getMessage();
        r4 = "reason_debug";
        r3 = kotlin.TuplesKt.to(r4, r3);
        r2[r6] = r3;
        r1 = r1.getErrorCode();
        r1 = java.lang.String.valueOf(r1);
        r3 = "reason_code";
        r1 = kotlin.TuplesKt.to(r3, r1);
        r2[r5] = r1;
        r12 = kotlin.collections.MapsKt__MapsKt.mapOf(r2);
        r16 = 58;
        r17 = 0;
        r10 = "bridge_send_event_failed";
        r11 = 0;
        r13 = 0;
        r14 = 0;
        r15 = 0;
        com.unity3d.ads.core.domain.SendDiagnosticEvent.DefaultImpls.invoke$default(r9, r10, r11, r12, r13, r14, r15, r16, r17);
        r1 = kotlin.Unit.INSTANCE;
        return r1;
    L_0x00a5:
        r1 = r4.invoke();
        r1 = (com.unity3d.ads.adplayer.model.WebViewEvent) r1;
        r4 = r7.bridge;
        r6 = 0;
        r2.L$0 = r6;
        r2.L$1 = r6;
        r2.label = r5;
        r1 = r4.sendEvent(r1, r2);
        if (r1 != r3) goto L_0x00bb;
    L_0x00ba:
        return r3;
    L_0x00bb:
        r1 = kotlin.Unit.INSTANCE;
        return r1;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.unity3d.ads.adplayer.WebViewAdPlayer.sendEvent(kotlin.jvm.functions.Function0, kotlin.coroutines.Continuation):java.lang.Object");
    }

    public Object sendScarBannerEvent(BannerEvent bannerEvent, Continuation<? super Unit> continuation) {
        Object sendEvent = sendEvent(new WebViewAdPlayer$sendScarBannerEvent$2(bannerEvent), continuation);
        return sendEvent == IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED() ? sendEvent : Unit.INSTANCE;
    }

    public Object sendGmaEvent(GMAEvent gMAEvent, Continuation<? super Unit> continuation) {
        Object sendEvent = sendEvent(new WebViewAdPlayer$sendGmaEvent$2(gMAEvent), continuation);
        return sendEvent == IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED() ? sendEvent : Unit.INSTANCE;
    }

    public Object sendOfferwallEvent(OfferwallEvent offerwallEvent, Continuation<? super Unit> continuation) {
        Object sendEvent = sendEvent(new WebViewAdPlayer$sendOfferwallEvent$2(offerwallEvent), continuation);
        return sendEvent == IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED() ? sendEvent : Unit.INSTANCE;
    }

    public Object sendMuteChange(boolean z, Continuation<? super Unit> continuation) {
        Object sendEvent = sendEvent(new WebViewAdPlayer$sendMuteChange$2(z), continuation);
        return sendEvent == IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED() ? sendEvent : Unit.INSTANCE;
    }

    public Object sendVisibilityChange(boolean z, Continuation<? super Unit> continuation) {
        Object sendEvent = sendEvent(new WebViewAdPlayer$sendVisibilityChange$2(z), continuation);
        return sendEvent == IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED() ? sendEvent : Unit.INSTANCE;
    }

    public Object sendFocusChange(boolean z, Continuation<? super Unit> continuation) {
        Object sendEvent = sendEvent(new WebViewAdPlayer$sendFocusChange$2(z), continuation);
        return sendEvent == IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED() ? sendEvent : Unit.INSTANCE;
    }

    public Object sendActivityDestroyed(Continuation<? super Unit> continuation) {
        Object sendEvent = sendEvent(WebViewAdPlayer$sendActivityDestroyed$2.INSTANCE, continuation);
        return sendEvent == IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED() ? sendEvent : Unit.INSTANCE;
    }

    public Object sendVolumeChange(double d, Continuation<? super Unit> continuation) {
        Object sendEvent = sendEvent(new WebViewAdPlayer$sendVolumeChange$2(d), continuation);
        return sendEvent == IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED() ? sendEvent : Unit.INSTANCE;
    }

    public Object sendUserConsentChange(byte[] bArr, Continuation<? super Unit> continuation) {
        Object sendEvent = sendEvent(new WebViewAdPlayer$sendUserConsentChange$2(bArr), continuation);
        return sendEvent == IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED() ? sendEvent : Unit.INSTANCE;
    }

    public Object sendPrivacyFsmChange(byte[] bArr, Continuation<? super Unit> continuation) {
        Object sendEvent = sendEvent(new WebViewAdPlayer$sendPrivacyFsmChange$2(bArr), continuation);
        return sendEvent == IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED() ? sendEvent : Unit.INSTANCE;
    }

    public Object onBroadcastEvent(String str, Continuation<? super Unit> continuation) {
        Object sendEvent = sendEvent(new WebViewAdPlayer$onBroadcastEvent$2(str), continuation);
        return sendEvent == IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED() ? sendEvent : Unit.INSTANCE;
    }

    public Object onAllowedPiiChange(byte[] bArr, Continuation<? super Unit> continuation) {
        Object sendEvent = sendEvent(new WebViewAdPlayer$onAllowedPiiChange$2(bArr), continuation);
        return sendEvent == IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED() ? sendEvent : Unit.INSTANCE;
    }
}
