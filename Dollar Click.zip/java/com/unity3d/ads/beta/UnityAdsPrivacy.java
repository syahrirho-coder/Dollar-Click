package com.unity3d.ads.beta;

import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

@Metadata(d1 = {"\u0000&\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\u001a\u0018\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u0005H\u0000\u001a\u0018\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0006\u001a\u00020\u00072\u0006\u0010\u0004\u001a\u00020\bH\u0000\u001a\u0018\u0010\t\u001a\u00020\u00012\u0006\u0010\n\u001a\u00020\u000b2\u0006\u0010\u0004\u001a\u00020\u0005H\u0000\u001a\u0018\u0010\t\u001a\u00020\u00012\u0006\u0010\n\u001a\u00020\u000b2\u0006\u0010\u0002\u001a\u00020\bH\u0000¨\u0006\f"}, d2 = {"set", "", "consent", "Lcom/unity3d/ads/beta/UnityAdsPrivacyConsent;", "value", "Lcom/unity3d/ads/beta/UnityAdsPrivacyConsentValue;", "privacy", "Lcom/unity3d/ads/beta/UnityAdsPrivacyFlag;", "Lcom/unity3d/ads/beta/UnityAdsPrivacyValue;", "setPrivacy", "flag", "", "unity-ads_release"}, k = 2, mv = {1, 8, 0}, xi = 48)
/* compiled from: UnityAdsPrivacy.kt */
public final class UnityAdsPrivacy {
    public static final void set(UnityAdsPrivacyConsent unityAdsPrivacyConsent, UnityAdsPrivacyConsentValue unityAdsPrivacyConsentValue) {
        Intrinsics.checkNotNullParameter(unityAdsPrivacyConsent, "consent");
        Intrinsics.checkNotNullParameter(unityAdsPrivacyConsentValue, "value");
    }

    public static final void set(UnityAdsPrivacyFlag unityAdsPrivacyFlag, UnityAdsPrivacyValue unityAdsPrivacyValue) {
        Intrinsics.checkNotNullParameter(unityAdsPrivacyFlag, "privacy");
        Intrinsics.checkNotNullParameter(unityAdsPrivacyValue, "value");
    }

    public static final void setPrivacy(String str, UnityAdsPrivacyConsentValue unityAdsPrivacyConsentValue) {
        Intrinsics.checkNotNullParameter(str, "flag");
        Intrinsics.checkNotNullParameter(unityAdsPrivacyConsentValue, "value");
    }

    public static final void setPrivacy(String str, UnityAdsPrivacyValue unityAdsPrivacyValue) {
        Intrinsics.checkNotNullParameter(str, "flag");
        Intrinsics.checkNotNullParameter(unityAdsPrivacyValue, "consent");
    }
}
