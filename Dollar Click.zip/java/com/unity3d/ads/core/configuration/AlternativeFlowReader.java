package com.unity3d.ads.core.configuration;

import com.unity3d.ads.core.data.repository.SessionRepository;
import com.unity3d.services.core.configuration.ConfigurationReader;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import kotlinx.coroutines.flow.MutableStateFlow;
import kotlinx.coroutines.flow.StateFlowKt;

@Metadata(d1 = {"\u0000*\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000b\n\u0002\b\u0003\u0018\u00002\u00020\u0001B\u001d\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007¢\u0006\u0002\u0010\bJ\t\u0010\r\u001a\u00020\u000bH\u0002R\u000e\u0010\u0002\u001a\u00020\u0003X\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\t\u001a\b\u0012\u0004\u0012\u00020\u000b0\nX\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\f\u001a\b\u0012\u0004\u0012\u00020\u000b0\nX\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0007X\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0004\u001a\u00020\u0005X\u0004¢\u0006\u0002\n\u0000¨\u0006\u000e"}, d2 = {"Lcom/unity3d/ads/core/configuration/AlternativeFlowReader;", "", "configurationReader", "Lcom/unity3d/services/core/configuration/ConfigurationReader;", "sessionRepository", "Lcom/unity3d/ads/core/data/repository/SessionRepository;", "mediationMetadataReader", "Lcom/unity3d/ads/core/configuration/MediationTraitsMetadataReader;", "(Lcom/unity3d/services/core/configuration/ConfigurationReader;Lcom/unity3d/ads/core/data/repository/SessionRepository;Lcom/unity3d/ads/core/configuration/MediationTraitsMetadataReader;)V", "isAlternativeFlowEnabled", "Lkotlinx/coroutines/flow/MutableStateFlow;", "", "isAlternativeFlowRead", "invoke", "unity-ads_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
/* compiled from: AlternativeFlowReader.kt */
public final class AlternativeFlowReader {
    private final ConfigurationReader configurationReader;
    private final MutableStateFlow<Boolean> isAlternativeFlowEnabled;
    private final MutableStateFlow<Boolean> isAlternativeFlowRead;
    private final MediationTraitsMetadataReader mediationMetadataReader;
    private final SessionRepository sessionRepository;

    public AlternativeFlowReader(ConfigurationReader configurationReader, SessionRepository sessionRepository, MediationTraitsMetadataReader mediationTraitsMetadataReader) {
        Intrinsics.checkNotNullParameter(configurationReader, "configurationReader");
        Intrinsics.checkNotNullParameter(sessionRepository, "sessionRepository");
        Intrinsics.checkNotNullParameter(mediationTraitsMetadataReader, "mediationMetadataReader");
        this.configurationReader = configurationReader;
        this.sessionRepository = sessionRepository;
        this.mediationMetadataReader = mediationTraitsMetadataReader;
        Boolean valueOf = Boolean.valueOf(false);
        this.isAlternativeFlowRead = StateFlowKt.MutableStateFlow(valueOf);
        this.isAlternativeFlowEnabled = StateFlowKt.MutableStateFlow(valueOf);
    }

    /* DevToolsApp WARNING: Missing block: B:9:0x0039, code:
            if (r0 == null) goto L_0x003b;
     */
    public final boolean invoke() {
        /*
        r5 = this;
        r0 = r5.isAlternativeFlowRead;
        r0 = r0.getValue();
        r0 = (java.lang.Boolean) r0;
        r0 = r0.booleanValue();
        if (r0 == 0) goto L_0x001b;
    L_0x000e:
        r0 = r5.isAlternativeFlowEnabled;
        r0 = r0.getValue();
        r0 = (java.lang.Boolean) r0;
        r0 = r0.booleanValue();
        return r0;
    L_0x001b:
        r0 = r5.mediationMetadataReader;
        r0 = (com.unity3d.ads.core.configuration.MetadataReader) r0;
        r1 = r0.getJsonStorage();
        r0 = r0.getKey();
        r0 = r1.get(r0);
        r1 = 0;
        if (r0 == 0) goto L_0x003b;
    L_0x002e:
        r2 = "get(key)";
        kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r0, r2);
        r2 = r0 instanceof org.json.JSONObject;
        if (r2 == 0) goto L_0x0038;
    L_0x0037:
        goto L_0x0039;
    L_0x0038:
        r0 = r1;
    L_0x0039:
        if (r0 != 0) goto L_0x003c;
    L_0x003b:
        r0 = r1;
    L_0x003c:
        r0 = (org.json.JSONObject) r0;
        r2 = 1;
        if (r0 == 0) goto L_0x0062;
    L_0x0041:
        r3 = "boldSdkEnabled";
        r4 = r0.has(r3);
        if (r4 == 0) goto L_0x004a;
    L_0x0049:
        r1 = r0;
    L_0x004a:
        if (r1 == 0) goto L_0x0062;
    L_0x004c:
        r0 = r5.isAlternativeFlowEnabled;
        r1 = r1.optBoolean(r3);
        r1 = java.lang.Boolean.valueOf(r1);
        r0.setValue(r1);
        r0 = r5.isAlternativeFlowRead;
        r1 = java.lang.Boolean.valueOf(r2);
        r0.setValue(r1);
    L_0x0062:
        r0 = r5.isAlternativeFlowRead;
        r0 = r0.getValue();
        r0 = (java.lang.Boolean) r0;
        r0 = r0.booleanValue();
        if (r0 != 0) goto L_0x00a6;
    L_0x0070:
        r0 = r5.isAlternativeFlowEnabled;
        r1 = r5.configurationReader;
        r1 = r1.getCurrentConfiguration();
        r1 = r1.getExperiments();
        r1 = r1.isBoldSdkNextSessionEnabled();
        if (r1 != 0) goto L_0x0095;
    L_0x0082:
        r1 = r5.sessionRepository;
        r1 = r1.getNativeConfiguration();
        r1 = r1.getFeatureFlags();
        r1 = r1.getBoldSdkNextSessionEnabled();
        if (r1 == 0) goto L_0x0093;
    L_0x0092:
        goto L_0x0095;
    L_0x0093:
        r1 = 0;
        goto L_0x0096;
    L_0x0095:
        r1 = r2;
    L_0x0096:
        r1 = java.lang.Boolean.valueOf(r1);
        r0.setValue(r1);
        r0 = r5.isAlternativeFlowRead;
        r1 = java.lang.Boolean.valueOf(r2);
        r0.setValue(r1);
    L_0x00a6:
        r0 = r5.isAlternativeFlowEnabled;
        r0 = r0.getValue();
        r0 = (java.lang.Boolean) r0;
        r0 = r0.booleanValue();
        return r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.unity3d.ads.core.configuration.AlternativeFlowReader.invoke():boolean");
    }
}
