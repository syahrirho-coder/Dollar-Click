package com.unity3d.ads.core.configuration;

import com.unity3d.services.core.misc.JsonStorage;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import org.json.JSONObject;

@Metadata(d1 = {"\u0000$\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0003\u0018\u0000 \u000b2\b\u0012\u0004\u0012\u00020\u00020\u0001:\u0001\u000bB\r\u0012\u0006\u0010\u0003\u001a\u00020\u0004¢\u0006\u0002\u0010\u0005J\u0015\u0010\u0006\u001a\u0004\u0018\u00010\u00072\u0006\u0010\b\u001a\u00020\t¢\u0006\u0002\u0010\n¨\u0006\f"}, d2 = {"Lcom/unity3d/ads/core/configuration/MediationTraitsMetadataReader;", "Lcom/unity3d/ads/core/configuration/MetadataReader;", "Lorg/json/JSONObject;", "jsonStorage", "Lcom/unity3d/services/core/misc/JsonStorage;", "(Lcom/unity3d/services/core/misc/JsonStorage;)V", "getBooleanTrait", "", "key", "", "(Ljava/lang/String;)Ljava/lang/Boolean;", "Companion", "unity-ads_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
/* compiled from: MediationTraitsMetadataReader.kt */
public final class MediationTraitsMetadataReader extends MetadataReader<JSONObject> {
    public static final String BOLD_SDK_ENABLED = "boldSdkEnabled";
    public static final Companion Companion = new Companion();
    public static final String MEDIATION_TRAITS = "mediation.traits.value";
    public static final String USE_REFACTORED_HTTP_CLIENT = "useRefactoredHttpClient";

    @Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0003\b\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002R\u000e\u0010\u0003\u001a\u00020\u0004XT¢\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0004XT¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0004XT¢\u0006\u0002\n\u0000¨\u0006\u0007"}, d2 = {"Lcom/unity3d/ads/core/configuration/MediationTraitsMetadataReader$Companion;", "", "()V", "BOLD_SDK_ENABLED", "", "MEDIATION_TRAITS", "USE_REFACTORED_HTTP_CLIENT", "unity-ads_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
    /* compiled from: MediationTraitsMetadataReader.kt */
    public static final class Companion {
        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        private Companion() {
        }
    }

    public MediationTraitsMetadataReader(JsonStorage jsonStorage) {
        Intrinsics.checkNotNullParameter(jsonStorage, "jsonStorage");
        super(jsonStorage, MEDIATION_TRAITS);
    }

    /* DevToolsApp WARNING: Missing block: B:5:0x0022, code:
            if (r0 == null) goto L_0x0024;
     */
    public final java.lang.Boolean getBooleanTrait(java.lang.String r4) {
        /*
        r3 = this;
        r0 = "key";
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r4, r0);
        r0 = r3;
        r0 = (com.unity3d.ads.core.configuration.MetadataReader) r0;
        r1 = r0.getJsonStorage();
        r0 = r0.getKey();
        r0 = r1.get(r0);
        r1 = 0;
        if (r0 == 0) goto L_0x0024;
    L_0x0017:
        r2 = "get(key)";
        kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r0, r2);
        r2 = r0 instanceof org.json.JSONObject;
        if (r2 == 0) goto L_0x0021;
    L_0x0020:
        goto L_0x0022;
    L_0x0021:
        r0 = r1;
    L_0x0022:
        if (r0 != 0) goto L_0x0025;
    L_0x0024:
        r0 = r1;
    L_0x0025:
        r0 = (org.json.JSONObject) r0;
        if (r0 == 0) goto L_0x003b;
    L_0x0029:
        r2 = r0.has(r4);
        if (r2 == 0) goto L_0x0030;
    L_0x002f:
        goto L_0x0031;
    L_0x0030:
        r0 = r1;
    L_0x0031:
        if (r0 == 0) goto L_0x003b;
    L_0x0033:
        r4 = r0.optBoolean(r4);
        r1 = java.lang.Boolean.valueOf(r4);
    L_0x003b:
        return r1;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.unity3d.ads.core.configuration.MediationTraitsMetadataReader.getBooleanTrait(java.lang.String):java.lang.Boolean");
    }
}
