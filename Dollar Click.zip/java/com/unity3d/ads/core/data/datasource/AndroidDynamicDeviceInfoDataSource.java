package com.unity3d.ads.core.data.datasource;

import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.Resources;
import android.media.AudioManager;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkInfo;
import android.os.Build.VERSION;
import android.os.Environment;
import android.os.LocaleList;
import android.os.SystemClock;
import android.provider.Settings.Global;
import android.provider.Settings.System;
import android.telephony.TelephonyManager;
import android.util.DisplayMetrics;
import androidx.core.app.NotificationCompat;
import com.google.protobuf.GeneratedMessageLite;
import com.unity3d.services.core.device.AdvertisingId;
import com.unity3d.services.core.device.Device.MemoryInfoType;
import com.unity3d.services.core.device.MimeTypes;
import com.unity3d.services.core.device.OpenAdvertisingId;
import com.unity3d.services.core.log.DeviceLog;
import gatewayprotocol.v1.DynamicDeviceInfoKt;
import gatewayprotocol.v1.DynamicDeviceInfoKt.AndroidKt.Dsl;
import gatewayprotocol.v1.DynamicDeviceInfoOuterClass.ConnectionType;
import gatewayprotocol.v1.DynamicDeviceInfoOuterClass.DynamicDeviceInfo;
import gatewayprotocol.v1.DynamicDeviceInfoOuterClass.DynamicDeviceInfo.Android;
import gatewayprotocol.v1.DynamicDeviceInfoOuterClass.DynamicDeviceInfo.Android.Builder;
import gatewayprotocol.v1.NetworkCapabilityTransportsOuterClass.NetworkCapabilityTransports;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TimeZone;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import kotlin.Deprecated;
import kotlin.Metadata;
import kotlin.TuplesKt;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlinx.coroutines.flow.Flow;
import kotlinx.coroutines.flow.FlowKt;
import kotlinx.coroutines.flow.MutableStateFlow;
import kotlinx.coroutines.flow.StateFlowKt;

@Metadata(d1 = {"\u0000\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\u0010$\n\u0002\u0010\u000e\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0006\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\t\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010 \n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0010\n\u0002\u0018\u0002\n\u0002\b\u0012\u0018\u0000 Y2\u00020\u0001:\u0001YB\u0015\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005¢\u0006\u0002\u0010\u0006J\b\u0010\u0013\u001a\u00020\rH\u0002J\b\u0010\u0014\u001a\u00020\u0015H\u0016J\b\u0010\u0016\u001a\u00020\u0017H\u0002J\b\u0010\u0018\u001a\u00020\rH\u0002J\n\u0010\u0019\u001a\u0004\u0018\u00010\u001aH\u0002J\b\u0010\u001b\u001a\u00020\u001cH\u0002J\b\u0010\u001d\u001a\u00020\u001eH\u0002J\u0006\u0010\u001f\u001a\u00020\u001eJ\b\u0010 \u001a\u00020!H\u0002J\b\u0010\"\u001a\u00020\fH\u0016J\n\u0010#\u001a\u0004\u0018\u00010$H\u0002J\b\u0010%\u001a\u00020\u001eH\u0016J\b\u0010&\u001a\u00020'H\u0002J\b\u0010(\u001a\u00020'H\u0002J\u0006\u0010)\u001a\u00020'J\u0012\u0010*\u001a\u00020'2\b\u0010+\u001a\u0004\u0018\u00010,H\u0003J\u0006\u0010-\u001a\u00020\rJ\b\u0010.\u001a\u00020\fH\u0002J\u000e\u0010/\u001a\b\u0012\u0004\u0012\u00020\f00H\u0016J\u0010\u00101\u001a\u00020'2\u0006\u00102\u001a\u000203H\u0002J\u0012\u00104\u001a\u00020'2\b\u00105\u001a\u0004\u0018\u00010\fH\u0002J\u0006\u00106\u001a\u000207J\u0006\u00108\u001a\u00020\fJ\b\u00109\u001a\u00020\rH\u0002J\b\u0010:\u001a\u00020\fH\u0002J\b\u0010;\u001a\u00020\fH\u0002J\b\u0010<\u001a\u00020\u001eH\u0003J\b\u0010=\u001a\u00020\fH\u0016J\u0012\u0010>\u001a\u000e\u0012\u0004\u0012\u00020\f\u0012\u0004\u0012\u00020\f0\u000bJ\b\u0010?\u001a\u00020\u001eH\u0016J\u0006\u0010@\u001a\u00020\u001eJ\b\u0010A\u001a\u00020\u001eH\u0002J\b\u0010B\u001a\u00020\u001eH\u0002J\u0006\u0010C\u001a\u00020\rJ\u000e\u0010D\u001a\u00020\u001c2\u0006\u0010E\u001a\u00020\u001eJ\u0010\u0010F\u001a\u00020\u001c2\u0006\u0010E\u001a\u00020\u001eH\u0002J\n\u0010G\u001a\u0004\u0018\u00010HH\u0002J\b\u0010I\u001a\u00020\fH\u0002J\b\u0010J\u001a\u00020'H\u0002J\u0006\u0010K\u001a\u00020'J\b\u0010L\u001a\u00020'H\u0002J\u0012\u0010M\u001a\u00020'2\b\u0010+\u001a\u0004\u0018\u00010,H\u0002J\b\u0010N\u001a\u00020\rH\u0016J\b\u0010O\u001a\u00020\rH\u0002J\b\u0010P\u001a\u00020\rH\u0003J\b\u0010Q\u001a\u00020\rH\u0002J\b\u0010R\u001a\u00020\rH\u0002J\b\u0010S\u001a\u00020\rH\u0002J\b\u0010T\u001a\u00020\rH\u0002J\b\u0010U\u001a\u00020\rH\u0002J\b\u0010V\u001a\u00020\rH\u0002J\b\u0010W\u001a\u00020\rH\u0002J\b\u0010X\u001a\u00020\rH\u0002R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0007\u0010\bR\u000e\u0010\u0004\u001a\u00020\u0005X\u0004¢\u0006\u0002\n\u0000R \u0010\t\u001a\u0014\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u00020\f\u0012\u0004\u0012\u00020\r0\u000b0\nX\u0004¢\u0006\u0002\n\u0000R\u001a\u0010\u000e\u001a\b\u0012\u0004\u0012\u00020\u00100\u000fX\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0011\u0010\u0012¨\u0006Z"}, d2 = {"Lcom/unity3d/ads/core/data/datasource/AndroidDynamicDeviceInfoDataSource;", "Lcom/unity3d/ads/core/data/datasource/DynamicDeviceInfoDataSource;", "context", "Landroid/content/Context;", "lifecycleDataSource", "Lcom/unity3d/ads/core/data/datasource/LifecycleDataSource;", "(Landroid/content/Context;Lcom/unity3d/ads/core/data/datasource/LifecycleDataSource;)V", "getContext", "()Landroid/content/Context;", "reportedWarning", "Lkotlinx/coroutines/flow/MutableStateFlow;", "", "", "", "volumeSettingsChange", "Lkotlinx/coroutines/flow/Flow;", "Lcom/unity3d/ads/core/data/datasource/VolumeSettingsChange;", "getVolumeSettingsChange", "()Lkotlinx/coroutines/flow/Flow;", "adbStatus", "fetch", "Lgatewayprotocol/v1/DynamicDeviceInfoOuterClass$DynamicDeviceInfo;", "fetchAndroidDynamicDeviceInfo", "Lgatewayprotocol/v1/DynamicDeviceInfoOuterClass$DynamicDeviceInfo$Android;", "getAirplaneMode", "getAudioManager", "Landroid/media/AudioManager;", "getBatteryLevel", "", "getBatteryStatus", "", "getChargingType", "getConnectionType", "Lgatewayprotocol/v1/DynamicDeviceInfoOuterClass$ConnectionType;", "getConnectionTypeStr", "getConnectivityManager", "Landroid/net/ConnectivityManager;", "getCurrentUiTheme", "getElapsedRealtime", "", "getEventTimeStamp", "getFreeMemory", "getFreeSpace", "file", "Ljava/io/File;", "getIsSdCardPresent", "getLanguage", "getLocaleList", "", "getMemoryInfo", "infoType", "Lcom/unity3d/services/core/device/Device$MemoryInfoType;", "getMemoryValueFromString", "memVal", "getNetworkCapabilityTransports", "Lgatewayprotocol/v1/NetworkCapabilityTransportsOuterClass$NetworkCapabilityTransports;", "getNetworkCountryISO", "getNetworkMetered", "getNetworkOperator", "getNetworkOperatorName", "getNetworkType", "getOrientation", "getProcessInfo", "getRingerMode", "getScreenBrightness", "getScreenHeight", "getScreenWidth", "getStayOnWhilePluggedIn", "getStreamMaxVolume", "streamType", "getStreamVolume", "getTelephonyManager", "Landroid/telephony/TelephonyManager;", "getTimeZone", "getTimeZoneOffset", "getTotalMemory", "getUptime", "getUsableSpace", "hasInternet", "hasInternetConnection", "hasInternetConnectionM", "isActiveNetworkConnected", "isAdbEnabled", "isAppActive", "isLimitAdTrackingEnabled", "isLimitOpenAdTrackingEnabled", "isUSBConnected", "isUsingWifi", "isWiredHeadsetOn", "Companion", "unity-ads_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
/* compiled from: AndroidDynamicDeviceInfoDataSource.kt */
public final class AndroidDynamicDeviceInfoDataSource implements DynamicDeviceInfoDataSource {
    public static final Companion Companion = new Companion();
    public static final String DIRECTORY_MEM_INFO = "/proc/meminfo";
    public static final String DIRECTORY_MODE_READ = "r";
    public static final String DIRECTORY_PROCESS_INFO = "/proc/self/stat";
    public static final String INTENT_USB_STATE = "android.hardware.usb.action.USB_STATE";
    public static final String KEY_STAT_CONTENT = "stat";
    public static final String USB_EXTRA_CONNECTED = "connected";
    private final Context context;
    private final LifecycleDataSource lifecycleDataSource;
    private final MutableStateFlow<Map<String, Boolean>> reportedWarning = StateFlowKt.MutableStateFlow(MapsKt__MapsKt.emptyMap());
    private final Flow<VolumeSettingsChange> volumeSettingsChange = FlowKt.callbackFlow(new AndroidDynamicDeviceInfoDataSource$volumeSettingsChange$1(this, null));

    @Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0006\b\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002R\u000e\u0010\u0003\u001a\u00020\u0004XT¢\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0004XT¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0004XT¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0004XT¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\u0004XT¢\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\u0004XT¢\u0006\u0002\n\u0000¨\u0006\n"}, d2 = {"Lcom/unity3d/ads/core/data/datasource/AndroidDynamicDeviceInfoDataSource$Companion;", "", "()V", "DIRECTORY_MEM_INFO", "", "DIRECTORY_MODE_READ", "DIRECTORY_PROCESS_INFO", "INTENT_USB_STATE", "KEY_STAT_CONTENT", "USB_EXTRA_CONNECTED", "unity-ads_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
    /* compiled from: AndroidDynamicDeviceInfoDataSource.kt */
    public static final class Companion {
        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        private Companion() {
        }
    }

    @Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
    /* compiled from: AndroidDynamicDeviceInfoDataSource.kt */
    public /* synthetic */ class WhenMappings {
        public static final /* synthetic */ int[] $EnumSwitchMapping$0;
        public static final /* synthetic */ int[] $EnumSwitchMapping$1;

        /* DevToolsApp WARNING: Failed to process nested try/catch */
        /* DevToolsApp WARNING: Missing block: B:12:?, code:
            r0[gatewayprotocol.v1.DynamicDeviceInfoOuterClass.ConnectionType.CONNECTION_TYPE_UNSPECIFIED.ordinal()] = 3;
     */
        static {
            /*
            r0 = com.unity3d.services.core.device.Device.MemoryInfoType.values();
            r0 = r0.length;
            r0 = new int[r0];
            r1 = 1;
            r2 = com.unity3d.services.core.device.Device.MemoryInfoType.TOTAL_MEMORY;	 Catch:{ NoSuchFieldError -> 0x0010 }
            r2 = r2.ordinal();	 Catch:{ NoSuchFieldError -> 0x0010 }
            r0[r2] = r1;	 Catch:{ NoSuchFieldError -> 0x0010 }
        L_0x0010:
            r2 = 2;
            r3 = com.unity3d.services.core.device.Device.MemoryInfoType.FREE_MEMORY;	 Catch:{ NoSuchFieldError -> 0x0019 }
            r3 = r3.ordinal();	 Catch:{ NoSuchFieldError -> 0x0019 }
            r0[r3] = r2;	 Catch:{ NoSuchFieldError -> 0x0019 }
        L_0x0019:
            $EnumSwitchMapping$0 = r0;
            r0 = gatewayprotocol.v1.DynamicDeviceInfoOuterClass.ConnectionType.values();
            r0 = r0.length;
            r0 = new int[r0];
            r3 = gatewayprotocol.v1.DynamicDeviceInfoOuterClass.ConnectionType.CONNECTION_TYPE_WIFI;	 Catch:{ NoSuchFieldError -> 0x002a }
            r3 = r3.ordinal();	 Catch:{ NoSuchFieldError -> 0x002a }
            r0[r3] = r1;	 Catch:{ NoSuchFieldError -> 0x002a }
        L_0x002a:
            r1 = gatewayprotocol.v1.DynamicDeviceInfoOuterClass.ConnectionType.CONNECTION_TYPE_CELLULAR;	 Catch:{ NoSuchFieldError -> 0x0032 }
            r1 = r1.ordinal();	 Catch:{ NoSuchFieldError -> 0x0032 }
            r0[r1] = r2;	 Catch:{ NoSuchFieldError -> 0x0032 }
        L_0x0032:
            r1 = gatewayprotocol.v1.DynamicDeviceInfoOuterClass.ConnectionType.CONNECTION_TYPE_UNSPECIFIED;	 Catch:{ NoSuchFieldError -> 0x003b }
            r1 = r1.ordinal();	 Catch:{ NoSuchFieldError -> 0x003b }
            r2 = 3;
            r0[r1] = r2;	 Catch:{ NoSuchFieldError -> 0x003b }
        L_0x003b:
            $EnumSwitchMapping$1 = r0;
            return;
            */
            throw new UnsupportedOperationException("Method not decompiled: com.unity3d.ads.core.data.datasource.AndroidDynamicDeviceInfoDataSource.WhenMappings.<clinit>():void");
        }
    }

    public AndroidDynamicDeviceInfoDataSource(Context context, LifecycleDataSource lifecycleDataSource) {
        Intrinsics.checkNotNullParameter(context, "context");
        Intrinsics.checkNotNullParameter(lifecycleDataSource, "lifecycleDataSource");
        this.context = context;
        this.lifecycleDataSource = lifecycleDataSource;
    }

    public final Context getContext() {
        return this.context;
    }

    private final Android fetchAndroidDynamicDeviceInfo() {
        DynamicDeviceInfoKt dynamicDeviceInfoKt = DynamicDeviceInfoKt.INSTANCE;
        gatewayprotocol.v1.DynamicDeviceInfoKt.AndroidKt.Dsl.Companion companion = Dsl.Companion;
        Builder newBuilder = Android.newBuilder();
        Intrinsics.checkNotNullExpressionValue(newBuilder, "newBuilder()");
        Dsl _create = companion._create(newBuilder);
        _create.setNetworkConnected(isActiveNetworkConnected());
        _create.setNetworkType(getNetworkType());
        _create.setNetworkMetered(getNetworkMetered());
        _create.setTelephonyManagerNetworkType(getNetworkType());
        _create.setAdbEnabled(isAdbEnabled());
        _create.setUsbConnected(isUSBConnected());
        _create.setVolume(getStreamVolume(3));
        _create.setMaxVolume(getStreamMaxVolume(3));
        _create.setDeviceElapsedRealtime(getElapsedRealtime());
        _create.setDeviceUpTime(getUptime());
        _create.setAirplaneMode(getAirplaneMode());
        _create.setChargingType(getChargingType());
        _create.setStayOnWhilePluggedIn(getStayOnWhilePluggedIn());
        _create.setSdCardPresent(getIsSdCardPresent());
        _create.setNetworkCapabilityTransports(getNetworkCapabilityTransports());
        return _create._build();
    }

    private final String getLanguage() {
        String locale = Locale.getDefault().toString();
        Intrinsics.checkNotNullExpressionValue(locale, "getDefault().toString()");
        return locale;
    }

    private final String getTimeZone() {
        try {
            String displayName = TimeZone.getDefault().getDisplayName(false, 0, Locale.US);
            Intrinsics.checkNotNullExpressionValue(displayName, "{\n            TimeZone.g…ORT, Locale.US)\n        }");
            return displayName;
        } catch (AssertionError e) {
            DeviceLog.error("Could not read timeZone information: %s", e.getMessage());
            return "";
        }
    }

    private final long getTimeZoneOffset() {
        return ((long) TimeZone.getDefault().getOffset(System.currentTimeMillis())) / ((long) 1000);
    }

    private final boolean isUsingWifi() {
        ConnectivityManager connectivityManager = getConnectivityManager();
        boolean z = false;
        if (connectivityManager == null) {
            return false;
        }
        TelephonyManager telephonyManager = getTelephonyManager();
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        if (activeNetworkInfo != null && connectivityManager.getBackgroundDataSetting() && activeNetworkInfo.isConnected() && telephonyManager != null && activeNetworkInfo.getType() == 1 && activeNetworkInfo.isConnected()) {
            z = true;
        }
        return z;
    }

    private final ConnectionType getConnectionType() {
        if (isUsingWifi()) {
            return ConnectionType.CONNECTION_TYPE_WIFI;
        }
        if (isActiveNetworkConnected()) {
            return ConnectionType.CONNECTION_TYPE_CELLULAR;
        }
        return ConnectionType.CONNECTION_TYPE_UNSPECIFIED;
    }

    @Deprecated(message = "This method was deprecated in API level 30. Use getDataNetworkType()")
    private final int getNetworkType() {
        TelephonyManager telephonyManager = getTelephonyManager();
        int i = -1;
        if (telephonyManager == null) {
            return -1;
        }
        try {
            i = telephonyManager.getNetworkType();
            return i;
        } catch (SecurityException unused) {
            String str = "getNetworkType";
            if (Intrinsics.areEqual(((Map) this.reportedWarning.getValue()).get(str), Boolean.valueOf(true))) {
                return i;
            }
            MutableStateFlow mutableStateFlow = this.reportedWarning;
            Object value;
            do {
                value = mutableStateFlow.getValue();
            } while (!mutableStateFlow.compareAndSet(value, MapsKt__MapsKt.plus((Map) value, TuplesKt.to(str, Boolean.valueOf(true)))));
            DeviceLog.warning("Unity Ads was not able to get current network type due to missing permission");
            return i;
        }
    }

    private final boolean getNetworkMetered() {
        ConnectivityManager connectivityManager = getConnectivityManager();
        if (connectivityManager == null || !connectivityManager.isActiveNetworkMetered()) {
            return false;
        }
        return true;
    }

    private final String getNetworkOperator() {
        TelephonyManager telephonyManager = getTelephonyManager();
        String networkOperator = telephonyManager != null ? telephonyManager.getNetworkOperator() : null;
        return networkOperator == null ? "" : networkOperator;
    }

    private final String getNetworkOperatorName() {
        TelephonyManager telephonyManager = getTelephonyManager();
        String networkOperatorName = telephonyManager != null ? telephonyManager.getNetworkOperatorName() : null;
        return networkOperatorName == null ? "" : networkOperatorName;
    }

    public final String getNetworkCountryISO() {
        TelephonyManager telephonyManager = getTelephonyManager();
        String networkCountryIso = telephonyManager != null ? telephonyManager.getNetworkCountryIso() : null;
        return networkCountryIso == null ? "" : networkCountryIso;
    }

    private final int getScreenWidth() {
        Resources resources = this.context.getResources();
        if (resources != null) {
            DisplayMetrics displayMetrics = resources.getDisplayMetrics();
            if (displayMetrics != null) {
                return displayMetrics.widthPixels;
            }
        }
        return -1;
    }

    private final int getScreenHeight() {
        Resources resources = this.context.getResources();
        if (resources != null) {
            DisplayMetrics displayMetrics = resources.getDisplayMetrics();
            if (displayMetrics != null) {
                return displayMetrics.heightPixels;
            }
        }
        return -1;
    }

    private final boolean isActiveNetworkConnected() {
        ConnectivityManager connectivityManager = getConnectivityManager();
        NetworkInfo activeNetworkInfo = connectivityManager != null ? connectivityManager.getActiveNetworkInfo() : null;
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }

    private final boolean isWiredHeadsetOn() {
        AudioManager audioManager = getAudioManager();
        if (audioManager == null || !audioManager.isWiredHeadsetOn()) {
            return false;
        }
        return true;
    }

    public int getRingerMode() {
        AudioManager audioManager = getAudioManager();
        return audioManager != null ? audioManager.getRingerMode() : -2;
    }

    private final double getStreamVolume(int i) {
        AudioManager audioManager = getAudioManager();
        return (double) (audioManager != null ? audioManager.getStreamVolume(i) : -2);
    }

    public final double getStreamMaxVolume(int i) {
        AudioManager audioManager = getAudioManager();
        return (double) (audioManager != null ? audioManager.getStreamMaxVolume(i) : -2);
    }

    public final int getScreenBrightness() {
        return System.getInt(this.context.getContentResolver(), "screen_brightness", -1);
    }

    @Deprecated(message = "Legacy method, migrated from to .getUsableSpace()")
    private final long getFreeSpace(File file) {
        return (file == null || !file.exists()) ? -1 : (long) MathKt__MathJVMKt.roundToInt((float) (file.getFreeSpace() / ((long) 1024)));
    }

    private final long getUsableSpace(File file) {
        return (file == null || !file.exists()) ? -1 : (long) MathKt__MathJVMKt.roundToInt((float) (file.getUsableSpace() / ((long) 1024)));
    }

    private final double getBatteryLevel() {
        Intent registerReceiver = this.context.registerReceiver(null, new IntentFilter("android.intent.action.BATTERY_CHANGED"));
        if (registerReceiver == null) {
            return -1.0d;
        }
        return ((double) registerReceiver.getIntExtra("level", 0)) / ((double) registerReceiver.getIntExtra("scale", 0));
    }

    private final int getBatteryStatus() {
        Intent registerReceiver = this.context.registerReceiver(null, new IntentFilter("android.intent.action.BATTERY_CHANGED"));
        return registerReceiver != null ? registerReceiver.getIntExtra(NotificationCompat.CATEGORY_STATUS, 0) : -1;
    }

    public final long getTotalMemory() {
        return getMemoryInfo(MemoryInfoType.TOTAL_MEMORY);
    }

    public final long getFreeMemory() {
        return getMemoryInfo(MemoryInfoType.FREE_MEMORY);
    }

    /* DevToolsApp WARNING: Missing block: B:17:0x0036, code:
            kotlin.io.CloseableKt.closeFinally(r6, r0);
     */
    private final long getMemoryInfo(com.unity3d.services.core.device.Device.MemoryInfoType r6) {
        /*
        r5 = this;
        r0 = com.unity3d.ads.core.data.datasource.AndroidDynamicDeviceInfoDataSource.WhenMappings.$EnumSwitchMapping$0;
        r6 = r6.ordinal();
        r6 = r0[r6];
        r0 = 1;
        if (r6 == r0) goto L_0x000f;
    L_0x000b:
        r0 = 2;
        if (r6 == r0) goto L_0x000f;
    L_0x000e:
        r0 = -1;
    L_0x000f:
        r6 = new java.io.RandomAccessFile;
        r1 = "/proc/meminfo";
        r2 = "r";
        r6.<init>(r1, r2);
        r6 = (java.io.Closeable) r6;
        r1 = r6;
        r1 = (java.io.RandomAccessFile) r1;	 Catch:{ all -> 0x0033 }
        r2 = 0;
        r3 = 0;
        r4 = r2;
    L_0x0020:
        if (r3 >= r0) goto L_0x0029;
    L_0x0022:
        r4 = r1.readLine();	 Catch:{ all -> 0x0033 }
        r3 = r3 + 1;
        goto L_0x0020;
    L_0x0029:
        r0 = kotlin.Unit.INSTANCE;	 Catch:{ all -> 0x0033 }
        kotlin.io.CloseableKt.closeFinally(r6, r2);
        r0 = r5.getMemoryValueFromString(r4);
        return r0;
    L_0x0033:
        r0 = move-exception;
        throw r0;	 Catch:{ all -> 0x0035 }
    L_0x0035:
        r1 = move-exception;
        kotlin.io.CloseableKt.closeFinally(r6, r0);
        throw r1;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.unity3d.ads.core.data.datasource.AndroidDynamicDeviceInfoDataSource.getMemoryInfo(com.unity3d.services.core.device.Device$MemoryInfoType):long");
    }

    private final long getMemoryValueFromString(String str) {
        if (str == null) {
            return -1;
        }
        Matcher matcher = Pattern.compile("(\\d+)").matcher(str);
        String str2 = null;
        while (matcher.find()) {
            str2 = matcher.group(1);
        }
        if (str2 != null) {
            return Long.parseLong(str2);
        }
        return -1;
    }

    private final boolean isAdbEnabled() {
        return adbStatus();
    }

    private final boolean adbStatus() {
        Boolean valueOf;
        try {
            boolean z = true;
            if (1 != Global.getInt(this.context.getContentResolver(), "adb_enabled", 0)) {
                z = false;
            }
            valueOf = Boolean.valueOf(z);
        } catch (Exception e) {
            DeviceLog.exception("Problems fetching adb enabled status", e);
            valueOf = null;
        }
        if (valueOf != null) {
            return valueOf.booleanValue();
        }
        return false;
    }

    private final boolean isUSBConnected() {
        Intent registerReceiver = this.context.registerReceiver(null, new IntentFilter(INTENT_USB_STATE));
        if (registerReceiver != null) {
            return registerReceiver.getBooleanExtra(USB_EXTRA_CONNECTED, false);
        }
        return false;
    }

    private final long getUptime() {
        return SystemClock.uptimeMillis();
    }

    private final long getElapsedRealtime() {
        return SystemClock.elapsedRealtime();
    }

    /* DevToolsApp WARNING: Missing block: B:9:0x0030, code:
            kotlin.io.CloseableKt.closeFinally(r1, r0);
     */
    public final java.util.Map<java.lang.String, java.lang.String> getProcessInfo() {
        /*
        r6 = this;
        r0 = new java.util.HashMap;
        r0.<init>();
        r1 = new java.io.RandomAccessFile;
        r2 = "/proc/self/stat";
        r3 = "r";
        r1.<init>(r2, r3);
        r1 = (java.io.Closeable) r1;
        r2 = r1;
        r2 = (java.io.RandomAccessFile) r2;	 Catch:{ all -> 0x002d }
        r2 = r2.readLine();	 Catch:{ all -> 0x002d }
        r3 = r0;
        r3 = (java.util.Map) r3;	 Catch:{ all -> 0x002d }
        r4 = "stat";
        r5 = "statContent";
        kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r2, r5);	 Catch:{ all -> 0x002d }
        r3.put(r4, r2);	 Catch:{ all -> 0x002d }
        r2 = kotlin.Unit.INSTANCE;	 Catch:{ all -> 0x002d }
        r2 = 0;
        kotlin.io.CloseableKt.closeFinally(r1, r2);
        r0 = (java.util.Map) r0;
        return r0;
    L_0x002d:
        r0 = move-exception;
        throw r0;	 Catch:{ all -> 0x002f }
    L_0x002f:
        r2 = move-exception;
        kotlin.io.CloseableKt.closeFinally(r1, r0);
        throw r2;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.unity3d.ads.core.data.datasource.AndroidDynamicDeviceInfoDataSource.getProcessInfo():java.util.Map<java.lang.String, java.lang.String>");
    }

    private final boolean isLimitAdTrackingEnabled() {
        return AdvertisingId.getLimitedAdTracking();
    }

    private final boolean isLimitOpenAdTrackingEnabled() {
        return OpenAdvertisingId.getLimitedOpenAdTracking();
    }

    private final boolean isAppActive() {
        return this.lifecycleDataSource.appIsForeground();
    }

    private final long getEventTimeStamp() {
        return System.currentTimeMillis() / ((long) 1000);
    }

    private final TelephonyManager getTelephonyManager() {
        Object systemService = this.context.getSystemService("phone");
        return systemService instanceof TelephonyManager ? (TelephonyManager) systemService : null;
    }

    private final ConnectivityManager getConnectivityManager() {
        Object systemService = this.context.getSystemService("connectivity");
        return systemService instanceof ConnectivityManager ? (ConnectivityManager) systemService : null;
    }

    private final AudioManager getAudioManager() {
        Object systemService = this.context.getSystemService(MimeTypes.BASE_TYPE_AUDIO);
        return systemService instanceof AudioManager ? (AudioManager) systemService : null;
    }

    public boolean hasInternet() {
        return hasInternetConnectionM();
    }

    private final boolean hasInternetConnection() {
        ConnectivityManager connectivityManager = getConnectivityManager();
        boolean z = false;
        if (connectivityManager == null) {
            return false;
        }
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        if (activeNetworkInfo != null && activeNetworkInfo.isConnected()) {
            z = true;
        }
        return z;
    }

    private final boolean hasInternetConnectionM() {
        ConnectivityManager connectivityManager = getConnectivityManager();
        boolean z = false;
        if (connectivityManager == null) {
            return false;
        }
        NetworkCapabilities networkCapabilities = connectivityManager.getNetworkCapabilities(connectivityManager.getActiveNetwork());
        if (networkCapabilities != null && networkCapabilities.hasCapability(12) && networkCapabilities.hasCapability(16)) {
            z = true;
        }
        return z;
    }

    public Flow<VolumeSettingsChange> getVolumeSettingsChange() {
        return this.volumeSettingsChange;
    }

    public String getOrientation() {
        if (getScreenHeight() > getScreenWidth()) {
            return "portrait";
        }
        return "landscape";
    }

    public String getConnectionTypeStr() {
        int i = WhenMappings.$EnumSwitchMapping$1[getConnectionType().ordinal()];
        if (i == 1) {
            return "wifi";
        }
        if (i != 2) {
            return "none";
        }
        return "cellular";
    }

    public int getCurrentUiTheme() {
        return this.context.getResources().getConfiguration().uiMode;
    }

    public List<String> getLocaleList() {
        LocaleList locales = this.context.getResources().getConfiguration().getLocales();
        Intrinsics.checkNotNullExpressionValue(locales, "context.resources.configuration.locales");
        int size = locales.size();
        ArrayList arrayList = new ArrayList(size);
        for (int i = 0; i < size; i++) {
            String locale = locales.get(i).toString();
            Intrinsics.checkNotNullExpressionValue(locale, "locales[it].toString()");
            arrayList.add(locale);
        }
        return arrayList;
    }

    private final boolean getAirplaneMode() {
        try {
            return Global.getInt(this.context.getContentResolver(), "airplane_mode_on", 0) != 0;
        } catch (Throwable th) {
            DeviceLog.error("Problems fetching airplane mode status", th.getMessage());
            return false;
        }
    }

    public final int getChargingType() {
        Intent registerReceiver = this.context.registerReceiver(null, new IntentFilter("android.intent.action.BATTERY_CHANGED"));
        if (registerReceiver != null) {
            return registerReceiver.getIntExtra("plugged", -1);
        }
        return -1;
    }

    public final boolean getStayOnWhilePluggedIn() {
        try {
            return Global.getInt(this.context.getContentResolver(), "stay_on_while_plugged_in", 0) != 0;
        } catch (Throwable th) {
            DeviceLog.error("Problems fetching stay on while plugged in status", th.getMessage());
            return false;
        }
    }

    public final boolean getIsSdCardPresent() {
        return Intrinsics.areEqual(Environment.getExternalStorageState(), (Object) "mounted");
    }

    public final NetworkCapabilityTransports getNetworkCapabilityTransports() {
        NetworkCapabilityTransports.Builder newBuilder = NetworkCapabilityTransports.newBuilder();
        String str = "result.build()";
        GeneratedMessageLite build;
        if (VERSION.SDK_INT < 31) {
            build = newBuilder.build();
            Intrinsics.checkNotNullExpressionValue(build, str);
            return (NetworkCapabilityTransports) build;
        }
        Object systemService = this.context.getSystemService("connectivity");
        ConnectivityManager connectivityManager = systemService instanceof ConnectivityManager ? (ConnectivityManager) systemService : null;
        if (connectivityManager != null) {
            Network activeNetwork = connectivityManager.getActiveNetwork();
            if (activeNetwork != null) {
                NetworkCapabilities networkCapabilities = connectivityManager.getNetworkCapabilities(activeNetwork);
                if (networkCapabilities == null) {
                    build = newBuilder.build();
                    Intrinsics.checkNotNullExpressionValue(build, str);
                    return (NetworkCapabilityTransports) build;
                }
                boolean hasTransport = networkCapabilities.hasTransport(1);
                Intrinsics.checkNotNullExpressionValue(newBuilder, "result");
                newBuilder.setWifi(hasTransport);
                newBuilder.setCellular(networkCapabilities.hasTransport(0));
                newBuilder.setVpn(networkCapabilities.hasTransport(4));
                newBuilder.setEthernet(networkCapabilities.hasTransport(3));
                newBuilder.setWifiAware(networkCapabilities.hasTransport(5));
                newBuilder.setLowpan(networkCapabilities.hasTransport(6));
                newBuilder.setBluetooth(networkCapabilities.hasTransport(2));
                build = newBuilder.build();
                Intrinsics.checkNotNullExpressionValue(build, str);
                return (NetworkCapabilityTransports) build;
            }
        }
        build = newBuilder.build();
        Intrinsics.checkNotNullExpressionValue(build, str);
        return (NetworkCapabilityTransports) build;
    }

    public DynamicDeviceInfo fetch() {
        gatewayprotocol.v1.DynamicDeviceInfoKt.Dsl.Companion companion = DynamicDeviceInfoKt.Dsl.Companion;
        DynamicDeviceInfo.Builder newBuilder = DynamicDeviceInfo.newBuilder();
        Intrinsics.checkNotNullExpressionValue(newBuilder, "newBuilder()");
        DynamicDeviceInfoKt.Dsl _create = companion._create(newBuilder);
        _create.setLanguage(getLanguage());
        _create.setNetworkOperator(getNetworkOperator());
        _create.setNetworkOperatorName(getNetworkOperatorName());
        _create.setFreeDiskSpace(getUsableSpace(this.context.getExternalFilesDir(null)));
        _create.setFreeRamMemory(getFreeMemory());
        _create.setWiredHeadset(isWiredHeadsetOn());
        _create.setTimeZone(getTimeZone());
        _create.setTimeZoneOffset(getTimeZoneOffset());
        _create.setLimitedTracking(isLimitAdTrackingEnabled());
        _create.setLimitedOpenAdTracking(isLimitOpenAdTrackingEnabled());
        _create.setBatteryLevel(getBatteryLevel());
        _create.setBatteryStatus(getBatteryStatus());
        _create.setConnectionType(getConnectionType());
        _create.setAndroid(fetchAndroidDynamicDeviceInfo());
        _create.setAppActive(isAppActive());
        _create.setScreenWidth(getScreenWidth());
        _create.setScreenHeight(getScreenHeight());
        return _create._build();
    }
}
