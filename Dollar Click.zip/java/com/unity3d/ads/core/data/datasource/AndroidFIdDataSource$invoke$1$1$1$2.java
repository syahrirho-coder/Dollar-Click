package com.unity3d.ads.core.data.datasource;

import com.google.android.gms.tasks.OnFailureListener;
import kotlin.Metadata;
import kotlin.Result;
import kotlin.Result.Companion;
import kotlin.ResultKt;
import kotlin.coroutines.Continuation;
import kotlin.jvm.internal.Intrinsics;

@Metadata(d1 = {"\u0000\u000e\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u0003H\n¢\u0006\u0002\b\u0004"}, d2 = {"<anonymous>", "", "it", "Ljava/lang/Exception;", "onFailure"}, k = 3, mv = {1, 8, 0}, xi = 48)
/* compiled from: AndroidFIdDataSource.kt */
final class AndroidFIdDataSource$invoke$1$1$1$2 implements OnFailureListener {
    final /* synthetic */ Continuation<String> $cont;

    AndroidFIdDataSource$invoke$1$1$1$2(Continuation<? super String> continuation) {
        this.$cont = continuation;
    }

    public final void onFailure(Exception exception) {
        Intrinsics.checkNotNullParameter(exception, "it");
        Continuation continuation = this.$cont;
        Companion companion = Result.Companion;
        continuation.resumeWith(Result.m17constructor-impl(ResultKt.createFailure(exception)));
    }
}
