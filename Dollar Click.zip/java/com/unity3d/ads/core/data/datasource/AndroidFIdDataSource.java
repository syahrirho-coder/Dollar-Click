package com.unity3d.ads.core.data.datasource;

import android.content.Context;
import com.google.android.gms.tasks.Task;
import com.unity3d.services.core.fid.FIdBridge;
import com.unity3d.services.core.fid.FIdStaticBridge;
import kotlin.Metadata;
import kotlin.Result;
import kotlin.Result.Companion;
import kotlin.ResultKt;
import kotlin.jvm.internal.Intrinsics;

@Metadata(d1 = {"\u0000\u001e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\u0018\u00002\u00020\u0001B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0002\u0010\u0004J\u000b\u0010\u0007\u001a\u0004\u0018\u00010\bH\u0002R\u000e\u0010\u0005\u001a\u00020\u0006X\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0002\u001a\u00020\u0003X\u0004¢\u0006\u0002\n\u0000¨\u0006\t"}, d2 = {"Lcom/unity3d/ads/core/data/datasource/AndroidFIdDataSource;", "Lcom/unity3d/ads/core/data/datasource/FIdDataSource;", "context", "Landroid/content/Context;", "(Landroid/content/Context;)V", "bridge", "Lcom/unity3d/services/core/fid/FIdStaticBridge;", "invoke", "", "unity-ads_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
/* compiled from: AndroidFIdDataSource.kt */
public final class AndroidFIdDataSource implements FIdDataSource {
    private FIdStaticBridge bridge = new FIdStaticBridge();
    private final Context context;

    public AndroidFIdDataSource(Context context) {
        Intrinsics.checkNotNullParameter(context, "context");
        this.context = context;
    }

    public String invoke() {
        String str = null;
        try {
            Companion companion = Result.Companion;
            AndroidFIdDataSource androidFIdDataSource = this;
            FIdBridge instance = this.bridge.getInstance(this.context);
            if (instance != null) {
                Task appInstanceId = instance.getAppInstanceId();
                if (appInstanceId != null) {
                    return (String) BuildersKt__BuildersKt.runBlocking$default(null, new AndroidFIdDataSource$invoke$1$1(appInstanceId, null), 1, null);
                }
            }
            return null;
        } catch (Throwable th) {
            Companion companion2 = Result.Companion;
            String constructor-impl = Result.m17constructor-impl(ResultKt.createFailure(th));
            if (!Result.m23isFailure-impl(constructor-impl)) {
                str = constructor-impl;
            }
            return str;
        }
    }
}
