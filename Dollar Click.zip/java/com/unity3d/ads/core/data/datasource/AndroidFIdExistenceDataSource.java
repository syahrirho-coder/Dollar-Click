package com.unity3d.ads.core.data.datasource;

import kotlin.Metadata;
import kotlin.Result;
import kotlin.Result.Companion;
import kotlin.ResultKt;
import kotlin.jvm.internal.Intrinsics;

@Metadata(d1 = {"\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0000\u0018\u00002\u00020\u0001B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0002\u0010\u0004J\t\u0010\u0005\u001a\u00020\u0006H\u0002R\u000e\u0010\u0002\u001a\u00020\u0003X\u0004¢\u0006\u0002\n\u0000¨\u0006\u0007"}, d2 = {"Lcom/unity3d/ads/core/data/datasource/AndroidFIdExistenceDataSource;", "Lcom/unity3d/ads/core/data/datasource/FIdExistenceDataSource;", "className", "", "(Ljava/lang/String;)V", "invoke", "", "unity-ads_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
/* compiled from: AndroidFIdExistenceDataSource.kt */
public final class AndroidFIdExistenceDataSource implements FIdExistenceDataSource {
    private final String className;

    public AndroidFIdExistenceDataSource(String str) {
        Intrinsics.checkNotNullParameter(str, "className");
        this.className = str;
    }

    public boolean invoke() {
        Object constructor-impl;
        try {
            Companion companion = Result.Companion;
            AndroidFIdExistenceDataSource androidFIdExistenceDataSource = this;
            constructor-impl = Result.m17constructor-impl(Class.forName(this.className));
        } catch (Throwable th) {
            Companion companion2 = Result.Companion;
            constructor-impl = Result.m17constructor-impl(ResultKt.createFailure(th));
        }
        return Result.m24isSuccess-impl(constructor-impl);
    }
}
