package com.unity3d.ads.core.data.datasource;

import gatewayprotocol.v1.PiiKt.Dsl;
import kotlin.Metadata;
import kotlin.jvm.internal.MutablePropertyReference0Impl;

@Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
/* compiled from: AndroidPrivacyDeviceInfoDataSource.kt */
/* synthetic */ class AndroidPrivacyDeviceInfoDataSource$fetch$1$3 extends MutablePropertyReference0Impl {
    AndroidPrivacyDeviceInfoDataSource$fetch$1$3(Object obj) {
        Object obj2 = obj;
        super(obj2, Dsl.class, "fid", "getFid()Ljava/lang/String;", 0);
    }

    public Object get() {
        return ((Dsl) this.receiver).getFid();
    }

    public void set(Object obj) {
        ((Dsl) this.receiver).setFid((String) obj);
    }
}
