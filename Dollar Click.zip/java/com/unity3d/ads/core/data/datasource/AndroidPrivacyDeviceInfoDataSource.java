package com.unity3d.ads.core.data.datasource;

import android.content.Context;
import com.unity3d.ads.core.extensions.ProtobufExtensionsKt;
import com.unity3d.services.core.device.AdvertisingId;
import com.unity3d.services.core.device.OpenAdvertisingId;
import gatewayprotocol.v1.AllowedPiiOuterClass.AllowedPii;
import gatewayprotocol.v1.PiiKt.Dsl;
import gatewayprotocol.v1.PiiKt.Dsl.Companion;
import gatewayprotocol.v1.PiiOuterClass.Pii;
import gatewayprotocol.v1.PiiOuterClass.Pii.Builder;
import java.util.UUID;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import kotlinx.coroutines.flow.MutableStateFlow;
import kotlinx.coroutines.flow.StateFlowKt;

@Metadata(d1 = {"\u00006\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\u0018\u00002\u00020\u0001B\u0015\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005¢\u0006\u0002\u0010\u0006J\u0010\u0010\n\u001a\u00020\u000b2\u0006\u0010\f\u001a\u00020\rH\u0016J\b\u0010\u000e\u001a\u00020\u000fH\u0002J\b\u0010\u0010\u001a\u00020\u000fH\u0002R\u000e\u0010\u0002\u001a\u00020\u0003X\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0004\u001a\u00020\u0005X\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\u0007\u001a\b\u0012\u0004\u0012\u00020\t0\bX\u0004¢\u0006\u0002\n\u0000¨\u0006\u0011"}, d2 = {"Lcom/unity3d/ads/core/data/datasource/AndroidPrivacyDeviceInfoDataSource;", "Lcom/unity3d/ads/core/data/datasource/PrivacyDeviceInfoDataSource;", "context", "Landroid/content/Context;", "fIdDataSource", "Lcom/unity3d/ads/core/data/datasource/FIdDataSource;", "(Landroid/content/Context;Lcom/unity3d/ads/core/data/datasource/FIdDataSource;)V", "idfaInitialized", "Lkotlinx/coroutines/flow/MutableStateFlow;", "", "fetch", "Lgatewayprotocol/v1/PiiOuterClass$Pii;", "allowed", "Lgatewayprotocol/v1/AllowedPiiOuterClass$AllowedPii;", "getAdvertisingTrackingId", "", "getOpenAdvertisingTrackingId", "unity-ads_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
/* compiled from: AndroidPrivacyDeviceInfoDataSource.kt */
public final class AndroidPrivacyDeviceInfoDataSource implements PrivacyDeviceInfoDataSource {
    private final Context context;
    private final FIdDataSource fIdDataSource;
    private final MutableStateFlow<Boolean> idfaInitialized = StateFlowKt.MutableStateFlow(Boolean.valueOf(false));

    public AndroidPrivacyDeviceInfoDataSource(Context context, FIdDataSource fIdDataSource) {
        Intrinsics.checkNotNullParameter(context, "context");
        Intrinsics.checkNotNullParameter(fIdDataSource, "fIdDataSource");
        this.context = context;
        this.fIdDataSource = fIdDataSource;
    }

    public Pii fetch(AllowedPii allowedPii) {
        Intrinsics.checkNotNullParameter(allowedPii, "allowed");
        if (!((Boolean) this.idfaInitialized.getValue()).booleanValue()) {
            this.idfaInitialized.setValue(Boolean.valueOf(true));
            AdvertisingId.init(this.context);
            OpenAdvertisingId.init(this.context);
        }
        Companion companion = Dsl.Companion;
        Builder newBuilder = Pii.newBuilder();
        Intrinsics.checkNotNullExpressionValue(newBuilder, "newBuilder()");
        Dsl _create = companion._create(newBuilder);
        if (allowedPii.getIdfa()) {
            UUID fromString;
            String advertisingTrackingId = getAdvertisingTrackingId();
            if (advertisingTrackingId.length() > 0) {
                fromString = UUID.fromString(advertisingTrackingId);
                Intrinsics.checkNotNullExpressionValue(fromString, "fromString(adId)");
                _create.setAdvertisingId(ProtobufExtensionsKt.toByteString(fromString));
            }
            advertisingTrackingId = getOpenAdvertisingTrackingId();
            if (advertisingTrackingId.length() > 0) {
                fromString = UUID.fromString(advertisingTrackingId);
                Intrinsics.checkNotNullExpressionValue(fromString, "fromString(openAdId)");
                _create.setOpenAdvertisingTrackingId(ProtobufExtensionsKt.toByteString(fromString));
            }
        }
        if (allowedPii.getFid()) {
            Object invoke = this.fIdDataSource.invoke();
            if (invoke != null) {
                if (((CharSequence) invoke).length() <= 0) {
                    invoke = null;
                }
                if (invoke != null) {
                    new AndroidPrivacyDeviceInfoDataSource$fetch$1$3(_create).set(invoke);
                }
            }
        }
        return _create._build();
    }

    private final String getAdvertisingTrackingId() {
        String advertisingTrackingId = AdvertisingId.getAdvertisingTrackingId();
        return advertisingTrackingId == null ? "" : advertisingTrackingId;
    }

    private final String getOpenAdvertisingTrackingId() {
        String openAdvertisingTrackingId = OpenAdvertisingId.getOpenAdvertisingTrackingId();
        return openAdvertisingTrackingId == null ? "" : openAdvertisingTrackingId;
    }
}
