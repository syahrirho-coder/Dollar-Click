package com.unity3d.ads.core.data.datasource;

import java.io.File;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.jvm.internal.Boxing;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function2;
import kotlinx.coroutines.CoroutineScope;

@Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0000\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H@"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {1, 8, 0}, xi = 48)
@DebugMetadata(c = "com.unity3d.ads.core.data.datasource.AndroidRemoteCacheDataSource$saveToCache$2", f = "AndroidRemoteCacheDataSource.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
/* compiled from: AndroidRemoteCacheDataSource.kt */
final class AndroidRemoteCacheDataSource$saveToCache$2 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Object>, Object> {
    final /* synthetic */ Object $body;
    final /* synthetic */ File $dest;
    int label;

    AndroidRemoteCacheDataSource$saveToCache$2(Object obj, File file, Continuation<? super AndroidRemoteCacheDataSource$saveToCache$2> continuation) {
        this.$body = obj;
        this.$dest = file;
        super(2, continuation);
    }

    public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
        return new AndroidRemoteCacheDataSource$saveToCache$2(this.$body, this.$dest, continuation);
    }

    public final Object invoke(CoroutineScope coroutineScope, Continuation<Object> continuation) {
        return ((AndroidRemoteCacheDataSource$saveToCache$2) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
    }

    public final Object invokeSuspend(Object obj) {
        IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED();
        if (this.label == 0) {
            ResultKt.throwOnFailure(obj);
            obj = this.$body;
            if (obj instanceof File) {
                FilesKt__UtilsKt.copyTo$default((File) obj, this.$dest, true, 0, 4, null);
                return Boxing.boxBoolean(((File) this.$body).delete());
            } else if (obj instanceof byte[]) {
                this.$dest.createNewFile();
                FilesKt__FileReadWriteKt.writeBytes(this.$dest, (byte[]) this.$body);
                return Unit.INSTANCE;
            } else {
                throw new IllegalStateException("Unknown body type".toString());
            }
        }
        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
    }
}
