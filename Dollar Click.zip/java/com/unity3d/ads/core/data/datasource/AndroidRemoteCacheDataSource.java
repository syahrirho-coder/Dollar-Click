package com.unity3d.ads.core.data.datasource;

import com.unity3d.ads.core.domain.CreateFile;
import com.unity3d.ads.core.domain.GetFileExtensionFromUrl;
import com.unity3d.services.core.network.core.HttpClient;
import com.unity3d.services.core.network.model.HttpRequest;
import com.unity3d.services.core.network.model.HttpResponse;
import java.io.File;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.jvm.internal.Intrinsics;
import kotlinx.coroutines.BuildersKt;
import kotlinx.coroutines.CoroutineDispatcher;

@Metadata(d1 = {"\u0000V\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\u0018\u00002\u00020\u0001B%\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\u0006\u0010\b\u001a\u00020\t¢\u0006\u0002\u0010\nJ#\u0010\u000b\u001a\u00020\f2\u0006\u0010\r\u001a\u00020\u000e2\b\u0010\u000f\u001a\u0004\u0018\u00010\u0010H@ø\u0001\u0000¢\u0006\u0002\u0010\u0011J5\u0010\u0012\u001a\u00020\u00132\u0006\u0010\u0014\u001a\u00020\u00152\u0006\u0010\u0016\u001a\u00020\u000e2\b\u0010\r\u001a\u0004\u0018\u00010\u000e2\b\u0010\u000f\u001a\u0004\u0018\u00010\u0010H@ø\u0001\u0000¢\u0006\u0002\u0010\u0017J#\u0010\u0018\u001a\u00020\u00192\u0006\u0010\u001a\u001a\u00020\u00152\b\u0010\u001b\u001a\u0004\u0018\u00010\u001cH@ø\u0001\u0000¢\u0006\u0002\u0010\u001dR\u000e\u0010\u0004\u001a\u00020\u0005X\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0007X\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\tX\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0002\u001a\u00020\u0003X\u0004¢\u0006\u0002\n\u0000\u0002\u0004\n\u0002\b\u0019¨\u0006\u001e"}, d2 = {"Lcom/unity3d/ads/core/data/datasource/AndroidRemoteCacheDataSource;", "Lcom/unity3d/ads/core/data/datasource/CacheDataSource;", "ioDispatcher", "Lkotlinx/coroutines/CoroutineDispatcher;", "createFile", "Lcom/unity3d/ads/core/domain/CreateFile;", "getFileExtensionFromUrl", "Lcom/unity3d/ads/core/domain/GetFileExtensionFromUrl;", "httpClient", "Lcom/unity3d/services/core/network/core/HttpClient;", "(Lkotlinx/coroutines/CoroutineDispatcher;Lcom/unity3d/ads/core/domain/CreateFile;Lcom/unity3d/ads/core/domain/GetFileExtensionFromUrl;Lcom/unity3d/services/core/network/core/HttpClient;)V", "downloadFile", "Lcom/unity3d/services/core/network/model/HttpResponse;", "url", "", "priority", "", "(Ljava/lang/String;Ljava/lang/Integer;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "getFile", "Lcom/unity3d/ads/core/data/model/CacheResult;", "cachePath", "Ljava/io/File;", "fileName", "(Ljava/io/File;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Integer;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "saveToCache", "", "dest", "body", "", "(Ljava/io/File;Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "unity-ads_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
/* compiled from: AndroidRemoteCacheDataSource.kt */
public final class AndroidRemoteCacheDataSource implements CacheDataSource {
    private final CreateFile createFile;
    private final GetFileExtensionFromUrl getFileExtensionFromUrl;
    private final HttpClient httpClient;
    private final CoroutineDispatcher ioDispatcher;

    public AndroidRemoteCacheDataSource(CoroutineDispatcher coroutineDispatcher, CreateFile createFile, GetFileExtensionFromUrl getFileExtensionFromUrl, HttpClient httpClient) {
        Intrinsics.checkNotNullParameter(coroutineDispatcher, "ioDispatcher");
        Intrinsics.checkNotNullParameter(createFile, "createFile");
        Intrinsics.checkNotNullParameter(getFileExtensionFromUrl, "getFileExtensionFromUrl");
        Intrinsics.checkNotNullParameter(httpClient, "httpClient");
        this.ioDispatcher = coroutineDispatcher;
        this.createFile = createFile;
        this.getFileExtensionFromUrl = getFileExtensionFromUrl;
        this.httpClient = httpClient;
    }

    private final Object saveToCache(File file, Object obj, Continuation<? super Unit> continuation) {
        Object withContext = BuildersKt.withContext(this.ioDispatcher, new AndroidRemoteCacheDataSource$saveToCache$2(obj, file, null), continuation);
        return withContext == IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED() ? withContext : Unit.INSTANCE;
    }

    /* DevToolsApp WARNING: Removed duplicated region for block: B:51:0x0116  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:49:0x010c  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:20:0x007a  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:8:0x002c  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:33:0x00b2  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:32:0x00b0  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:59:0x0144  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:36:0x00bf  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:49:0x010c  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:51:0x0116  */
    public java.lang.Object getFile(java.io.File r15, java.lang.String r16, java.lang.String r17, java.lang.Integer r18, kotlin.coroutines.Continuation<? super com.unity3d.ads.core.data.model.CacheResult> r19) {
        /*
        r14 = this;
        r1 = r14;
        r0 = r17;
        r2 = r18;
        r3 = r19;
        r4 = r3 instanceof com.unity3d.ads.core.data.datasource.AndroidRemoteCacheDataSource$getFile$1;
        if (r4 == 0) goto L_0x001b;
    L_0x000b:
        r4 = r3;
        r4 = (com.unity3d.ads.core.data.datasource.AndroidRemoteCacheDataSource$getFile$1) r4;
        r5 = r4.label;
        r6 = -2147483648; // 0xffffffff80000000 float:-0.0 double:NaN;
        r5 = r5 & r6;
        if (r5 == 0) goto L_0x001b;
    L_0x0015:
        r3 = r4.label;
        r3 = r3 - r6;
        r4.label = r3;
        goto L_0x0020;
    L_0x001b:
        r4 = new com.unity3d.ads.core.data.datasource.AndroidRemoteCacheDataSource$getFile$1;
        r4.<init>(r14, r3);
    L_0x0020:
        r3 = r4.result;
        r5 = kotlin.coroutines.intrinsics.IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED();
        r6 = r4.label;
        r7 = 2;
        r8 = 1;
        if (r6 == 0) goto L_0x007a;
    L_0x002c:
        if (r6 == r8) goto L_0x005e;
    L_0x002e:
        if (r6 != r7) goto L_0x0056;
    L_0x0030:
        r0 = r4.L$5;
        r2 = r0;
        r2 = (java.io.File) r2;
        r0 = r4.L$4;
        r5 = r0;
        r5 = (java.lang.String) r5;
        r0 = r4.L$3;
        r6 = r0;
        r6 = (com.unity3d.services.core.network.model.HttpResponse) r6;
        r0 = r4.L$2;
        r7 = r0;
        r7 = (java.lang.Integer) r7;
        r0 = r4.L$1;
        r8 = r0;
        r8 = (java.lang.String) r8;
        r0 = r4.L$0;
        r4 = r0;
        r4 = (java.lang.String) r4;
        kotlin.ResultKt.throwOnFailure(r3);	 Catch:{ all -> 0x0053 }
        goto L_0x00e9;
    L_0x0053:
        r0 = move-exception;
        goto L_0x00f7;
    L_0x0056:
        r0 = new java.lang.IllegalStateException;
        r2 = "call to 'resume' before 'invoke' with coroutine";
        r0.<init>(r2);
        throw r0;
    L_0x005e:
        r0 = r4.L$4;
        r0 = (java.lang.Integer) r0;
        r2 = r4.L$3;
        r2 = (java.lang.String) r2;
        r6 = r4.L$2;
        r6 = (java.lang.String) r6;
        r8 = r4.L$1;
        r8 = (java.io.File) r8;
        r9 = r4.L$0;
        r9 = (com.unity3d.ads.core.data.datasource.AndroidRemoteCacheDataSource) r9;
        kotlin.ResultKt.throwOnFailure(r3);	 Catch:{ Exception -> 0x0151 }
        r13 = r8;
        r8 = r0;
        r0 = r3;
        r3 = r13;
        goto L_0x00a4;
    L_0x007a:
        kotlin.ResultKt.throwOnFailure(r3);
        if (r0 != 0) goto L_0x0089;
    L_0x007f:
        r0 = new com.unity3d.ads.core.data.model.CacheResult$Failure;
        r2 = com.unity3d.ads.core.data.model.CacheError.MALFORMED_URL;
        r3 = com.unity3d.ads.core.data.model.CacheSource.REMOTE;
        r0.<init>(r2, r3);
        return r0;
    L_0x0089:
        r4.L$0 = r1;	 Catch:{ Exception -> 0x0151 }
        r3 = r15;
        r4.L$1 = r3;	 Catch:{ Exception -> 0x0151 }
        r6 = r16;
        r4.L$2 = r6;	 Catch:{ Exception -> 0x0151 }
        r4.L$3 = r0;	 Catch:{ Exception -> 0x0151 }
        r4.L$4 = r2;	 Catch:{ Exception -> 0x0151 }
        r4.label = r8;	 Catch:{ Exception -> 0x0151 }
        r8 = r14.downloadFile(r0, r2, r4);	 Catch:{ Exception -> 0x0151 }
        if (r8 != r5) goto L_0x009f;
    L_0x009e:
        return r5;
    L_0x009f:
        r9 = r1;
        r13 = r2;
        r2 = r0;
        r0 = r8;
        r8 = r13;
    L_0x00a4:
        r10 = r0;
        r10 = (com.unity3d.services.core.network.model.HttpResponse) r10;	 Catch:{ Exception -> 0x0151 }
        r0 = r2;
        r0 = (java.lang.CharSequence) r0;
        r0 = r0.length();
        if (r0 != 0) goto L_0x00b2;
    L_0x00b0:
        r0 = 0;
        goto L_0x00b8;
    L_0x00b2:
        r0 = r9.getFileExtensionFromUrl;
        r0 = r0.invoke(r2);
    L_0x00b8:
        r11 = r0;
        r0 = com.unity3d.services.core.network.model.HttpResponseKt.isSuccessful(r10);
        if (r0 == 0) goto L_0x0144;
    L_0x00bf:
        r0 = r9.createFile;
        r3 = r0.invoke(r3, r6);
        r0 = kotlin.Result.Companion;	 Catch:{ all -> 0x00f0 }
        r0 = r9;
        r0 = (com.unity3d.ads.core.data.datasource.AndroidRemoteCacheDataSource) r0;	 Catch:{ all -> 0x00f0 }
        r0 = r10.getBody();	 Catch:{ all -> 0x00f0 }
        r4.L$0 = r6;	 Catch:{ all -> 0x00f0 }
        r4.L$1 = r2;	 Catch:{ all -> 0x00f0 }
        r4.L$2 = r8;	 Catch:{ all -> 0x00f0 }
        r4.L$3 = r10;	 Catch:{ all -> 0x00f0 }
        r4.L$4 = r11;	 Catch:{ all -> 0x00f0 }
        r4.L$5 = r3;	 Catch:{ all -> 0x00f0 }
        r4.label = r7;	 Catch:{ all -> 0x00f0 }
        r0 = r9.saveToCache(r3, r0, r4);	 Catch:{ all -> 0x00f0 }
        if (r0 != r5) goto L_0x00e3;
    L_0x00e2:
        return r5;
    L_0x00e3:
        r4 = r6;
        r7 = r8;
        r6 = r10;
        r5 = r11;
        r8 = r2;
        r2 = r3;
    L_0x00e9:
        r0 = kotlin.Unit.INSTANCE;	 Catch:{ all -> 0x0053 }
        r0 = kotlin.Result.m17constructor-impl(r0);	 Catch:{ all -> 0x0053 }
        goto L_0x0101;
    L_0x00f0:
        r0 = move-exception;
        r4 = r6;
        r7 = r8;
        r6 = r10;
        r5 = r11;
        r8 = r2;
        r2 = r3;
    L_0x00f7:
        r3 = kotlin.Result.Companion;
        r0 = kotlin.ResultKt.createFailure(r0);
        r0 = kotlin.Result.m17constructor-impl(r0);
    L_0x0101:
        r3 = r6;
        r6 = r2;
        r2 = r5;
        r5 = r4;
        r4 = r8;
        r0 = kotlin.Result.m20exceptionOrNull-impl(r0);
        if (r0 == 0) goto L_0x0116;
    L_0x010c:
        r0 = new com.unity3d.ads.core.data.model.CacheResult$Failure;
        r2 = com.unity3d.ads.core.data.model.CacheError.FILE_STATE_WRONG;
        r3 = com.unity3d.ads.core.data.model.CacheSource.REMOTE;
        r0.<init>(r2, r3);
        return r0;
    L_0x0116:
        r0 = new com.unity3d.ads.core.data.model.CachedFile;
        if (r2 != 0) goto L_0x011c;
    L_0x011a:
        r2 = "";
    L_0x011c:
        r8 = r2;
        r9 = r3.getContentSize();
        r11 = r3.getProtocol();
        if (r7 == 0) goto L_0x012c;
    L_0x0127:
        r2 = r7.intValue();
        goto L_0x012f;
    L_0x012c:
        r2 = 2147483647; // 0x7fffffff float:NaN double:1.060997895E-314;
    L_0x012f:
        r12 = r2;
        r3 = "";
        r2 = r0;
        r7 = r8;
        r8 = r9;
        r10 = r11;
        r11 = r12;
        r2.<init>(r3, r4, r5, r6, r7, r8, r10, r11);
        r2 = new com.unity3d.ads.core.data.model.CacheResult$Success;
        r3 = com.unity3d.ads.core.data.model.CacheSource.REMOTE;
        r2.<init>(r0, r3);
        r2 = (com.unity3d.ads.core.data.model.CacheResult) r2;
        goto L_0x0150;
    L_0x0144:
        r0 = new com.unity3d.ads.core.data.model.CacheResult$Failure;
        r2 = com.unity3d.ads.core.data.model.CacheError.NETWORK_ERROR;
        r3 = com.unity3d.ads.core.data.model.CacheSource.REMOTE;
        r0.<init>(r2, r3);
        r2 = r0;
        r2 = (com.unity3d.ads.core.data.model.CacheResult) r2;
    L_0x0150:
        return r2;
    L_0x0151:
        r0 = new com.unity3d.ads.core.data.model.CacheResult$Failure;
        r2 = com.unity3d.ads.core.data.model.CacheError.NETWORK_ERROR;
        r3 = com.unity3d.ads.core.data.model.CacheSource.REMOTE;
        r0.<init>(r2, r3);
        return r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.unity3d.ads.core.data.datasource.AndroidRemoteCacheDataSource.getFile(java.io.File, java.lang.String, java.lang.String, java.lang.Integer, kotlin.coroutines.Continuation):java.lang.Object");
    }

    private final Object downloadFile(String str, Integer num, Continuation<? super HttpResponse> continuation) {
        HttpRequest httpRequest = r0;
        HttpRequest httpRequest2 = new HttpRequest(str, null, null, null, null, null, null, null, null, 0, 0, 0, 0, false, null, null, num != null ? num.intValue() : Integer.MAX_VALUE, 65534, null);
        return this.httpClient.execute(httpRequest, continuation);
    }
}
