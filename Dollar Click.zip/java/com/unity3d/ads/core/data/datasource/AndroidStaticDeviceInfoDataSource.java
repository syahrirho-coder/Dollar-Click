package com.unity3d.ads.core.data.datasource;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.content.pm.Signature;
import android.content.res.Resources;
import android.hardware.Sensor;
import android.hardware.SensorManager;
import android.media.MediaCodecInfo;
import android.media.MediaCodecList;
import android.os.Build;
import android.os.Build.VERSION;
import android.os.SystemClock;
import android.os.ext.SdkExtensions;
import android.telephony.TelephonyManager;
import android.util.DisplayMetrics;
import android.webkit.WebSettings;
import com.unity3d.ads.core.data.model.StorageType;
import com.unity3d.services.UnityAdsConstants.Preferences;
import com.unity3d.services.core.device.AdvertisingId;
import com.unity3d.services.core.device.Device.MemoryInfoType;
import com.unity3d.services.core.device.MimeTypes;
import com.unity3d.services.core.device.OpenAdvertisingId;
import com.unity3d.services.core.log.DeviceLog;
import com.unity3d.services.core.misc.Utilities;
import com.unity3d.services.core.preferences.AndroidPreferences;
import com.unity3d.services.core.properties.ClientProperties;
import com.unity3d.services.core.properties.MadeWithUnityDetector;
import com.unity3d.services.core.properties.SdkProperties;
import gatewayprotocol.v1.StaticDeviceInfoKt;
import gatewayprotocol.v1.StaticDeviceInfoKt.AndroidKt;
import gatewayprotocol.v1.StaticDeviceInfoKt.Dsl;
import gatewayprotocol.v1.StaticDeviceInfoOuterClass.StaticDeviceInfo;
import gatewayprotocol.v1.StaticDeviceInfoOuterClass.StaticDeviceInfo.Android;
import gatewayprotocol.v1.StaticDeviceInfoOuterClass.StaticDeviceInfo.Builder;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.security.MessageDigest;
import java.security.cert.Certificate;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.ListIterator;
import java.util.Locale;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.security.auth.x500.X500Principal;
import kotlin.Deprecated;
import kotlin.Metadata;
import kotlin.coroutines.Continuation;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.Regex;

@Metadata(d1 = {"\u0000\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010 \n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\t\n\u0002\b\u000e\n\u0002\u0010\u0007\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\n\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u000b\n\u0002\u0018\u0002\n\u0002\b\u000b\n\u0002\u0010\u000b\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\f\u0018\u0000 m2\u00020\u0001:\u0001mB%\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\u0006\u0010\b\u001a\u00020\t¢\u0006\u0002\u0010\nJ\u001f\u0010\u0015\u001a\u00020\u00142\f\u0010\u0016\u001a\b\u0012\u0004\u0012\u00020\u000e0\u0017H@ø\u0001\u0000¢\u0006\u0002\u0010\u0018J\b\u0010\u0019\u001a\u00020\u001aH\u0002J\b\u0010\u001b\u001a\u00020\u0014H\u0016J\u0006\u0010\u001c\u001a\u00020\u000eJ\b\u0010\u001d\u001a\u00020\u001eH\u0002J\b\u0010\u001f\u001a\u00020\u000eH\u0016J\b\u0010 \u001a\u00020!H\u0002J\b\u0010\"\u001a\u00020\u000eH\u0002J\u0013\u0010#\u001a\u0004\u0018\u00010\u000eH@ø\u0001\u0000¢\u0006\u0002\u0010$J\u0006\u0010%\u001a\u00020\u000eJ\u0006\u0010&\u001a\u00020\u000eJ\u0006\u0010'\u001a\u00020\u000eJ\b\u0010(\u001a\u0004\u0018\u00010\u000eJ\b\u0010)\u001a\u0004\u0018\u00010\u000eJ\b\u0010*\u001a\u00020!H\u0002J\b\u0010+\u001a\u00020\u000eH\u0002J\b\u0010,\u001a\u00020\u000eH\u0003J\u0006\u0010-\u001a\u00020\u000eJ\u0006\u0010.\u001a\u00020\u000eJ\b\u0010/\u001a\u000200H\u0002J\b\u00101\u001a\u00020\u001eH\u0002J\u0012\u00102\u001a\u0004\u0018\u0001032\u0006\u00104\u001a\u000205H\u0002J\b\u00106\u001a\u00020\u000eH\u0002J\u0013\u00107\u001a\u0004\u0018\u00010\u000eH@ø\u0001\u0000¢\u0006\u0002\u0010$J\b\u00108\u001a\u00020\u000eH\u0002J\u0006\u00109\u001a\u00020\u000eJ\u0006\u0010:\u001a\u00020\u000eJ\u0011\u0010;\u001a\u00020\u000eH@ø\u0001\u0000¢\u0006\u0002\u0010$J\b\u0010<\u001a\u00020\u000eH\u0003J\b\u0010=\u001a\u00020\u000eH\u0016J\u0010\u0010>\u001a\u00020!2\u0006\u0010?\u001a\u00020@H\u0002J\u0012\u0010A\u001a\u00020!2\b\u0010B\u001a\u0004\u0018\u00010\u000eH\u0002J\b\u0010C\u001a\u00020\u000eH\u0016J\u000e\u0010D\u001a\b\u0012\u0004\u0012\u00020\u000e0EH\u0003J\u000e\u0010F\u001a\b\u0012\u0004\u0012\u00020\u000e0\u0017H\u0002J\b\u0010G\u001a\u00020\u000eH\u0002J\b\u0010H\u001a\u00020\u000eH\u0016J\b\u0010I\u001a\u00020\u001eH\u0002J\b\u0010J\u001a\u00020\u000eH\u0002J\u0006\u0010K\u001a\u00020\u000eJ\b\u0010L\u001a\u00020\u001eH\u0002J\b\u0010M\u001a\u00020\u001eH\u0002J\b\u0010N\u001a\u00020\u001eH\u0002J\b\u0010O\u001a\u00020\u001eH\u0002J\f\u0010P\u001a\b\u0012\u0004\u0012\u00020Q0\u0017J\b\u0010R\u001a\u00020\u000eH\u0002J\u001e\u0010S\u001a\b\u0012\u0004\u0012\u00020\u000e0\u00172\u000e\b\u0002\u0010\u0016\u001a\b\u0012\u0004\u0012\u00020\u000e0\u0017H\u0002J\f\u0010T\u001a\b\u0012\u0004\u0012\u00020\u000e0\u0017J\b\u0010U\u001a\u00020!H\u0016J\u0006\u0010V\u001a\u00020!J\u0010\u0010W\u001a\u00020!2\b\u0010X\u001a\u0004\u0018\u000103J\b\u0010Y\u001a\u00020\u001eH\u0002J\b\u0010Z\u001a\u00020\u000eH\u0002J\b\u0010[\u001a\u00020\u000eH\u0002J\u0006\u0010\\\u001a\u00020]J\u0006\u0010^\u001a\u00020]J\b\u0010_\u001a\u00020]H\u0002J\u001a\u0010`\u001a\u00020]2\u0006\u0010a\u001a\u00020b2\b\u0010c\u001a\u0004\u0018\u00010\u000eH\u0002J\u0010\u0010d\u001a\u00020]2\u0006\u0010a\u001a\u00020bH\u0003J\u0006\u0010e\u001a\u00020]J\b\u0010f\u001a\u00020]H\u0002J\u001a\u0010g\u001a\u00020]2\u0006\u0010a\u001a\u00020b2\b\u0010c\u001a\u0004\u0018\u00010\u000eH\u0002J\u0010\u0010h\u001a\u00020]2\u0006\u0010a\u001a\u00020bH\u0003J\b\u0010i\u001a\u00020]H\u0002J\u0010\u0010j\u001a\u00020]2\u0006\u0010k\u001a\u00020\u000eH\u0002J\u0018\u0010l\u001a\b\u0012\u0004\u0012\u00020b0\u00172\b\u0010c\u001a\u0004\u0018\u00010\u000eH\u0002R\u000e\u0010\u000b\u001a\u00020\fX\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0007X\u0004¢\u0006\u0002\n\u0000R\u0016\u0010\r\u001a\u0004\u0018\u00010\u000e8VX\u0004¢\u0006\u0006\u001a\u0004\b\u000f\u0010\u0010R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0011\u0010\u0012R\u000e\u0010\u0004\u001a\u00020\u0005X\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0013\u001a\u00020\u0014X\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\tX\u0004¢\u0006\u0002\n\u0000\u0002\u0004\n\u0002\b\u0019¨\u0006n"}, d2 = {"Lcom/unity3d/ads/core/data/datasource/AndroidStaticDeviceInfoDataSource;", "Lcom/unity3d/ads/core/data/datasource/StaticDeviceInfoDataSource;", "context", "Landroid/content/Context;", "glInfoStore", "Lcom/unity3d/ads/core/data/datasource/ByteStringDataSource;", "analyticsDataSource", "Lcom/unity3d/ads/core/data/datasource/AnalyticsDataSource;", "storeDataSource", "Lcom/unity3d/ads/core/data/datasource/StoreDataSource;", "(Landroid/content/Context;Lcom/unity3d/ads/core/data/datasource/ByteStringDataSource;Lcom/unity3d/ads/core/data/datasource/AnalyticsDataSource;Lcom/unity3d/ads/core/data/datasource/StoreDataSource;)V", "DEBUG_CERT", "Ljavax/security/auth/x500/X500Principal;", "analyticsUserId", "", "getAnalyticsUserId", "()Ljava/lang/String;", "getContext", "()Landroid/content/Context;", "staticDeviceInfo", "Lgatewayprotocol/v1/StaticDeviceInfoOuterClass$StaticDeviceInfo;", "fetch", "additionalStores", "", "(Ljava/util/List;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "fetchAndroidStaticDeviceInfo", "Lgatewayprotocol/v1/StaticDeviceInfoOuterClass$StaticDeviceInfo$Android;", "fetchCached", "getAdvertisingTrackingId", "getApiLevel", "", "getAppName", "getAppStartTime", "", "getAppVersion", "getAuid", "(Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "getBoard", "getBootloader", "getBrand", "getBuildId", "getBuildVersionIncremental", "getCPUCount", "getCPUModel", "getCertificateFingerprint", "getDevice", "getDisplay", "getDisplayMetricDensity", "", "getExtensionVersion", "getFileForStorageType", "Ljava/io/File;", "storageType", "Lcom/unity3d/ads/core/data/model/StorageType;", "getFingerprint", "getGPUModel", "getGameId", "getHardware", "getHost", "getIdfi", "getInstallerPackageName", "getManufacturer", "getMemoryInfo", "infoType", "Lcom/unity3d/services/core/device/Device$MemoryInfoType;", "getMemoryValueFromString", "memVal", "getModel", "getNewAbiList", "Ljava/util/ArrayList;", "getOldAbiList", "getOpenAdvertisingTrackingId", "getOsVersion", "getPhoneType", "getPlatform", "getProduct", "getScreenDensity", "getScreenHeight", "getScreenLayout", "getScreenWidth", "getSensorList", "Landroid/hardware/Sensor;", "getSimOperator", "getStores", "getSupportedAbis", "getSystemBootTime", "getTotalMemory", "getTotalSpace", "file", "getVersionCode", "getVersionName", "getWebViewUserAgent", "hasX264Decoder", "", "hasX265Decoder", "isAppDebuggable", "isHardwareAccelerated", "codecInfo", "Landroid/media/MediaCodecInfo;", "mimeType", "isHardwareAcceleratedV29", "isLimitOpenAdTrackingEnabled", "isRooted", "isSoftwareOnly", "isSoftwareOnlyV29", "isTestMode", "searchPathForBinary", "binary", "selectAllDecodeCodecs", "Companion", "unity-ads_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
/* compiled from: AndroidStaticDeviceInfoDataSource.kt */
public final class AndroidStaticDeviceInfoDataSource implements StaticDeviceInfoDataSource {
    public static final String ALGORITHM_SHA1 = "SHA-1";
    public static final String APP_VERSION_FAKE = "FakeVersionName";
    public static final String BINARY_SU = "su";
    public static final String CERTIFICATE_TYPE_X509 = "X.509";
    public static final Companion Companion = new Companion();
    public static final String ENVIRONMENT_VARIABLE_PATH = "PATH";
    public static final String PLATFORM_ANDROID = "android";
    public static final String STORE_GOOGLE = "google";
    private final X500Principal DEBUG_CERT = new X500Principal("CN=Android Debug,O=Android,C=US");
    private final AnalyticsDataSource analyticsDataSource;
    private final Context context;
    private final ByteStringDataSource glInfoStore;
    private StaticDeviceInfo staticDeviceInfo;
    private final StoreDataSource storeDataSource;

    @Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0007\b\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002R\u000e\u0010\u0003\u001a\u00020\u0004XT¢\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0004XT¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0004XT¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0004XT¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\u0004XT¢\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\u0004XT¢\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u0004XT¢\u0006\u0002\n\u0000¨\u0006\u000b"}, d2 = {"Lcom/unity3d/ads/core/data/datasource/AndroidStaticDeviceInfoDataSource$Companion;", "", "()V", "ALGORITHM_SHA1", "", "APP_VERSION_FAKE", "BINARY_SU", "CERTIFICATE_TYPE_X509", "ENVIRONMENT_VARIABLE_PATH", "PLATFORM_ANDROID", "STORE_GOOGLE", "unity-ads_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
    /* compiled from: AndroidStaticDeviceInfoDataSource.kt */
    public static final class Companion {
        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        private Companion() {
        }
    }

    @Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
    /* compiled from: AndroidStaticDeviceInfoDataSource.kt */
    public /* synthetic */ class WhenMappings {
        public static final /* synthetic */ int[] $EnumSwitchMapping$0;
        public static final /* synthetic */ int[] $EnumSwitchMapping$1;

        /* DevToolsApp WARNING: Failed to process nested try/catch */
        /* DevToolsApp WARNING: Missing block: B:11:0x0032, code:
            $EnumSwitchMapping$1 = r0;
     */
        /* DevToolsApp WARNING: Missing block: B:12:0x0034, code:
            return;
     */
        static {
            /*
            r0 = com.unity3d.services.core.device.Device.MemoryInfoType.values();
            r0 = r0.length;
            r0 = new int[r0];
            r1 = 1;
            r2 = com.unity3d.services.core.device.Device.MemoryInfoType.TOTAL_MEMORY;	 Catch:{ NoSuchFieldError -> 0x0010 }
            r2 = r2.ordinal();	 Catch:{ NoSuchFieldError -> 0x0010 }
            r0[r2] = r1;	 Catch:{ NoSuchFieldError -> 0x0010 }
        L_0x0010:
            r2 = 2;
            r3 = com.unity3d.services.core.device.Device.MemoryInfoType.FREE_MEMORY;	 Catch:{ NoSuchFieldError -> 0x0019 }
            r3 = r3.ordinal();	 Catch:{ NoSuchFieldError -> 0x0019 }
            r0[r3] = r2;	 Catch:{ NoSuchFieldError -> 0x0019 }
        L_0x0019:
            $EnumSwitchMapping$0 = r0;
            r0 = com.unity3d.ads.core.data.model.StorageType.values();
            r0 = r0.length;
            r0 = new int[r0];
            r3 = com.unity3d.ads.core.data.model.StorageType.INTERNAL;	 Catch:{ NoSuchFieldError -> 0x002a }
            r3 = r3.ordinal();	 Catch:{ NoSuchFieldError -> 0x002a }
            r0[r3] = r1;	 Catch:{ NoSuchFieldError -> 0x002a }
        L_0x002a:
            r1 = com.unity3d.ads.core.data.model.StorageType.EXTERNAL;	 Catch:{ NoSuchFieldError -> 0x0032 }
            r1 = r1.ordinal();	 Catch:{ NoSuchFieldError -> 0x0032 }
            r0[r1] = r2;	 Catch:{ NoSuchFieldError -> 0x0032 }
        L_0x0032:
            $EnumSwitchMapping$1 = r0;
            return;
            */
            throw new UnsupportedOperationException("Method not decompiled: com.unity3d.ads.core.data.datasource.AndroidStaticDeviceInfoDataSource.WhenMappings.<clinit>():void");
        }
    }

    private final int getVersionCode() {
        return 41500;
    }

    public AndroidStaticDeviceInfoDataSource(Context context, ByteStringDataSource byteStringDataSource, AnalyticsDataSource analyticsDataSource, StoreDataSource storeDataSource) {
        Intrinsics.checkNotNullParameter(context, "context");
        Intrinsics.checkNotNullParameter(byteStringDataSource, "glInfoStore");
        Intrinsics.checkNotNullParameter(analyticsDataSource, "analyticsDataSource");
        Intrinsics.checkNotNullParameter(storeDataSource, "storeDataSource");
        this.context = context;
        this.glInfoStore = byteStringDataSource;
        this.analyticsDataSource = analyticsDataSource;
        this.storeDataSource = storeDataSource;
        gatewayprotocol.v1.StaticDeviceInfoKt.Dsl.Companion companion = Dsl.Companion;
        Builder newBuilder = StaticDeviceInfo.newBuilder();
        Intrinsics.checkNotNullExpressionValue(newBuilder, "newBuilder()");
        Dsl _create = companion._create(newBuilder);
        _create.setBundleId(getAppName());
        _create.setBundleVersion(getAppVersion());
        _create.setAppDebuggable(isAppDebuggable());
        _create.setRooted(isRooted());
        _create.setOsVersion(getOsVersion());
        _create.setDeviceMake(getManufacturer());
        _create.setDeviceModel(getModel());
        _create.setWebviewUa(getWebViewUserAgent());
        _create.setScreenDensity(getScreenDensity());
        _create.setScreenWidth(getScreenWidth());
        _create.setScreenHeight(getScreenHeight());
        _create.setScreenSize(getScreenLayout());
        _create.addAllStores(_create.getStores(), getStores$default(this, null, 1, null));
        _create.setTotalDiskSpace(getTotalSpace(getFileForStorageType(StorageType.EXTERNAL)));
        _create.setTotalRamMemory(getTotalMemory());
        _create.setCpuModel(getCPUModel());
        _create.setCpuCount(getCPUCount());
        _create.setAndroid(fetchAndroidStaticDeviceInfo());
        _create.setMadeWithUnity(MadeWithUnityDetector.isMadeWithUnity());
        this.staticDeviceInfo = _create._build();
    }

    public final Context getContext() {
        return this.context;
    }

    /* DevToolsApp WARNING: Removed duplicated region for block: B:12:0x003a  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:8:0x0024  */
    public java.lang.Object fetch(java.util.List<java.lang.String> r5, kotlin.coroutines.Continuation<? super gatewayprotocol.v1.StaticDeviceInfoOuterClass.StaticDeviceInfo> r6) {
        /*
        r4 = this;
        r0 = r6 instanceof com.unity3d.ads.core.data.datasource.AndroidStaticDeviceInfoDataSource$fetch$1;
        if (r0 == 0) goto L_0x0014;
    L_0x0004:
        r0 = r6;
        r0 = (com.unity3d.ads.core.data.datasource.AndroidStaticDeviceInfoDataSource$fetch$1) r0;
        r1 = r0.label;
        r2 = -2147483648; // 0xffffffff80000000 float:-0.0 double:NaN;
        r1 = r1 & r2;
        if (r1 == 0) goto L_0x0014;
    L_0x000e:
        r6 = r0.label;
        r6 = r6 - r2;
        r0.label = r6;
        goto L_0x0019;
    L_0x0014:
        r0 = new com.unity3d.ads.core.data.datasource.AndroidStaticDeviceInfoDataSource$fetch$1;
        r0.<init>(r4, r6);
    L_0x0019:
        r6 = r0.result;
        r1 = kotlin.coroutines.intrinsics.IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED();
        r2 = r0.label;
        r3 = 1;
        if (r2 == 0) goto L_0x003a;
    L_0x0024:
        if (r2 != r3) goto L_0x0032;
    L_0x0026:
        r5 = r0.L$1;
        r5 = (java.util.List) r5;
        r0 = r0.L$0;
        r0 = (com.unity3d.ads.core.data.datasource.AndroidStaticDeviceInfoDataSource) r0;
        kotlin.ResultKt.throwOnFailure(r6);
        goto L_0x005f;
    L_0x0032:
        r5 = new java.lang.IllegalStateException;
        r6 = "call to 'resume' before 'invoke' with coroutine";
        r5.<init>(r6);
        throw r5;
    L_0x003a:
        kotlin.ResultKt.throwOnFailure(r6);
        r6 = r4.staticDeviceInfo;
        r6 = r6.getGpuModel();
        r6 = (java.lang.CharSequence) r6;
        if (r6 == 0) goto L_0x0051;
    L_0x0047:
        r6 = r6.length();
        if (r6 != 0) goto L_0x004e;
    L_0x004d:
        goto L_0x0051;
    L_0x004e:
        r5 = r4.staticDeviceInfo;
        return r5;
    L_0x0051:
        r0.L$0 = r4;
        r0.L$1 = r5;
        r0.label = r3;
        r6 = r4.getGPUModel(r0);
        if (r6 != r1) goto L_0x005e;
    L_0x005d:
        return r1;
    L_0x005e:
        r0 = r4;
    L_0x005f:
        r6 = (java.lang.String) r6;
        r1 = r6;
        r1 = (java.lang.CharSequence) r1;
        if (r1 == 0) goto L_0x009e;
    L_0x0066:
        r1 = r1.length();
        if (r1 != 0) goto L_0x006d;
    L_0x006c:
        goto L_0x009e;
    L_0x006d:
        r1 = r0.staticDeviceInfo;
        r2 = gatewayprotocol.v1.StaticDeviceInfoKt.Dsl.Companion;
        r1 = r1.toBuilder();
        r3 = "this.toBuilder()";
        kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r1, r3);
        r1 = (gatewayprotocol.v1.StaticDeviceInfoOuterClass.StaticDeviceInfo.Builder) r1;
        r1 = r2._create(r1);
        r1.setGpuModel(r6);
        r6 = r1.getStores();
        r1.clearStores(r6);
        r6 = r1.getStores();
        r5 = r0.getStores(r5);
        r5 = (java.lang.Iterable) r5;
        r1.addAllStores(r6, r5);
        r5 = r1._build();
        r0.staticDeviceInfo = r5;
        return r5;
    L_0x009e:
        r5 = r0.staticDeviceInfo;
        return r5;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.unity3d.ads.core.data.datasource.AndroidStaticDeviceInfoDataSource.fetch(java.util.List, kotlin.coroutines.Continuation):java.lang.Object");
    }

    public StaticDeviceInfo fetchCached() {
        return this.staticDeviceInfo;
    }

    private final Android fetchAndroidStaticDeviceInfo() {
        StaticDeviceInfoKt staticDeviceInfoKt = StaticDeviceInfoKt.INSTANCE;
        gatewayprotocol.v1.StaticDeviceInfoKt.AndroidKt.Dsl.Companion companion = AndroidKt.Dsl.Companion;
        Android.Builder newBuilder = Android.newBuilder();
        Intrinsics.checkNotNullExpressionValue(newBuilder, "newBuilder()");
        AndroidKt.Dsl _create = companion._create(newBuilder);
        _create.setApiLevel(getApiLevel());
        _create.setVersionCode(getVersionCode());
        _create.setAndroidFingerprint(getFingerprint());
        _create.setAppInstaller(getInstallerPackageName());
        _create.setApkDeveloperSigningCertificateHash(getCertificateFingerprint());
        _create.setBuildBoard(getBoard());
        _create.setBuildBrand(getBrand());
        _create.setBuildDevice(getDevice());
        _create.setBuildDisplay(getDisplay());
        _create.setBuildFingerprint(getFingerprint());
        _create.setBuildHardware(getHardware());
        _create.setBuildHost(getHost());
        _create.setBuildBootloader(getBootloader());
        _create.setBuildProduct(getProduct());
        _create.setExtensionVersion(getExtensionVersion());
        String buildId = getBuildId();
        if (buildId != null) {
            _create.setBuildId(buildId);
        }
        _create.setPhoneType(getPhoneType());
        _create.setSimOperator(getSimOperator());
        return _create._build();
    }

    private final int getApiLevel() {
        return VERSION.SDK_INT;
    }

    public String getOsVersion() {
        String str = VERSION.RELEASE;
        return str == null ? "" : str;
    }

    public String getManufacturer() {
        String str = Build.MANUFACTURER;
        return str == null ? "" : str;
    }

    public String getModel() {
        String str = Build.MODEL;
        return str == null ? "" : str;
    }

    private final int getScreenLayout() {
        return this.context.getResources().getConfiguration().screenLayout;
    }

    public final String getAdvertisingTrackingId() {
        String advertisingTrackingId = AdvertisingId.getAdvertisingTrackingId();
        return advertisingTrackingId == null ? "" : advertisingTrackingId;
    }

    private final String getOpenAdvertisingTrackingId() {
        String openAdvertisingTrackingId = OpenAdvertisingId.getOpenAdvertisingTrackingId();
        return openAdvertisingTrackingId == null ? "" : openAdvertisingTrackingId;
    }

    public final boolean isLimitOpenAdTrackingEnabled() {
        return OpenAdvertisingId.getLimitedOpenAdTracking();
    }

    public Object getIdfi(Continuation<? super String> continuation) {
        String str = Preferences.PREF_NAME_IDFI;
        String str2 = Preferences.PREF_KEY_IDFI;
        Object string = AndroidPreferences.getString(str, str2);
        if (string == null) {
            string = null;
        }
        if (string != null) {
            return string;
        }
        String uuid = UUID.randomUUID().toString();
        AndroidPreferences.setString(str, str2, uuid);
        return uuid;
    }

    public String getAnalyticsUserId() {
        return this.analyticsDataSource.getUserId();
    }

    public long getSystemBootTime() {
        return (System.currentTimeMillis() - SystemClock.elapsedRealtime()) / ((long) 1000);
    }

    public Object getAuid(Continuation<? super String> continuation) {
        Object string = AndroidPreferences.getString(Preferences.PREF_NAME_AUID, "auid");
        return string == null ? null : string;
    }

    private final float getDisplayMetricDensity() {
        Resources resources = this.context.getResources();
        if (resources != null) {
            DisplayMetrics displayMetrics = resources.getDisplayMetrics();
            if (displayMetrics != null) {
                return displayMetrics.density;
            }
        }
        return 0.0f;
    }

    private final int getScreenDensity() {
        Resources resources = this.context.getResources();
        if (resources != null) {
            DisplayMetrics displayMetrics = resources.getDisplayMetrics();
            if (displayMetrics != null) {
                return displayMetrics.densityDpi;
            }
        }
        return -1;
    }

    private final int getScreenWidth() {
        Resources resources = this.context.getResources();
        if (resources != null) {
            DisplayMetrics displayMetrics = resources.getDisplayMetrics();
            if (displayMetrics != null) {
                return displayMetrics.widthPixels;
            }
        }
        return -1;
    }

    private final int getScreenHeight() {
        Resources resources = this.context.getResources();
        if (resources != null) {
            DisplayMetrics displayMetrics = resources.getDisplayMetrics();
            if (displayMetrics != null) {
                return displayMetrics.heightPixels;
            }
        }
        return -1;
    }

    private final boolean isRooted() {
        try {
            return searchPathForBinary(BINARY_SU);
        } catch (Exception e) {
            DeviceLog.exception("Rooted check failed", e);
            return false;
        }
    }

    private final boolean searchPathForBinary(String str) {
        String str2 = System.getenv(ENVIRONMENT_VARIABLE_PATH);
        if (str2 != null) {
            List split = new Regex(":").split(str2, 0);
            if (split != null) {
                if (!split.isEmpty()) {
                    ListIterator listIterator = split.listIterator(split.size());
                    while (listIterator.hasPrevious()) {
                        if (((String) listIterator.previous()).length() != 0) {
                            split = CollectionsKt___CollectionsKt.take(split, listIterator.nextIndex() + 1);
                            break;
                        }
                    }
                }
                split = CollectionsKt__CollectionsKt.emptyList();
                if (split != null) {
                    String[] strArr = (String[]) split.toArray(new String[0]);
                    if (strArr != null) {
                        for (String file : strArr) {
                            File file2 = new File(file);
                            if (file2.exists() && file2.isDirectory()) {
                                File[] listFiles = file2.listFiles();
                                if (listFiles != null) {
                                    for (File name : listFiles) {
                                        if (Intrinsics.areEqual(name.getName(), (Object) str)) {
                                            return true;
                                        }
                                    }
                                    continue;
                                } else {
                                    continue;
                                }
                            }
                        }
                    }
                }
            }
        }
        return false;
    }

    @Deprecated(message = "This constant was deprecated in API level 28. Use GET_SIGNING_CERTIFICATES instead")
    private final String getCertificateFingerprint() {
        try {
            Signature[] signatureArr = this.context.getPackageManager().getPackageInfo(this.context.getPackageName(), 64).signatures;
            if (signatureArr != null) {
                if ((signatureArr.length == 0 ? 1 : 0) == 0) {
                    Certificate generateCertificate = CertificateFactory.getInstance(CERTIFICATE_TYPE_X509).generateCertificate(new ByteArrayInputStream(signatureArr[0].toByteArray()));
                    Intrinsics.checkNotNull(generateCertificate, "null cannot be cast to non-null type java.security.cert.X509Certificate");
                    String toHexString = Utilities.toHexString(MessageDigest.getInstance(ALGORITHM_SHA1).digest(((X509Certificate) generateCertificate).getEncoded()));
                    Intrinsics.checkNotNullExpressionValue(toHexString, "toHexString(publicKey)");
                    return toHexString;
                }
            }
        } catch (Exception e) {
            DeviceLog.exception("Exception when signing certificate fingerprint", e);
        }
        return "";
    }

    public final String getBoard() {
        String str = Build.BOARD;
        return str == null ? "" : str;
    }

    public final String getBootloader() {
        String str = Build.BOOTLOADER;
        return str == null ? "" : str;
    }

    public final String getBrand() {
        String str = Build.BRAND;
        return str == null ? "" : str;
    }

    public final String getDisplay() {
        String str = Build.DISPLAY;
        return str == null ? "" : str;
    }

    public final String getDevice() {
        String str = Build.DEVICE;
        return str == null ? "" : str;
    }

    public final String getHardware() {
        String str = Build.HARDWARE;
        return str == null ? "" : str;
    }

    public final String getHost() {
        String str = Build.HOST;
        return str == null ? "" : str;
    }

    public final String getProduct() {
        String str = Build.PRODUCT;
        return str == null ? "" : str;
    }

    private final String getFingerprint() {
        String str = Build.FINGERPRINT;
        return str == null ? "" : str;
    }

    @Deprecated(message = "This method was deprecated in API level 30. use getInstallSourceInfo")
    private final String getInstallerPackageName() {
        String installerPackageName = this.context.getPackageManager().getInstallerPackageName(this.context.getPackageName());
        return installerPackageName == null ? "" : installerPackageName;
    }

    public final List<String> getSupportedAbis() {
        if (getApiLevel() < 21) {
            return getOldAbiList();
        }
        return getNewAbiList();
    }

    public final List<Sensor> getSensorList() {
        Object systemService = this.context.getSystemService("sensor");
        Intrinsics.checkNotNull(systemService, "null cannot be cast to non-null type android.hardware.SensorManager");
        List<Sensor> sensorList = ((SensorManager) systemService).getSensorList(-1);
        Intrinsics.checkNotNullExpressionValue(sensorList, "sensorManager.getSensorList(Sensor.TYPE_ALL)");
        return sensorList;
    }

    private final String getCPUModel() {
        if (VERSION.SDK_INT >= 31) {
            String str = Build.SOC_MODEL;
            Intrinsics.checkNotNullExpressionValue(str, "{\n            Build.SOC_MODEL\n        }");
            return str;
        }
        try {
            return (String) CollectionsKt___CollectionsKt.last(FilesKt__FileReadWriteKt.readLines$default(new File("/proc/cpuinfo"), null, 1, null));
        } catch (FileNotFoundException e) {
            DeviceLog.exception("Error reading CPU model", e);
            return "";
        }
    }

    private final long getCPUCount() {
        return (long) Runtime.getRuntime().availableProcessors();
    }

    /* DevToolsApp WARNING: Removed duplicated region for block: B:12:0x0032  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:8:0x0024  */
    private final java.lang.Object getGPUModel(kotlin.coroutines.Continuation<? super java.lang.String> r5) {
        /*
        r4 = this;
        r0 = r5 instanceof com.unity3d.ads.core.data.datasource.AndroidStaticDeviceInfoDataSource$getGPUModel$1;
        if (r0 == 0) goto L_0x0014;
    L_0x0004:
        r0 = r5;
        r0 = (com.unity3d.ads.core.data.datasource.AndroidStaticDeviceInfoDataSource$getGPUModel$1) r0;
        r1 = r0.label;
        r2 = -2147483648; // 0xffffffff80000000 float:-0.0 double:NaN;
        r1 = r1 & r2;
        if (r1 == 0) goto L_0x0014;
    L_0x000e:
        r5 = r0.label;
        r5 = r5 - r2;
        r0.label = r5;
        goto L_0x0019;
    L_0x0014:
        r0 = new com.unity3d.ads.core.data.datasource.AndroidStaticDeviceInfoDataSource$getGPUModel$1;
        r0.<init>(r4, r5);
    L_0x0019:
        r5 = r0.result;
        r1 = kotlin.coroutines.intrinsics.IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED();
        r2 = r0.label;
        r3 = 1;
        if (r2 == 0) goto L_0x0032;
    L_0x0024:
        if (r2 != r3) goto L_0x002a;
    L_0x0026:
        kotlin.ResultKt.throwOnFailure(r5);
        goto L_0x0040;
    L_0x002a:
        r5 = new java.lang.IllegalStateException;
        r0 = "call to 'resume' before 'invoke' with coroutine";
        r5.<init>(r0);
        throw r5;
    L_0x0032:
        kotlin.ResultKt.throwOnFailure(r5);
        r5 = r4.glInfoStore;
        r0.label = r3;
        r5 = r5.get(r0);
        if (r5 != r1) goto L_0x0040;
    L_0x003f:
        return r1;
    L_0x0040:
        r5 = (com.unity3d.ads.datastore.ByteStringStoreOuterClass.ByteStringStore) r5;
        r5 = r5.getData();
        r0 = kotlin.text.Charsets.UTF_8;
        r5 = r5.toString(r0);
        return r5;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.unity3d.ads.core.data.datasource.AndroidStaticDeviceInfoDataSource.getGPUModel(kotlin.coroutines.Continuation):java.lang.Object");
    }

    public final String getBuildId() {
        return Build.ID;
    }

    public final String getBuildVersionIncremental() {
        return VERSION.INCREMENTAL;
    }

    private final List<String> getOldAbiList() {
        List<String> arrayList = new ArrayList();
        String str = Build.CPU_ABI;
        Intrinsics.checkNotNullExpressionValue(str, "CPU_ABI");
        arrayList.add(str);
        str = Build.CPU_ABI2;
        Intrinsics.checkNotNullExpressionValue(str, "CPU_ABI2");
        arrayList.add(str);
        return arrayList;
    }

    private final ArrayList<String> getNewAbiList() {
        ArrayList<String> arrayList = new ArrayList();
        Object obj = Build.SUPPORTED_ABIS;
        Intrinsics.checkNotNullExpressionValue(obj, "SUPPORTED_ABIS");
        arrayList.addAll(CollectionsKt__CollectionsKt.listOf(Arrays.copyOf(obj, obj.length)));
        return arrayList;
    }

    private final String getWebViewUserAgent() {
        try {
            String defaultUserAgent = WebSettings.getDefaultUserAgent(this.context);
            Intrinsics.checkNotNullExpressionValue(defaultUserAgent, "{\n        WebSettings.ge…tUserAgent(context)\n    }");
            return defaultUserAgent;
        } catch (Exception e) {
            DeviceLog.exception("Exception getting webview user agent", e);
            return "";
        }
    }

    private final List<String> getStores(List<String> list) {
        return this.storeDataSource.fetchStores(list);
    }

    static /* synthetic */ List getStores$default(AndroidStaticDeviceInfoDataSource androidStaticDeviceInfoDataSource, List list, int i, Object obj) {
        if ((i & 1) != 0) {
            list = CollectionsKt__CollectionsKt.emptyList();
        }
        return androidStaticDeviceInfoDataSource.getStores(list);
    }

    private final long getAppStartTime() {
        return SdkProperties.getInitializationTimeEpoch();
    }

    private final String getVersionName() {
        return "4.15.0";
    }

    private final boolean isTestMode() {
        return SdkProperties.isTestMode();
    }

    private final String getPlatform() {
        return "android";
    }

    private final String getGameId() {
        String gameId = ClientProperties.getGameId();
        return gameId == null ? "" : gameId;
    }

    public final long getTotalMemory() {
        return getMemoryInfo(MemoryInfoType.TOTAL_MEMORY);
    }

    /* DevToolsApp ERROR: DevToolsAppRE in pass: e
        g.d.a.b.DevToolsAppRE: Exception block dominator not found, method:com.unity3d.ads.core.data.datasource.AndroidStaticDeviceInfoDataSource.getMemoryInfo(com.unity3d.services.core.device.Device$MemoryInfoType):long, dom blocks: [B:16:0x0031, B:21:0x003a]
        	at X4.e.e(SourceFile:1288)
        	at androidx.work.D.U(SourceFile:12)
        	at androidx.work.D.T(SourceFile:51)
        	at n1.c.u(SourceFile:42)
        	at n1.c.u(SourceFile:83)
        	at C4.c.run(SourceFile:73)
        */
    private final long getMemoryInfo(com.unity3d.services.core.device.Device.MemoryInfoType r6) {
        /*
        r5 = this;
        r0 = com.unity3d.ads.core.data.datasource.AndroidStaticDeviceInfoDataSource.WhenMappings.$EnumSwitchMapping$0;
        r6 = r6.ordinal();
        r6 = r0[r6];
        r0 = 1;
        if (r6 == r0) goto L_0x0015;
    L_0x000b:
        r0 = 2;
        if (r6 != r0) goto L_0x000f;
    L_0x000e:
        goto L_0x0015;
    L_0x000f:
        r6 = new kotlin.NoWhenBranchMatchedException;
        r6.<init>();
        throw r6;
    L_0x0015:
        r6 = 0;
        r1 = new java.io.RandomAccessFile;	 Catch:{ FileNotFoundException -> 0x0042 }
        r2 = "/proc/meminfo";	 Catch:{ FileNotFoundException -> 0x0042 }
        r3 = "r";	 Catch:{ FileNotFoundException -> 0x0042 }
        r1.<init>(r2, r3);	 Catch:{ FileNotFoundException -> 0x0042 }
        r1 = (java.io.Closeable) r1;	 Catch:{ FileNotFoundException -> 0x0042 }
        r2 = r1;	 Catch:{ all -> 0x0037 }
        r2 = (java.io.RandomAccessFile) r2;	 Catch:{ all -> 0x0037 }
        r3 = 0;
        r4 = r6;
    L_0x0026:
        if (r3 >= r0) goto L_0x002f;
    L_0x0028:
        r4 = r2.readLine();	 Catch:{ all -> 0x0035 }
        r3 = r3 + 1;	 Catch:{ all -> 0x0035 }
        goto L_0x0026;	 Catch:{ all -> 0x0035 }
    L_0x002f:
        r0 = kotlin.Unit.INSTANCE;	 Catch:{ all -> 0x0035 }
        kotlin.io.CloseableKt.closeFinally(r1, r6);	 Catch:{ FileNotFoundException -> 0x0040 }
        goto L_0x004c;
    L_0x0035:
        r6 = move-exception;
        goto L_0x003a;
    L_0x0037:
        r0 = move-exception;
        r4 = r6;
        r6 = r0;
    L_0x003a:
        throw r6;	 Catch:{ all -> 0x003b }
    L_0x003b:
        r0 = move-exception;
        kotlin.io.CloseableKt.closeFinally(r1, r6);	 Catch:{ FileNotFoundException -> 0x0040 }
        throw r0;	 Catch:{ FileNotFoundException -> 0x0040 }
    L_0x0040:
        r6 = move-exception;
        goto L_0x0045;
    L_0x0042:
        r0 = move-exception;
        r4 = r6;
        r6 = r0;
    L_0x0045:
        r0 = "Error reading memory info";
        r6 = (java.lang.Exception) r6;
        com.unity3d.services.core.log.DeviceLog.exception(r0, r6);
    L_0x004c:
        r0 = r5.getMemoryValueFromString(r4);
        return r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.unity3d.ads.core.data.datasource.AndroidStaticDeviceInfoDataSource.getMemoryInfo(com.unity3d.services.core.device.Device$MemoryInfoType):long");
    }

    private final long getMemoryValueFromString(String str) {
        if (str == null) {
            return 0;
        }
        Matcher matcher = Pattern.compile("(\\d+)").matcher(str);
        String str2 = null;
        while (matcher.find()) {
            str2 = matcher.group(1);
        }
        return str2 != null ? Long.parseLong(str2) : -1;
    }

    public final long getTotalSpace(File file) {
        return (file == null || !file.exists()) ? -1 : (long) MathKt__MathJVMKt.roundToInt((float) (file.getTotalSpace() / ((long) 1024)));
    }

    private final File getFileForStorageType(StorageType storageType) {
        int i = WhenMappings.$EnumSwitchMapping$1[storageType.ordinal()];
        if (i == 1) {
            return this.context.getCacheDir();
        }
        if (i == 2) {
            return this.context.getExternalCacheDir();
        }
        DeviceLog.error("Unhandled storagetype: " + storageType);
        return null;
    }

    public String getAppName() {
        String packageName = this.context.getPackageName();
        Intrinsics.checkNotNullExpressionValue(packageName, "context.packageName");
        return packageName;
    }

    private final String getAppVersion() {
        String packageName = this.context.getPackageName();
        PackageManager packageManager = this.context.getPackageManager();
        try {
            if (packageManager.getPackageInfo(packageName, 0).versionName == null) {
                packageName = APP_VERSION_FAKE;
            } else {
                packageName = packageManager.getPackageInfo(packageName, 0).versionName;
            }
            Intrinsics.checkNotNullExpressionValue(packageName, "{\n            if (pm.get…e\n            }\n        }");
            return packageName;
        } catch (NameNotFoundException e) {
            DeviceLog.exception("Error getting package info", e);
            return "";
        }
    }

    private final boolean isAppDebuggable() {
        boolean z;
        String str = "Could not find name";
        PackageManager packageManager = this.context.getPackageManager();
        Intrinsics.checkNotNullExpressionValue(packageManager, "context.packageManager");
        String packageName = this.context.getPackageName();
        Intrinsics.checkNotNullExpressionValue(packageName, "context.packageName");
        int i = 1;
        int i2 = 0;
        try {
            ApplicationInfo applicationInfo = packageManager.getApplicationInfo(packageName, 0);
            Intrinsics.checkNotNullExpressionValue(applicationInfo, "pm.getApplicationInfo(pkgName, 0)");
            applicationInfo.flags &= 2;
            if (applicationInfo.flags != 0) {
                z = true;
                i = 0;
            } else {
                i = 0;
                z = i;
            }
        } catch (NameNotFoundException e) {
            DeviceLog.exception(str, e);
            z = false;
        }
        if (i != 0) {
            try {
                Object obj = packageManager.getPackageInfo(packageName, 64).signatures;
                Intrinsics.checkNotNullExpressionValue(obj, "signatures");
                int length = obj.length;
                while (i2 < length) {
                    Certificate generateCertificate = CertificateFactory.getInstance(CERTIFICATE_TYPE_X509).generateCertificate(new ByteArrayInputStream(obj[i2].toByteArray()));
                    Intrinsics.checkNotNull(generateCertificate, "null cannot be cast to non-null type java.security.cert.X509Certificate");
                    z = Intrinsics.areEqual(((X509Certificate) generateCertificate).getSubjectX500Principal(), this.DEBUG_CERT);
                    if (z) {
                        break;
                    }
                    i2++;
                }
            } catch (NameNotFoundException e2) {
                DeviceLog.exception(str, e2);
            } catch (CertificateException e3) {
                DeviceLog.exception("Certificate exception", e3);
            }
        }
        return z;
    }

    private final int getExtensionVersion() {
        return VERSION.SDK_INT >= 30 ? SdkExtensions.getExtensionVersion(30) : -1;
    }

    public final boolean hasX264Decoder() {
        return selectAllDecodeCodecs(MimeTypes.VIDEO_H264).isEmpty() ^ 1;
    }

    public final boolean hasX265Decoder() {
        return selectAllDecodeCodecs(MimeTypes.VIDEO_H265).isEmpty() ^ 1;
    }

    private final List<MediaCodecInfo> selectAllDecodeCodecs(String str) {
        List<MediaCodecInfo> arrayList = new ArrayList();
        int codecCount = MediaCodecList.getCodecCount();
        for (int i = 0; i < codecCount; i++) {
            MediaCodecInfo codecInfoAt = MediaCodecList.getCodecInfoAt(i);
            if (!codecInfoAt.isEncoder()) {
                for (String equals : codecInfoAt.getSupportedTypes()) {
                    if (StringsKt__StringsJVMKt.equals(equals, str, true)) {
                        Intrinsics.checkNotNullExpressionValue(codecInfoAt, "codecInfo");
                        if (isHardwareAccelerated(codecInfoAt, str)) {
                            arrayList.add(codecInfoAt);
                        }
                    }
                }
            }
        }
        return arrayList;
    }

    private final boolean isHardwareAccelerated(MediaCodecInfo mediaCodecInfo, String str) {
        if (getApiLevel() >= 29) {
            return isHardwareAcceleratedV29(mediaCodecInfo);
        }
        return !isSoftwareOnly(mediaCodecInfo, str);
    }

    private final boolean isHardwareAcceleratedV29(MediaCodecInfo mediaCodecInfo) {
        return mediaCodecInfo.isHardwareAccelerated();
    }

    private final boolean isSoftwareOnly(MediaCodecInfo mediaCodecInfo, String str) {
        if (getApiLevel() >= 29) {
            return isSoftwareOnlyV29(mediaCodecInfo);
        }
        String name = mediaCodecInfo.getName();
        Intrinsics.checkNotNullExpressionValue(name, "codecInfo.name");
        Locale locale = Locale.ROOT;
        Intrinsics.checkNotNullExpressionValue(locale, "ROOT");
        Object toLowerCase = name.toLowerCase(locale);
        Intrinsics.checkNotNullExpressionValue(toLowerCase, "this as java.lang.String).toLowerCase(locale)");
        boolean z = false;
        if (!StringsKt__StringsJVMKt.startsWith$default(toLowerCase, "arc.", false, 2, null) && (StringsKt__StringsJVMKt.startsWith$default(toLowerCase, "omx.google.", false, 2, null) || StringsKt__StringsJVMKt.startsWith$default(toLowerCase, "omx.ffmpeg.", false, 2, null) || ((StringsKt__StringsJVMKt.startsWith$default(toLowerCase, "omx.sec.", false, 2, null) && StringsKt__StringsKt.contains$default((CharSequence) toLowerCase, (CharSequence) ".sw.", false, 2, null)) || Intrinsics.areEqual(toLowerCase, (Object) "omx.qcom.video.decoder.hevcswvdec") || StringsKt__StringsJVMKt.startsWith$default(toLowerCase, "c2.android.", false, 2, null) || StringsKt__StringsJVMKt.startsWith$default(toLowerCase, "c2.google.", false, 2, null) || !(StringsKt__StringsJVMKt.startsWith$default(toLowerCase, "omx.", false, 2, null) || StringsKt__StringsJVMKt.startsWith$default(toLowerCase, "c2.", false, 2, null))))) {
            z = true;
        }
        return z;
    }

    private final boolean isSoftwareOnlyV29(MediaCodecInfo mediaCodecInfo) {
        return mediaCodecInfo.isSoftwareOnly();
    }

    private final int getPhoneType() {
        Object systemService = this.context.getSystemService("phone");
        Intrinsics.checkNotNull(systemService, "null cannot be cast to non-null type android.telephony.TelephonyManager");
        return ((TelephonyManager) systemService).getPhoneType();
    }

    private final String getSimOperator() {
        Object systemService = this.context.getSystemService("phone");
        Intrinsics.checkNotNull(systemService, "null cannot be cast to non-null type android.telephony.TelephonyManager");
        String simOperator = ((TelephonyManager) systemService).getSimOperator();
        Intrinsics.checkNotNullExpressionValue(simOperator, "telephonyManager.simOperator");
        return simOperator;
    }
}
