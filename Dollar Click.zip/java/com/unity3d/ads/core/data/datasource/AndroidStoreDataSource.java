package com.unity3d.ads.core.data.datasource;

import android.content.Context;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

@Metadata(d1 = {"\u0000\u001e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010 \n\u0002\u0010\u000e\n\u0002\b\u0002\b\u0000\u0018\u00002\u00020\u0001B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0002\u0010\u0004J\u001c\u0010\u0005\u001a\b\u0012\u0004\u0012\u00020\u00070\u00062\f\u0010\b\u001a\b\u0012\u0004\u0012\u00020\u00070\u0006H\u0016R\u000e\u0010\u0002\u001a\u00020\u0003X\u0004¢\u0006\u0002\n\u0000¨\u0006\t"}, d2 = {"Lcom/unity3d/ads/core/data/datasource/AndroidStoreDataSource;", "Lcom/unity3d/ads/core/data/datasource/StoreDataSource;", "context", "Landroid/content/Context;", "(Landroid/content/Context;)V", "fetchStores", "", "", "additionalStores", "unity-ads_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
/* compiled from: AndroidStoreDataSource.kt */
public final class AndroidStoreDataSource implements StoreDataSource {
    private final Context context;

    public AndroidStoreDataSource(Context context) {
        Intrinsics.checkNotNullParameter(context, "context");
        this.context = context;
    }

    /* DevToolsApp WARNING: Can't wrap try/catch for R(6:6|7|8|(1:10)(1:11)|(2:13|20)(1:19)|4) */
    /* DevToolsApp WARNING: Missing block: B:5:0x0049, code:
            if (r8.hasNext() != false) goto L_0x004b;
     */
    /* DevToolsApp WARNING: Missing block: B:6:0x004b, code:
            r2 = r8.next();
            r4 = (java.lang.String) r2;
     */
    /* DevToolsApp WARNING: Missing block: B:9:0x0056, code:
            if (android.os.Build.VERSION.SDK_INT >= 33) goto L_0x0058;
     */
    /* DevToolsApp WARNING: Missing block: B:10:0x0058, code:
            r4 = r0.getPackageInfo(r4, android.content.pm.PackageManager.PackageInfoFlags.of(0));
     */
    /* DevToolsApp WARNING: Missing block: B:11:0x0063, code:
            r4 = r0.getPackageInfo(r4, 0);
     */
    /* DevToolsApp WARNING: Missing block: B:12:0x0067, code:
            if (r4 != null) goto L_0x0069;
     */
    /* DevToolsApp WARNING: Missing block: B:13:0x0069, code:
            r1.add(r2);
     */
    /* DevToolsApp WARNING: Missing block: B:15:0x006f, code:
            return (java.util.List) r1;
     */
    public java.util.List<java.lang.String> fetchStores(java.util.List<java.lang.String> r8) {
        /*
        r7 = this;
        r0 = "additionalStores";
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r8, r0);
        r0 = com.unity3d.ads.core.data.datasource.AndroidKnownStore.values();
        r1 = new java.util.ArrayList;
        r2 = r0.length;
        r1.<init>(r2);
        r1 = (java.util.Collection) r1;
        r2 = r0.length;
        r3 = 0;
        r4 = r3;
    L_0x0014:
        if (r4 >= r2) goto L_0x0022;
    L_0x0016:
        r5 = r0[r4];
        r5 = r5.getPackageName();
        r1.add(r5);
        r4 = r4 + 1;
        goto L_0x0014;
    L_0x0022:
        r1 = (java.util.List) r1;
        r1 = (java.util.Collection) r1;
        r8 = (java.lang.Iterable) r8;
        r8 = kotlin.collections.CollectionsKt___CollectionsKt.plus(r1, r8);
        r8 = (java.lang.Iterable) r8;
        r8 = kotlin.collections.CollectionsKt___CollectionsKt.distinct(r8);
        r0 = r7.context;
        r0 = r0.getPackageManager();
        r8 = (java.lang.Iterable) r8;
        r1 = new java.util.ArrayList;
        r1.<init>();
        r1 = (java.util.Collection) r1;
        r8 = r8.iterator();
    L_0x0045:
        r2 = r8.hasNext();
        if (r2 == 0) goto L_0x006d;
    L_0x004b:
        r2 = r8.next();
        r4 = r2;
        r4 = (java.lang.String) r4;
        r5 = android.os.Build.VERSION.SDK_INT;	 Catch:{ NameNotFoundException -> 0x0045 }
        r6 = 33;
        if (r5 < r6) goto L_0x0063;
    L_0x0058:
        r5 = 0;
        r5 = android.content.pm.PackageManager.PackageInfoFlags.of(r5);	 Catch:{ NameNotFoundException -> 0x0045 }
        r4 = r0.getPackageInfo(r4, r5);	 Catch:{ NameNotFoundException -> 0x0045 }
        goto L_0x0067;
    L_0x0063:
        r4 = r0.getPackageInfo(r4, r3);	 Catch:{ NameNotFoundException -> 0x0045 }
    L_0x0067:
        if (r4 == 0) goto L_0x0045;
    L_0x0069:
        r1.add(r2);
        goto L_0x0045;
    L_0x006d:
        r1 = (java.util.List) r1;
        return r1;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.unity3d.ads.core.data.datasource.AndroidStoreDataSource.fetchStores(java.util.List):java.util.List<java.lang.String>");
    }
}
