package com.unity3d.ads.core.data.datasource;

import com.unity3d.ads.datastore.WebviewConfigurationStore.WebViewConfigurationStore;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function2;

@Metadata(d1 = {"\u0000\b\n\u0000\n\u0002\u0018\u0002\n\u0000\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u0001H@"}, d2 = {"<anonymous>", "Lcom/unity3d/ads/datastore/WebviewConfigurationStore$WebViewConfigurationStore;", "it"}, k = 3, mv = {1, 8, 0}, xi = 48)
@DebugMetadata(c = "com.unity3d.ads.core.data.datasource.WebviewConfigurationDataSource$set$2", f = "WebviewConfigurationDataSource.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
/* compiled from: WebviewConfigurationDataSource.kt */
final class WebviewConfigurationDataSource$set$2 extends SuspendLambda implements Function2<WebViewConfigurationStore, Continuation<? super WebViewConfigurationStore>, Object> {
    final /* synthetic */ WebViewConfigurationStore $data;
    int label;

    WebviewConfigurationDataSource$set$2(WebViewConfigurationStore webViewConfigurationStore, Continuation<? super WebviewConfigurationDataSource$set$2> continuation) {
        this.$data = webViewConfigurationStore;
        super(2, continuation);
    }

    public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
        return new WebviewConfigurationDataSource$set$2(this.$data, continuation);
    }

    public final Object invoke(WebViewConfigurationStore webViewConfigurationStore, Continuation<? super WebViewConfigurationStore> continuation) {
        return ((WebviewConfigurationDataSource$set$2) create(webViewConfigurationStore, continuation)).invokeSuspend(Unit.INSTANCE);
    }

    public final Object invokeSuspend(Object obj) {
        IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED();
        if (this.label == 0) {
            ResultKt.throwOnFailure(obj);
            return this.$data;
        }
        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
    }
}
