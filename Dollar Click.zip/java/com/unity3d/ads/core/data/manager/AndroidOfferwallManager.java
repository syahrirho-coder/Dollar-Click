package com.unity3d.ads.core.data.manager;

import com.unity3d.ads.core.domain.HandleInvocationsFromAdViewer;
import com.unity3d.ads.core.domain.offerwall.OfferwallEventData;
import com.unity3d.services.ads.offerwall.OfferwallAdapterBridge;
import com.unity3d.services.core.log.DeviceLog;
import kotlin.Metadata;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.jvm.internal.Boxing;
import kotlin.jvm.internal.Intrinsics;
import kotlinx.coroutines.flow.Flow;
import kotlinx.coroutines.flow.FlowKt;

@Metadata(d1 = {"\u00002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0004\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\u0018\u00002\u00020\u0001B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0002\u0010\u0004J\u0011\u0010\u0005\u001a\u00020\u0006H@ø\u0001\u0000¢\u0006\u0002\u0010\u0007J\u0019\u0010\b\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u0006H@ø\u0001\u0000¢\u0006\u0002\u0010\u000bJ\u0011\u0010\f\u001a\u00020\tH@ø\u0001\u0000¢\u0006\u0002\u0010\u0007J\u0019\u0010\r\u001a\u00020\u000e2\u0006\u0010\n\u001a\u00020\u0006H@ø\u0001\u0000¢\u0006\u0002\u0010\u000bJ\u0016\u0010\u000f\u001a\b\u0012\u0004\u0012\u00020\u00110\u00102\u0006\u0010\n\u001a\u00020\u0006H\u0016R\u000e\u0010\u0002\u001a\u00020\u0003X\u0004¢\u0006\u0002\n\u0000\u0002\u0004\n\u0002\b\u0019¨\u0006\u0012"}, d2 = {"Lcom/unity3d/ads/core/data/manager/AndroidOfferwallManager;", "Lcom/unity3d/ads/core/data/manager/OfferwallManager;", "offerwallBridge", "Lcom/unity3d/services/ads/offerwall/OfferwallAdapterBridge;", "(Lcom/unity3d/services/ads/offerwall/OfferwallAdapterBridge;)V", "getVersion", "", "(Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "isAdReady", "", "placementName", "(Ljava/lang/String;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "isConnected", "loadAd", "", "showAd", "Lkotlinx/coroutines/flow/Flow;", "Lcom/unity3d/ads/core/domain/offerwall/OfferwallEventData;", "unity-ads_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
/* compiled from: AndroidOfferwallManager.kt */
public final class AndroidOfferwallManager implements OfferwallManager {
    private final OfferwallAdapterBridge offerwallBridge;

    public AndroidOfferwallManager(OfferwallAdapterBridge offerwallAdapterBridge) {
        Intrinsics.checkNotNullParameter(offerwallAdapterBridge, "offerwallBridge");
        this.offerwallBridge = offerwallAdapterBridge;
    }

    public Object getVersion(Continuation<? super String> continuation) {
        return this.offerwallBridge.getVersion();
    }

    public Object isConnected(Continuation<? super Boolean> continuation) {
        return Boxing.boxBoolean(this.offerwallBridge.isConnected());
    }

    public Object isAdReady(String str, Continuation<? super Boolean> continuation) {
        return Boxing.boxBoolean(this.offerwallBridge.isAdReady(str));
    }

    /* DevToolsApp WARNING: Removed duplicated region for block: B:12:0x0033  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:8:0x0025  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:17:0x0076  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:25:0x009b  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:20:0x007b  */
    public java.lang.Object loadAd(java.lang.String r6, kotlin.coroutines.Continuation<? super kotlin.Unit> r7) {
        /*
        r5 = this;
        r0 = r7 instanceof com.unity3d.ads.core.data.manager.AndroidOfferwallManager$loadAd$1;
        if (r0 == 0) goto L_0x0014;
    L_0x0004:
        r0 = r7;
        r0 = (com.unity3d.ads.core.data.manager.AndroidOfferwallManager$loadAd$1) r0;
        r1 = r0.label;
        r2 = -2147483648; // 0xffffffff80000000 float:-0.0 double:NaN;
        r1 = r1 & r2;
        if (r1 == 0) goto L_0x0014;
    L_0x000e:
        r7 = r0.label;
        r7 = r7 - r2;
        r0.label = r7;
        goto L_0x0019;
    L_0x0014:
        r0 = new com.unity3d.ads.core.data.manager.AndroidOfferwallManager$loadAd$1;
        r0.<init>(r5, r7);
    L_0x0019:
        r7 = r0.result;
        r1 = kotlin.coroutines.intrinsics.IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED();
        r2 = r0.label;
        r3 = 1;
        r4 = 0;
        if (r2 == 0) goto L_0x0033;
    L_0x0025:
        if (r2 != r3) goto L_0x002b;
    L_0x0027:
        kotlin.ResultKt.throwOnFailure(r7);
        goto L_0x006b;
    L_0x002b:
        r6 = new java.lang.IllegalStateException;
        r7 = "call to 'resume' before 'invoke' with coroutine";
        r6.<init>(r7);
        throw r6;
    L_0x0033:
        kotlin.ResultKt.throwOnFailure(r7);
        r7 = new java.lang.StringBuilder;
        r2 = "Offerwall Manager - loadAd: ";
        r7.<init>(r2);
        r7 = r7.append(r6);
        r7 = r7.toString();
        com.unity3d.services.core.log.DeviceLog.debug(r7);
        r7 = r5.offerwallBridge;
        r7 = r7.getOfferwallEventFlow();
        r2 = new com.unity3d.ads.core.data.manager.AndroidOfferwallManager$loadAd$2;
        r2.<init>(r5, r6, r4);
        r2 = (kotlin.jvm.functions.Function2) r2;
        r7 = kotlinx.coroutines.flow.FlowKt.onSubscription(r7, r2);
        r7 = (kotlinx.coroutines.flow.Flow) r7;
        r2 = new com.unity3d.ads.core.data.manager.AndroidOfferwallManager$loadAd$3;
        r2.<init>(r6, r4);
        r2 = (kotlin.jvm.functions.Function2) r2;
        r0.label = r3;
        r7 = kotlinx.coroutines.flow.FlowKt.first(r7, r2, r0);
        if (r7 != r1) goto L_0x006b;
    L_0x006a:
        return r1;
    L_0x006b:
        r6 = r7;
        r6 = (com.unity3d.ads.core.domain.offerwall.OfferwallEventData) r6;
        r6 = r6.getOfferwallEvent();
        r0 = com.unity3d.services.ads.offerwall.OfferwallEvent.REQUEST_SUCCESS;
        if (r6 == r0) goto L_0x0077;
    L_0x0076:
        r4 = r7;
    L_0x0077:
        r4 = (com.unity3d.ads.core.domain.offerwall.OfferwallEventData) r4;
        if (r4 == 0) goto L_0x009b;
    L_0x007b:
        r6 = new com.unity3d.ads.core.data.model.exception.LoadException;
        r7 = new java.lang.StringBuilder;
        r0 = "Error loading offerwall ad: ";
        r7.<init>(r0);
        r0 = r4.getErrorMessage();
        if (r0 != 0) goto L_0x008e;
    L_0x008a:
        r0 = r4.getOfferwallEvent();
    L_0x008e:
        r7 = r7.append(r0);
        r7 = r7.toString();
        r0 = 0;
        r6.<init>(r0, r7);
        throw r6;
    L_0x009b:
        r6 = kotlin.Unit.INSTANCE;
        return r6;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.unity3d.ads.core.data.manager.AndroidOfferwallManager.loadAd(java.lang.String, kotlin.coroutines.Continuation):java.lang.Object");
    }

    public Flow<OfferwallEventData> showAd(String str) {
        Intrinsics.checkNotNullParameter(str, HandleInvocationsFromAdViewer.KEY_PLACEMENT_NAME);
        DeviceLog.debug("Offerwall Manager - showAd: " + str);
        return FlowKt.transformWhile(FlowKt.onSubscription(this.offerwallBridge.getOfferwallEventFlow(), new AndroidOfferwallManager$showAd$1(this, str, null)), new AndroidOfferwallManager$showAd$2(null));
    }
}
