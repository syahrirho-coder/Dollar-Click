package com.unity3d.ads.core.data.manager;

import com.unity3d.ads.core.extensions.AdFormatExtensions;
import com.unity3d.services.ads.gmascar.handlers.BiddingSignalsHandler;
import com.unity3d.services.ads.gmascar.models.BiddingSignals;
import gatewayprotocol.v1.InitializationResponseOuterClass.AdFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.DebugProbesKt;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function2;
import kotlinx.coroutines.CancellableContinuation;
import kotlinx.coroutines.CancellableContinuationImpl;
import kotlinx.coroutines.CoroutineScope;

@Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u0004\u0018\u00010\u0001*\u00020\u0002H@"}, d2 = {"<anonymous>", "Lcom/unity3d/services/ads/gmascar/models/BiddingSignals;", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {1, 8, 0}, xi = 48)
@DebugMetadata(c = "com.unity3d.ads.core.data.manager.AndroidScarManager$getSignals$2", f = "AndroidScarManager.kt", i = {}, l = {130}, m = "invokeSuspend", n = {}, s = {})
/* compiled from: AndroidScarManager.kt */
final class AndroidScarManager$getSignals$2 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super BiddingSignals>, Object> {
    final /* synthetic */ List<AdFormat> $adFormat;
    Object L$0;
    Object L$1;
    int label;
    final /* synthetic */ AndroidScarManager this$0;

    AndroidScarManager$getSignals$2(List<? extends AdFormat> list, AndroidScarManager androidScarManager, Continuation<? super AndroidScarManager$getSignals$2> continuation) {
        this.$adFormat = list;
        this.this$0 = androidScarManager;
        super(2, continuation);
    }

    public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
        return new AndroidScarManager$getSignals$2(this.$adFormat, this.this$0, continuation);
    }

    public final Object invoke(CoroutineScope coroutineScope, Continuation<? super BiddingSignals> continuation) {
        return ((AndroidScarManager$getSignals$2) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
    }

    public final Object invokeSuspend(Object obj) {
        Object coroutine_suspended = IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED();
        int i = this.label;
        if (i == 0) {
            List list;
            ResultKt.throwOnFailure(obj);
            List list2 = this.$adFormat;
            AndroidScarManager androidScarManager = this.this$0;
            this.L$0 = list2;
            this.L$1 = androidScarManager;
            this.label = 1;
            Continuation continuation = this;
            CancellableContinuationImpl cancellableContinuationImpl = new CancellableContinuationImpl(IntrinsicsKt__IntrinsicsJvmKt.intercepted(continuation), 1);
            cancellableContinuationImpl.initCancellability();
            CancellableContinuation cancellableContinuation = cancellableContinuationImpl;
            if (list2 != null) {
                Iterable<AdFormat> iterable = list2;
                Collection arrayList = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(iterable, 10));
                for (AdFormat toUnityAdFormat : iterable) {
                    arrayList.add(AdFormatExtensions.toUnityAdFormat(toUnityAdFormat));
                }
                list = (List) arrayList;
            } else {
                list = null;
            }
            androidScarManager.gmaBridge.getSCARBiddingSignals(list, new BiddingSignalsHandler(true, new AndroidScarManager$getSignals$2$1$1(cancellableContinuation)));
            obj = cancellableContinuationImpl.getResult();
            if (obj == IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED()) {
                DebugProbesKt.probeCoroutineSuspended(continuation);
            }
            if (obj == coroutine_suspended) {
                return coroutine_suspended;
            }
        } else if (i == 1) {
            AndroidScarManager androidScarManager2 = (AndroidScarManager) this.L$1;
            List list3 = (List) this.L$0;
            ResultKt.throwOnFailure(obj);
        } else {
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }
        return obj;
    }
}
