package com.unity3d.ads.core.data.manager;

import com.unity3d.ads.core.domain.scar.GmaEventData;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function2;

@Metadata(d1 = {"\u0000\f\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u0003H@"}, d2 = {"<anonymous>", "", "it", "Lcom/unity3d/ads/core/domain/scar/GmaEventData;"}, k = 3, mv = {1, 8, 0}, xi = 48)
@DebugMetadata(c = "com.unity3d.ads.core.data.manager.AndroidScarManager$loadAd$3", f = "AndroidScarManager.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
/* compiled from: AndroidScarManager.kt */
final class AndroidScarManager$loadAd$3 extends SuspendLambda implements Function2<GmaEventData, Continuation<? super Boolean>, Object> {
    final /* synthetic */ String $placementId;
    /* synthetic */ Object L$0;
    int label;

    AndroidScarManager$loadAd$3(String str, Continuation<? super AndroidScarManager$loadAd$3> continuation) {
        this.$placementId = str;
        super(2, continuation);
    }

    public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
        AndroidScarManager$loadAd$3 androidScarManager$loadAd$3 = new AndroidScarManager$loadAd$3(this.$placementId, continuation);
        androidScarManager$loadAd$3.L$0 = obj;
        return androidScarManager$loadAd$3;
    }

    public final Object invoke(GmaEventData gmaEventData, Continuation<? super Boolean> continuation) {
        return ((AndroidScarManager$loadAd$3) create(gmaEventData, continuation)).invokeSuspend(Unit.INSTANCE);
    }

    /* DevToolsApp WARNING: Missing block: B:7:0x0050, code:
            if (kotlin.collections.CollectionsKt__CollectionsKt.listOf(com.unity3d.scar.adapter.common.GMAEvent.METHOD_ERROR, com.unity3d.scar.adapter.common.GMAEvent.SCAR_NOT_PRESENT, com.unity3d.scar.adapter.common.GMAEvent.INTERNAL_LOAD_ERROR).contains(r6.getGmaEvent()) != false) goto L_0x0052;
     */
    public final java.lang.Object invokeSuspend(java.lang.Object r6) {
        /*
        r5 = this;
        kotlin.coroutines.intrinsics.IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED();
        r0 = r5.label;
        if (r0 != 0) goto L_0x0058;
    L_0x0007:
        kotlin.ResultKt.throwOnFailure(r6);
        r6 = r5.L$0;
        r6 = (com.unity3d.ads.core.domain.scar.GmaEventData) r6;
        r0 = 2;
        r1 = new com.unity3d.scar.adapter.common.GMAEvent[r0];
        r2 = com.unity3d.scar.adapter.common.GMAEvent.AD_LOADED;
        r3 = 0;
        r1[r3] = r2;
        r2 = com.unity3d.scar.adapter.common.GMAEvent.LOAD_ERROR;
        r4 = 1;
        r1[r4] = r2;
        r1 = kotlin.collections.CollectionsKt__CollectionsKt.listOf(r1);
        r2 = r6.getGmaEvent();
        r1 = r1.contains(r2);
        if (r1 == 0) goto L_0x0035;
    L_0x0029:
        r1 = r6.getPlacementId();
        r2 = r5.$placementId;
        r1 = kotlin.jvm.internal.Intrinsics.areEqual(r1, r2);
        if (r1 != 0) goto L_0x0052;
    L_0x0035:
        r1 = 3;
        r1 = new com.unity3d.scar.adapter.common.GMAEvent[r1];
        r2 = com.unity3d.scar.adapter.common.GMAEvent.METHOD_ERROR;
        r1[r3] = r2;
        r2 = com.unity3d.scar.adapter.common.GMAEvent.SCAR_NOT_PRESENT;
        r1[r4] = r2;
        r2 = com.unity3d.scar.adapter.common.GMAEvent.INTERNAL_LOAD_ERROR;
        r1[r0] = r2;
        r0 = kotlin.collections.CollectionsKt__CollectionsKt.listOf(r1);
        r6 = r6.getGmaEvent();
        r6 = r0.contains(r6);
        if (r6 == 0) goto L_0x0053;
    L_0x0052:
        r3 = r4;
    L_0x0053:
        r6 = kotlin.coroutines.jvm.internal.Boxing.boxBoolean(r3);
        return r6;
    L_0x0058:
        r6 = new java.lang.IllegalStateException;
        r0 = "call to 'resume' before 'invoke' with coroutine";
        r6.<init>(r0);
        throw r6;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.unity3d.ads.core.data.manager.AndroidScarManager$loadAd$3.invokeSuspend(java.lang.Object):java.lang.Object");
    }
}
