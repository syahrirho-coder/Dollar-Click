package com.unity3d.ads.core.data.manager;

import com.unity3d.ads.core.domain.scar.GmaEventData;
import com.unity3d.scar.adapter.common.GMAEvent;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.jvm.internal.Boxing;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function3;
import kotlinx.coroutines.flow.FlowCollector;

@Metadata(d1 = {"\u0000\u0010\n\u0000\n\u0002\u0010\u000b\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\u0010\u0000\u001a\u00020\u0001*\b\u0012\u0004\u0012\u00020\u00030\u00022\u0006\u0010\u0004\u001a\u00020\u0003H@"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/flow/FlowCollector;", "Lcom/unity3d/ads/core/domain/scar/GmaEventData;", "it"}, k = 3, mv = {1, 8, 0}, xi = 48)
@DebugMetadata(c = "com.unity3d.ads.core.data.manager.AndroidScarManager$show$2", f = "AndroidScarManager.kt", i = {0}, l = {123}, m = "invokeSuspend", n = {"it"}, s = {"L$0"})
/* compiled from: AndroidScarManager.kt */
final class AndroidScarManager$show$2 extends SuspendLambda implements Function3<FlowCollector<? super GmaEventData>, GmaEventData, Continuation<? super Boolean>, Object> {
    private /* synthetic */ Object L$0;
    /* synthetic */ Object L$1;
    int label;

    AndroidScarManager$show$2(Continuation<? super AndroidScarManager$show$2> continuation) {
        super(3, continuation);
    }

    public final Object invoke(FlowCollector<? super GmaEventData> flowCollector, GmaEventData gmaEventData, Continuation<? super Boolean> continuation) {
        AndroidScarManager$show$2 androidScarManager$show$2 = new AndroidScarManager$show$2(continuation);
        androidScarManager$show$2.L$0 = flowCollector;
        androidScarManager$show$2.L$1 = gmaEventData;
        return androidScarManager$show$2.invokeSuspend(Unit.INSTANCE);
    }

    public final Object invokeSuspend(Object obj) {
        GmaEventData gmaEventData;
        Object coroutine_suspended = IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED();
        int i = this.label;
        if (i == 0) {
            ResultKt.throwOnFailure(obj);
            FlowCollector flowCollector = (FlowCollector) this.L$0;
            GmaEventData gmaEventData2 = (GmaEventData) this.L$1;
            Continuation continuation = this;
            this.L$0 = gmaEventData2;
            this.label = 1;
            if (flowCollector.emit(gmaEventData2, continuation) == coroutine_suspended) {
                return coroutine_suspended;
            }
            gmaEventData = gmaEventData2;
        } else if (i == 1) {
            gmaEventData = (GmaEventData) this.L$0;
            ResultKt.throwOnFailure(obj);
        } else {
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }
        return Boxing.boxBoolean(ArraysKt___ArraysKt.contains((Object[]) new GMAEvent[]{GMAEvent.AD_CLOSED, GMAEvent.NO_AD_ERROR, GMAEvent.INTERSTITIAL_SHOW_ERROR, GMAEvent.REWARDED_SHOW_ERROR}, (Object) gmaEventData.getGmaEvent()) ^ true);
    }
}
