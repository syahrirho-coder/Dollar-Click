package com.unity3d.ads.core.data.manager;

import android.content.Context;
import com.unity3d.ads.core.domain.HandleInvocationsFromAdViewer;
import com.unity3d.ads.core.domain.scar.CommonScarEventReceiver;
import com.unity3d.ads.core.domain.scar.GmaEventData;
import com.unity3d.ads.core.domain.scar.ScarTimeHackFixer;
import com.unity3d.scar.adapter.common.scarads.ScarAdMetadata;
import com.unity3d.services.ads.gmascar.GMAScarAdapterBridge;
import com.unity3d.services.ads.gmascar.models.BiddingSignals;
import com.unity3d.services.banners.BannerView;
import com.unity3d.services.banners.UnityBannerSize;
import com.unity3d.services.core.di.ServiceProvider;
import gatewayprotocol.v1.InitializationResponseOuterClass.AdFormat;
import java.util.List;
import kotlin.Metadata;
import kotlin.coroutines.Continuation;
import kotlin.jvm.internal.Intrinsics;
import kotlinx.coroutines.TimeoutKt;
import kotlinx.coroutines.flow.Flow;
import kotlinx.coroutines.flow.FlowKt;

@Metadata(d1 = {"\u0000l\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0005\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\u0018\u00002\u00020\u0001B\u001d\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007¢\u0006\u0002\u0010\bJ#\u0010\t\u001a\u0004\u0018\u00010\n2\u000e\u0010\u000b\u001a\n\u0012\u0004\u0012\u00020\r\u0018\u00010\fH@ø\u0001\u0000¢\u0006\u0002\u0010\u000eJ\u0013\u0010\u000f\u001a\u0004\u0018\u00010\u0010H@ø\u0001\u0000¢\u0006\u0002\u0010\u0011JA\u0010\u0012\u001a\u00020\u00132\u0006\u0010\u000b\u001a\u00020\u00102\u0006\u0010\u0014\u001a\u00020\u00102\u0006\u0010\u0015\u001a\u00020\u00102\u0006\u0010\u0016\u001a\u00020\u00102\u0006\u0010\u0017\u001a\u00020\u00102\u0006\u0010\u0018\u001a\u00020\u0019H@ø\u0001\u0000¢\u0006\u0002\u0010\u001aJ6\u0010\u001b\u001a\b\u0012\u0004\u0012\u00020\u001d0\u001c2\u0006\u0010\u001e\u001a\u00020\u001f2\u0006\u0010 \u001a\u00020!2\u0006\u0010\"\u001a\u00020#2\u0006\u0010$\u001a\u00020%2\u0006\u0010&\u001a\u00020\u0010H\u0016J\u001e\u0010'\u001a\b\u0012\u0004\u0012\u00020\u001d0\u001c2\u0006\u0010\u0014\u001a\u00020\u00102\u0006\u0010\u0017\u001a\u00020\u0010H\u0016R\u000e\u0010\u0004\u001a\u00020\u0005X\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0002\u001a\u00020\u0003X\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0007X\u0004¢\u0006\u0002\n\u0000\u0002\u0004\n\u0002\b\u0019¨\u0006("}, d2 = {"Lcom/unity3d/ads/core/data/manager/AndroidScarManager;", "Lcom/unity3d/ads/core/data/manager/ScarManager;", "scarEventReceiver", "Lcom/unity3d/ads/core/domain/scar/CommonScarEventReceiver;", "gmaBridge", "Lcom/unity3d/services/ads/gmascar/GMAScarAdapterBridge;", "scarTimeHackFixer", "Lcom/unity3d/ads/core/domain/scar/ScarTimeHackFixer;", "(Lcom/unity3d/ads/core/domain/scar/CommonScarEventReceiver;Lcom/unity3d/services/ads/gmascar/GMAScarAdapterBridge;Lcom/unity3d/ads/core/domain/scar/ScarTimeHackFixer;)V", "getSignals", "Lcom/unity3d/services/ads/gmascar/models/BiddingSignals;", "adFormat", "", "Lgatewayprotocol/v1/InitializationResponseOuterClass$AdFormat;", "(Ljava/util/List;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "getVersion", "", "(Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "loadAd", "", "placementId", "adString", "adUnitId", "queryId", "videoLength", "", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ILkotlin/coroutines/Continuation;)Ljava/lang/Object;", "loadBannerAd", "Lkotlinx/coroutines/flow/Flow;", "Lcom/unity3d/ads/core/domain/scar/GmaEventData;", "context", "Landroid/content/Context;", "bannerView", "Lcom/unity3d/services/banners/BannerView;", "scarAdMetadata", "Lcom/unity3d/scar/adapter/common/scarads/ScarAdMetadata;", "bannerSize", "Lcom/unity3d/services/banners/UnityBannerSize;", "opportunityId", "show", "unity-ads_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
/* compiled from: AndroidScarManager.kt */
public final class AndroidScarManager implements ScarManager {
    private final GMAScarAdapterBridge gmaBridge;
    private final CommonScarEventReceiver scarEventReceiver;
    private final ScarTimeHackFixer scarTimeHackFixer;

    public AndroidScarManager(CommonScarEventReceiver commonScarEventReceiver, GMAScarAdapterBridge gMAScarAdapterBridge, ScarTimeHackFixer scarTimeHackFixer) {
        Intrinsics.checkNotNullParameter(commonScarEventReceiver, "scarEventReceiver");
        Intrinsics.checkNotNullParameter(gMAScarAdapterBridge, "gmaBridge");
        Intrinsics.checkNotNullParameter(scarTimeHackFixer, "scarTimeHackFixer");
        this.scarEventReceiver = commonScarEventReceiver;
        this.gmaBridge = gMAScarAdapterBridge;
        this.scarTimeHackFixer = scarTimeHackFixer;
    }

    public Object getVersion(Continuation<? super String> continuation) {
        return TimeoutKt.withTimeoutOrNull(ServiceProvider.SCAR_VERSION_FETCH_TIMEOUT, new AndroidScarManager$getVersion$2(this, null), continuation);
    }

    public Object getSignals(List<? extends AdFormat> list, Continuation<? super BiddingSignals> continuation) {
        return TimeoutKt.withTimeoutOrNull(ServiceProvider.SCAR_SIGNALS_FETCH_TIMEOUT, new AndroidScarManager$getSignals$2(list, this, null), continuation);
    }

    /* DevToolsApp WARNING: Removed duplicated region for block: B:12:0x0038  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:8:0x002a  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:17:0x0085  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:25:0x00aa  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:20:0x008a  */
    public java.lang.Object loadAd(java.lang.String r17, java.lang.String r18, java.lang.String r19, java.lang.String r20, java.lang.String r21, int r22, kotlin.coroutines.Continuation<? super kotlin.Unit> r23) {
        /*
        r16 = this;
        r9 = r16;
        r0 = r23;
        r1 = r0 instanceof com.unity3d.ads.core.data.manager.AndroidScarManager$loadAd$1;
        if (r1 == 0) goto L_0x0018;
    L_0x0008:
        r1 = r0;
        r1 = (com.unity3d.ads.core.data.manager.AndroidScarManager$loadAd$1) r1;
        r2 = r1.label;
        r3 = -2147483648; // 0xffffffff80000000 float:-0.0 double:NaN;
        r2 = r2 & r3;
        if (r2 == 0) goto L_0x0018;
    L_0x0012:
        r0 = r1.label;
        r0 = r0 - r3;
        r1.label = r0;
        goto L_0x001d;
    L_0x0018:
        r1 = new com.unity3d.ads.core.data.manager.AndroidScarManager$loadAd$1;
        r1.<init>(r9, r0);
    L_0x001d:
        r10 = r1;
        r0 = r10.result;
        r11 = kotlin.coroutines.intrinsics.IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED();
        r1 = r10.label;
        r12 = 0;
        r13 = 1;
        if (r1 == 0) goto L_0x0038;
    L_0x002a:
        if (r1 != r13) goto L_0x0030;
    L_0x002c:
        kotlin.ResultKt.throwOnFailure(r0);
        goto L_0x007a;
    L_0x0030:
        r0 = new java.lang.IllegalStateException;
        r1 = "call to 'resume' before 'invoke' with coroutine";
        r0.<init>(r1);
        throw r0;
    L_0x0038:
        kotlin.ResultKt.throwOnFailure(r0);
        r0 = com.unity3d.scar.adapter.common.scarads.UnityAdFormat.INTERSTITIAL;
        r0 = r0.toString();
        r1 = r17;
        r2 = kotlin.text.StringsKt__StringsJVMKt.equals(r1, r0, r13);
        r0 = r9.scarEventReceiver;
        r14 = r0.getGmaEventFlow();
        r15 = new com.unity3d.ads.core.data.manager.AndroidScarManager$loadAd$2;
        r8 = 0;
        r0 = r15;
        r1 = r16;
        r3 = r18;
        r4 = r21;
        r5 = r19;
        r6 = r20;
        r7 = r22;
        r0.<init>(r1, r2, r3, r4, r5, r6, r7, r8);
        r15 = (kotlin.jvm.functions.Function2) r15;
        r0 = kotlinx.coroutines.flow.FlowKt.onSubscription(r14, r15);
        r0 = (kotlinx.coroutines.flow.Flow) r0;
        r1 = new com.unity3d.ads.core.data.manager.AndroidScarManager$loadAd$3;
        r2 = r18;
        r1.<init>(r2, r12);
        r1 = (kotlin.jvm.functions.Function2) r1;
        r10.label = r13;
        r0 = kotlinx.coroutines.flow.FlowKt.first(r0, r1, r10);
        if (r0 != r11) goto L_0x007a;
    L_0x0079:
        return r11;
    L_0x007a:
        r1 = r0;
        r1 = (com.unity3d.ads.core.domain.scar.GmaEventData) r1;
        r1 = r1.getGmaEvent();
        r2 = com.unity3d.scar.adapter.common.GMAEvent.AD_LOADED;
        if (r1 == r2) goto L_0x0086;
    L_0x0085:
        r12 = r0;
    L_0x0086:
        r12 = (com.unity3d.ads.core.domain.scar.GmaEventData) r12;
        if (r12 == 0) goto L_0x00aa;
    L_0x008a:
        r0 = new com.unity3d.ads.core.data.model.exception.LoadException;
        r1 = new java.lang.StringBuilder;
        r2 = "Error loading SCAR ad: ";
        r1.<init>(r2);
        r2 = r12.getErrorMessage();
        if (r2 != 0) goto L_0x009d;
    L_0x0099:
        r2 = r12.getGmaEvent();
    L_0x009d:
        r1 = r1.append(r2);
        r1 = r1.toString();
        r2 = 0;
        r0.<init>(r2, r1);
        throw r0;
    L_0x00aa:
        r0 = kotlin.Unit.INSTANCE;
        return r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.unity3d.ads.core.data.manager.AndroidScarManager.loadAd(java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, int, kotlin.coroutines.Continuation):java.lang.Object");
    }

    public Flow<GmaEventData> loadBannerAd(Context context, BannerView bannerView, ScarAdMetadata scarAdMetadata, UnityBannerSize unityBannerSize, String str) {
        Intrinsics.checkNotNullParameter(context, "context");
        Intrinsics.checkNotNullParameter(bannerView, "bannerView");
        Intrinsics.checkNotNullParameter(scarAdMetadata, "scarAdMetadata");
        Intrinsics.checkNotNullParameter(unityBannerSize, "bannerSize");
        Intrinsics.checkNotNullParameter(str, "opportunityId");
        return new AndroidScarManager$loadBannerAd$$inlined$filter$1(FlowKt.onStart(this.scarEventReceiver.getGmaEventFlow(), new AndroidScarManager$loadBannerAd$1(this, context, bannerView, str, scarAdMetadata, unityBannerSize, null)), str);
    }

    public Flow<GmaEventData> show(String str, String str2) {
        Intrinsics.checkNotNullParameter(str, HandleInvocationsFromAdViewer.KEY_PLACEMENT_ID);
        Intrinsics.checkNotNullParameter(str2, HandleInvocationsFromAdViewer.KEY_QUERY_ID);
        return FlowKt.transformWhile(FlowKt.onSubscription(this.scarEventReceiver.getGmaEventFlow(), new AndroidScarManager$show$1(this, str, str2, null)), new AndroidScarManager$show$2(null));
    }
}
