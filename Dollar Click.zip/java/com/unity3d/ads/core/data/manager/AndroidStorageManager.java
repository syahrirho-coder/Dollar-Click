package com.unity3d.ads.core.data.manager;

import android.content.Context;
import com.unity3d.ads.core.domain.HandleInvocationsFromAdViewer;
import com.unity3d.services.core.device.Storage;
import com.unity3d.services.core.device.StorageManager;
import com.unity3d.services.core.device.StorageManager.StorageType;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;

@Metadata(d1 = {"\u0000:\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\u0018\u0000 \u00142\u00020\u0001:\u0001\u0014B\u0005¢\u0006\u0002\u0010\u0002J\u001c\u0010\u0003\u001a\u00020\u00042\n\u0010\u0005\u001a\u00060\u0006j\u0002`\u00072\u0006\u0010\b\u001a\u00020\tH\u0016J\u0014\u0010\n\u001a\u00020\u000b2\n\u0010\u0005\u001a\u00060\u0006j\u0002`\u0007H\u0016J\b\u0010\f\u001a\u00020\u0004H\u0016J\u0014\u0010\r\u001a\u00020\u000e2\n\u0010\u0005\u001a\u00060\u0006j\u0002`\u0007H\u0016J\u0010\u0010\u000f\u001a\u00020\u000e2\u0006\u0010\u0010\u001a\u00020\u0011H\u0016J\u0014\u0010\u0012\u001a\u00020\u00042\n\u0010\u0005\u001a\u00060\u0006j\u0002`\u0007H\u0016J\u0014\u0010\u0013\u001a\u00020\u00042\n\u0010\u0005\u001a\u00060\u0006j\u0002`\u0007H\u0016¨\u0006\u0015"}, d2 = {"Lcom/unity3d/ads/core/data/manager/AndroidStorageManager;", "Lcom/unity3d/ads/core/data/manager/StorageManager;", "()V", "addStorageLocation", "", "type", "Lcom/unity3d/services/core/device/StorageManager$StorageType;", "Lcom/unity3d/ads/core/data/manager/LegacyStorageType;", "fileName", "", "getStorage", "Lcom/unity3d/services/core/device/Storage;", "hasInitialized", "hasStorage", "", "init", "context", "Landroid/content/Context;", "initStorage", "removeStorage", "Companion", "unity-ads_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
/* compiled from: AndroidStorageManager.kt */
public final class AndroidStorageManager implements StorageManager {
    public static final Companion Companion = new Companion();
    private static final String KEY_INITIALIZED = "configuration.hasInitialized";

    @Metadata(d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\b\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002R\u000e\u0010\u0003\u001a\u00020\u0004XT¢\u0006\u0002\n\u0000¨\u0006\u0005"}, d2 = {"Lcom/unity3d/ads/core/data/manager/AndroidStorageManager$Companion;", "", "()V", "KEY_INITIALIZED", "", "unity-ads_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
    /* compiled from: AndroidStorageManager.kt */
    public static final class Companion {
        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        private Companion() {
        }
    }

    public boolean init(Context context) {
        Intrinsics.checkNotNullParameter(context, "context");
        return StorageManager.init(context);
    }

    public void initStorage(StorageType storageType) {
        Intrinsics.checkNotNullParameter(storageType, HandleInvocationsFromAdViewer.KEY_AD_TYPE);
        StorageManager.initStorage(storageType);
    }

    public Storage getStorage(StorageType storageType) {
        Intrinsics.checkNotNullParameter(storageType, HandleInvocationsFromAdViewer.KEY_AD_TYPE);
        Storage storage = StorageManager.getStorage(storageType);
        Intrinsics.checkNotNullExpressionValue(storage, "getStorage(type)");
        return storage;
    }

    public boolean hasStorage(StorageType storageType) {
        Intrinsics.checkNotNullParameter(storageType, HandleInvocationsFromAdViewer.KEY_AD_TYPE);
        return StorageManager.hasStorage(storageType);
    }

    public void addStorageLocation(StorageType storageType, String str) {
        Intrinsics.checkNotNullParameter(storageType, HandleInvocationsFromAdViewer.KEY_AD_TYPE);
        Intrinsics.checkNotNullParameter(str, "fileName");
        StorageManager.addStorageLocation(storageType, str);
    }

    public void removeStorage(StorageType storageType) {
        Intrinsics.checkNotNullParameter(storageType, HandleInvocationsFromAdViewer.KEY_AD_TYPE);
        StorageManager.removeStorage(storageType);
    }

    public void hasInitialized() {
        Storage storage = getStorage(StorageType.PRIVATE);
        storage.set(KEY_INITIALIZED, Boolean.valueOf(true));
        storage.writeStorage();
    }
}
