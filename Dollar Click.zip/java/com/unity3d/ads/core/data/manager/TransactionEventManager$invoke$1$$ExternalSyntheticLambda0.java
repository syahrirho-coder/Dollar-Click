package com.unity3d.ads.core.data.manager;

import com.unity3d.services.store.gpbl.bridges.BillingResultBridge;
import com.unity3d.services.store.gpbl.listeners.PurchasesResponseListener;
import java.util.List;

/* compiled from: D8$$SyntheticClass */
public final /* synthetic */ class TransactionEventManager$invoke$1$$ExternalSyntheticLambda0 implements PurchasesResponseListener {
    public final /* synthetic */ TransactionEventManager f$0;

    public /* synthetic */ TransactionEventManager$invoke$1$$ExternalSyntheticLambda0(TransactionEventManager transactionEventManager) {
        this.f$0 = transactionEventManager;
    }

    public final void onPurchaseResponse(BillingResultBridge billingResultBridge, List list) {
        TransactionEventManager$invoke$1.invokeSuspend$lambda$1(this.f$0, billingResultBridge, list);
    }
}
