package com.unity3d.ads.core.data.manager;

import com.unity3d.ads.core.data.model.exception.TransactionException;
import com.unity3d.services.store.gpbl.BillingResultResponseCode;
import com.unity3d.services.store.gpbl.bridges.BillingResultBridge;
import com.unity3d.services.store.gpbl.bridges.PurchaseBridge;
import com.unity3d.services.store.gpbl.listeners.BillingInitializationListener;
import java.util.List;
import kotlin.Metadata;
import kotlin.Result;
import kotlin.Result.Companion;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.jvm.internal.Intrinsics;
import kotlinx.coroutines.CancellableContinuation;

@Metadata(d1 = {"\u00001\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000*\u0001\u0000\b\n\u0018\u00002\u00020\u0001J\b\u0010\u0002\u001a\u00020\u0003H\u0016J\u0010\u0010\u0004\u001a\u00020\u00032\u0006\u0010\u0005\u001a\u00020\u0006H\u0016J\b\u0010\u0007\u001a\u00020\u0003H\u0016J \u0010\b\u001a\u00020\u00032\u0006\u0010\u0005\u001a\u00020\u00062\u000e\u0010\t\u001a\n\u0012\u0004\u0012\u00020\u000b\u0018\u00010\nH\u0016J\b\u0010\f\u001a\u00020\u0003H\u0002J\u0014\u0010\r\u001a\u00020\u00032\n\u0010\u000e\u001a\u00060\u000fj\u0002`\u0010H\u0002¨\u0006\u0011"}, d2 = {"com/unity3d/ads/core/data/manager/TransactionEventManager$invoke$1$1$1", "Lcom/unity3d/services/store/gpbl/listeners/BillingInitializationListener;", "onBillingServiceDisconnected", "", "onBillingSetupFinished", "billingResult", "Lcom/unity3d/services/store/gpbl/bridges/BillingResultBridge;", "onIsAlreadyInitialized", "onPurchaseUpdated", "purchases", "", "Lcom/unity3d/services/store/gpbl/bridges/PurchaseBridge;", "tryResume", "tryResumeWithException", "exception", "Ljava/lang/Exception;", "Lkotlin/Exception;", "unity-ads_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
/* compiled from: TransactionEventManager.kt */
public final class TransactionEventManager$invoke$1$1$1 implements BillingInitializationListener {
    final /* synthetic */ CancellableContinuation<Unit> $it;
    final /* synthetic */ TransactionEventManager this$0;

    TransactionEventManager$invoke$1$1$1(CancellableContinuation<? super Unit> cancellableContinuation, TransactionEventManager transactionEventManager) {
        this.$it = cancellableContinuation;
        this.this$0 = transactionEventManager;
    }

    private final void tryResume() {
        if (this.$it.isActive()) {
            Continuation continuation = this.$it;
            Companion companion = Result.Companion;
            continuation.resumeWith(Result.m17constructor-impl(Unit.INSTANCE));
        }
    }

    private final void tryResumeWithException(Exception exception) {
        if (this.$it.isActive()) {
            Continuation continuation = this.$it;
            Companion companion = Result.Companion;
            continuation.resumeWith(Result.m17constructor-impl(ResultKt.createFailure(exception)));
        }
    }

    public void onIsAlreadyInitialized() {
        tryResume();
    }

    public void onBillingSetupFinished(BillingResultBridge billingResultBridge) {
        Intrinsics.checkNotNullParameter(billingResultBridge, "billingResult");
        if (billingResultBridge.getResponseCode() != BillingResultResponseCode.OK) {
            tryResumeWithException(new TransactionException("Billing setup failed"));
        } else {
            tryResume();
        }
    }

    public void onBillingServiceDisconnected() {
        tryResumeWithException(new TransactionException("Billing service disconnected"));
    }

    public void onPurchaseUpdated(BillingResultBridge billingResultBridge, List<? extends PurchaseBridge> list) {
        Intrinsics.checkNotNullParameter(billingResultBridge, "billingResult");
        this.this$0.onPurchasesReceived(billingResultBridge, list);
    }
}
