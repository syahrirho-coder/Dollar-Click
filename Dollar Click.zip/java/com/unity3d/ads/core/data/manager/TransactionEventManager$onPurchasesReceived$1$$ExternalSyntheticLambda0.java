package com.unity3d.ads.core.data.manager;

import com.unity3d.services.store.gpbl.bridges.BillingResultBridge;
import com.unity3d.services.store.gpbl.bridges.PurchaseBridge;
import com.unity3d.services.store.gpbl.listeners.SkuDetailsResponseListener;
import java.util.List;

/* compiled from: D8$$SyntheticClass */
public final /* synthetic */ class TransactionEventManager$onPurchasesReceived$1$$ExternalSyntheticLambda0 implements SkuDetailsResponseListener {
    public final /* synthetic */ List f$0;
    public final /* synthetic */ int f$1;
    public final /* synthetic */ List f$2;
    public final /* synthetic */ TransactionEventManager f$3;
    public final /* synthetic */ PurchaseBridge f$4;

    public /* synthetic */ TransactionEventManager$onPurchasesReceived$1$$ExternalSyntheticLambda0(List list, int i, List list2, TransactionEventManager transactionEventManager, PurchaseBridge purchaseBridge) {
        this.f$0 = list;
        this.f$1 = i;
        this.f$2 = list2;
        this.f$3 = transactionEventManager;
        this.f$4 = purchaseBridge;
    }

    public final void onSkuDetailsUpdated(BillingResultBridge billingResultBridge, List list) {
        TransactionEventManager$onPurchasesReceived$1.invokeSuspend$lambda$3$lambda$2(this.f$0, this.f$1, this.f$2, this.f$3, this.f$4, billingResultBridge, list);
    }
}
