package com.unity3d.ads.core.data.manager;

import com.unity3d.services.store.gpbl.BillingResultResponseCode;
import com.unity3d.services.store.gpbl.bridges.BillingResultBridge;
import com.unity3d.services.store.gpbl.bridges.PurchaseBridge;
import com.unity3d.services.store.gpbl.bridges.SkuDetailsBridge;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function2;
import kotlinx.coroutines.CompletableDeferred;
import kotlinx.coroutines.CoroutineScope;

@Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H@"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {1, 8, 0}, xi = 48)
@DebugMetadata(c = "com.unity3d.ads.core.data.manager.TransactionEventManager$onPurchasesReceived$1", f = "TransactionEventManager.kt", i = {0, 0, 0, 0, 0, 0, 1}, l = {92, 109, 112}, m = "invokeSuspend", n = {"transactionDataList", "deferredPurchaseList", "purchase", "index$iv", "index", "purchaseTime", "transactionDataList"}, s = {"L$0", "L$1", "L$4", "I$0", "I$1", "J$0", "L$0"})
/* compiled from: TransactionEventManager.kt */
final class TransactionEventManager$onPurchasesReceived$1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
    final /* synthetic */ List<PurchaseBridge> $purchases;
    int I$0;
    int I$1;
    long J$0;
    Object L$0;
    Object L$1;
    Object L$2;
    Object L$3;
    Object L$4;
    int label;
    final /* synthetic */ TransactionEventManager this$0;

    TransactionEventManager$onPurchasesReceived$1(List<? extends PurchaseBridge> list, TransactionEventManager transactionEventManager, Continuation<? super TransactionEventManager$onPurchasesReceived$1> continuation) {
        this.$purchases = list;
        this.this$0 = transactionEventManager;
        super(2, continuation);
    }

    public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
        return new TransactionEventManager$onPurchasesReceived$1(this.$purchases, this.this$0, continuation);
    }

    public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
        return ((TransactionEventManager$onPurchasesReceived$1) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
    }

    /* DevToolsApp WARNING: Removed duplicated region for block: B:35:0x0172  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:18:0x009f  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:32:0x0168 A:{RETURN} */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:35:0x0172  */
    public final java.lang.Object invokeSuspend(java.lang.Object r25) {
        /*
        r24 = this;
        r0 = r24;
        r1 = kotlin.coroutines.intrinsics.IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED();
        r2 = r0.label;
        r3 = 0;
        r4 = 3;
        r5 = 2;
        r6 = 1;
        r7 = 0;
        if (r2 == 0) goto L_0x0056;
    L_0x000f:
        if (r2 == r6) goto L_0x002d;
    L_0x0011:
        if (r2 == r5) goto L_0x0024;
    L_0x0013:
        if (r2 != r4) goto L_0x001c;
    L_0x0015:
        kotlin.ResultKt.throwOnFailure(r25);
        r2 = r25;
        goto L_0x0188;
    L_0x001c:
        r1 = new java.lang.IllegalStateException;
        r2 = "call to 'resume' before 'invoke' with coroutine";
        r1.<init>(r2);
        throw r1;
    L_0x0024:
        r2 = r0.L$0;
        r2 = (java.util.List) r2;
        kotlin.ResultKt.throwOnFailure(r25);
        goto L_0x0169;
    L_0x002d:
        r8 = r0.J$0;
        r2 = r0.I$1;
        r10 = r0.I$0;
        r11 = r0.L$4;
        r11 = (com.unity3d.services.store.gpbl.bridges.PurchaseBridge) r11;
        r12 = r0.L$3;
        r12 = (java.util.Iterator) r12;
        r13 = r0.L$2;
        r13 = (com.unity3d.ads.core.data.manager.TransactionEventManager) r13;
        r14 = r0.L$1;
        r14 = (java.util.List) r14;
        r15 = r0.L$0;
        r15 = (java.util.List) r15;
        kotlin.ResultKt.throwOnFailure(r25);
        r21 = r11;
        r4 = r15;
        r22 = r8;
        r9 = r25;
    L_0x0051:
        r8 = r10;
        r10 = r22;
        goto L_0x00e7;
    L_0x0056:
        kotlin.ResultKt.throwOnFailure(r25);
        r2 = new java.util.ArrayList;
        r2.<init>();
        r2 = (java.util.List) r2;
        r8 = r0.$purchases;
        r8 = (java.lang.Iterable) r8;
        r9 = new java.util.ArrayList;
        r10 = 10;
        r10 = kotlin.collections.CollectionsKt__IterablesKt.collectionSizeOrDefault(r8, r10);
        r9.<init>(r10);
        r9 = (java.util.Collection) r9;
        r8 = r8.iterator();
    L_0x0075:
        r10 = r8.hasNext();
        if (r10 == 0) goto L_0x0089;
    L_0x007b:
        r10 = r8.next();
        r10 = (com.unity3d.services.store.gpbl.bridges.PurchaseBridge) r10;
        r10 = kotlinx.coroutines.CompletableDeferredKt.CompletableDeferred$default(r7, r6, r7);
        r9.add(r10);
        goto L_0x0075;
    L_0x0089:
        r9 = (java.util.List) r9;
        r8 = r0.$purchases;
        r8 = (java.lang.Iterable) r8;
        r10 = r0.this$0;
        r8 = r8.iterator();
        r12 = r8;
        r14 = r9;
        r13 = r10;
        r8 = r3;
    L_0x0099:
        r9 = r12.hasNext();
        if (r9 == 0) goto L_0x0140;
    L_0x009f:
        r9 = r12.next();
        r10 = r8 + 1;
        if (r8 >= 0) goto L_0x00aa;
    L_0x00a7:
        kotlin.collections.CollectionsKt__CollectionsKt.throwIndexOverflow();
    L_0x00aa:
        r11 = r9;
        r11 = (com.unity3d.services.store.gpbl.bridges.PurchaseBridge) r11;
        r9 = r11.getOriginalJson();
        r15 = "purchaseTime";
        r9 = r9.get(r15);
        r15 = "null cannot be cast to non-null type kotlin.Long";
        kotlin.jvm.internal.Intrinsics.checkNotNull(r9, r15);
        r9 = (java.lang.Long) r9;
        r4 = r9.longValue();
        r9 = r13.iapTransactionStore;
        r0.L$0 = r2;
        r0.L$1 = r14;
        r0.L$2 = r13;
        r0.L$3 = r12;
        r0.L$4 = r11;
        r0.I$0 = r10;
        r0.I$1 = r8;
        r0.J$0 = r4;
        r0.label = r6;
        r9 = r9.get(r0);
        if (r9 != r1) goto L_0x00df;
    L_0x00de:
        return r1;
    L_0x00df:
        r21 = r11;
        r22 = r4;
        r4 = r2;
        r2 = r8;
        goto L_0x0051;
    L_0x00e7:
        r9 = (com.unity3d.ads.datastore.ByteStringStoreOuterClass.ByteStringStore) r9;
        r5 = r9.getData();
        r5 = com.google.protobuf.Timestamp.parseFrom(r5);
        r6 = r5.getSeconds();
        r5 = (float) r6;
        r6 = (float) r10;
        r7 = 1148846080; // 0x447a0000 float:1000.0 double:5.676053805E-315;
        r6 = r6 / r7;
        r5 = (r5 > r6 ? 1 : (r5 == r6 ? 0 : -1));
        if (r5 >= 0) goto L_0x012e;
    L_0x00fe:
        r5 = r13.storeMonitor;
        r6 = r21.getOriginalJson();
        r7 = "productId";
        r6 = r6.get(r7);
        r7 = "null cannot be cast to non-null type kotlin.String";
        kotlin.jvm.internal.Intrinsics.checkNotNull(r6, r7);
        r6 = (java.lang.String) r6;
        r6 = kotlin.collections.CollectionsKt__CollectionsJVMKt.listOf(r6);
        r7 = new com.unity3d.ads.core.data.manager.TransactionEventManager$onPurchasesReceived$1$$ExternalSyntheticLambda0;
        r16 = r7;
        r17 = r14;
        r18 = r2;
        r19 = r4;
        r20 = r13;
        r16.<init>(r17, r18, r19, r20, r21);
        r2 = 42;
        r10 = "inapp";
        r5.getSkuDetails(r2, r10, r6, r7);
        goto L_0x0139;
    L_0x012e:
        r2 = r14.get(r2);
        r2 = (kotlinx.coroutines.CompletableDeferred) r2;
        r5 = kotlin.Unit.INSTANCE;
        r2.complete(r5);
    L_0x0139:
        r2 = r4;
        r4 = 3;
        r5 = 2;
        r6 = 1;
        r7 = 0;
        goto L_0x0099;
    L_0x0140:
        r14 = (java.util.Collection) r14;
        r3 = new kotlinx.coroutines.CompletableDeferred[r3];
        r3 = r14.toArray(r3);
        r3 = (kotlinx.coroutines.CompletableDeferred[]) r3;
        r4 = r3.length;
        r3 = java.util.Arrays.copyOf(r3, r4);
        r3 = (kotlinx.coroutines.Deferred[]) r3;
        r4 = r0;
        r4 = (kotlin.coroutines.Continuation) r4;
        r0.L$0 = r2;
        r5 = 0;
        r0.L$1 = r5;
        r0.L$2 = r5;
        r0.L$3 = r5;
        r0.L$4 = r5;
        r5 = 2;
        r0.label = r5;
        r3 = kotlinx.coroutines.AwaitKt.awaitAll(r3, r4);
        if (r3 != r1) goto L_0x0169;
    L_0x0168:
        return r1;
    L_0x0169:
        r3 = r2;
        r3 = (java.util.Collection) r3;
        r3 = r3.isEmpty();
        if (r3 != 0) goto L_0x0193;
    L_0x0172:
        r3 = r0.this$0;
        r3 = r3.getTransactionRequest;
        r4 = r0;
        r4 = (kotlin.coroutines.Continuation) r4;
        r5 = 0;
        r0.L$0 = r5;
        r5 = 3;
        r0.label = r5;
        r2 = r3.invoke(r2, r4);
        if (r2 != r1) goto L_0x0188;
    L_0x0187:
        return r1;
    L_0x0188:
        r2 = (gatewayprotocol.v1.TransactionEventRequestOuterClass.TransactionEventRequest) r2;
        r1 = r0.this$0;
        r1 = r1.transactionEventRepository;
        r1.addTransactionEvent(r2);
    L_0x0193:
        r1 = kotlin.Unit.INSTANCE;
        return r1;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.unity3d.ads.core.data.manager.TransactionEventManager$onPurchasesReceived$1.invokeSuspend(java.lang.Object):java.lang.Object");
    }

    private static final void invokeSuspend$lambda$3$lambda$2(List list, int i, List list2, TransactionEventManager transactionEventManager, PurchaseBridge purchaseBridge, BillingResultBridge billingResultBridge, List list3) {
        if (list3 == null || billingResultBridge.getResponseCode() != BillingResultResponseCode.OK) {
            ((CompletableDeferred) list.get(i)).complete(Unit.INSTANCE);
            return;
        }
        Iterable<SkuDetailsBridge> iterable = list3;
        Collection arrayList = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(iterable, 10));
        for (SkuDetailsBridge invoke : iterable) {
            arrayList.add(transactionEventManager.getTransactionData.invoke(purchaseBridge, invoke));
        }
        list2.addAll((List) arrayList);
        ((CompletableDeferred) list.get(i)).complete(Unit.INSTANCE);
    }
}
