package com.unity3d.ads.core.data.model;

import com.unity3d.services.core.properties.SdkProperties.InitializationState;
import kotlin.Metadata;
import kotlin.NoWhenBranchMatchedException;
import kotlin.jvm.internal.Intrinsics;

@Metadata(d1 = {"\u0000\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\u001a\n\u0010\u0000\u001a\u00020\u0001*\u00020\u0002\u001a\n\u0010\u0003\u001a\u00020\u0002*\u00020\u0001¨\u0006\u0004"}, d2 = {"toBold", "Lcom/unity3d/ads/core/data/model/InitializationState;", "Lcom/unity3d/services/core/properties/SdkProperties$InitializationState;", "toLegacy", "unity-ads_release"}, k = 2, mv = {1, 8, 0}, xi = 48)
/* compiled from: InitializationState.kt */
public final class InitializationStateKt {

    @Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
    /* compiled from: InitializationState.kt */
    public /* synthetic */ class WhenMappings {
        public static final /* synthetic */ int[] $EnumSwitchMapping$0;
        public static final /* synthetic */ int[] $EnumSwitchMapping$1;

        /* DevToolsApp WARNING: Failed to process nested try/catch */
        /* DevToolsApp WARNING: Missing block: B:20:?, code:
            r0[com.unity3d.services.core.properties.SdkProperties.InitializationState.INITIALIZED_FAILED.ordinal()] = 4;
     */
        static {
            /*
            r0 = com.unity3d.ads.core.data.model.InitializationState.values();
            r0 = r0.length;
            r0 = new int[r0];
            r1 = 1;
            r2 = com.unity3d.ads.core.data.model.InitializationState.NOT_INITIALIZED;	 Catch:{ NoSuchFieldError -> 0x0010 }
            r2 = r2.ordinal();	 Catch:{ NoSuchFieldError -> 0x0010 }
            r0[r2] = r1;	 Catch:{ NoSuchFieldError -> 0x0010 }
        L_0x0010:
            r2 = 2;
            r3 = com.unity3d.ads.core.data.model.InitializationState.INITIALIZING;	 Catch:{ NoSuchFieldError -> 0x0019 }
            r3 = r3.ordinal();	 Catch:{ NoSuchFieldError -> 0x0019 }
            r0[r3] = r2;	 Catch:{ NoSuchFieldError -> 0x0019 }
        L_0x0019:
            r3 = 3;
            r4 = com.unity3d.ads.core.data.model.InitializationState.INITIALIZED;	 Catch:{ NoSuchFieldError -> 0x0022 }
            r4 = r4.ordinal();	 Catch:{ NoSuchFieldError -> 0x0022 }
            r0[r4] = r3;	 Catch:{ NoSuchFieldError -> 0x0022 }
        L_0x0022:
            r4 = 4;
            r5 = com.unity3d.ads.core.data.model.InitializationState.FAILED;	 Catch:{ NoSuchFieldError -> 0x002b }
            r5 = r5.ordinal();	 Catch:{ NoSuchFieldError -> 0x002b }
            r0[r5] = r4;	 Catch:{ NoSuchFieldError -> 0x002b }
        L_0x002b:
            $EnumSwitchMapping$0 = r0;
            r0 = com.unity3d.services.core.properties.SdkProperties.InitializationState.values();
            r0 = r0.length;
            r0 = new int[r0];
            r5 = com.unity3d.services.core.properties.SdkProperties.InitializationState.NOT_INITIALIZED;	 Catch:{ NoSuchFieldError -> 0x003c }
            r5 = r5.ordinal();	 Catch:{ NoSuchFieldError -> 0x003c }
            r0[r5] = r1;	 Catch:{ NoSuchFieldError -> 0x003c }
        L_0x003c:
            r1 = com.unity3d.services.core.properties.SdkProperties.InitializationState.INITIALIZING;	 Catch:{ NoSuchFieldError -> 0x0044 }
            r1 = r1.ordinal();	 Catch:{ NoSuchFieldError -> 0x0044 }
            r0[r1] = r2;	 Catch:{ NoSuchFieldError -> 0x0044 }
        L_0x0044:
            r1 = com.unity3d.services.core.properties.SdkProperties.InitializationState.INITIALIZED_SUCCESSFULLY;	 Catch:{ NoSuchFieldError -> 0x004c }
            r1 = r1.ordinal();	 Catch:{ NoSuchFieldError -> 0x004c }
            r0[r1] = r3;	 Catch:{ NoSuchFieldError -> 0x004c }
        L_0x004c:
            r1 = com.unity3d.services.core.properties.SdkProperties.InitializationState.INITIALIZED_FAILED;	 Catch:{ NoSuchFieldError -> 0x0054 }
            r1 = r1.ordinal();	 Catch:{ NoSuchFieldError -> 0x0054 }
            r0[r1] = r4;	 Catch:{ NoSuchFieldError -> 0x0054 }
        L_0x0054:
            $EnumSwitchMapping$1 = r0;
            return;
            */
            throw new UnsupportedOperationException("Method not decompiled: com.unity3d.ads.core.data.model.InitializationStateKt.WhenMappings.<clinit>():void");
        }
    }

    public static final InitializationState toLegacy(InitializationState initializationState) {
        Intrinsics.checkNotNullParameter(initializationState, "<this>");
        int i = WhenMappings.$EnumSwitchMapping$0[initializationState.ordinal()];
        if (i == 1) {
            return InitializationState.NOT_INITIALIZED;
        }
        if (i == 2) {
            return InitializationState.INITIALIZING;
        }
        if (i == 3) {
            return InitializationState.INITIALIZED_SUCCESSFULLY;
        }
        if (i == 4) {
            return InitializationState.INITIALIZED_FAILED;
        }
        throw new NoWhenBranchMatchedException();
    }

    public static final InitializationState toBold(InitializationState initializationState) {
        Intrinsics.checkNotNullParameter(initializationState, "<this>");
        int i = WhenMappings.$EnumSwitchMapping$1[initializationState.ordinal()];
        if (i == 1) {
            return InitializationState.NOT_INITIALIZED;
        }
        if (i == 2) {
            return InitializationState.INITIALIZING;
        }
        if (i == 3) {
            return InitializationState.INITIALIZED;
        }
        if (i == 4) {
            return InitializationState.FAILED;
        }
        throw new NoWhenBranchMatchedException();
    }
}
