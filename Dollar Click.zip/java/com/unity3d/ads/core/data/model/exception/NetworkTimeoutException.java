package com.unity3d.ads.core.data.model.exception;

import com.unity3d.ads.core.data.model.OperationType;
import com.unity3d.ads.core.domain.HandleInvocationsFromAdViewer;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;

@Metadata(d1 = {"\u0000\u001e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0006\u0018\u00002\u00020\u0001BS\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0004\u001a\u00020\u0005\u0012\n\b\u0002\u0010\u0006\u001a\u0004\u0018\u00010\u0007\u0012\n\b\u0002\u0010\b\u001a\u0004\u0018\u00010\u0003\u0012\n\b\u0002\u0010\t\u001a\u0004\u0018\u00010\u0003\u0012\n\b\u0002\u0010\n\u001a\u0004\u0018\u00010\u0007\u0012\n\b\u0002\u0010\u000b\u001a\u0004\u0018\u00010\u0003¢\u0006\u0002\u0010\f¨\u0006\r"}, d2 = {"Lcom/unity3d/ads/core/data/model/exception/NetworkTimeoutException;", "Lcom/unity3d/ads/core/data/model/exception/UnityAdsNetworkException;", "message", "", "type", "Lcom/unity3d/ads/core/data/model/OperationType;", "code", "", "url", "protocol", "cronetCode", "client", "(Ljava/lang/String;Lcom/unity3d/ads/core/data/model/OperationType;Ljava/lang/Integer;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Integer;Ljava/lang/String;)V", "unity-ads_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
/* compiled from: NetworkTimeoutException.kt */
public final class NetworkTimeoutException extends UnityAdsNetworkException {
    public /* synthetic */ NetworkTimeoutException(String str, OperationType operationType, Integer num, String str2, String str3, Integer num2, String str4, int i, DefaultConstructorMarker defaultConstructorMarker) {
        OperationType operationType2 = (i & 2) != 0 ? OperationType.UNKNOWN : operationType;
        String str5 = null;
        Integer num3 = (i & 4) != 0 ? null : num;
        String str6 = (i & 8) != 0 ? null : str2;
        String str7 = (i & 16) != 0 ? null : str3;
        Integer num4 = (i & 32) != 0 ? null : num2;
        if ((i & 64) == 0) {
            str5 = str4;
        }
        this(str, operationType2, num3, str6, str7, num4, str5);
    }

    public NetworkTimeoutException(String str, OperationType operationType, Integer num, String str2, String str3, Integer num2, String str4) {
        Intrinsics.checkNotNullParameter(str, "message");
        Intrinsics.checkNotNullParameter(operationType, HandleInvocationsFromAdViewer.KEY_AD_TYPE);
        super(str, operationType, num, str2, str3, num2, str4);
    }
}
