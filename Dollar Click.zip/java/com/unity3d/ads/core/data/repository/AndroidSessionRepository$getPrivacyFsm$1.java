package com.unity3d.ads.core.data.repository;

import kotlin.Metadata;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.jvm.internal.ContinuationImpl;
import kotlin.coroutines.jvm.internal.DebugMetadata;

@Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
@DebugMetadata(c = "com.unity3d.ads.core.data.repository.AndroidSessionRepository", f = "AndroidSessionRepository.kt", i = {}, l = {217}, m = "getPrivacyFsm", n = {}, s = {})
/* compiled from: AndroidSessionRepository.kt */
final class AndroidSessionRepository$getPrivacyFsm$1 extends ContinuationImpl {
    int label;
    /* synthetic */ Object result;
    final /* synthetic */ AndroidSessionRepository this$0;

    AndroidSessionRepository$getPrivacyFsm$1(AndroidSessionRepository androidSessionRepository, Continuation<? super AndroidSessionRepository$getPrivacyFsm$1> continuation) {
        this.this$0 = androidSessionRepository;
        super(continuation);
    }

    public final Object invokeSuspend(Object obj) {
        this.result = obj;
        this.label |= Integer.MIN_VALUE;
        return this.this$0.getPrivacyFsm(this);
    }
}
