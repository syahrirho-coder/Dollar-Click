package com.unity3d.ads.core.extensions;

import com.unity3d.scar.adapter.common.scarads.UnityAdFormat;
import gatewayprotocol.v1.InitializationResponseOuterClass.AdFormat;
import kotlin.Metadata;
import kotlin.NoWhenBranchMatchedException;
import kotlin.jvm.internal.Intrinsics;

@Metadata(d1 = {"\u0000\u0012\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\u001a\n\u0010\u0000\u001a\u00020\u0001*\u00020\u0002\u001a\n\u0010\u0003\u001a\u00020\u0004*\u00020\u0002\u001a\f\u0010\u0003\u001a\u0004\u0018\u00010\u0004*\u00020\u0001¨\u0006\u0005"}, d2 = {"toProtoAdFormat", "Lgatewayprotocol/v1/InitializationResponseOuterClass$AdFormat;", "Lcom/unity3d/ads/AdFormat;", "toUnityAdFormat", "Lcom/unity3d/scar/adapter/common/scarads/UnityAdFormat;", "unity-ads_release"}, k = 2, mv = {1, 8, 0}, xi = 48)
/* compiled from: AdFormatExtensions.kt */
public final class AdFormatExtensions {

    @Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
    /* compiled from: AdFormatExtensions.kt */
    public /* synthetic */ class WhenMappings {
        public static final /* synthetic */ int[] $EnumSwitchMapping$0;
        public static final /* synthetic */ int[] $EnumSwitchMapping$1;

        /* DevToolsApp WARNING: Failed to process nested try/catch */
        /* DevToolsApp WARNING: Missing block: B:15:?, code:
            r0[com.unity3d.ads.AdFormat.REWARDED.ordinal()] = 3;
     */
        static {
            /*
            r0 = gatewayprotocol.v1.InitializationResponseOuterClass.AdFormat.values();
            r0 = r0.length;
            r0 = new int[r0];
            r1 = 1;
            r2 = gatewayprotocol.v1.InitializationResponseOuterClass.AdFormat.AD_FORMAT_REWARDED;	 Catch:{ NoSuchFieldError -> 0x0010 }
            r2 = r2.ordinal();	 Catch:{ NoSuchFieldError -> 0x0010 }
            r0[r2] = r1;	 Catch:{ NoSuchFieldError -> 0x0010 }
        L_0x0010:
            r2 = 2;
            r3 = gatewayprotocol.v1.InitializationResponseOuterClass.AdFormat.AD_FORMAT_INTERSTITIAL;	 Catch:{ NoSuchFieldError -> 0x0019 }
            r3 = r3.ordinal();	 Catch:{ NoSuchFieldError -> 0x0019 }
            r0[r3] = r2;	 Catch:{ NoSuchFieldError -> 0x0019 }
        L_0x0019:
            r3 = 3;
            r4 = gatewayprotocol.v1.InitializationResponseOuterClass.AdFormat.AD_FORMAT_BANNER;	 Catch:{ NoSuchFieldError -> 0x0022 }
            r4 = r4.ordinal();	 Catch:{ NoSuchFieldError -> 0x0022 }
            r0[r4] = r3;	 Catch:{ NoSuchFieldError -> 0x0022 }
        L_0x0022:
            $EnumSwitchMapping$0 = r0;
            r0 = com.unity3d.ads.AdFormat.values();
            r0 = r0.length;
            r0 = new int[r0];
            r4 = com.unity3d.ads.AdFormat.BANNER;	 Catch:{ NoSuchFieldError -> 0x0033 }
            r4 = r4.ordinal();	 Catch:{ NoSuchFieldError -> 0x0033 }
            r0[r4] = r1;	 Catch:{ NoSuchFieldError -> 0x0033 }
        L_0x0033:
            r1 = com.unity3d.ads.AdFormat.INTERSTITIAL;	 Catch:{ NoSuchFieldError -> 0x003b }
            r1 = r1.ordinal();	 Catch:{ NoSuchFieldError -> 0x003b }
            r0[r1] = r2;	 Catch:{ NoSuchFieldError -> 0x003b }
        L_0x003b:
            r1 = com.unity3d.ads.AdFormat.REWARDED;	 Catch:{ NoSuchFieldError -> 0x0043 }
            r1 = r1.ordinal();	 Catch:{ NoSuchFieldError -> 0x0043 }
            r0[r1] = r3;	 Catch:{ NoSuchFieldError -> 0x0043 }
        L_0x0043:
            $EnumSwitchMapping$1 = r0;
            return;
            */
            throw new UnsupportedOperationException("Method not decompiled: com.unity3d.ads.core.extensions.AdFormatExtensions.WhenMappings.<clinit>():void");
        }
    }

    public static final UnityAdFormat toUnityAdFormat(AdFormat adFormat) {
        Intrinsics.checkNotNullParameter(adFormat, "<this>");
        int i = WhenMappings.$EnumSwitchMapping$0[adFormat.ordinal()];
        if (i == 1) {
            return UnityAdFormat.REWARDED;
        }
        if (i == 2) {
            return UnityAdFormat.INTERSTITIAL;
        }
        if (i != 3) {
            return null;
        }
        return UnityAdFormat.BANNER;
    }

    public static final AdFormat toProtoAdFormat(com.unity3d.ads.AdFormat adFormat) {
        Intrinsics.checkNotNullParameter(adFormat, "<this>");
        int i = WhenMappings.$EnumSwitchMapping$1[adFormat.ordinal()];
        if (i == 1) {
            return AdFormat.AD_FORMAT_BANNER;
        }
        if (i == 2) {
            return AdFormat.AD_FORMAT_INTERSTITIAL;
        }
        if (i == 3) {
            return AdFormat.AD_FORMAT_REWARDED;
        }
        throw new NoWhenBranchMatchedException();
    }

    public static final UnityAdFormat toUnityAdFormat(com.unity3d.ads.AdFormat adFormat) {
        Intrinsics.checkNotNullParameter(adFormat, "<this>");
        int i = WhenMappings.$EnumSwitchMapping$1[adFormat.ordinal()];
        if (i == 1) {
            return UnityAdFormat.BANNER;
        }
        if (i == 2) {
            return UnityAdFormat.INTERSTITIAL;
        }
        if (i == 3) {
            return UnityAdFormat.REWARDED;
        }
        throw new NoWhenBranchMatchedException();
    }
}
