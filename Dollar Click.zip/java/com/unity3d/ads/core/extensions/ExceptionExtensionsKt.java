package com.unity3d.ads.core.extensions;

import kotlin.Metadata;

@Metadata(d1 = {"\u0000\u0014\n\u0000\n\u0002\u0010\u000e\n\u0002\u0010\u0003\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\u001a\u0014\u0010\u0000\u001a\u00020\u0001*\u00020\u00022\b\b\u0002\u0010\u0003\u001a\u00020\u0004\u001a\n\u0010\u0005\u001a\u00020\u0001*\u00020\u0002¨\u0006\u0006"}, d2 = {"getShortenedStackTrace", "", "", "maxLines", "", "retrieveUnityCrashValue", "unity-ads_release"}, k = 2, mv = {1, 8, 0}, xi = 48)
/* compiled from: ExceptionExtensions.kt */
public final class ExceptionExtensionsKt {
    /* DevToolsApp WARNING: Removed duplicated region for block: B:11:0x0039 A:{LOOP_END, LOOP:0: B:1:0x0013->B:11:0x0039} */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:22:0x0037 A:{SYNTHETIC} */
    public static final java.lang.String retrieveUnityCrashValue(java.lang.Throwable r8) {
        /*
        r0 = "<this>";
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r8, r0);
        r8 = r8.getStackTrace();
        r0 = "this.stackTrace";
        kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r8, r0);
        r8 = (java.lang.Object[]) r8;
        r0 = r8.length;
        r1 = 0;
        r2 = r1;
    L_0x0013:
        r3 = 0;
        if (r2 >= r0) goto L_0x003c;
    L_0x0016:
        r4 = r8[r2];
        r5 = r4;
        r5 = (java.lang.StackTraceElement) r5;
        if (r5 == 0) goto L_0x0034;
    L_0x001d:
        r5 = r5.getClassName();
        if (r5 == 0) goto L_0x0034;
    L_0x0023:
        r6 = "className";
        kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r5, r6);
        r5 = (java.lang.CharSequence) r5;
        r6 = "com.unity3d";
        r6 = (java.lang.CharSequence) r6;
        r7 = 2;
        r3 = kotlin.text.StringsKt__StringsKt.contains$default(r5, r6, r1, r7, r3);
        goto L_0x0035;
    L_0x0034:
        r3 = r1;
    L_0x0035:
        if (r3 == 0) goto L_0x0039;
    L_0x0037:
        r3 = r4;
        goto L_0x003c;
    L_0x0039:
        r2 = r2 + 1;
        goto L_0x0013;
    L_0x003c:
        r3 = (java.lang.StackTraceElement) r3;
        r8 = "unknown";
        if (r3 == 0) goto L_0x006d;
    L_0x0042:
        r0 = r3.getFileName();
        if (r0 != 0) goto L_0x004a;
    L_0x0048:
        r0 = r8;
        goto L_0x004f;
    L_0x004a:
        r1 = "it.fileName ?: SDKErrorHandler.UNKNOWN_FILE";
        kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r0, r1);
    L_0x004f:
        r1 = r3.getLineNumber();
        r2 = new java.lang.StringBuilder;
        r2.<init>();
        r0 = r2.append(r0);
        r2 = 95;
        r0 = r0.append(r2);
        r0 = r0.append(r1);
        r0 = r0.toString();
        if (r0 == 0) goto L_0x006d;
    L_0x006c:
        r8 = r0;
    L_0x006d:
        return r8;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.unity3d.ads.core.extensions.ExceptionExtensionsKt.retrieveUnityCrashValue(java.lang.Throwable):java.lang.String");
    }

    public static /* synthetic */ String getShortenedStackTrace$default(Throwable th, int i, int i2, Object obj) {
        if ((i2 & 1) != 0) {
            i = 15;
        }
        return getShortenedStackTrace(th, i);
    }

    /* DevToolsApp WARNING: Missing block: B:18:?, code:
            kotlin.io.CloseableKt.closeFinally(r2, r12);
     */
    /* DevToolsApp WARNING: Missing block: B:25:?, code:
            kotlin.io.CloseableKt.closeFinally(r0, r12);
     */
    public static final java.lang.String getShortenedStackTrace(java.lang.Throwable r12, int r13) {
        /*
        r0 = "<this>";
        kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r12, r0);
        r0 = new java.io.StringWriter;	 Catch:{ all -> 0x0063 }
        r0.<init>();	 Catch:{ all -> 0x0063 }
        r0 = (java.io.Closeable) r0;	 Catch:{ all -> 0x0063 }
        r1 = r0;
        r1 = (java.io.StringWriter) r1;	 Catch:{ all -> 0x005c }
        r2 = new java.io.PrintWriter;	 Catch:{ all -> 0x005c }
        r3 = r1;
        r3 = (java.io.Writer) r3;	 Catch:{ all -> 0x005c }
        r2.<init>(r3);	 Catch:{ all -> 0x005c }
        r2 = (java.io.Closeable) r2;	 Catch:{ all -> 0x005c }
        r3 = r2;
        r3 = (java.io.PrintWriter) r3;	 Catch:{ all -> 0x0055 }
        r12.printStackTrace(r3);	 Catch:{ all -> 0x0055 }
        r12 = r1.toString();	 Catch:{ all -> 0x0055 }
        r1 = "stringWriter.toString()";
        kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r12, r1);	 Catch:{ all -> 0x0055 }
        r12 = (java.lang.CharSequence) r12;	 Catch:{ all -> 0x0055 }
        r12 = kotlin.text.StringsKt__StringsKt.trim(r12);	 Catch:{ all -> 0x0055 }
        r12 = r12.toString();	 Catch:{ all -> 0x0055 }
        r12 = (java.lang.CharSequence) r12;	 Catch:{ all -> 0x0055 }
        r12 = kotlin.text.StringsKt__StringsKt.lineSequence(r12);	 Catch:{ all -> 0x0055 }
        r3 = kotlin.sequences.SequencesKt___SequencesKt.take(r12, r13);	 Catch:{ all -> 0x0055 }
        r12 = "\n";
        r4 = r12;
        r4 = (java.lang.CharSequence) r4;	 Catch:{ all -> 0x0055 }
        r10 = 62;
        r11 = 0;
        r5 = 0;
        r6 = 0;
        r7 = 0;
        r8 = 0;
        r9 = 0;
        r12 = kotlin.sequences.SequencesKt___SequencesKt.joinToString$default(r3, r4, r5, r6, r7, r8, r9, r10, r11);	 Catch:{ all -> 0x0055 }
        r13 = 0;
        kotlin.io.CloseableKt.closeFinally(r2, r13);	 Catch:{ all -> 0x005c }
        kotlin.io.CloseableKt.closeFinally(r0, r13);	 Catch:{ all -> 0x0063 }
        return r12;
    L_0x0055:
        r12 = move-exception;
        throw r12;	 Catch:{ all -> 0x0057 }
    L_0x0057:
        r13 = move-exception;
        kotlin.io.CloseableKt.closeFinally(r2, r12);	 Catch:{ all -> 0x005c }
        throw r13;	 Catch:{ all -> 0x005c }
    L_0x005c:
        r12 = move-exception;
        throw r12;	 Catch:{ all -> 0x005e }
    L_0x005e:
        r13 = move-exception;
        kotlin.io.CloseableKt.closeFinally(r0, r12);	 Catch:{ all -> 0x0063 }
        throw r13;	 Catch:{ all -> 0x0063 }
    L_0x0063:
        r12 = "";
        return r12;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.unity3d.ads.core.extensions.ExceptionExtensionsKt.getShortenedStackTrace(java.lang.Throwable, int):java.lang.String");
    }
}
