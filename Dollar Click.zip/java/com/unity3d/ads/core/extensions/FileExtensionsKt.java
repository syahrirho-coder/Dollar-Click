package com.unity3d.ads.core.extensions;

import java.io.File;
import java.util.LinkedList;
import java.util.List;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

@Metadata(d1 = {"\u0000\f\n\u0000\n\u0002\u0010\t\n\u0002\u0018\u0002\n\u0000\u001a\n\u0010\u0000\u001a\u00020\u0001*\u00020\u0002¨\u0006\u0003"}, d2 = {"getDirectorySize", "", "Ljava/io/File;", "unity-ads_release"}, k = 2, mv = {1, 8, 0}, xi = 48)
/* compiled from: FileExtensions.kt */
public final class FileExtensionsKt {
    public static final long getDirectorySize(File file) {
        Intrinsics.checkNotNullParameter(file, "<this>");
        long j = 0;
        if (!file.exists()) {
            return 0;
        }
        if (!file.isDirectory()) {
            return file.length();
        }
        List linkedList = new LinkedList();
        linkedList.add(file);
        while (!linkedList.isEmpty()) {
            int i = 0;
            File file2 = (File) linkedList.remove(0);
            if (file2.exists()) {
                File[] listFiles = file2.listFiles();
                if (listFiles != null) {
                    if (listFiles.length != 0) {
                        int length = listFiles.length;
                        while (i < length) {
                            File file3 = listFiles[i];
                            if (file3.isDirectory()) {
                                Intrinsics.checkNotNullExpressionValue(file3, "child");
                                linkedList.add(file3);
                            } else {
                                j += file3.length();
                            }
                            i++;
                        }
                    }
                }
            }
        }
        return j;
    }
}
