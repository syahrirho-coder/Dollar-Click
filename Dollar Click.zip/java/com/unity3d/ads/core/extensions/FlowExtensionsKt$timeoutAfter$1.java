package com.unity3d.ads.core.extensions;

import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function2;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.DelayKt;
import kotlinx.coroutines.channels.ProducerScope;
import kotlinx.coroutines.channels.SendChannel.DefaultImpls;
import kotlinx.coroutines.flow.Flow;
import kotlinx.coroutines.flow.FlowCollector;

@Metadata(d1 = {"\u0000\f\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001\"\u0004\b\u0000\u0010\u0002*\b\u0012\u0004\u0012\u0002H\u00020\u0003H@"}, d2 = {"<anonymous>", "", "T", "Lkotlinx/coroutines/channels/ProducerScope;"}, k = 3, mv = {1, 8, 0}, xi = 48)
@DebugMetadata(c = "com.unity3d.ads.core.extensions.FlowExtensionsKt$timeoutAfter$1", f = "FlowExtensions.kt", i = {0}, l = {15, 17}, m = "invokeSuspend", n = {"$this$channelFlow"}, s = {"L$0"})
/* compiled from: FlowExtensions.kt */
final class FlowExtensionsKt$timeoutAfter$1 extends SuspendLambda implements Function2<ProducerScope<? super T>, Continuation<? super Unit>, Object> {
    final /* synthetic */ boolean $active;
    final /* synthetic */ Function2<Function0<Unit>, Continuation<? super Unit>, Object> $block;
    final /* synthetic */ Flow<T> $this_timeoutAfter;
    final /* synthetic */ long $timeoutMillis;
    private /* synthetic */ Object L$0;
    int label;

    FlowExtensionsKt$timeoutAfter$1(long j, boolean z, Function2<? super Function0<Unit>, ? super Continuation<? super Unit>, ? extends Object> function2, Flow<? extends T> flow, Continuation<? super FlowExtensionsKt$timeoutAfter$1> continuation) {
        this.$timeoutMillis = j;
        this.$active = z;
        this.$block = function2;
        this.$this_timeoutAfter = flow;
        super(2, continuation);
    }

    public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
        FlowExtensionsKt$timeoutAfter$1 flowExtensionsKt$timeoutAfter$1 = new FlowExtensionsKt$timeoutAfter$1(this.$timeoutMillis, this.$active, this.$block, this.$this_timeoutAfter, continuation);
        flowExtensionsKt$timeoutAfter$1.L$0 = obj;
        return flowExtensionsKt$timeoutAfter$1;
    }

    public final Object invoke(ProducerScope<? super T> producerScope, Continuation<? super Unit> continuation) {
        return ((FlowExtensionsKt$timeoutAfter$1) create(producerScope, continuation)).invokeSuspend(Unit.INSTANCE);
    }

    public final Object invokeSuspend(Object obj) {
        final Object obj2;
        Object coroutine_suspended = IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED();
        int i = this.label;
        if (i == 0) {
            ResultKt.throwOnFailure(obj);
            obj2 = (ProducerScope) this.L$0;
            CoroutineScope coroutineScope = (CoroutineScope) obj2;
            final Flow flow = this.$this_timeoutAfter;
            BuildersKt__Builders_commonKt.launch$default(coroutineScope, null, null, new Function2<CoroutineScope, Continuation<? super Unit>, Object>(null) {
                int label;

                public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                    return /* anonymous class already generated */;
                }

                public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                    return ((AnonymousClass1) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
                }

                public final Object invokeSuspend(Object obj) {
                    Object coroutine_suspended = IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED();
                    int i = this.label;
                    if (i == 0) {
                        ResultKt.throwOnFailure(obj);
                        Flow flow = flow;
                        final ProducerScope producerScope = obj2;
                        FlowCollector anonymousClass1 = new FlowCollector() {
                            public final Object emit(T t, Continuation<? super Unit> continuation) {
                                Object send = producerScope.send(t, continuation);
                                return send == IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED() ? send : Unit.INSTANCE;
                            }
                        };
                        Continuation continuation = this;
                        this.label = 1;
                        if (flow.collect(anonymousClass1, continuation) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                    } else if (i == 1) {
                        ResultKt.throwOnFailure(obj);
                    } else {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    DefaultImpls.close$default(obj2, null, 1, null);
                    return Unit.INSTANCE;
                }
            }, 3, null);
            long j = this.$timeoutMillis;
            Continuation continuation = this;
            this.L$0 = obj2;
            this.label = 1;
            if (DelayKt.delay(j, continuation) == coroutine_suspended) {
                return coroutine_suspended;
            }
        } else if (i == 1) {
            obj2 = (ProducerScope) this.L$0;
            ResultKt.throwOnFailure(obj);
        } else if (i == 2) {
            ResultKt.throwOnFailure(obj);
            return Unit.INSTANCE;
        } else {
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }
        if (this.$active) {
            Function2 function2 = this.$block;
            AnonymousClass2 anonymousClass2 = new Function0<Unit>(obj2) {
                public final void invoke() {
                    DefaultImpls.close$default((ProducerScope) this.receiver, null, 1, null);
                }
            };
            this.L$0 = null;
            this.label = 2;
            if (function2.invoke(anonymousClass2, this) == coroutine_suspended) {
                return coroutine_suspended;
            }
        }
        return Unit.INSTANCE;
    }
}
