package com.unity3d.ads.core.extensions;

import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import kotlin.sequences.Sequence;
import org.json.JSONObject;

@Metadata(d1 = {"\u0000\u0014\n\u0000\n\u0002\u0010$\n\u0002\u0010\u000e\n\u0002\u0010\u0000\n\u0002\u0018\u0002\n\u0000\u001a\u0018\u0010\u0000\u001a\u0010\u0012\u0004\u0012\u00020\u0002\u0012\u0006\u0012\u0004\u0018\u00010\u00030\u0001*\u00020\u0004¨\u0006\u0005"}, d2 = {"toBuiltInMap", "", "", "", "Lorg/json/JSONObject;", "unity-ads_release"}, k = 2, mv = {1, 8, 0}, xi = 48)
/* compiled from: JSONObjectExtensions.kt */
public final class JSONObjectExtensionsKt {
    public static final Map<String, Object> toBuiltInMap(JSONObject jSONObject) {
        Intrinsics.checkNotNullParameter(jSONObject, "<this>");
        Iterator keys = jSONObject.keys();
        Intrinsics.checkNotNullExpressionValue(keys, "keys()");
        Sequence asSequence = SequencesKt__SequencesKt.asSequence(keys);
        LinkedHashMap linkedHashMap = new LinkedHashMap();
        for (Object next : asSequence) {
            Map map = linkedHashMap;
            Object opt = jSONObject.opt((String) next);
            if (opt != null) {
                Intrinsics.checkNotNullExpressionValue(opt, "opt(value)");
                if (!(Intrinsics.areEqual(String.valueOf(opt), (Object) "undefined") || Intrinsics.areEqual(String.valueOf(opt), (Object) "null"))) {
                    map.put(next, opt);
                }
            }
            opt = null;
            map.put(next, opt);
        }
        return linkedHashMap;
    }
}
