package com.unity3d.ads.core.extensions;

import com.unity3d.ads.UnityAds.UnityAdsShowCompletionState;
import com.unity3d.ads.adplayer.model.ShowStatus;
import gatewayprotocol.v1.NativeConfigurationOuterClass.ShowCompletionState;
import kotlin.Metadata;
import kotlin.NoWhenBranchMatchedException;
import kotlin.jvm.internal.Intrinsics;

@Metadata(d1 = {"\u0000\u0012\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\u001a\u0012\u0010\u0000\u001a\u00020\u0001*\u00020\u00022\u0006\u0010\u0003\u001a\u00020\u0004¨\u0006\u0005"}, d2 = {"toUnityAdsShowCompletionState", "Lcom/unity3d/ads/UnityAds$UnityAdsShowCompletionState;", "Lcom/unity3d/ads/adplayer/model/ShowStatus;", "defaultShowCompletionState", "Lgatewayprotocol/v1/NativeConfigurationOuterClass$ShowCompletionState;", "unity-ads_release"}, k = 2, mv = {1, 8, 0}, xi = 48)
/* compiled from: ShowStatusExtensions.kt */
public final class ShowStatusExtensionsKt {

    @Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
    /* compiled from: ShowStatusExtensions.kt */
    public /* synthetic */ class WhenMappings {
        public static final /* synthetic */ int[] $EnumSwitchMapping$0;
        public static final /* synthetic */ int[] $EnumSwitchMapping$1;

        /* DevToolsApp WARNING: Failed to process nested try/catch */
        /* DevToolsApp WARNING: Missing block: B:12:?, code:
            r0[com.unity3d.ads.adplayer.model.ShowStatus.ERROR.ordinal()] = 3;
     */
        static {
            /*
            r0 = gatewayprotocol.v1.NativeConfigurationOuterClass.ShowCompletionState.values();
            r0 = r0.length;
            r0 = new int[r0];
            r1 = 1;
            r2 = gatewayprotocol.v1.NativeConfigurationOuterClass.ShowCompletionState.SHOW_COMPLETION_STATE_COMPLETED;	 Catch:{ NoSuchFieldError -> 0x0010 }
            r2 = r2.ordinal();	 Catch:{ NoSuchFieldError -> 0x0010 }
            r0[r2] = r1;	 Catch:{ NoSuchFieldError -> 0x0010 }
        L_0x0010:
            r2 = 2;
            r3 = gatewayprotocol.v1.NativeConfigurationOuterClass.ShowCompletionState.SHOW_COMPLETION_STATE_SKIPPED;	 Catch:{ NoSuchFieldError -> 0x0019 }
            r3 = r3.ordinal();	 Catch:{ NoSuchFieldError -> 0x0019 }
            r0[r3] = r2;	 Catch:{ NoSuchFieldError -> 0x0019 }
        L_0x0019:
            $EnumSwitchMapping$0 = r0;
            r0 = com.unity3d.ads.adplayer.model.ShowStatus.values();
            r0 = r0.length;
            r0 = new int[r0];
            r3 = com.unity3d.ads.adplayer.model.ShowStatus.COMPLETED;	 Catch:{ NoSuchFieldError -> 0x002a }
            r3 = r3.ordinal();	 Catch:{ NoSuchFieldError -> 0x002a }
            r0[r3] = r1;	 Catch:{ NoSuchFieldError -> 0x002a }
        L_0x002a:
            r1 = com.unity3d.ads.adplayer.model.ShowStatus.SKIPPED;	 Catch:{ NoSuchFieldError -> 0x0032 }
            r1 = r1.ordinal();	 Catch:{ NoSuchFieldError -> 0x0032 }
            r0[r1] = r2;	 Catch:{ NoSuchFieldError -> 0x0032 }
        L_0x0032:
            r1 = com.unity3d.ads.adplayer.model.ShowStatus.ERROR;	 Catch:{ NoSuchFieldError -> 0x003b }
            r1 = r1.ordinal();	 Catch:{ NoSuchFieldError -> 0x003b }
            r2 = 3;
            r0[r1] = r2;	 Catch:{ NoSuchFieldError -> 0x003b }
        L_0x003b:
            $EnumSwitchMapping$1 = r0;
            return;
            */
            throw new UnsupportedOperationException("Method not decompiled: com.unity3d.ads.core.extensions.ShowStatusExtensionsKt.WhenMappings.<clinit>():void");
        }
    }

    public static final UnityAdsShowCompletionState toUnityAdsShowCompletionState(ShowStatus showStatus, ShowCompletionState showCompletionState) {
        Intrinsics.checkNotNullParameter(showStatus, "<this>");
        Intrinsics.checkNotNullParameter(showCompletionState, "defaultShowCompletionState");
        int i = WhenMappings.$EnumSwitchMapping$1[showStatus.ordinal()];
        if (i == 1) {
            return UnityAdsShowCompletionState.COMPLETED;
        }
        if (i == 2) {
            return UnityAdsShowCompletionState.SKIPPED;
        }
        if (i == 3) {
            i = WhenMappings.$EnumSwitchMapping$0[showCompletionState.ordinal()];
            if (i == 1) {
                return UnityAdsShowCompletionState.COMPLETED;
            }
            if (i != 2) {
                return UnityAdsShowCompletionState.COMPLETED;
            }
            return UnityAdsShowCompletionState.SKIPPED;
        }
        throw new NoWhenBranchMatchedException();
    }
}
